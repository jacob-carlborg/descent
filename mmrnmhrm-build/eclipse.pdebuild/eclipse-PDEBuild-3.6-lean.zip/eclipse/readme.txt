What is this ?

PDEBuild-lean is an eclipse package created out of Eclipse SDK 3.6, consisting only of the plugins required to run headless PDE-Build.
It was was created using the included pdebuild-lean.product, for the win32 platform, but with the delta plugins for other platform added as well (from the delta pack), so it should run on any supported platform, provided you run the launcher jar, not the eclipse executable.

See also:
http://stackoverflow.com/questions/2347535/eclipse-what-is-the-minimum-eclipse-installation-needed-for-a-headless-pde-build