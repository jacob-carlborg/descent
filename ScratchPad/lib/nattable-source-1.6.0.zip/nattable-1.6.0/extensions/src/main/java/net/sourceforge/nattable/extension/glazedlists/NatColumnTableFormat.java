package net.sourceforge.nattable.extension.glazedlists;

import java.util.Comparator;

import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.DefaultComparator;
import ca.odell.glazedlists.gui.AdvancedTableFormat;

public class NatColumnTableFormat<R> implements AdvancedTableFormat<R> {

	private String[] columnNames;
	
	private IColumnAccessor<R> columnAccessor;
	
	private ContentConfigRegistry contentConfigRegistry;
	
	public NatColumnTableFormat(String[] columnNames, IColumnAccessor<R> columnAccessor, ContentConfigRegistry contentConfigRegistry) {
		this.columnNames = columnNames;
		this.columnAccessor = columnAccessor;
		this.contentConfigRegistry = contentConfigRegistry;
	}

	public Class<?> getColumnClass(int col) {
		return null;
	}

	public Comparator<?> getColumnComparator(final int col) {
		if (contentConfigRegistry != null) {
			return contentConfigRegistry.getComparator(col);
		}
		return DefaultComparator.getInstance();
	}

	public int getColumnCount() {
		return columnNames.length;
	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getColumnValue(R rowObj, int col) {
		return columnAccessor.getColumnValue(rowObj, col);
	}

}
