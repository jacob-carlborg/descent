package net.sourceforge.nattable.extension.dialog;

import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.editor.IEditController;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.support.BulkUpdateResponse;
import net.sourceforge.nattable.support.BulkUpdateTypeEnum;
import net.sourceforge.nattable.support.IBulkUpdateRequestHandler;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class BulkUpdateDialog implements IBulkUpdateRequestHandler {

	private final Shell table;

	public BulkUpdateDialog(Shell table) {
		this.table = table;
	}
	
	public BulkUpdateResponse bulkUpdate(String fieldName,
			ICellRenderer bodyCellRenderer, int row, int column) {
		AbstractDialog dialog = createDialog(table, fieldName, bodyCellRenderer, row, column);
		
		dialog.setBlockOnOpen(true);
		int returnValue = dialog.open();
		
		if (returnValue == Dialog.OK) {
			Object value = dialog.getValue();
			BulkUpdateTypeEnum type = dialog.getBulkUpdateType();
			
			BulkUpdateResponse response = new BulkUpdateResponse(value, type);
			return response;
		}
		
		return null;
	}

	protected AbstractDialog createDialog(Shell table, String fieldName,
			ICellRenderer bodyCellRenderer, int row, int column) {
		return new DialogImpl(table, fieldName, bodyCellRenderer, row, column);
	}
	
	protected static abstract class AbstractDialog extends Dialog {

		protected AbstractDialog(Shell parentShell) {
			super(parentShell);
		}
		
		public BulkUpdateTypeEnum getBulkUpdateType() {
			return BulkUpdateTypeEnum.SET;
		}
		
		public abstract Object getValue();
	}
	
	static class DialogImpl extends AbstractDialog {

		private static final Rectangle ZERO_RECTANGLE = new Rectangle(0, 0, 0, 0);
		private static final String SET = "Set";
		private static final String INCREASE_BY = "Increase by";
		private static final String DECREASE_BY = "Decrease by";
		private static final String [] OPTIONS = {SET, INCREASE_BY, DECREASE_BY};
		
		private final String fieldName;
		private final ICellEditor natCellEditor;
		private final boolean isNumber;
		
		private Combo updateCombo;
		private Object editorValue = null;
		private int lastSelectedIndex = 0;
		
		public DialogImpl(Shell shell, String fieldName,
				ICellRenderer bodyCellRenderer, int row, int column) {
			super(shell);
			
			setShellStyle(SWT.RESIZE | SWT.APPLICATION_MODAL | SWT.DIALOG_TRIM);
			
			this.fieldName = fieldName;
			
			natCellEditor = bodyCellRenderer.getCellEditor(row, column);
			
			boolean isNumber = false;
			Object value = bodyCellRenderer.getValue(row, column);
			
			if (value != null) {
				
				if (value instanceof Number) {
					isNumber = true;
				}
				else {
					String valueStr = ObjectUtils.toString(value);
					isNumber = NumberUtils.isNumber(valueStr.trim());
				}
			}
			
			this.isNumber = isNumber;
		}

		@Override
		protected Control createDialogArea(Composite parent) {
			Composite composite = (Composite) super.createDialogArea(parent);
			GridDataFactory.fillDefaults().grab(true, true).applyTo(composite);
			
			GridLayout layout = (GridLayout) composite.getLayout();

			layout.numColumns = isNumber ? 3 : 2;
			
			Label fieldLabel = new Label(composite, SWT.NONE);
			fieldLabel.setText(fieldName + ":");
			fieldLabel.setFont(getLabelFont());
			GridDataFactory.swtDefaults().applyTo(fieldLabel);
			
			if (isNumber) {
				updateCombo = new Combo(composite, SWT.READ_ONLY | SWT.DROP_DOWN | SWT.BORDER);
				
				for (String option : OPTIONS) {
					updateCombo.add(option);
				}
				
				updateCombo.select(0);
				
				updateCombo.addDisposeListener(new DisposeListener() {

					public void widgetDisposed(DisposeEvent arg0) {
						lastSelectedIndex = updateCombo.getSelectionIndex();
						updateCombo.removeDisposeListener(this);
					}
					
				});
				
				GridDataFactory.swtDefaults().applyTo(updateCombo);
			}
			
			IEditController editController = new IEditController() {

				public boolean validate(Object oldValue, Object newValue) {
					return true;
				}
				
				public void commit(Object newValue) {
					editorValue = newValue;
				}
				
			};
			final Control editorControl = natCellEditor.activateCell(editController, composite, ZERO_RECTANGLE, null);
			
			GridDataFactory.fillDefaults().grab(true, false).minSize(100, 0).applyTo(editorControl);
			
			Label separator = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
			GridDataFactory.fillDefaults().grab(true, false).span(layout.numColumns, 1).applyTo(separator);
			
			getShell().setText("Bulk Update [" + fieldName + "]");
			
			editorControl.setFocus();
			
			return composite;
		}
		
		@Override
		public Object getValue() {
			return editorValue;
		}

		@Override
		public BulkUpdateTypeEnum getBulkUpdateType() {
			if (isNumber && updateCombo != null) {
				
				int selectionIndex = updateCombo.isDisposed() ? lastSelectedIndex : updateCombo.getSelectionIndex();
				
				switch (selectionIndex) {
				case 0:
					return BulkUpdateTypeEnum.SET;
				case 1:
					return BulkUpdateTypeEnum.INCREASE;
				case 2:
					return BulkUpdateTypeEnum.DECREASE;
				default:
					// fall through
				}
			}
			
			return super.getBulkUpdateType();
		}
		
		private Font getLabelFont() {
			Font font = JFaceResources.getHeaderFont();
			return font;
		}

	}
	
}
