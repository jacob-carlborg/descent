package net.sourceforge.nattable.extension.blink;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FieldChangeSupport {
	
	private final List<FieldChangeListener> listeners;
	private final Map<String, LastMovement> lastMovements;
	
	public FieldChangeSupport() {
		listeners = new ArrayList<FieldChangeListener>();
		lastMovements = new HashMap<String, LastMovement>();
	}
	
	public void addFieldChangeListener(FieldChangeListener listener) {
		listeners.add(listener);
	}

	public void removeFieldChangeListener(FieldChangeListener listener) {
		listeners.remove(listener);
	}
	
	public void notifyFieldChange(Object source, String field, double newValue) {
		final long timeStamp = System.currentTimeMillis();
		LastMovement movement = lastMovements.get(field);
		if (movement == null) {
			movement = new LastMovement(newValue, timeStamp);
			lastMovements.put(field, movement);
		} else {
			movement.update(newValue, timeStamp);
		}
		
		FieldChangeEvent event = new FieldChangeEvent(source, field, movement.direction, movement.updateTime);
		for (FieldChangeListener listener: listeners) {
			listener.fieldChanged(event);
		}
	}
	
	private class LastMovement
	{
		public double previousValue;
		public long updateTime;
		public MovementDirection direction; 

		public LastMovement(double value, long timeStamp)
		{
			previousValue = value;
			updateTime = timeStamp;
			direction = MovementDirection.NONE;
		}

		public void update(double value, long timeStamp)
		{
			if(value==previousValue)
			{
				return;
			}
			
			updateTime = timeStamp;
			direction = (value > previousValue) ? MovementDirection.UP : MovementDirection.DOWN;
			previousValue = value;
		}
	}
	
}
