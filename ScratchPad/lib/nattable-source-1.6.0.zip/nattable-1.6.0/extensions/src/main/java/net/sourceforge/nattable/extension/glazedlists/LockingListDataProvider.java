package net.sourceforge.nattable.extension.glazedlists;

import net.sourceforge.nattable.data.IRowDataProvider;
import ca.odell.glazedlists.util.concurrent.Lock;

public class LockingListDataProvider<T> implements IRowDataProvider<T>
{
	private final IRowDataProvider<T> dataProvider;
	private final Lock readLock;

	public LockingListDataProvider(IRowDataProvider<T> dataProvider, Lock readLock) {
		
		assert(dataProvider != null);
		assert(readLock != null);
		
		this.dataProvider = dataProvider;
		this.readLock = readLock;
	}

	public T getRowObject(int row)
	{
		readLock.lock();
		try {
			return dataProvider.getRowObject(row);
		} finally {
			readLock.unlock();
		}
	}

	public int getColumnCount()
	{
//		readLock.lock();
//		try {
			return dataProvider.getColumnCount();
//		} finally {
//			readLock.unlock();
//		}
	}

	public int getRowCount()
	{
		readLock.lock();
		try {
			return dataProvider.getRowCount();
		} finally {
			readLock.unlock();
		}
	}

	public Object getValue(int row, int col)
	{
		readLock.lock();
		try {
			return dataProvider.getValue(row, col);
		} finally {
			readLock.unlock();
		}
	}

}
