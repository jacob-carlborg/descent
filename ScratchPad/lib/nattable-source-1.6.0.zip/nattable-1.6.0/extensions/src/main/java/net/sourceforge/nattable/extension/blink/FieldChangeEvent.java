package net.sourceforge.nattable.extension.blink;

import java.util.EventObject;

public class FieldChangeEvent extends EventObject {
	private static final long serialVersionUID = 1L;
	public final long timeOfChange;
	public final MovementDirection movementDirection;
	public final String field;
	
	public FieldChangeEvent(Object source, String field, MovementDirection movement, long timeStamp) {
		super(source);
		
		this.field = field;
		this.movementDirection = movement;
		this.timeOfChange = timeStamp;
	}
	
	public String toString() {
		return new StringBuilder("FieldChangeEvent[").append(field).append(",").append(movementDirection).append(",").append(source).append(",").append(timeOfChange).append("]").toString();
	}
}
