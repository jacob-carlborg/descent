package net.sourceforge.nattable.extension.handler;

import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.support.BulkUpdateResponse;
import net.sourceforge.nattable.support.BulkUpdateTypeEnum;
import net.sourceforge.nattable.support.IBulkUpdateRequestHandler;

public class TickBulkUpdateRequestHandler implements IBulkUpdateRequestHandler {

	private boolean isTickUp;
	private Number delta = Double.valueOf(0);

	public void prepareUpdate(boolean isTickUp, Number delta) {
		this.isTickUp = isTickUp;
		this.delta = delta;
	}

	public BulkUpdateResponse bulkUpdate(String fieldName,
			ICellRenderer bodyCellRenderer, int row, int column) {
		BulkUpdateResponse response = new BulkUpdateResponse(delta,
				isTickUp ? BulkUpdateTypeEnum.INCREASE
						: BulkUpdateTypeEnum.DECREASE);
		return response;
	}

}
