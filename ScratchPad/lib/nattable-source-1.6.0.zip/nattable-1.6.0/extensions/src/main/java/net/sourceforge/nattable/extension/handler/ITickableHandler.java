package net.sourceforge.nattable.extension.handler;

import net.sourceforge.nattable.support.IBulkUpdateResponseHandler;

import org.eclipse.swt.events.KeyEvent;

public interface ITickableHandler extends IBulkUpdateResponseHandler {

	boolean isTickUpEvent(KeyEvent event);
	
	boolean isTickDownEvent(KeyEvent event);
	
	boolean isQuickEditEvent(KeyEvent event);
	
}
