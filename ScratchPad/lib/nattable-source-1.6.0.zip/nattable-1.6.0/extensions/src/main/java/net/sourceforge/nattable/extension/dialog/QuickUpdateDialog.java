package net.sourceforge.nattable.extension.dialog;

import net.sourceforge.nattable.editor.EditorSelectionEnum;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.editor.IEditController;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.support.BulkUpdateTypeEnum;

import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class QuickUpdateDialog extends BulkUpdateDialog {

	private static final Rectangle ZERO_RECTANGLE = new Rectangle(0, 0, 0, 0);
	
	private KeyEvent triggeringEvent;

	public QuickUpdateDialog(Shell shell) {
		super(shell);
	}

	public void setTriggeringEvent(KeyEvent triggeringEvent) {
		this.triggeringEvent = triggeringEvent;
	}
	
	@Override
	protected AbstractDialog createDialog(Shell shell, String fieldName,
			ICellRenderer bodyCellRenderer, int row, int column) {
		return new DialogImpl(shell, fieldName, bodyCellRenderer, row, column);
	}
	
	class DialogImpl extends AbstractDialog {

		private final String fieldName;
		private final ICellEditor natCellEditor;
		private final PlusMinusKeyListener plusMinusKeyListener = new PlusMinusKeyListener();
		
		private BulkUpdateTypeEnum updateType = BulkUpdateTypeEnum.SET;
		
		private Object editorValue = null;
		
		public DialogImpl(Shell shell, String fieldName,
				ICellRenderer bodyCellRenderer, int row, int column) {
			super(shell);
			
			setShellStyle(SWT.RESIZE | SWT.APPLICATION_MODAL | SWT.DIALOG_TRIM);
			
			this.fieldName = fieldName;
			
			natCellEditor = bodyCellRenderer.getCellEditor(row, column);
		}

		@Override
		protected void okPressed() {
			natCellEditor.commit();
			super.okPressed();
		}
		
		@Override
		protected Control createDialogArea(Composite parent) {
			Composite composite = (Composite) super.createDialogArea(parent);
			GridDataFactory.fillDefaults().grab(true, true).applyTo(composite);
			
			GridLayout layout = (GridLayout) composite.getLayout();

			layout.numColumns = 2;
			
			Label fieldLabel = new Label(composite, SWT.NONE);
			fieldLabel.setText(fieldName + ":");
			
			fieldLabel.setFont(getLabelFont());
			
			GridDataFactory.swtDefaults().applyTo(fieldLabel);

			Object oldValue = null;
			
			if (triggeringEvent != null) {
				oldValue = Character.toString(triggeringEvent.character);
				triggeringEvent = null;
			}

			final EditorSelectionEnum oldSelectionMode = natCellEditor.getSelectionMode();
			natCellEditor.setSelectionMode(EditorSelectionEnum.END);
			
			IEditController editController = new IEditController() {

				public boolean validate(Object oldValue, Object newValue) {
					return true;
				}

				public void commit(Object newValue) {
					natCellEditor.setSelectionMode(oldSelectionMode);
					editorValue = newValue;
//					editorControl.removeKeyListener(plusMinusKeyListener);
				}
				
			};
			final Control editorControl = natCellEditor.activateCell(editController, composite, ZERO_RECTANGLE, oldValue);
			
			GridDataFactory.fillDefaults().grab(true, false).minSize(100, 0).applyTo(editorControl);
			
			insertSeperator(composite, layout);
			
			createHelpLabel(composite, "[Enter]", "set value");
			createHelpLabel(composite, "[  +  ]", "increase by");
			createHelpLabel(composite, "[  -  ]", "decrease by");
			
			insertSeperator(composite, layout);
			
			getShell().setText("Quick Update [" + fieldName + "]");
			
			editorControl.setFocus();
			
			editorControl.addKeyListener(plusMinusKeyListener);
			
			return composite;
		}

		private void insertSeperator(Composite composite, GridLayout layout) {
			Label separator = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
			GridDataFactory.fillDefaults().grab(true, false).span(layout.numColumns, 1).applyTo(separator);
		}
		
		private void createHelpLabel(Composite parent, String key, String details) {
			Label label = new Label(parent, SWT.NONE);
			label.setText(key + " " + details);
			
			label.setFont(getFixedWidthFont());
			
			GridDataFactory.fillDefaults().grab(true, false).span(2, 1).applyTo(label);
		}

		private Font getLabelFont() {
			Font font = JFaceResources.getHeaderFont();
			return font;
		}
		
		private Font getFixedWidthFont() {
			Font font = JFaceResources.getTextFont();
			return font;
		}

		@Override
		public Object getValue() {
			return editorValue;
		}

		@Override
		public BulkUpdateTypeEnum getBulkUpdateType() {
			return updateType;
		}
		
		class PlusMinusKeyListener extends KeyAdapter {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.character == '+') {
					updateType = BulkUpdateTypeEnum.INCREASE;
					okPressed();
				}
				else if (e.character == '-') {
					updateType = BulkUpdateTypeEnum.DECREASE;
					okPressed();
				}
			}
		}
	}

}
