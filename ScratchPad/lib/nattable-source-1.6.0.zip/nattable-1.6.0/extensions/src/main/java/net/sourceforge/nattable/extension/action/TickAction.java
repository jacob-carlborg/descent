package net.sourceforge.nattable.extension.action;

import net.sourceforge.nattable.action.IKeyEventAction;
import net.sourceforge.nattable.extension.dialog.QuickUpdateDialog;
import net.sourceforge.nattable.extension.event.TickEventEnum;
import net.sourceforge.nattable.extension.handler.ITickableHandler;
import net.sourceforge.nattable.extension.handler.TickBulkUpdateRequestHandler;
import net.sourceforge.nattable.support.BulkCellUpdateSupport;
import net.sourceforge.nattable.support.IBulkUpdateRequestHandler;

import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.widgets.Shell;

public class TickAction implements IKeyEventAction {

	private final ITickableHandler handler;
	
	private final BulkCellUpdateSupport<?> updateSupport;
	
	private final QuickUpdateDialog quickUpdateDialog;
	
	private final TickBulkUpdateRequestHandler tickRequestHandler;

	public TickAction(Shell shell, BulkCellUpdateSupport<?> updateSupport, ITickableHandler handler) {
		this.updateSupport = updateSupport;
		this.handler = handler;
		
		quickUpdateDialog = new QuickUpdateDialog(shell);
		tickRequestHandler = new TickBulkUpdateRequestHandler();
	}
	
	public void run(KeyEvent event) {
		TickEventEnum tickEvent = getTickEvent(event, handler);
		
		IBulkUpdateRequestHandler requestHandler;
		
		if (tickEvent != TickEventEnum.QUICK) {
			tickRequestHandler.prepareUpdate(tickEvent == TickEventEnum.UP, Double.valueOf(1.0));
			requestHandler = tickRequestHandler;
		} else {
			quickUpdateDialog.setTriggeringEvent(event);
			requestHandler = quickUpdateDialog;
		}
		
		updateSupport.bulkUpdateSelection(requestHandler, handler);
	}
	
	public static TickEventEnum getTickEvent(KeyEvent event, ITickableHandler handler) {
		TickEventEnum tickEvent = TickEventEnum.NONE;
		
		if (handler.isTickUpEvent(event)) {
			tickEvent = TickEventEnum.UP;
		} else if (handler.isTickDownEvent(event)) {
			tickEvent = TickEventEnum.DOWN;
		} else if (handler.isQuickEditEvent(event)) {
			tickEvent = TickEventEnum.QUICK;
		}
		
		return tickEvent;
	}

}
