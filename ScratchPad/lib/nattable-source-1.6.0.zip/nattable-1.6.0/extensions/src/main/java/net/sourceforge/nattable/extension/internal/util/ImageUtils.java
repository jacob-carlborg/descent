package net.sourceforge.nattable.extension.internal.util;

import java.net.URL;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.graphics.Image;

public class ImageUtils {

	private static final String[] EXTENSIONS = new String[] { ".png", ".gif" };

	public static synchronized Image getImage(String imageName) {
		Image image = JFaceResources.getImage(imageName);

		if (image == null) {
			ImageDescriptor descriptor = getImageDescriptor(imageName);
			ImageRegistry registry = JFaceResources.getImageRegistry();
			registry.put(imageName, descriptor);
			image = JFaceResources.getImage(imageName);
		}

		return image;
	}

	public static ImageDescriptor getImageDescriptor(String imageName) {
		ImageRegistry registry = JFaceResources.getImageRegistry();
		ImageDescriptor descriptor = registry.getDescriptor(imageName);
		if (descriptor == null) {
			descriptor = ImageDescriptor.createFromURL(getImageURL(imageName));
			if (descriptor != null) {
				registry.put(imageName, descriptor);
				return descriptor;
			}
		}
		return descriptor;
	}

	private static URL getImageURL(String imageName) {
		URL url = null;
		for (String ext : EXTENSIONS) {
			url = ImageUtils.class.getClassLoader().getResource(imageName + ext);
			if (url != null)
				return url;
		}
		return url;
	}
}
