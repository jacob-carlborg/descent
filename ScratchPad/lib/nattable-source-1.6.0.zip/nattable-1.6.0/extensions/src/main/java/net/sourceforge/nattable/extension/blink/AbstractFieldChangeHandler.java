package net.sourceforge.nattable.extension.blink;

import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.event.ListEvent;
import ca.odell.glazedlists.event.ListEventListener;

public abstract class AbstractFieldChangeHandler<T extends FieldChangePublisher> implements FieldChangeListener {
	
	protected final EventList<T> sourceEventList;

	public AbstractFieldChangeHandler(EventList<T> sourceEventList) {
		
		this.sourceEventList = sourceEventList;
		
		for (FieldChangePublisher publisher: sourceEventList)
		{
			publisher.addFieldChangeListener(this);
		}
		
		trackAdditionsAndRemovalsFromDataSet(sourceEventList);
	}

	private void trackAdditionsAndRemovalsFromDataSet(EventList<T> changeableData) {
		
		changeableData.addListEventListener(new ListEventListener<T>()
		{
			public void listChanged(ListEvent<T> listChanges)
			{
				listChanges.getSourceList().getReadWriteLock().readLock().lock();
				try {
					while (listChanges.next()) {
						final int changeType = listChanges.getType();
			            final int changeIndex = listChanges.getIndex();
						
						switch (changeType) {
						case ListEvent.INSERT:
							listChanges.getSourceList().get(changeIndex).addFieldChangeListener(AbstractFieldChangeHandler.this);
							break;
							
						case ListEvent.DELETE:
							if (listChanges.getSourceList().size() > changeIndex) {
								listChanges.getSourceList().get(changeIndex).removeFieldChangeListener(AbstractFieldChangeHandler.this);
							} else {
								System.err.println("Received event change with index beyond end of list! " + changeIndex + " >= " + listChanges.getSourceList().size());
							}
							break;
							
						default:
							break;
						}
					}
				} finally {
					listChanges.getSourceList().getReadWriteLock().readLock().unlock();
				}
			}
		});
	}
	
}
