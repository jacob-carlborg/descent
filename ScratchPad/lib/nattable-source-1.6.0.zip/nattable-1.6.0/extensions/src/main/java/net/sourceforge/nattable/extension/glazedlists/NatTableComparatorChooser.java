package net.sourceforge.nattable.extension.glazedlists;

import java.util.List;

import net.sourceforge.nattable.sorting.SortingDirection;
import net.sourceforge.nattable.sorting.ISortingDirectionChangeListener;
import net.sourceforge.nattable.sorting.SortingDirection.DirectionEnum;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.gui.AbstractTableComparatorChooser;
import ca.odell.glazedlists.gui.TableFormat;
import ca.odell.glazedlists.impl.gui.SortingState;

public class NatTableComparatorChooser<T> extends AbstractTableComparatorChooser<T> implements ISortingDirectionChangeListener {
	
	public NatTableComparatorChooser(SortedList<T> sortedList, TableFormat<T> tableFormat) {
		super(sortedList, tableFormat);
	}
	
	public void sortingDirectionChanged(SortingDirection[] directions) {
		List<SortingState.SortingColumn> recentlyClickedColumns = sortingState.getRecentlyClickedColumns();
		for (SortingState.SortingColumn sortingColumn : recentlyClickedColumns) {
			sortingColumn.clear();
		}
		recentlyClickedColumns.clear();
		
		if (directions != null) {
			for (SortingDirection direction : directions) {
				SortingState.SortingColumn sortingColumn = sortingState.getColumns().get(direction.getColumn());
				sortingColumn.setComparatorIndex(0);
				sortingColumn.setReverse(direction.getDirection() == DirectionEnum.DOWN);
				recentlyClickedColumns.add(sortingColumn);
			}
		}
		
		sortingState.fireSortingChanged();
	}

}
