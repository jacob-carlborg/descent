package net.sourceforge.nattable.extension;

import java.io.InputStream;

import net.sourceforge.nattable.config.IColumnHeaderConfig;
import net.sourceforge.nattable.config.ICornerConfig;
import net.sourceforge.nattable.config.IRowHeaderConfig;
import net.sourceforge.nattable.extension.typeconfig.style.IStyleMarkupHandler;
import net.sourceforge.nattable.extension.typeconfig.style.XMLStyleMarkupHandler;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.widgets.Display;

public class FusionTableModelLoader {
	public static DefaultNatTableModel configureTableModelFromXML(InputStream xml, ICornerConfig cornerConfig, IColumnHeaderConfig columnHeaderConfig, IRowHeaderConfig rowHeaderConfig,
			Display currentDisplay) {
		ContentConfigRegistry contentConfigRegistry = new ContentConfigRegistry();
		StyleConfigRegistry styleConfigRegistry = new StyleConfigRegistry();
		DefaultNatTableModel tableModel = new DefaultNatTableModel(contentConfigRegistry, styleConfigRegistry, cornerConfig, columnHeaderConfig, rowHeaderConfig, null);
		IStyleMarkupHandler xmlStyleHandler = new XMLStyleMarkupHandler(xml);
		xmlStyleHandler.assembleConfiguration(tableModel.getStyleConfigRegistry(), currentDisplay);
		xmlStyleHandler.loadGridAttributes(tableModel, tableModel.getStyleConfigRegistry(), currentDisplay);
		return tableModel;
	}
}
