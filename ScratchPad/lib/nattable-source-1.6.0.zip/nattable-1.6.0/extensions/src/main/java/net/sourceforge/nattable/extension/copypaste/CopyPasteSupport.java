package net.sourceforge.nattable.extension.copypaste;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.widgets.Display;

import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.support.TableDataSerializerSupport;
import net.sourceforge.nattable.util.MethodNameGenerator;

public class CopyPasteSupport<T> implements ICopyPasteSupport<T> {
	private TableDataSerializerSupport<T> dataSerializer = new TableDataSerializerSupport<T>("\n", "\t");
	private IRowIdAccessor<T> rowIdAccessor;

	public CopyPasteSupport(IRowIdAccessor<T> rowIdAccessor) {
		this.rowIdAccessor = rowIdAccessor;
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.nattable.support.ICopyPasteSupport#paste(java.util.List, java.util.List, java.util.List)
	 */
	public void pasteSupport(List<List<Object>> rows, List<T> selectedRows,List<String> propertyNames, DataUpdateHelper<T> helper) {
		
		List<Serializable> rowIds = new ArrayList<Serializable>();
		if(selectedRows != null) {
			for(T selectedRow : selectedRows) {
				rowIds.add(rowIdAccessor.getRowId(selectedRow));
			}
		}
		/*
		 * If the user has selected more rows than were available in the clipboard, then we loop through each row adding
		 * the clipboard contents to it.  Otherwise we loop the clipboard context and where we find a selected row 
		 * we do an update. 
		 */
		int rowCounter = 0;
		if(rowIds.size() > rows.size()) {
			for(Serializable rowId : rowIds) {
				if(rowCounter < rows.size()) {
					List<Object>cells = rows.get(rowCounter++);
					helper.getBulkUpdate().addUpdates(rowId, cells, propertyNames, helper);
				}else {
					break;
				}
			}
		} else {			
			for(List<Object> cells : rows) {
				//If there is no ID present it means we have an insert
				Serializable id = rowIds.size() > 0 && rowCounter < rowIds.size() ? rowIds.get(rowCounter++) : null;
				helper.getBulkUpdate().addUpdates(id, cells, propertyNames, helper);
			}
		}
	}

	/* (non-Javadoc)
	 * @see net.sourceforge.nattable.support.ICopyPasteSupport#copy(java.util.List, java.util.List)
	 */
	public Clipboard copySupport(List<?> dataToCopy, List<String> propertiesToCopy) {
		//translate property names to method names
		for(int index = 0; index < propertiesToCopy.size(); index++) {
			String property = propertiesToCopy.remove(index);
			property = MethodNameGenerator.buildGetMethodName(property);
			propertiesToCopy.add(index, property);
		}
		
		// store copied data in clipboard
		Clipboard cb = new Clipboard(Display.getDefault());
		cb.clearContents();
		cb.setContents(new Object[] { dataSerializer.serializeAndDelimit(dataToCopy, propertiesToCopy).toString() }, new Transfer[] { TextTransfer.getInstance() });
		return cb;
	}

	/**
	 * Use to override default row delimiter
	 * 
	 * @param rowDelimiter
	 */
	public void setRowDelimiter(String rowDelimiter) {
		dataSerializer.setRowDelimiter(rowDelimiter);
	}

	/**
	 * Use to override default cell delimiter
	 * 
	 * @param cellDelimiter
	 */
	public void setCellDelimiter(String cellDelimiter) {
		dataSerializer.setCellDelimiter(cellDelimiter);
	}
}