package net.sourceforge.nattable.extension.event;

public enum TickEventEnum {
	NONE,
	QUICK,
	UP,
	DOWN
}
