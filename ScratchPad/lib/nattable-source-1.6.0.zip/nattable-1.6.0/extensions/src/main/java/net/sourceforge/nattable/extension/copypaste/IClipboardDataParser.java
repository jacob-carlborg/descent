package net.sourceforge.nattable.extension.copypaste;

import java.util.List;

import org.eclipse.swt.dnd.Clipboard;

public interface IClipboardDataParser {
	/**
	 * This method parses the contents of the clipboard into a list of rows which.  The cell data for a given row
	 * is represented by another list.
	 * @param cb clipboard reference
	 * @return
	 */
	public List<List<Object>> parseClipboard(Clipboard cb);
}
