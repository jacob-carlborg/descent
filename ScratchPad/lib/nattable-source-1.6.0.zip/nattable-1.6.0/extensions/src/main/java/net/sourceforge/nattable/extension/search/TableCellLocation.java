package net.sourceforge.nattable.extension.search;

public class TableCellLocation {
	
	public final int row;
	public final int column;

	public TableCellLocation(int row, int column) {
		this.row = row;
		this.column = column;
	}
}
