package net.sourceforge.nattable.extension.dialog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.extension.search.SearchResult;
import net.sourceforge.nattable.extension.search.TableCellLocation;
import net.sourceforge.nattable.extension.search.TableSearch;
import net.sourceforge.nattable.support.OrderEnum;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class SearchDialog extends Dialog {
	
	public static void installKeyHandler(final NatTable table) {
		
		table.addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.keyCode == 102&& (e.stateMask & SWT.CTRL) != 0) {
					new SearchDialog(table).open();
				}
			}
		});
	}

	private final NatTable natTable;
	private Text findText;
	private Button findButton;
	private Button caseSensitiveButton;
	private Label statusLabel;
	private Button wrapSearchButton;
	private Button forwardButton;
	
	private SearchDialog(NatTable natTable) {
		super(natTable.getShell());
		
		this.natTable = natTable;
		setShellStyle(SWT.CLOSE | SWT.MODELESS | SWT.BORDER | SWT.TITLE | SWT.RESIZE);
		setBlockOnOpen(false);
	}

	@Override
	public void create() {

		super.create();
		getShell().setText("Find");

	}
	
	@Override
	protected Control createContents(final Composite parent) {
		
		final Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(1,false));
		GridDataFactory.fillDefaults().grab(true, true).applyTo(composite);

		GridDataFactory.fillDefaults().align(SWT.FILL, SWT.FILL).grab(true, false).applyTo(createInputPanel(composite));

		GridDataFactory.fillDefaults().align(SWT.FILL, SWT.FILL).grab(true, true).applyTo(createOptionsPanel(composite));

		Composite buttonPanel = createButtonSection(composite);
		GridDataFactory.swtDefaults().align(SWT.FILL, SWT.BOTTOM).grab(true, true).applyTo(buttonPanel);
		
		return composite;
	}

	private Composite createButtonSection(Composite composite) {

		Composite panel = new Composite(composite, SWT.NONE);
		GridLayout layout= new GridLayout(1,false);
		panel.setLayout(layout);
		
		statusLabel = new Label(panel, SWT.LEFT);
		statusLabel.setForeground(statusLabel.getDisplay().getSystemColor(SWT.COLOR_RED));
		GridDataFactory.fillDefaults().align(SWT.FILL, SWT.CENTER).grab(true, false).applyTo(statusLabel);
		
		findButton = createButton(panel, IDialogConstants.CLIENT_ID, "&Find", false);
		GridDataFactory.swtDefaults().align(SWT.RIGHT, SWT.BOTTOM).grab(false, false).hint(52, SWT.DEFAULT).applyTo(findButton);
		
		findButton.setEnabled(false);
		getShell().setDefaultButton(findButton);
		
		findButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				doFind();
			}
		});
 		
		Button closeButton = createButton(panel, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
		GridDataFactory.swtDefaults().align(SWT.RIGHT, SWT.BOTTOM).grab(false, false).hint(52, SWT.DEFAULT).applyTo(closeButton);
		
		return panel;
	}

	private Composite createInputPanel(final Composite composite)
	{
		final Composite row = new Composite(composite, SWT.NONE);
		row.setLayout(new GridLayout(2,false));
		
		final Label findLabel = new Label(row, SWT.NONE);
		findLabel.setText("F&ind:");
		GridDataFactory.fillDefaults().align(SWT.LEFT, SWT.CENTER).applyTo(findLabel);
		
		findText = new Text(row, SWT.SINGLE | SWT.BORDER);
		GridDataFactory.fillDefaults().grab(true, false).applyTo(findText);
		findText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				findButton.setEnabled(findText.getText().length() > 0);
			}
		});
		findText.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				if (findButton.isEnabled()) {
					doFind();
				}
			}
		});
		
		return row;
	}	
	
	private Composite createOptionsPanel(final Composite composite)
	{
		final Composite row = new Composite(composite, SWT.NONE);
		row.setLayout(new GridLayout(2,true));
		
		final Group directionGroup = new Group(row, SWT.SHADOW_ETCHED_IN);
		GridDataFactory.fillDefaults().grab(true, true).applyTo(directionGroup);
		directionGroup.setText("Direction");
		final RowLayout rowLayout = new RowLayout(SWT.VERTICAL);
		rowLayout.marginHeight = rowLayout.marginWidth = 3;
		directionGroup.setLayout(rowLayout);
		forwardButton = new Button(directionGroup, SWT.RADIO);
		forwardButton.setText("F&orward");
		forwardButton.setSelection(true);
		final Button backwardButton = new Button(directionGroup, SWT.RADIO);
		backwardButton.setText("&Backward");

		final Group optionsGroup = new Group(row, SWT.SHADOW_ETCHED_IN);
		GridDataFactory.fillDefaults().grab(true, true).applyTo(optionsGroup);
		optionsGroup.setText("Options");
		optionsGroup.setLayout(rowLayout);
		caseSensitiveButton = new Button(optionsGroup, SWT.CHECK);
		caseSensitiveButton.setText("&Case Sensitive");
		wrapSearchButton = new Button(optionsGroup, SWT.CHECK);
		wrapSearchButton.setText("&Wrap Search");
		wrapSearchButton.setSelection(true);
		
		return row;
	}

	private void doFind() {
		
		BusyIndicator.showWhile(natTable.getDisplay(), new Runnable() {
			public void run() {
				statusLabel.setText("");

				TableCellLocation searchStartLocation = getSearchStartLocation();
				
				List<Integer> visibleColumnIndexes = new ArrayList<Integer>();
				for (int col : natTable.getModelBodyColumnOrder()) {
					if (natTable.isModelBodyColumnViewable(col)) {
						visibleColumnIndexes.add(Integer.valueOf(col));
					}
				}
				for (int visiblePosition=0; visiblePosition < visibleColumnIndexes.size(); visiblePosition++) {
					Integer visibleColumnIndex = visibleColumnIndexes.get(visiblePosition);
					if (visibleColumnIndex != null &&
							searchStartLocation.column == visibleColumnIndex.intValue()) {
						searchStartLocation = new TableCellLocation(searchStartLocation.row, visiblePosition);
						break;
					}
				}
				
				final TableSearch tableSearch = new TableSearch(natTable, caseSensitiveButton.getSelection(), wrapSearchButton.getSelection());
				final SearchResult result = tableSearch.performSearch(findText.getText(), searchStartLocation, forwardButton.getSelection(), Collections.unmodifiableList(visibleColumnIndexes));
				
				switch (result) {
				case NOT_FOUND:
					statusLabel.setText("Text not found");
					break;
				case FOUND:
					Integer columnToSelect = visibleColumnIndexes.get(result.getFoundLocation().column);
					
					if (columnToSelect != null)
						setAndMoveSelectionToCellAt(result.getFoundLocation().row,
								columnToSelect.intValue(), forwardButton.getSelection());
					
					break;
				default:
					break;
				}
			}
		});
	}
	
	private TableCellLocation getSearchStartLocation() {
		int startRow = 0, startColumn = 0;
		if (!natTable.getSelectionModel().isEmpty()) {
			startRow = natTable.getSelectionModel().getSelectedRows()[0];
			startColumn = natTable.reorderedToModelBodyColumn(natTable.getSelectionModel().getSelectedColumns()[0]);
		}
		return new TableCellLocation(startRow, startColumn);
	}

	private void setAndMoveSelectionToCellAt(int rowToSelect, int columnToSelect, boolean forwardSearch) {
		natTable.getSelectionSupport().setSelectedCell(rowToSelect, natTable.modelToReorderedBodyColumn(columnToSelect));
		natTable.showBodyColumn(columnToSelect, forwardSearch ? OrderEnum.LAST : OrderEnum.FIRST);
		natTable.showBodyRow(Integer.valueOf(rowToSelect));
	}
}
