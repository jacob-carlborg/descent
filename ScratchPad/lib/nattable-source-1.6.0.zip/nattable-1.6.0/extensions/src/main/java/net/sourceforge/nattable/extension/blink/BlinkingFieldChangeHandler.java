package net.sourceforge.nattable.extension.blink;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.support.ConflationSupport;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import ca.odell.glazedlists.EventList;

public class BlinkingFieldChangeHandler<T extends FieldChangePublisher> extends AbstractFieldChangeHandler<T> implements IConfigTypeResolver {
	
//	private static Logger log = Logger.getLogger(BlinkingFieldChangeHandler.class);
	
	private final IRowIdAccessor<T> rowIdAccessor;
	private final HashMap<Object, Map<String, FieldChangeInfo>> fieldChangeMap;
	private final HashMap<Integer, String> blinkFieldForColumn;
	private final Lock fieldChangeLock;
	private final IRowDataProvider<T> rowDataProvider;
	private final BlinkStyleRemover blinkStyleRemover;

	static class FieldChangeInfo {
		private long updateTime;
		private MovementDirection direction;
		
		public void update(FieldChangeEvent event) {
			this.updateTime = event.timeOfChange;
			this.direction = event.movementDirection;
		}
		
		public long getUpdateTime() {
			return updateTime;
		}
		
		public MovementDirection getMovementDirection() {
			return direction;
		}
		
		@Override
		public String toString() {
			return "FieldChangeInfo:" + direction + ":" + updateTime;
		}
	}
	
	public BlinkingFieldChangeHandler(EventList<T> sourceEventList, int blinkTimeoutMillis, IRowIdAccessor<T> rowIdProvider, IRowDataProvider<T> rowDataProvider) {
		
		super(sourceEventList);
		
		this.rowIdAccessor = rowIdProvider;
		this.rowDataProvider = rowDataProvider;
		this.fieldChangeMap = new HashMap<Object, Map<String, FieldChangeInfo>>();
		this.blinkFieldForColumn = new HashMap<Integer, String>();
		this.fieldChangeLock = new ReentrantLock();
		this.blinkStyleRemover = new BlinkStyleRemover(blinkTimeoutMillis);
	}

	public void setConflationSupport(ConflationSupport natTableConflationSupport) {
		blinkStyleRemover.setConflationSupport(natTableConflationSupport);
	}

	public void setBlinkingField(String field, int columnNumber) {
		blinkFieldForColumn.put(Integer.valueOf(columnNumber), field);
	}
	
	public void removeBlinkingField(int columnNumber) {
		Integer modelColumnIndex = Integer.valueOf(columnNumber);
		if(blinkFieldForColumn.containsKey(modelColumnIndex)) {
			blinkFieldForColumn.remove(modelColumnIndex);
		}
	}
	
	public boolean hasBlinkingFields() {
		return blinkFieldForColumn != null ? blinkFieldForColumn.size() > 0 : false;
	}
	
	@SuppressWarnings("unchecked")
	public void fieldChanged(FieldChangeEvent event) {
		
		final Object rowId = rowIdAccessor.getRowId((T)event.getSource());

		fieldChangeLock.lock();
		try {
			Map<String,FieldChangeInfo> fieldChangeInfoMap = fieldChangeMap.get(rowId);
			if (fieldChangeInfoMap == null) {
				fieldChangeInfoMap = new HashMap<String, FieldChangeInfo>();
				fieldChangeMap.put(rowId, fieldChangeInfoMap);
			}
			FieldChangeInfo info = fieldChangeInfoMap.get(event.field);
			if (info == null) {
				info = new FieldChangeInfo();
				fieldChangeInfoMap.put(event.field, info);
			}
			info.update(event);

			blinkStyleRemover.queueBlinkRemoval((T)event.getSource(), event.field, info.getUpdateTime());
		} finally {
			fieldChangeLock.unlock();
		}
	}

	public String getConfigType(int row, int col) {
		Integer column = Integer.valueOf(col);
		
		if (blinkFieldForColumn.containsKey(column)) {
			
			final Object rowId = rowIdAccessor.getRowId(rowDataProvider.getRowObject(row));
			fieldChangeLock.lock();
			try {
				final Map<String, FieldChangeInfo> map = fieldChangeMap.get(rowId);
				if (map != null && map.get(blinkFieldForColumn.get(column)) != null) {
					switch (map.get(blinkFieldForColumn.get(column)).getMovementDirection()) {
					case UP:
						return "blink_up";
					case DOWN:
						return "blink_down";
					default:
						break;
					}
				}
			} finally {
				fieldChangeLock.unlock();
			}
		}
		return null;
	}

	///////////////////////////////////////////////////////////////////////////
	
	class BlinkStyleRemover {
		
		class CellEntry {
			final T row;
			final String field;

			CellEntry(T row, String field) {
				this.row = row;
				this.field = field;
			}
		}
		
		private final int blinkTimeoutMillis;
		private final Timer timer;
		private final Queue<CellEntry> cellQueue;
		private final Map<CellEntry,Long> cellUpdateTimes;
		private final ReadWriteLock localLock;
		private final AtomicReference<BlinkStyleRemovingTimerTask> timerTask;
		private ConflationSupport natTableConflationSupport;

		BlinkStyleRemover(int blinkTimeoutMillis) {
			this.blinkTimeoutMillis = blinkTimeoutMillis;
			this.cellQueue = new LinkedList<CellEntry>();
			this.cellUpdateTimes = new HashMap<CellEntry,Long>();
			this.timer = new Timer("Blink Style Remover", true);
			this.localLock = new ReentrantReadWriteLock();
			this.timerTask = new AtomicReference<BlinkStyleRemovingTimerTask>();
		}

		void queueBlinkRemoval(T rowObject, String field, long updateTime) {
			localLock.writeLock().lock();
			try {
				if (cellUpdateTimes.containsKey(rowObject)) {
					cellQueue.remove(rowObject);
				}
				final CellEntry queueEntry = new CellEntry(rowObject, field);
				cellQueue.offer(queueEntry);
				cellUpdateTimes.put(queueEntry, Long.valueOf(updateTime));
			} finally {
				localLock.writeLock().unlock();
			}
			
			if (timerTask.get() == null) {
				scheduleBlinkRemoval(blinkTimeoutMillis);
			}
		}

		void setConflationSupport(ConflationSupport natTableConflationSupport) {
			this.natTableConflationSupport = natTableConflationSupport;
		}

		private void scheduleBlinkRemoval(int executeAfterMillis) {
			timerTask.set(new BlinkStyleRemovingTimerTask());
			timer.schedule(timerTask.get(), executeAfterMillis);
		}
		
		///////////////////////////////////////////////////////////////////////////
		
		class BlinkStyleRemovingTimerTask extends TimerTask {
			
			@Override
			public void run() {
				List<CellEntry> entriesToClear = removeEntriesUpToCutOffTime(System.currentTimeMillis() - blinkTimeoutMillis);
				sourceEventList.getReadWriteLock().readLock().lock();
				fieldChangeLock.lock();
				try {
					for (CellEntry entry: entriesToClear) {
						fieldChangeMap.get(rowIdAccessor.getRowId(entry.row)).remove(entry.field);
						if (natTableConflationSupport == null) {
//							BlinkingFieldChangeHandler.this.log.error("Cannot repaint NatTable as NatTableConflationSupport has not yet been set on BlinkingFieldChangeHandler");
						} else if (sourceEventList.contains(entry.row)) {
							final int rowIndex = sourceEventList.indexOf(entry.row);
							natTableConflationSupport.redrawUpdatedRow(rowIndex, rowIndex);
						}
					}
				} finally {
					fieldChangeLock.unlock();
					sourceEventList.getReadWriteLock().readLock().unlock();
				}
				
				if (cellQueue.isEmpty()) {
					timerTask.set(null);
				} else {
					BlinkStyleRemover.this.scheduleBlinkRemoval(blinkTimeoutMillis/2);
				}
			}

			private List<CellEntry> removeEntriesUpToCutOffTime(long cutOffTime)
			{
				final List<CellEntry> matchingEntries = new ArrayList<CellEntry>();
				
				localLock.writeLock().lock();
				try {
					while (!cellQueue.isEmpty() && cellUpdateTimes.get(cellQueue.peek()).longValue() <= cutOffTime) {
						final CellEntry rowEntry = cellQueue.remove();
						cellUpdateTimes.remove(rowEntry.row);
						matchingEntries.add(rowEntry);
					}
					return matchingEntries;
					
				} finally {
					localLock.writeLock().unlock();
				}
			}
		}
	}
}
