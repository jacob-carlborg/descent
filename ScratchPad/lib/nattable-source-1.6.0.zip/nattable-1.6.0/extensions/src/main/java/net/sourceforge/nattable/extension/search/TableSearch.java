package net.sourceforge.nattable.extension.search;

import java.util.List;

import net.sourceforge.nattable.NatTable;

public class TableSearch {

	private final boolean isCaseSensitive;
	private final NatTable natTable;
	private final boolean isWrapSearch;

	public TableSearch(NatTable natTable, boolean isCaseSensitive, boolean isWrapSearch) {
		this.natTable = natTable;
		this.isCaseSensitive = isCaseSensitive;
		this.isWrapSearch = isWrapSearch;
	}
	
	public SearchResult performSearch(String searchText, TableCellLocation searchStartLocationWithVisibleColumnIndex, boolean isForwardSearch, List<Integer> visibleColumnIndexes)
	{
		if (isForwardSearch) {
			return forwardSearch(searchText, searchStartLocationWithVisibleColumnIndex, natTable.getNatTableModel().getBodyRowCount(), visibleColumnIndexes);
		} else {
			return backwardSearch(searchText, searchStartLocationWithVisibleColumnIndex, natTable.getNatTableModel().getBodyRowCount(), visibleColumnIndexes);
		}
	}
	
	private boolean containsSearchText(String cellText, String searchText) {
		if (cellText != null) {
			if (isCaseSensitive) {
				return cellText.contains(searchText);
			} else {
				return cellText.toLowerCase().contains(searchText.toLowerCase());
			}
		}
		return false;
	}
	
	private SearchResult backwardSearch(String searchText, TableCellLocation searchStartLocation, int bodyRowCount, List<Integer> visibleColumnIndexes) {
		
		final int endRowCount = isWrapSearch ? searchStartLocation.row - bodyRowCount : 0;
		for (int row = searchStartLocation.row; row > endRowCount; row--) {
			int currentRow = row < 0 ? (bodyRowCount + row) : row;
			for (int column = searchStartLocation.column-1; column >= searchStartLocation.column - visibleColumnIndexes.size(); column--) {
				int currentColumn = column;
				if (currentColumn < 0) {
					if (currentColumn == -1) currentRow = --currentRow + (currentRow < 0 ? bodyRowCount : 0);
					currentColumn = visibleColumnIndexes.size() + currentColumn;
				}
				
				final String cellText = natTable.getNatTableModel().getBodyCellRenderer().getDisplayText(currentRow, visibleColumnIndexes.get(currentColumn).intValue());
				if (containsSearchText(cellText, searchText)) {
					return SearchResult.FOUND.setFoundLocation(currentRow, currentColumn);
				}
				if (natTable.isDisposed()) {
					return SearchResult.FIND_TERMINATED;
				}
			}
		}
		return SearchResult.NOT_FOUND;
	}

	private SearchResult forwardSearch(String searchText, TableCellLocation searchStartLocation, int bodyRowCount, List<Integer> visibleColumnIndexes) {

		final int endRowCount = isWrapSearch ? searchStartLocation.row + bodyRowCount : bodyRowCount-1;
		for (int row = searchStartLocation.row; row < endRowCount; row++) {
			int currentRow = row % bodyRowCount;
			for (int column = searchStartLocation.column+1; column <= searchStartLocation.column + visibleColumnIndexes.size(); column++) {
				int currentColumn = column % visibleColumnIndexes.size();
				if (currentColumn == 0) currentRow = ++currentRow % bodyRowCount;
				
				final String cellText = natTable.getNatTableModel().getBodyCellRenderer().getDisplayText(currentRow, visibleColumnIndexes.get(currentColumn).intValue());
				if (containsSearchText(cellText, searchText)) {
					return SearchResult.FOUND.setFoundLocation(currentRow, currentColumn);
				}
				if (natTable.isDisposed()) {
					return SearchResult.FIND_TERMINATED;
				}
			}
		}
		return SearchResult.NOT_FOUND;
	}
}
