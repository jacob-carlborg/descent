package net.sourceforge.nattable.extension.widget;

import net.sourceforge.nattable.extension.internal.util.ImageUtils;

import org.apache.commons.lang.StringUtils;
import org.eclipse.core.runtime.ListenerList;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;

public class SelectionList extends Composite {

	private final ListViewer availableListViewer;
	private final ListViewer selectedListViewer;
	private List availableList;
	private List selectedList;
	private ListenerList listeners;
	
	public SelectionList(Composite parent, int style) {
		this(parent, style, null, null);
	}
	
	public SelectionList(Composite parent, int style, String availableLabel, String selectedLabel) {
		super(parent, style);

		listeners = new ListenerList();
		
		setLayout(new GridLayout(4, false));

		createLabels(this, availableLabel, selectedLabel);
		
		availableList = new List(this, SWT.MULTI | SWT.BORDER
				| SWT.H_SCROLL | SWT.V_SCROLL);
		availableListViewer = new ListViewer(availableList);

		GridData gridData = GridDataFactory.fillDefaults().grab(true, true).create();
		availableList.setLayoutData(gridData);
		availableList.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseDoubleClick(MouseEvent e) {
				addSelected();
			}

		});
		
		availableList.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.character == ' ')
					addSelected();
			}
		});
		
		Composite buttonComposite = new Composite(this, SWT.NONE);
		buttonComposite.setLayout(new GridLayout(1, true));

		Button addButton = new Button(buttonComposite, SWT.PUSH);
		addButton.setImage(ImageUtils.getImage("arrow_right"));
		gridData = GridDataFactory.fillDefaults().grab(false, true).align(SWT.CENTER, SWT.CENTER).create();
		addButton.setLayoutData(gridData);
		addButton.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
				widgetSelected(e);
			}

			public void widgetSelected(SelectionEvent e) {
				addSelected();
			}
			
		});
		
		Button removeButton = new Button(buttonComposite, SWT.PUSH);
		removeButton.setImage(ImageUtils.getImage("arrow_left"));
		gridData = GridDataFactory.copyData(gridData);
		removeButton.setLayoutData(gridData);
		removeButton.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
				widgetSelected(e);
			}

			public void widgetSelected(SelectionEvent e) {
				removeSelected();
			}
			
		});
		
		selectedList = new List(this, SWT.MULTI | SWT.BORDER
				| SWT.H_SCROLL | SWT.V_SCROLL);
		selectedListViewer = new ListViewer(selectedList);
		
		gridData = GridDataFactory.fillDefaults().grab(true, true).create();
		selectedList.setLayoutData(gridData);
		selectedList.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseDoubleClick(MouseEvent e) {
				removeSelected();
			}

		});
		
		selectedList.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				boolean controlMask = (e.stateMask & SWT.CONTROL) == SWT.CONTROL;
				if (controlMask && e.keyCode == SWT.ARROW_UP) {
					moveSelectedUp();
					e.doit = false;
				} else if (controlMask && e.keyCode == SWT.ARROW_DOWN) {
					moveSelectedDown();
					e.doit = false;
				}
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				
				if (e.character == ' ')
					removeSelected();
			}
		});
		
		Composite upDownbuttonComposite = new Composite(this, SWT.NONE);
		upDownbuttonComposite.setLayout(new GridLayout(1, true));

		Button upButton = new Button(upDownbuttonComposite, SWT.PUSH);
		upButton.setImage(ImageUtils.getImage("arrow_up"));
		gridData = GridDataFactory.fillDefaults().grab(false, true).align(SWT.CENTER, SWT.CENTER).create();
		upButton.setLayoutData(gridData);
		upButton.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
				widgetSelected(e);
			}

			public void widgetSelected(SelectionEvent e) {
				moveSelectedUp();
			}
			
		});
		
		Button downButton = new Button(upDownbuttonComposite, SWT.PUSH);
		downButton.setImage(ImageUtils.getImage("arrow_down"));
		gridData = GridDataFactory.copyData(gridData);
		downButton.setLayoutData(gridData);
		downButton.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
				widgetSelected(e);
			}

			public void widgetSelected(SelectionEvent e) {
				moveSelectedDown();
			}
			
		});

	}

	private void createLabels(Composite parent, String availableStr,
			String selectedStr) {
		boolean availableSet = StringUtils.isNotEmpty(availableStr);
		boolean selectedSet = StringUtils.isNotEmpty(selectedStr);
		
		if (availableSet && selectedSet) {
			if (availableSet) {
				Label availableLabel = new Label(parent, SWT.NONE);
				availableLabel.setText(availableStr);
				GridDataFactory.swtDefaults().applyTo(availableLabel);
			}
			
			Label filler = new Label(parent, SWT.NONE);
			GridDataFactory.swtDefaults().span(availableSet ? 1 : 2, 1).applyTo(filler);
			
			if (selectedSet) {
				Label selectedLabel = new Label(parent, SWT.NONE);
				selectedLabel.setText(selectedStr);
				GridDataFactory.swtDefaults().span(2, 1).applyTo(selectedLabel);
			}
		}
	}

	public void addSelectionListListener(ISelectionListListener listener) {
		listeners.add(listener);
	}
	
	public void removeSelectionListListener(ISelectionListListener listener) {
		listeners.remove(listener);
	}
	
	protected final void fireItemsSelected(Object [] addedItems) {
		for (Object listener : listeners.getListeners()) {
			((ISelectionListListener) listener).itemsSelected(this, addedItems);
		}
	}
	
	protected final void fireItemsRemoved(Object [] removedItems) {
		for (Object listener : listeners.getListeners()) {
			((ISelectionListListener) listener).itemsRemoved(this, removedItems);
		}
	}
	
	protected final void fireItemsMoved(int [] oldIndexes, int[] newIndexes) {
		for (Object listener : listeners.getListeners()) {
			((ISelectionListListener) listener).itemsMoved(this, oldIndexes, newIndexes);
		}
	}
	
	public ListViewer getAvailableListViewer() {
		return availableListViewer;
	}

	public ListViewer getSelectedListViewer() {
		return selectedListViewer;
	}

	private void addSelected() {
		int[] selected = availableList.getSelectionIndices();
		Object [] selectedObjects = new Object[selected.length];
		
		for (int i = 0; i < selected.length; i++) {
			Object item = availableListViewer.getElementAt(selected[i]);
			selectedObjects[i] = item;
		}
		
		int selectionIndex = selectedList.getSelectionIndex();
		
		if (selectionIndex < 0)
			selectedListViewer.add(selectedObjects);
		else {
			for (int i = 0; i < selectedObjects.length; i++) {
				selectedListViewer.insert(selectedObjects[i], selectionIndex + i + 1);
			}
		}
		
		availableListViewer.remove(selectedObjects);
		
		fireItemsSelected(selectedObjects);
	}
	
	private void removeSelected() {
		int[] selected = selectedList.getSelectionIndices();
		Object [] selectedObjects = new Object[selected.length];
		
		for (int i = 0; i < selected.length; i++) {
			Object item = selectedListViewer.getElementAt(selected[i]);
			selectedObjects[i] = item;
		}
		
		availableListViewer.add(selectedObjects);
		selectedListViewer.remove(selectedObjects);
		
		fireItemsRemoved(selectedObjects);
	}

	private void moveSelectedUp() {
		int[] selected = selectedList.getSelectionIndices();
		int[] newSelectionIndex = new int[selected.length];
		
		boolean changed = false;
		
		for (int i = 0; i < selected.length; i++) {
			Object item = selectedListViewer.getElementAt(selected[i]);
			
			if (selected[i] > i) {
				selectedListViewer.remove(item);
				selectedListViewer.insert(item, selected[i] - 1);
				newSelectionIndex[i] = selected[i] - 1;
				changed = true;
			} else {
				newSelectionIndex[i] =  selected[i];
			}
		}
		
		if (changed) {
			selectedList.setSelection(newSelectionIndex);

			fireItemsMoved(selected, newSelectionIndex);
		}
	}
	
	private void moveSelectedDown() {
		int[] selected = selectedList.getSelectionIndices();
		int[] newSelectionIndex = new int[selected.length];
		
		boolean changed = false;
		
		for (int i = selected.length - 1; i >= 0; i--) {
			Object item = selectedListViewer.getElementAt(selected[i]);
			
			if (selected[i] < selectedList.getItemCount() - (selected.length - i)) {
				selectedListViewer.remove(item);
				selectedListViewer.insert(item, selected[i] + 1);
				newSelectionIndex[i] = selected[i] + 1;
				changed = true;
			} else {
				newSelectionIndex[i] = selected[i];
			}
		}
		

		if (changed) {
			selectedList.setSelection(newSelectionIndex);
			selectedList.redraw();

			fireItemsMoved(selected, newSelectionIndex);
		}
	}
	
	public Object [] getSelectedItems() {
		Object [] items = new Object [selectedList.getItemCount()];
		
		for (int i = 0; i < items.length; i++) {
			items[i] = selectedListViewer.getElementAt(i);
		}
		
		return items;
	}
	
	@Override
	public void dispose() {
		listeners.clear();
		
		super.dispose();
	}
	
	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		shell.setLayout(new GridLayout());

		new SelectionList(shell, SWT.NONE);
		
		shell.setSize(300, 300);
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
