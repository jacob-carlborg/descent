package net.sourceforge.nattable.extension.blink;

public enum MovementDirection {
	
	UP, DOWN, NONE;
}
