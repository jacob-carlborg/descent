package net.sourceforge.nattable.extension.typeconfig.style;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.typeconfig.style.AlternateRowColoringStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StaticStyleAssembler;
import net.sourceforge.nattable.typeconfig.style.StaticStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.widgets.Display;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XMLStyleMarkupHandler implements IStyleMarkupHandler {
	private Map<String, XPathExpression> compiledXPathExp = new HashMap<String, XPathExpression>();
	private org.w3c.dom.Document instanceDocument;
	private XPath xpathCompiler;

	public XMLStyleMarkupHandler(InputStream xml) {
		assert xml != null;
		initalizeValidatedInstance(xml);
	}

	public void assembleConfiguration(StyleConfigRegistry styleConfigRegistry, Display currentDisplay) {
		assembleDefaultStyle(styleConfigRegistry, currentDisplay);
		assembleTypedStyle(styleConfigRegistry, currentDisplay);
	}

	private void assembleDefaultStyle(StyleConfigRegistry styleConfigRegistry, Display currentDisplay) {
		try {
			assembleStyle(styleConfigRegistry, currentDisplay, (NodeList) getXPathExpressionObj("n:grid/n:styles/n:style").evaluate(instanceDocument, XPathConstants.NODESET));
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
	}

	private void assembleTypedStyle(StyleConfigRegistry styleConfigRegistry, Display currentDisplay) {
		try {
			NodeList types = (NodeList) getXPathExpressionObj("n:grid/n:types/n:type").evaluate(instanceDocument, XPathConstants.NODESET);
			if (types != null && types.getLength() > 0) {
				for (int nodeIndex = 0; nodeIndex < types.getLength(); nodeIndex++) {
					Node type = types.item(nodeIndex);
					String typeName = null;
					if (type != null) {
						typeName = type.getAttributes().getNamedItem("name").getTextContent();
						assembleStyle(styleConfigRegistry, currentDisplay, (NodeList) getXPathExpressionObj("n:styles/n:style").evaluate(type, XPathConstants.NODESET),typeName);
					}
					Node superType = type.getAttributes().getNamedItem("parent");
					//register the inheritance
					if (superType != null) {
						styleConfigRegistry.registerSuperType(typeName, superType.getTextContent());
					}
				}
			}
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}

	}

	public void loadGridAttributes(DefaultNatTableModel tableModel, StyleConfigRegistry styleConfigRegistry, Display currentDisplay) {
		try {
			Node grid = (Node) getXPathExpressionObj("n:grid").evaluate(instanceDocument, XPathConstants.NODE);
			NamedNodeMap gridAttributes = grid.getAttributes();
			tableModel.setGridLineEnabled(parseBooleanXSDType(gridAttributes.getNamedItem("gridLineEnabled")));
			tableModel.setEnableMoveColumn(parseBooleanXSDType(gridAttributes.getNamedItem("movableColumnsEnabled")));
			tableModel.setFullRowSelection(parseBooleanXSDType(gridAttributes.getNamedItem("rowSelectionEnabled")));
			tableModel.setMultipleSelection(parseBooleanXSDType(gridAttributes.getNamedItem("multiSelectionEnabled")));
			tableModel.setSingleCellSelection(parseBooleanXSDType(gridAttributes.getNamedItem("cellSelectionEnabled")));
			tableModel.setSortingEnabled(parseBooleanXSDType(gridAttributes.getNamedItem("sortEnabled")));
			tableModel.setFreezeColumnCount(parseFreezeIndex(gridAttributes.getNamedItem("freezeColumn")));
			tableModel.setFreezeRowCount(parseFreezeIndex(gridAttributes.getNamedItem("freezeRow")));

			// setup alternate row coloring
			AlternateRowColoringStyleConfig rowColorConfig = new AlternateRowColoringStyleConfig(
					StaticStyleAssembler.assembleColor(currentDisplay, 
							gridAttributes.getNamedItem("evenRowRGBColor").getTextContent()), 
					StaticStyleAssembler.assembleColor(currentDisplay,	
							gridAttributes.getNamedItem("oddRowRGBColor").getTextContent()));
			IStyleConfig existingStyle = null;
			if ((existingStyle = styleConfigRegistry.getDefaultStyleConfig(DisplayModeEnum.NORMAL.toString())) != null) {
				rowColorConfig.adaptExistingStyle(existingStyle);
			}
			styleConfigRegistry.registerDefaultStyleConfig(DisplayModeEnum.NORMAL.toString(), rowColorConfig);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
	}

	private boolean parseBooleanXSDType(Node booleanAttribute) {
		return Boolean.parseBoolean(booleanAttribute.getTextContent());
	}

	private int parseFreezeIndex(Node freezeIndex) {
		int index = 0;
		//parse the node's value, if parsing fails, then return zero.
		try {
			index = Integer.parseInt(freezeIndex.getTextContent(), 10);			
		} catch(Exception e) {
			index = 0;
		}
		return index < 0 ? 0 : index;
	}
	
	private void assembleStyle(StyleConfigRegistry styleConfigRegistry, Display currentDisplay, NodeList styleNodes, String... typeMarkers)
			throws XPathExpressionException {
		for (int nodeIndex = 0; nodeIndex < styleNodes.getLength(); nodeIndex++) {
			Node styleNode = styleNodes.item(nodeIndex);
			StaticStyleConfig style = new StaticStyleConfig();
			extractFontAttributes((Node) getXPathExpressionObj("n:font").evaluate(styleNode, XPathConstants.NODE), style);
			extractBackgroundAttributes((Node) getXPathExpressionObj("n:background").evaluate(styleNode, XPathConstants.NODE), style);
			extractForeGroundAttributes((Node) getXPathExpressionObj("n:foreground").evaluate(styleNode, XPathConstants.NODE), style);
			try {
				extractImageAttributes((Node) getXPathExpressionObj("n:image").evaluate(styleNode, XPathConstants.NODE), style);
			} catch (IOException e) {
				e.printStackTrace();
			}
			String displayMode = styleNode.getAttributes().getNamedItem("mode").getTextContent();			
			if (typeMarkers != null && typeMarkers.length == 1) {
				styleConfigRegistry.registerStyleConfig(displayMode, typeMarkers[0], style);
			} else {
				styleConfigRegistry.registerDefaultStyleConfig(displayMode, style);
			}
		}
	}

	private void extractFontAttributes(Node fontNode, StaticStyleConfig style) {
		if (fontNode != null) {
			NamedNodeMap fontAttributes = fontNode.getAttributes();
			style.setFontAttributes(fontAttributes.getNamedItem("name").getTextContent(), fontAttributes
					.getNamedItem("size").getTextContent(),fontAttributes.getNamedItem("style").getTextContent());
		}
	}

	private void extractForeGroundAttributes(Node fgNode, StaticStyleConfig style) {
		if (fgNode != null) {
			style.setFGColorRGB(fgNode.getAttributes().getNamedItem("color").getTextContent());
		}
	}

	private void extractBackgroundAttributes(Node bgNode, StaticStyleConfig style) {
		if (bgNode != null) {
			style.setBGColorRGB(bgNode.getAttributes().getNamedItem("color").getTextContent());
		}
	}

	private void extractImageAttributes(Node imgNode, StaticStyleConfig style) throws IOException {
		// if the uri does not work, try URL
		if (imgNode != null) {
			String imageUrl = imgNode.getAttributes().getNamedItem("url").getTextContent();
			if (imageUrl != null && imageUrl != "") {
				style.setImageURI(imageUrl);
			}
		}
	}

	// TODO handle exception
	private void initalizeValidatedInstance(InputStream xml) {
		try {
			// Load schema and validate
			SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema styleSchema = schemaFactory.newSchema(new StreamSource(this.getClass().getResourceAsStream("StyleSyntaxDefinition.xsd")));

			// parse and load document
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			docFactory.setIgnoringComments(true);
			docFactory.setIgnoringElementContentWhitespace(true);
			docFactory.setNamespaceAware(true);
			docFactory.setSchema(styleSchema);
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			instanceDocument = docBuilder.parse(new InputSource(xml));
			//styleSchema.newValidator().validate(new DOMSource(instanceDocument));

			// initialize xpath compiler
			xpathCompiler = XPathFactory.newInstance().newXPath();
			xpathCompiler.setNamespaceContext(nsResolver);
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}

	private XPathExpression getXPathExpressionObj(String xpath) throws XPathExpressionException {
		XPathExpression expression = null;
		// check if expression was cached
		if ((expression = compiledXPathExp.get(xpath)) == null) {
			expression = xpathCompiler.compile(xpath);
			// cache expression, will be used multiple times
			compiledXPathExp.put(xpath, expression);
		}

		return expression;
	}

	private NamespaceContext nsResolver = new NamespaceContext() {
		// Our default Schema ns uri.
		private final String schemaNamespaceURI = "http://sourceforge.net/projects/nattable/typeconfig/style/1.0";

		public String getNamespaceURI(String prefix) {
			return schemaNamespaceURI;
		}

		public String getPrefix(String namespaceURI) {
			return "n";
		}

		public Iterator<String> getPrefixes(String namespaceURI) {
			return null;
		}

	};
}
