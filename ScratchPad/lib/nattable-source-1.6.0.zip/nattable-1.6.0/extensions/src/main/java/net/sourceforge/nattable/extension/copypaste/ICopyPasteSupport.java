package net.sourceforge.nattable.extension.copypaste;

import java.util.List;

import net.sourceforge.nattable.data.DataUpdateHelper;

import org.eclipse.swt.dnd.Clipboard;

public interface ICopyPasteSupport<T> {

	public abstract void pasteSupport(List<List<Object>> rows, List<T> selectedRows, List<String> propertyNames, DataUpdateHelper<T> helper);

	/**
	 * Methods must follow java bean getters, the assumption is the methods do
	 * not need arguments.
	 * 
	 * @param dataToCopy
	 * @param propertiesToCopy
	 */
	public abstract Clipboard copySupport(List<?> dataToCopy, List<String> propertiesToCopy);

}