package net.sourceforge.nattable.extension.copypaste;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.IColumnPropertyProvider;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.IEditableRule;

import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;

public class CopyPasteEventListener<T> implements KeyListener {
	private int copyKey = 99;
	private int pasteKey = 118;

	private SelectionModel selectionModel;
	private IRowDataProvider<T> dataProvider;
	private DataUpdateHelper<T> helperObject;
	private ICopyPasteSupport<T> copyPasterSupporter;
	private IClipboardDataParser cbParser = new DefaultClipboardDataParser();
	private IPasteExecutionSupport<T> pasteCommiter;
	private ContentConfigRegistry contentConfigReg;

	public CopyPasteEventListener(SelectionModel selectionModel, IRowDataProvider<T> dataProvider, DataUpdateHelper<T> helperObject, ICopyPasteSupport<T> copyPasterSupporter,
			IPasteExecutionSupport<T> pasteCommiter, ContentConfigRegistry contentConfigReg) {
		this.selectionModel = selectionModel;
		this.dataProvider = dataProvider;
		this.copyPasterSupporter = copyPasterSupporter;
		this.pasteCommiter = pasteCommiter;
		this.helperObject = helperObject;
		this.contentConfigReg = contentConfigReg;
	}

	public void keyPressed(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
		if ((e.stateMask & SWT.CTRL) != 0) {
			if (e.keyCode == copyKey) {
				performCopy();
			} else if (e.keyCode == pasteKey) {
				if (!performPaste()) {
					MessageBox msg = new MessageBox(e.widget.getDisplay().getActiveShell(), SWT.ICON_INFORMATION | SWT.OK);
					msg.setMessage("Please select cells which are editable.");
					msg.open();
				}
			}
		}
	}

	public void performCopy() {
		copyPasterSupporter.copySupport(getSelectedRowObjects(null), getSelectedColumnProperties(null));
	}

	public boolean performPaste() {
		boolean valid = true;
		List<List<Object>> cbData = cbParser.parseClipboard(new Clipboard(Display.getDefault()));

		// collect entire set of rows to update for validation
		List<Integer> rowIndexCollector = new ArrayList<Integer>();
		List<T> rowObjects = cbData.size() > 0 ? getRowObjects(cbData.size(), rowIndexCollector) : new ArrayList<T>();

		// collect entire set of cols to update for validation
		List<Integer> columnIndexCollector = new ArrayList<Integer>();
		List<String> colProps = cbData.size() > 0 ? resolveColumnProperties(cbData.get(0).size(), columnIndexCollector) : new ArrayList<String>();

		valid = validateSelection(rowIndexCollector, columnIndexCollector);
		if (valid) {
			copyPasterSupporter.pasteSupport(cbData, rowObjects, colProps, helperObject);
			pasteCommiter.doPaste(helperObject);
		}
		return valid;
	}

	public void setCopyPasterSupporter(ICopyPasteSupport<T> copyPasterSupporter) {
		this.copyPasterSupporter = copyPasterSupporter;
	}

	/**
	 * Use this method to inject your own clip board parser. If the default @see
	 * {@link DefaultClipboardDataParser} suffices then there is no need to call
	 * this method.
	 * 
	 * @param cbParser
	 */
	public void setClipBoardParser(IClipboardDataParser cbParser) {
		this.cbParser = cbParser;
	}

	private List<T> getSelectedRowObjects(List<Integer> rowIndicesCollector) {
		List<T> data = new ArrayList<T>();
		boolean collectRows = rowIndicesCollector != null;
		for (int modelRowIndex : selectionModel.getSelectedRows()) {
			data.add(dataProvider.getRowObject(modelRowIndex));
			if (collectRows) {
				rowIndicesCollector.add(Integer.valueOf(modelRowIndex));
			}
		}
		return data;
	}

	private List<T> getRowObjects(int rowsInClipboard, List<Integer> rowIndicesCollector) {
		List<T> data = new ArrayList<T>();
		data = getSelectedRowObjects(rowIndicesCollector);
		if (data.size() < rowsInClipboard && selectionModel.getSelectedRows().length > 0) {
			int currentRow = selectionModel.getSelectedRows()[selectionModel.getSelectedRows().length - 1];
			int storedRowCount = data.size();
			for (int counter = 0; counter < (rowsInClipboard - storedRowCount); counter++) {
				if (++currentRow < dataProvider.getRowCount()) {
					data.add(dataProvider.getRowObject(currentRow));
					rowIndicesCollector.add(Integer.valueOf(currentRow));
				}
			}
		}
		return data;
	}

	private List<String> getSelectedColumnProperties(List<Integer> columnIndicesCollector) {
		List<String> properties = new ArrayList<String>();
		IColumnPropertyProvider propResolver = helperObject.getPropertyResolver();
		boolean collectColumns = columnIndicesCollector != null;
		for (int modelColumnIndex : selectionModel.getSelectedColumns()) {
			properties.add(propResolver.getPropertyName(modelColumnIndex));
			if (collectColumns) {
				columnIndicesCollector.add(Integer.valueOf(modelColumnIndex));
			}
		}
		return properties;
	}

	private List<String> resolveColumnProperties(int colsInClipboard, List<Integer> columnIndicesCollector) {
		List<String> properties = new ArrayList<String>();
		properties = getSelectedColumnProperties(columnIndicesCollector);
		if (properties.size() < colsInClipboard && selectionModel.getSelectedColumns().length > 0) {
			int currentCol = selectionModel.getSelectedColumns()[selectionModel.getSelectedColumns().length - 1];
			IColumnPropertyProvider propResolver = helperObject.getPropertyResolver();
			int storedPropertyCount = properties.size();
			for (int counter = 0; counter < (colsInClipboard - storedPropertyCount); counter++) {
				if (++currentCol < dataProvider.getColumnCount()) {
					properties.add(propResolver.getPropertyName(currentCol));
					columnIndicesCollector.add(Integer.valueOf(currentCol));
				}
			}
		}
		return properties;
	}

	/**
	 * Validation can be turned off by passing a null cell renderer TODO
	 * refactor to a better solution.
	 * 
	 * @return
	 */
	private boolean validateSelection(List<Integer> rowIndices, List<Integer> colIndices) {
		boolean valid = true;

		if (contentConfigReg != null) {
			for (int rowIndex : rowIndices) {
				for (int colIndex : colIndices) {
					String type = contentConfigReg.getConfigType(rowIndex, colIndex);
					if (type != null) {
						IEditableRule rule = contentConfigReg.getEditableRule(type);
						valid = rule != null ? rule.isEditable(rowIndex, colIndex) : false;
					}
				}
			}
		}

		return valid;
	}
}
