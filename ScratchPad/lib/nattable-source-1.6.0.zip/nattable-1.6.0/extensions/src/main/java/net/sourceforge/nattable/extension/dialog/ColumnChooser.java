package net.sourceforge.nattable.extension.dialog;

import java.util.ArrayList;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.extension.widget.ISelectionListListener;
import net.sourceforge.nattable.extension.widget.SelectionList;
import net.sourceforge.nattable.support.ColumnGroupSupport;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Spinner;

public final class ColumnChooser extends Dialog {

	private NatTable table;
	private ArrayList<ColumnEntry> hiddenColumns;
	private ArrayList<ColumnEntry> displayedColumns;
	private SelectionList selectionList;
	private Spinner columnCountSpinner;
	private final boolean withFrozenColumnOptions;
	private boolean withColumnGroups = false;

	private ColumnChooser(NatTable table, boolean withFrozenColumnOptions) {
		super(table.getShell());
		this.withFrozenColumnOptions = withFrozenColumnOptions;
		setShellStyle(SWT.RESIZE | SWT.APPLICATION_MODAL | SWT.DIALOG_TRIM);

		this.table = table;
	}

	public void dispose() {
		if (selectionList != null)
			selectionList.dispose();
		
		table = null;
	}

	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, "Done",
				true);
	}
	
	@Override
	protected Control createDialogArea(final Composite parent) {
		Composite composite = (Composite) super.createDialogArea(parent);
		GridDataFactory.fillDefaults().grab(true, true).applyTo(composite);
		
		composite.setLayout(new GridLayout(1, true));
		
		composite.getShell().setText("Column Chooser");
		initModel();
		
		createSelectionList(composite);
		
		if (withFrozenColumnOptions)
			createFrozenControl(composite);
		
		Label separator = new Label(composite, SWT.SEPARATOR | SWT.HORIZONTAL);
		GridDataFactory.fillDefaults().grab(true, false).applyTo(separator);
		
		return composite;
	}

	private void createFrozenControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new RowLayout());
		
		Label label = new Label(composite, SWT.NONE);
		label.setText("&Frozen column count:");
		
		columnCountSpinner = new Spinner(composite, SWT.WRAP | SWT.BORDER);
		columnCountSpinner.setMinimum(0);
		columnCountSpinner.setMaximum(table.getNatTableModel().getBodyColumnCount() - table.getHiddenModelBodyColumns().size());
		columnCountSpinner.setSelection(table.getNatTableModel().getFreezeColumnCount());
		columnCountSpinner.setPageIncrement(1);
		
		columnCountSpinner.addModifyListener(new ModifyListener() {

			public void modifyText(ModifyEvent e) {
				frozenColumnChanged(columnCountSpinner.getSelection());
			}
			
		});
	}

	private void createSelectionList(Composite parent) {
		selectionList = new SelectionList(parent, SWT.NONE, "Available Columns", "Selected Columns");
		selectionList.getAvailableListViewer().setSorter(new ViewerSorter());
		
		selectionList.getAvailableListViewer().add(hiddenColumns.toArray());
		
		selectionList.getSelectedListViewer().add(displayedColumns.toArray());
		
		selectionList.addSelectionListListener(new ISelectionListListener() {

			public void itemsRemoved(SelectionList selectionList,
					Object[] removedItems) {
				if (removedItems != null && removedItems.length > 0) {
					for (Object item : removedItems) {
						ColumnEntry columnEntry = (ColumnEntry) item;
						if (columnEntry.isColumnGroup) {
							table.getColumnGroupSupport().hideColumnGroup(columnEntry.getName());
						} else {
							table.hideModelBodyColumn(columnEntry.getColumn());							
						}
					}
					reindexBodyColumns();
				}
			}

			public void itemsSelected(SelectionList selectionList,
					Object[] addedItems) {
				if (addedItems != null && addedItems.length > 0) {
					for (Object item : addedItems) {
						ColumnEntry columnEntry = (ColumnEntry) item;

						if (columnEntry.isColumnGroup()) {
							table.getColumnGroupSupport().showColumnGroup(columnEntry.getName());
						} else {
							table.showModelBodyColumn(columnEntry.getColumn());
						}
					}
					reindexBodyColumns();
				}
			}

			public void itemsMoved(SelectionList selectionList,
					int[] oldIndexes, int[] newIndexes) {
				if (newIndexes != null && newIndexes.length > 0)
					reindexBodyColumns();
			}
			
		});
		
		if (withFrozenColumnOptions) {
			selectionList.addPaintListener(new PaintListener() {

				public void paintControl(PaintEvent e) {
					GC gc = e.gc;


					if (columnCountSpinner.getSelection() > 0) {
						gc.setForeground(e.display.getSystemColor(SWT.COLOR_BLUE));
						gc.setLineWidth(2);

						List list = selectionList.getSelectedListViewer().getList();
						Rectangle listBounds = list.getBounds();

						int totalFrozenHeight = list.getItemHeight() * columnCountSpinner.getSelection();
						int innerListHeight = listBounds.height - (2 * list.getBorderWidth());

						gc.drawLine(listBounds.x - 4, listBounds.y + list.getBorderWidth(),
								listBounds.x - 4, listBounds.y + Math.min(totalFrozenHeight, innerListHeight));
					}
				}

			});
		}
		
		GridDataFactory.fillDefaults().grab(true, true).applyTo(selectionList);
	}
	
	private void frozenColumnChanged(int frozenColumn) {
		table.getNatTableModel().setFreezeColumnCount(frozenColumn);
		table.reset();
		table.updateResize(true);
		selectionList.redraw();
	}
	
	private void reindexBodyColumns() {
		int[] order = table.getModelBodyColumnOrder();
		int[] visibleMask = new int [order.length];
				
		for (int i = 0; i < order.length; i++) {
			if (!table.isModelBodyColumnViewable(order[i]) && !isVisibleColumnGroup(order[i])) {
				visibleMask[i] = Integer.MIN_VALUE;
			} else {
				visibleMask[i] = order[i];
			}
		}

		Object[] selectedItems;
		if (withColumnGroups) {
			selectedItems = buildSelectedItems(selectionList.getSelectedItems());
		} else {
			selectedItems = selectionList.getSelectedItems();
		}
		
		int selectedIndex = 0;
		for (int i = 0; i < visibleMask.length; i++) {
			if (visibleMask[i] != Integer.MIN_VALUE) {
				ColumnEntry entry = (ColumnEntry) selectedItems[selectedIndex];

				order[i] = entry.getColumn();
				selectedIndex++;					
			} 
		}
		
		table.setModelBodyColumnOrder(order);
		if (columnCountSpinner != null) {
			columnCountSpinner.setMaximum(selectedItems.length);
			columnCountSpinner.setSelection(Math.min(columnCountSpinner.getSelection(), selectedItems.length));
		}
	}
	
	private Object[] buildSelectedItems(Object[] selectedItems) {
		ArrayList<ColumnEntry> entries = new ArrayList<ColumnEntry>();
		for (int i = 0; i < selectedItems.length; i++) {
			ColumnEntry entry = (ColumnEntry) selectedItems[i];
			if (entry.isColumnGroup()) {
				for (Integer groupMember : table.getColumnGroupSupport().getColumnGroupMembers(entry.getName())) {
					entries.add(new ColumnEntry(groupMember.intValue(), entry.getName(), 
							entry.isOriginallyHidden(), true));
				}
			} else {
				entries.add(entry);
			}
		}
		return entries.toArray(new Object[0]);
	}

	private boolean isVisibleColumnGroup(int modelBodyColumn) {
		if (table.isColumnGroupsEnabled()) {
			ColumnGroupSupport support = table.getColumnGroupSupport();
			if (support.isColumnInColumnGroup(modelBodyColumn)) {
				String groupName = support.getColumnGroupName(modelBodyColumn);
				java.util.List<Integer> groupMembers = support.getColumnGroupMembers(groupName);
				// if the first col in a group is visible then the group is considered to be visible
				return (table.isModelBodyColumnViewable(groupMembers.get(0).intValue()));
			}
		}
		return false;
	}

	private void initModel() {
		hiddenColumns = new ArrayList<ColumnEntry>();
		displayedColumns = new ArrayList<ColumnEntry>();
		int headerRowIndex = table.isColumnGroupsEnabled() ? 1 : 0;
		ColumnEntry entry = null;
		boolean hidden = false;
		
		for (int col : table.getModelBodyColumnOrder()) {
			if (table.isColumnGroupsEnabled() && table.getColumnGroupSupport().isColumnInColumnGroup(col)) {
				ColumnGroupSupport support = table.getColumnGroupSupport();
				String name = support.getColumnGroupName(col);
				int firstGroupCol = support.getColumnGroupMembers(name).get(0).intValue();
				hidden = !table.isModelBodyColumnViewable(firstGroupCol);
				entry = new ColumnEntry(firstGroupCol, name, hidden, true);
				withColumnGroups = true;
			} else {
				String name = table.getNatTableModel().getColumnHeaderCellRenderer().getDisplayText(headerRowIndex, col);
				hidden = !table.isModelBodyColumnViewable(col);
				entry = new ColumnEntry(col, name, hidden, false);
			}
			if (hidden) {
				if (!hiddenColumns.contains(entry))
					hiddenColumns.add(entry);
			} else if (!displayedColumns.contains(entry)) {
				displayedColumns.add(entry);
			}
		}
		
	}

	public static void open(NatTable table) {
		open(table, true);
	}
	
	public static void open(NatTable table, boolean withFrozenColumnOptions) {
		ColumnChooser chooser = new ColumnChooser(table, withFrozenColumnOptions);
		
		chooser.setBlockOnOpen(true);
		chooser.open();
	}

	static class ColumnEntry {
		private final String name;
		private final int column;
		private final boolean originallyHidden;
		private final boolean isColumnGroup;
		
		public ColumnEntry(int column, String name, boolean originallyHidden, boolean isColumnGroup) {
			this.column = column;
			this.name = name;
			this.originallyHidden = originallyHidden;
			this.isColumnGroup = isColumnGroup;
		}
		
		public int getColumn() {
			return column;
		}
		
		public String getName() {
			return name;
		}
		
		public boolean isOriginallyHidden() {
			return originallyHidden;
		}
		
		@Override
		public String toString() {
			return name;
		}
		
		public boolean isColumnGroup() {
			return isColumnGroup;
		}

		@Override
		public int hashCode() {
			return 73 * name.hashCode() + column;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (obj instanceof ColumnEntry) {
				ColumnEntry that = (ColumnEntry) obj;
				return name.equals(that.name) && column == that.column;
			}
			
			return super.equals(obj);
		}
	}
}
