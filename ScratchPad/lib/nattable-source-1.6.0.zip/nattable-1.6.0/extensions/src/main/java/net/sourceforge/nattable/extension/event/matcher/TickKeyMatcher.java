package net.sourceforge.nattable.extension.event.matcher;

import net.sourceforge.nattable.event.matcher.IKeyEventMatcher;
import net.sourceforge.nattable.extension.action.TickAction;
import net.sourceforge.nattable.extension.event.TickEventEnum;
import net.sourceforge.nattable.extension.handler.ITickableHandler;

import org.eclipse.swt.events.KeyEvent;

public class TickKeyMatcher implements IKeyEventMatcher {

	private final ITickableHandler handler;

	public TickKeyMatcher(ITickableHandler handler) {
		this.handler = handler;
	}
	
	public boolean matches(KeyEvent event) {
		return TickAction.getTickEvent(event, handler) != TickEventEnum.NONE;
	}

}
