package net.sourceforge.nattable.extension.blink;

public interface FieldChangePublisher {
	
	void addFieldChangeListener(FieldChangeListener listener);
	void removeFieldChangeListener(FieldChangeListener listener);
}
