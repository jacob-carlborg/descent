package net.sourceforge.nattable.extension.blink;

public interface FieldChangeListener {
	
	void fieldChanged(FieldChangeEvent event);
}
