package net.sourceforge.nattable.extension.search;


public enum SearchResult {
	
	FOUND,
	NOT_FOUND,
	FIND_TERMINATED;
	
	private TableCellLocation rowColumnLocation;
	
	public SearchResult setFoundLocation(int row, int column) {
		assert this == FOUND;
		assert row >= 0;
		assert column >= 0;
		this.rowColumnLocation = new TableCellLocation(row, column);
		return this;
	}
	
	public TableCellLocation getFoundLocation() {
		return rowColumnLocation;
	}
}
