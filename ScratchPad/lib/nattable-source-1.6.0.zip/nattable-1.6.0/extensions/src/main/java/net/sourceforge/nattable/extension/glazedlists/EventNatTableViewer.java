package net.sourceforge.nattable.extension.glazedlists;

import net.sourceforge.nattable.NatTable;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.TransformedList;
import ca.odell.glazedlists.event.ListEvent;
import ca.odell.glazedlists.event.ListEventListener;
import ca.odell.glazedlists.swt.GlazedListsSWT;

public class EventNatTableViewer<R> implements ListEventListener<R> {

	private TransformedList<R, R> swtSource;
	
	private final NatTable natTable;
	
	private final RedrawStrategy redrawStrategy;
	
	public EventNatTableViewer(EventList<R> source, NatTable natTable) {
		this(source, natTable, true);
	}
	
	/**
	 * @param source The source list.
	 * @param natTable The table to update.
	 * @param conflateTableUpdates Whether or not the redraws should occur via the <CODE>NatTableConflationSupport</CODE>. Default is </CODE>true</CODE>.
	 */
	@SuppressWarnings("unchecked")
	public EventNatTableViewer(EventList<R> source, NatTable natTable, boolean conflateTableUpdates) {
		this.natTable = natTable;
		this.redrawStrategy = conflateTableUpdates ? new ConflatingRedrawStrategy() : new ImmediateRedrawStrategy();
		
		swtSource = GlazedListsSWT.swtThreadProxyList(source, natTable.getDisplay());
		
		swtSource.addListEventListener(this);
	}
	
	public void listChanged(ListEvent<R> listChanges) {
		swtSource.getReadWriteLock().readLock().lock();
		try {
			if (!natTable.isDisposed()) {
				while (listChanges.next()) {
		            final int changeIndex = listChanges.getIndex();
		            final int changeType = listChanges.getType();
		            
					switch (changeType) {
					case ListEvent.INSERT:
						redrawStrategy.redrawInsertedRow(changeIndex, changeIndex);
						break;
					case ListEvent.UPDATE:
						redrawStrategy.redrawUpdatedRow(changeIndex, changeIndex);
						break;
					case ListEvent.DELETE:
						redrawStrategy.redrawDeletedRow(changeIndex, changeIndex);
						break;
					default:
						System.out.println("Unknown list event type " + changeType);
					}
				}
			}
		} finally {
			swtSource.getReadWriteLock().readLock().unlock();
		}
	}
	
	public void dispose() {
		swtSource.dispose();
	}
	
	private interface RedrawStrategy {
		void redrawInsertedRow(int fromRow, int toRow);
		void redrawUpdatedRow(int fromRow, int toRow);
		void redrawDeletedRow(int fromRow, int toRow);
	}
	
	private class ConflatingRedrawStrategy implements RedrawStrategy {
		public void redrawInsertedRow(int fromRow, int toRow) {
			natTable.getConflationSupport().redrawInsertedRow(fromRow, toRow);
		}

		public void redrawUpdatedRow(int fromRow, int toRow) {
			natTable.getConflationSupport().redrawUpdatedRow(fromRow, toRow);
		}
		
		public void redrawDeletedRow(int fromRow, int toRow) {
			natTable.getConflationSupport().redrawDeletedRow(fromRow, toRow);
		}
	}

	private class ImmediateRedrawStrategy implements RedrawStrategy {
		public void redrawInsertedRow(int fromRow, int toRow) {
			natTable.redrawInsertedBodyRow(fromRow, toRow);
		}
		
		public void redrawUpdatedRow(int fromRow, int toRow) {
			natTable.redrawUpdatedBodyRow(fromRow, toRow);
		}
		
		public void redrawDeletedRow(int fromRow, int toRow) {
			natTable.redrawDeletedBodyRow(fromRow, toRow);
		}
	}
	
}
