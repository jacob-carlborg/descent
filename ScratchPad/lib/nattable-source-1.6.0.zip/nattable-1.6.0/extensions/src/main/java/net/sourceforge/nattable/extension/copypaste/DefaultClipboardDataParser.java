package net.sourceforge.nattable.extension.copypaste;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;


/**
 * This class assumes in the clipboard the data is represented as a grid with
 * the \n character delimiting rows, and the \t character delimiting cells or
 * columns.
 * 
 */
public class DefaultClipboardDataParser implements IClipboardDataParser {

	public List<List<Object>> parseClipboard(Clipboard cb) {
		List<List<Object>> parsedData = new ArrayList<List<Object>>();
		Object contents =  cb.getContents(TextTransfer.getInstance());
		if(contents != null) {
			StringTokenizer gridData = new StringTokenizer((String)contents, "\n");
			while(gridData.hasMoreElements()) {
				StringTokenizer cellData = new StringTokenizer(gridData.nextToken(), "\t");
				List<Object>cells = new ArrayList<Object>();
				while(cellData.hasMoreElements()) {
					cells.add(cellData.nextToken());
				}
				parsedData.add(cells);
			}
		}
		return parsedData;
	}
}
