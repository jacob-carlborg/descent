package net.sourceforge.nattable.data.generator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import net.sourceforge.nattable.data.pricing.PricingDataBean;

import org.junit.Test;

public class DataGeneratorTest {

	@Test
	public void testGenerate() {
		try {
			PricingDataBean pricingDataBean = new DataGenerator<PricingDataBean>().generate(PricingDataBean.class);
			
			assertNotNull(pricingDataBean);
			assertTrue(pricingDataBean.getBid() >= 0.0d);
			assertTrue(pricingDataBean.getBid() < 10000.0d);
			
			assertTrue(pricingDataBean.getAsk() >= 0.0d);
			assertTrue(pricingDataBean.getAsk() < 10000.0d);
			
			assertTrue(pricingDataBean.getClosingPrice() >= 0.0d);
			assertTrue(pricingDataBean.getClosingPrice() < 10000.0d);
			
			assertNotNull(pricingDataBean.getPricingSource());
		} catch (GeneratorException e) {
			e.printStackTrace();
			fail(e.getMessage() + " : " + e.getCause().getMessage());
		}
	}

}
