package net.sourceforge.nattable.support;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.PotentialParameterValue;

public class ColumnTransformSupportSupplier extends ParameterSupplier {

	private static ArrayList<PotentialParameterValue> list;

	@Override
	public List<PotentialParameterValue> getValueSources(Object arg0,
			ParameterSignature arg1) {
		
		if (list == null) {
			list = new ArrayList<PotentialParameterValue>();

			list.add(PotentialParameterValue.forValue(createEmpty()));

			for (int i = 0 ; i < 2; i++) {
				int size = (int)Math.pow(100, i);
				list.add(PotentialParameterValue.forValue(createSized(size, size, 0)));
				list.add(PotentialParameterValue.forValue(createSized(size, i + 1, 2)));
				list.add(PotentialParameterValue.forValue(createSized(size, 3, 1)));
			}
		}
		
		return list;
	}
	
	private ColumnTransformSupport createEmpty() {
		ColumnTransformSupport support = new ColumnTransformSupport(null) {

			@Override
			public Set<Integer> getHiddenModelBodyColumns() {
				return Collections.emptySet();
			}

			@Override
			public int[] getModelBodyColumnOrder() {
				return new int[0];
			}

			@Override
			public boolean isModelBodyColumnViewable(int modelBodyColumn) {
				return false;
			}

			@Override
			public int modelToReorderedBodyColumn(int modelBodyColumn) {
				return modelBodyColumn;
			}

			@Override
			public int reorderedToModelBodyColumn(int reorderedBodyColumn) {
				return reorderedBodyColumn;
			}

			@Override
			public String toString() {
				return getClass().getName() + ": EMPTY";
			}
		};
		
		return support;
	}

	private ColumnTransformSupport createSized(int size, int orderMod, int hiddenMod) {
		
		final int [] columns = new int [size];
		
		Arrays.fill(columns, Integer.MIN_VALUE);
		int i = 0;
		
		for (; i < columns.length; i++) {
			int index = i % orderMod;
			
			if (columns[index] == Integer.MIN_VALUE)
				columns[index] = i;
			else
				break;
		}
		
		for (int index = 0; index < columns.length; index++) {
			if (columns[index] == Integer.MIN_VALUE) {
				columns[index] = i;
				i++;
			}
		}
		
		final Set<Integer> hiddenSet = new HashSet<Integer>();
		
		if (hiddenMod != 0) {
			for (int index = 0; index < columns.length; index++) {
				if (index % hiddenMod == 0) {
					hiddenSet.add(Integer.valueOf(index));
				}
			}
		}
		
		ColumnTransformSupport support = new ColumnTransformSupport(null) {

			@Override
			public Set<Integer> getHiddenModelBodyColumns() {
				return hiddenSet;
			}

			@Override
			public int[] getModelBodyColumnOrder() {
				return columns;
			}

			@Override
			public boolean isModelBodyColumnViewable(int modelBodyColumn) {
				return !hiddenSet.contains(Integer.valueOf(modelBodyColumn));
			}

			@Override
			public int modelToReorderedBodyColumn(int modelBodyColumn) {
				return columns[modelBodyColumn];
			}

			@Override
			public int reorderedToModelBodyColumn(int reorderedBodyColumn) {
				for (int i = 0; i < columns.length; i++) {
					if (columns[i] == reorderedBodyColumn)
						return i;
				}
				
				return -1;
			}
			
			@Override
			public String toString() {
				return getClass().getName() + ": " + Arrays.toString(columns);
			}
		};
		
		return support;
	}
}
