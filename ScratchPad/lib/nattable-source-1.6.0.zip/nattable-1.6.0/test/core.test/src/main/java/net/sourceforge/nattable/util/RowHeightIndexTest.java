package net.sourceforge.nattable.util;

import static org.junit.Assert.assertEquals;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.support.ModelDataPoint;
import net.sourceforge.nattable.support.ModelTestEnum;

import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class RowHeightIndexTest {
	
	@Theory
	public void testGetBestStartingSearchRow(
			@ModelDataPoint(rowHeight = ModelTestEnum.VARIABLE, variableRowHeight = true) INatTableModel model, int height) {
		
		RowHeightIndex rowHeightIndex = new RowHeightIndex(model);
		rowHeightIndex.update();
		
		int curHeight = 0;
		int rowIndex = 0;
		
		for (; rowIndex < model.getBodyRowCount();) {
			int rowHeight = model.getBodyRowHeight(model.isAllBodyRowsSameHeight() ? 0 : rowIndex);
			
			curHeight += rowHeight;
			
			if (curHeight < height)
				rowIndex++;
			else
				break;
		}
		
		int actual = rowHeightIndex.getBestStartingSearchRow(height);
		
		if (curHeight == 0)
			rowIndex = 0;
		else {
			if (rowIndex == model.getBodyRowCount() && rowIndex % RowHeightIndex.BASE == 0)
				rowIndex--;
			
			rowIndex -= rowIndex % RowHeightIndex.BASE;
		}

		assertEquals(rowIndex, actual, 0);
	}

	@Theory
	public void testGetHeightByStartIndex(
			@ModelDataPoint(rowHeight = ModelTestEnum.VARIABLE, variableRowHeight = true) INatTableModel model, int rowIndex) {
		RowHeightIndex rowHeightIndex = new RowHeightIndex(model);
		rowHeightIndex.update();
		
		int height = 0;
		
		for (int i = 0; i < Math.min(model.getBodyRowCount(), rowIndex); i++) {
			height += model.getBodyRowHeight(model.isAllBodyRowsSameHeight() ? 0 : i);
		}
		
		int actual = rowHeightIndex.getHeightByStartIndex(rowIndex);
		
		assertEquals(height, actual, 0);
	}

	@DataPoint
	public static final int NEGATIVE = -1;
	
	@DataPoint
	public static final int ZERO = 0;

	@DataPoint
	public static final int MAX = Integer.MAX_VALUE;

	@DataPoint
	public static final int FIVE = 5;

	@DataPoint
	public static final int TWO_THIRTY_SEVEN = 237;
	
	@DataPoint
	public static final int TEN_MILLION = 10000000;
	

}
