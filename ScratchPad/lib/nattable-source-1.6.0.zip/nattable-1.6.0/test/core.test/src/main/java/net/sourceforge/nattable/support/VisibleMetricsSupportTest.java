package net.sourceforge.nattable.support;

import static org.junit.Assert.assertEquals;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.model.INatTableModel;

import org.eclipse.swt.graphics.Rectangle;
import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.ParametersSuppliedBy;
import org.junit.experimental.theories.PotentialParameterValue;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class VisibleMetricsSupportTest {
	
	@Theory
	public void testGetVisibleModelBodyColumns(
			@ClientAreaProviderDataPoint(values = { 0, 430, 10001 }) IClientAreaProvider clientAreaProvider,
			@ModelDataPoint(columnWidth = ModelTestEnum.VARIABLE, rowHeaderColumnWidth = ModelTestEnum.VARIABLE, withFrozenColumns = true) INatTableModel model,
			@ColumnTransformSupportDataPoint ColumnTransformSupport gridTransformSupport) {
		
		Rectangle clientArea = clientAreaProvider.getClientArea();
		
		List<Integer> expected = new ArrayList<Integer>();
		
		int rowHeaderColumnCount = model.getRowHeaderColumnCount();
		int freezeColumnCount = model.getFreezeColumnCount();
		
		int widthCount = 0;
		
		for (int i = 0; i < rowHeaderColumnCount; i++) {
			int width = model.getRowHeaderColumnWidth(i);
			
			widthCount += width;
			
			if (widthCount >= clientArea.width)
				break;
		}
		
		int[] modelBodyColumnOrder = gridTransformSupport.getModelBodyColumnOrder();
		int bodyColumnCount = modelBodyColumnOrder.length;
		int bodyIndex = 0;
		
		for (int frozenIndex = 0; frozenIndex < freezeColumnCount
				&& bodyIndex < bodyColumnCount && widthCount < clientArea.width; bodyIndex++) {
			int bodyColumnIndex = modelBodyColumnOrder[bodyIndex];
			
			if (gridTransformSupport.isModelBodyColumnViewable(bodyColumnIndex)) {
				
				expected.add(Integer.valueOf(bodyColumnIndex));
				
				int bodyColumnWidth = model.getBodyColumnWidth(bodyColumnIndex);
				widthCount += bodyColumnWidth;
				frozenIndex++;
			}
		}
		
		int curX = widthCount;
		
		for (; bodyIndex < bodyColumnCount && widthCount < clientArea.width; bodyIndex++) {
			int bodyColumnIndex = modelBodyColumnOrder[bodyIndex];
			
			
			if (gridTransformSupport.isModelBodyColumnViewable(bodyColumnIndex)) {
				int bodyColumnWidth = model.getBodyColumnWidth(bodyColumnIndex);
				
				if (clientArea.x <= curX) {
					expected.add(Integer.valueOf(bodyColumnIndex));
					widthCount += bodyColumnWidth;
				}
				
				curX += bodyColumnWidth;
			}
		}
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				clientAreaProvider, model, gridTransformSupport);
		
		List<Integer> actual = support.getVisibleModelBodyColumns();

		assertEquals(expected, actual);
	}

	@Theory
	public void testGetVisibleModelBodyRows(
			@ClientAreaProviderDataPoint(values = { 0, 430, 10001 }) IClientAreaProvider clientAreaProvider,
			@ModelDataPoint(rowHeight = ModelTestEnum.VARIABLE, columnHeaderRowHeight = ModelTestEnum.VARIABLE, withFrozenRow = true, variableRowHeight = true) INatTableModel model) {
		Rectangle clientArea = clientAreaProvider.getClientArea();
		
		List<Integer> expected = new ArrayList<Integer>();
		
		int columnHeaderRowCount = model.getColumnHeaderRowCount();
		int freezeRowCount = model.getFreezeRowCount();
		int bodyRowCount = model.getBodyRowCount();

		int heightCount = 0;
		
		for (int i = 0; i < columnHeaderRowCount && clientArea.height > heightCount; i++) {
			heightCount += model.getColumnHeaderRowHeight(i);
		}
		
		int modelIndex = 0;
		for (int i = 0; i < freezeRowCount && modelIndex < bodyRowCount && clientArea.height > heightCount; i++) {
			heightCount += model.getBodyRowHeight(modelIndex);
			expected.add(Integer.valueOf(modelIndex));
			modelIndex++;
		}
		
		int curY = heightCount;
		
		for (; modelIndex < bodyRowCount && clientArea.height > heightCount; modelIndex++) {
			int height = model.getBodyRowHeight(modelIndex);
			
			if (curY >= clientArea.y) {
				heightCount += height;
				expected.add(Integer.valueOf(modelIndex));
			}
			
			curY += height;
		}
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				clientAreaProvider, model, null);
		
		List<Integer> actual = support.getVisibleModelBodyRows();
		
		assertEquals(expected, actual);
	}

	@Theory
	public void testGetTotalColumnHeaderHeight(@ModelDataPoint(rowHeight = ModelTestEnum.VARIABLE, columnHeaderRowHeight = ModelTestEnum.VARIABLE) INatTableModel model) {
		int total = 0;
		
		for (int i = 0; i < model.getColumnHeaderRowCount(); i++) {
			total += model.getColumnHeaderRowHeight(i);
		}
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				null, model, null);
		
		assertEquals(total, support.getTotalColumnHeaderHeight(), 0);
	}

	@Theory
	public void testGetBodyScrollableViewWidth(@ClientAreaProviderDataPoint(values = { 0, 430, 10001 }) IClientAreaProvider clientAreaProvider,
			@ModelDataPoint(columnWidth = ModelTestEnum.VARIABLE, rowHeaderColumnWidth = ModelTestEnum.VARIABLE, withFrozenColumns = true) INatTableModel model,
			@ColumnTransformSupportDataPoint ColumnTransformSupport gridTransformSupport) {
		Rectangle clientArea = clientAreaProvider.getClientArea();
		
		int rowHeaderWidth = 0;
		
		for (int i = 0; i < model.getRowHeaderColumnCount(); i++) {
			rowHeaderWidth += model.getRowHeaderColumnWidth(i);
		}
		
		int[] modelBodyColumnOrder = gridTransformSupport.getModelBodyColumnOrder();
		int bodyColumnCount = modelBodyColumnOrder.length;
		int bodyIndex = 0;
		int frozenWidth = 0;
		
		for (int frozenIndex = 0; frozenIndex < model.getFreezeColumnCount()
				&& bodyIndex < bodyColumnCount; bodyIndex++) {
			int bodyColumnIndex = modelBodyColumnOrder[bodyIndex];
			
			if (gridTransformSupport.isModelBodyColumnViewable(bodyColumnIndex)) {
				int bodyColumnWidth = model.getBodyColumnWidth(bodyColumnIndex);
				frozenWidth += bodyColumnWidth;
				frozenIndex++;
			}
		}
		
		int width = clientArea.width - rowHeaderWidth - frozenWidth;
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				clientAreaProvider, model, gridTransformSupport);
		
		assertEquals(Math.max(0, width), support.getBodyScrollableViewWidth(), 0);
	}

	@Theory
	public void testGetTotalRowHeaderWidth(@ModelDataPoint(rowHeaderColumnWidth = ModelTestEnum.VARIABLE) INatTableModel model) {
		int rowHeaderWidth = 0;
		
		for (int i = 0; i < model.getRowHeaderColumnCount(); i++) {
			rowHeaderWidth += model.getRowHeaderColumnWidth(i);
		}
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				null, model, null);
		
		assertEquals(rowHeaderWidth, support.getTotalRowHeaderWidth(), 0);
	}

	@Theory
	public void testGetTotalBodyHeight(@ModelDataPoint(rowHeight = ModelTestEnum.VARIABLE, columnHeaderRowHeight = ModelTestEnum.VARIABLE, withFrozenRow = true, variableRowHeight = true) INatTableModel model) {
		int height = 0;
		
		for (int i = 0; i < model.getBodyRowCount(); i++) {
			height += model.getBodyRowHeight(i);
		}
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				null, model, null);
		
		assertEquals(height, support.getTotalBodyHeight(), 0);
	}

	@Theory
	public void testGetTotalBodyWidth(@ModelDataPoint(columnWidth = ModelTestEnum.VARIABLE, rowHeaderColumnWidth = ModelTestEnum.VARIABLE, withFrozenColumns = true) INatTableModel model,
			@ColumnTransformSupportDataPoint ColumnTransformSupport gridTransformSupport) {
		int width = 0; 
		int[] modelBodyColumnOrder = gridTransformSupport.getModelBodyColumnOrder();
		
		for (int i = 0; i < modelBodyColumnOrder.length; i++) {
			int bodyColumnIndex = modelBodyColumnOrder[i];
			width += model.getBodyColumnWidth(bodyColumnIndex);
		}
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				null, model, gridTransformSupport);
		assertEquals(width, support.getTotalBodyWidth(), 0);
	}

	@Theory
	public void testGetTotalViewableBodyWidth(@ModelDataPoint(columnWidth = ModelTestEnum.VARIABLE, rowHeaderColumnWidth = ModelTestEnum.VARIABLE, withFrozenColumns = true) INatTableModel model,
			@ColumnTransformSupportDataPoint ColumnTransformSupport gridTransformSupport) {
		int width = 0; 
		int[] modelBodyColumnOrder = gridTransformSupport.getModelBodyColumnOrder();
		
		for (int i = 0; i < modelBodyColumnOrder.length; i++) {
			int bodyColumnIndex = modelBodyColumnOrder[i];
			if (gridTransformSupport.isModelBodyColumnViewable(bodyColumnIndex)) {
				width += model.getBodyColumnWidth(bodyColumnIndex);
			}
		}
		
		VisibleMetricsSupport support = new VisibleMetricsSupport(
				null, model, gridTransformSupport);
		assertEquals(width, support.getTotalViewableBodyWidth(), 0);
	}

	@Retention(RetentionPolicy.RUNTIME)
	@ParametersSuppliedBy(ClientAreaProviderSupplier.class)
	public static @interface ClientAreaProviderDataPoint {
		int[] values();
	}
	
	public static class ClientAreaProviderSupplier extends ParameterSupplier {

		@Override
		public List<PotentialParameterValue> getValueSources(Object test,
				ParameterSignature sig) {
	
			int [] values = ((ClientAreaProviderDataPoint) sig.getSupplierAnnotation()).values();
			
			List<PotentialParameterValue> list = new ArrayList<PotentialParameterValue>();
			
			boolean zeroFinished = false;
			
			for (int widthIndex = 0; widthIndex < values.length; widthIndex++) {
				for (int heightIndex = 0; heightIndex < values.length; heightIndex++) {
					
					if (zeroFinished && (values[widthIndex] == 0 || values[heightIndex] == 0))
						break;
					
					final Rectangle rect = new Rectangle(0, 0, values[widthIndex], values[heightIndex]);
					
					IClientAreaProvider provider = new IClientAreaProvider() {

						public Rectangle getClientArea() {
							return rect;
						}

						public void updateResize() {
							// no-op
						}
						
						@Override
						public String toString() {
							return rect.toString();
						}
					};
					
					list.add(PotentialParameterValue.forValue(provider));
					
					if (!zeroFinished) {
						zeroFinished = (values[widthIndex] == 0) || (values[heightIndex] == 0);
					}
				}
			}
			
			return list;
		}
		
	}
}
