package net.sourceforge.nattable.testutils;

import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.IColumnHeaderConfig;
import net.sourceforge.nattable.data.ColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnAccessor;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.data.pricing.PricingDataBeanGenerator;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

public class CoreObjectGenerator {
	public static INatTableModel getNatTableModel() {
		IColumnHeaderConfig colHeaderConfig = new DefaultColumnHeaderConfig(new ColumnHeaderLabelProvider(ColumnHeaders.getLabels()));
		IRowDataProvider<PricingDataBean> dataProvider;
		try {
			dataProvider = new ListDataProvider<PricingDataBean>(PricingDataBeanGenerator.getData(100), new ReflectiveColumnAccessor<PricingDataBean>(ColumnHeaders.getProperties()));
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		IConfigTypeResolver configTypeResolver = new IConfigTypeResolver() {

			public String getConfigType(int row, int col) {
				return null;
			}

		};

		DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider, new ContentConfigRegistry(configTypeResolver), new StyleConfigRegistry(configTypeResolver));
		
		return new DefaultNatTableModel(null, colHeaderConfig, new DefaultRowHeaderConfig(), bodyConfig);
	}
}
