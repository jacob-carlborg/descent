package net.sourceforge.nattable.support;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.renderer.ICellRenderer;

import org.easymock.classextension.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class NatTableBulkCellUpdateSupportTest {

	private static NatTable table;
	private static ISelectionValidator validator;
	@SuppressWarnings("unchecked")
	private static BulkCellUpdateSupport support;

	private static Object[] classMocks;
	private static Object[] interfaceMocks;
	private static IBulkUpdateRequestHandler requestHandler;
	private static SelectionModel selectionModel;
	private static INatTableModel natTableModel;
	private static ICellRenderer bodyCellRenderer;
	private static IBulkUpdateResponseHandler responseHandler;
	@SuppressWarnings("unchecked")
	private static IRowDataProvider rowDataProvider;
	@SuppressWarnings("unchecked")
	private static IRowIdAccessor rowIdAccessor;
	
	@SuppressWarnings("unchecked")
	@BeforeClass
	public static void beforeClass() {
		table = EasyMock.createStrictMock(NatTable.class);
		selectionModel = EasyMock.createStrictMock(SelectionModel.class);
		
		natTableModel = org.easymock.EasyMock.createStrictMock(INatTableModel.class);
		validator = org.easymock.EasyMock.createStrictMock(ISelectionValidator.class);
		requestHandler = org.easymock.EasyMock.createStrictMock(IBulkUpdateRequestHandler.class);
		responseHandler = org.easymock.EasyMock.createStrictMock(IBulkUpdateResponseHandler.class);
		bodyCellRenderer = org.easymock.EasyMock.createStrictMock(ICellRenderer.class);
		rowDataProvider = org.easymock.EasyMock.createStrictMock(IRowDataProvider.class);
		rowIdAccessor = org.easymock.EasyMock.createStrictMock(IRowIdAccessor.class);
		
		
		support = new BulkCellUpdateSupport(table, rowDataProvider, rowIdAccessor, validator);
		
		classMocks = new Object[] { table, selectionModel };
		interfaceMocks = new Object[] { validator, requestHandler,
				natTableModel, bodyCellRenderer, responseHandler,
				rowDataProvider, rowIdAccessor };
	}
	
	@Before
	public void before() {
		EasyMock.reset(classMocks);
		org.easymock.EasyMock.reset(interfaceMocks);
	}
	
	@Test
	public void bulkUpdateDoesNotInvokeHandlerWithInvalidSelection() {
		int col = 1;
		int row = 2;
		int [] columns = new int[] {col};
		int[] rows = new int[] {row};
		
		setupBulkUpdateSelection(false, null, columns, rows);
		
		replayMocks();
		assertFalse(support.bulkUpdateSelection(requestHandler, responseHandler));
		verifyMocks();
	}
	
	@Test
	public void bulkUpdateDoesNotInvokeHandlerWithNullResponse() {
		int col = 23;
		int row = 534;
		int[] columns = new int[] {col};
		int[] rows = new int[] {row};

		setupBulkUpdateSelection(true, null, columns, rows);
		
		replayMocks();
		assertFalse(support.bulkUpdateSelection(requestHandler, responseHandler));
		verifyMocks();
	}
	
	@Test
	public void bulkUpdateInvokesRequestHandler() {
		int col = 12;
		int row = 2;
		int fieldIndex = 3;
		int[] columns = new int[] {col};
		Serializable[] rows = new Serializable[] {Integer.valueOf(row)};

		BulkUpdateResponse response = new BulkUpdateResponse("newValue", BulkUpdateTypeEnum.SET);
		setupBulkUpdateSelection(true, response, columns, new int [] {row});

		table.reorderedToModelBodyColumn(col);
		EasyMock.expectLastCall().andReturn(Integer.valueOf(fieldIndex));
		
		responseHandler.applyBulkUpdate(EasyMock.eq(response), EasyMock.aryEq(rows), EasyMock.eq(fieldIndex));
		EasyMock.expectLastCall().andReturn(Boolean.TRUE);
		
		replayMocks();
		assertTrue(support.bulkUpdateSelection(requestHandler, responseHandler));
		verifyMocks();

	}
	
	@SuppressWarnings("unchecked")
	private void setupBulkUpdateSelection(boolean validSelection, BulkUpdateResponse response, int [] columns, int [] rows) {
		
		validator.isSelectionValid();
		org.easymock.EasyMock.expectLastCall().andReturn(Boolean.valueOf(validSelection));
		
		if (validSelection) {

			table.getSelectionModel();
			EasyMock.expectLastCall().andReturn(selectionModel);

			selectionModel.getSelectedColumns();
			EasyMock.expectLastCall().andReturn(columns);

			selectionModel.getSelectedRows();
			EasyMock.expectLastCall().andReturn(rows);

			table.getNatTableModel();
			EasyMock.expectLastCall().andReturn(natTableModel);

			for (int row : rows) {
				rowDataProvider.getRowObject(row);
				org.easymock.EasyMock.expectLastCall().andReturn(Integer.valueOf(row));

				rowIdAccessor.getRowId(Integer.valueOf(row));
				org.easymock.EasyMock.expectLastCall().andReturn(Integer.valueOf(row));
			}
			
			table.reorderedToModelBodyColumn(columns[0]);
			EasyMock.expectLastCall().andReturn(Integer.valueOf(columns[0]));
			
			natTableModel.getBodyCellRenderer();
			EasyMock.expectLastCall().andReturn(bodyCellRenderer);

			natTableModel.getColumnHeaderCellRenderer();
			EasyMock.expectLastCall().andReturn(bodyCellRenderer);

			bodyCellRenderer.getDisplayText(0, columns[0]);
			EasyMock.expectLastCall().andReturn("testColumn");
			
			requestHandler.bulkUpdate("testColumn", bodyCellRenderer, rows[0], columns[0]);
			org.easymock.EasyMock.expectLastCall().andReturn(response);
		}
	}
	
	private void replayMocks() {
		EasyMock.replay(classMocks);
		org.easymock.EasyMock.replay(interfaceMocks);
	}
	
	private void verifyMocks() {
		EasyMock.verify(classMocks);
		org.easymock.EasyMock.verify(interfaceMocks);
	}
	

}
