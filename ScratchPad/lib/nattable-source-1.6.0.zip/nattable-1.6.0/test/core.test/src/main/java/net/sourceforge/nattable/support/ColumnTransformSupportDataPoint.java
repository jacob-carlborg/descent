package net.sourceforge.nattable.support;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.experimental.theories.ParametersSuppliedBy;

@Retention(RetentionPolicy.RUNTIME)
@ParametersSuppliedBy(ColumnTransformSupportSupplier.class)
public @interface ColumnTransformSupportDataPoint {
	// nothing
}
