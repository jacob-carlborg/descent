package net.sourceforge.nattable.typeconfig;

import junit.framework.Assert;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.junit.Before;
import org.junit.Test;

public class StyleConfigRegistryTest {

	private StyleConfigRegistry styleConfigRegistry;

	private Display display;
	
	@Before
	public void setup() {
		styleConfigRegistry = new StyleConfigRegistry();
		display = new Shell().getDisplay();
	}
	
	// direct lookup
	
	@Test
	public void testDisplayModeDirect() {
		Color color_normal = registerBgConfig(DisplayModeEnum.NORMAL, SWT.COLOR_BLACK);
		registerBgConfig(DisplayModeEnum.SELECT, SWT.COLOR_GRAY);  // display mode distraction
		registerBgConfig(DisplayModeEnum.NORMAL, "cell", SWT.COLOR_BLUE);  // type distraction
		registerBgConfig(DisplayModeEnum.SELECT, "cell", SWT.COLOR_YELLOW);  // type distraction
		
		Assert.assertEquals(color_normal, styleConfigRegistry.getStyleConfig(DisplayModeEnum.NORMAL.toString(), null).getBackgroundColor(0, 0));
		Assert.assertEquals(color_normal, styleConfigRegistry.getStyleConfig(DisplayModeEnum.NORMAL.toString(), "other_cell").getBackgroundColor(0, 0));
	}
	
	@Test
	public void testTypeDirect() {
		registerBgConfig(DisplayModeEnum.NORMAL, SWT.COLOR_BLACK);  // display mode distraction
		registerBgConfig(DisplayModeEnum.SELECT, SWT.COLOR_GRAY);  // display mode distraction
		registerBgConfig(DisplayModeEnum.NORMAL, "cell", SWT.COLOR_BLUE);  // type distraction
		Color color_cell_select = registerBgConfig(DisplayModeEnum.SELECT, "cell", SWT.COLOR_YELLOW);
		
		Assert.assertEquals(color_cell_select, styleConfigRegistry.getStyleConfig(DisplayModeEnum.SELECT.toString(), "cell").getBackgroundColor(0, 0));
	}
	
	// direct lookup of subtypes
	
	@Test
	public void testSubDisplayModeDirect() {
		registerBgConfig(DisplayModeEnum.NORMAL, SWT.COLOR_BLACK);  // display mode distraction
		Color color_select = registerBgConfig(DisplayModeEnum.SELECT, SWT.COLOR_GRAY);
		registerBgConfig(DisplayModeEnum.NORMAL, "cell", SWT.COLOR_BLUE);  // type distraction
		registerBgConfig(DisplayModeEnum.SELECT, "cell", SWT.COLOR_YELLOW);  // type distraction
		
		Assert.assertEquals(color_select, styleConfigRegistry.getStyleConfig(DisplayModeEnum.SELECT.toString(), null).getBackgroundColor(0, 0));
		Assert.assertEquals(color_select, styleConfigRegistry.getStyleConfig(DisplayModeEnum.SELECT.toString(), "other_cell").getBackgroundColor(0, 0));
	}
	
	@Test
	public void testSubTypeDirect() {
		registerBgConfig(DisplayModeEnum.NORMAL, SWT.COLOR_BLACK);  // display mode distraction
		registerBgConfig(DisplayModeEnum.SELECT, SWT.COLOR_GRAY);  // display mode distraction
		registerBgConfig(DisplayModeEnum.NORMAL, "cell", SWT.COLOR_BLUE);  // type distraction
		registerBgConfig(DisplayModeEnum.SELECT, "cell", SWT.COLOR_YELLOW);  // type distraction
		Color color_sub_cell_select = registerBgConfig(DisplayModeEnum.SELECT, "sub-cell", SWT.COLOR_MAGENTA);
		styleConfigRegistry.registerSuperType("sub-cell", "cell");
		
		Assert.assertEquals(color_sub_cell_select, styleConfigRegistry.getStyleConfig(DisplayModeEnum.SELECT.toString(), "sub-cell").getBackgroundColor(0, 0));
	}
	
	// defaulting
	
	@Test
	public void testDisplayModeDefaulting() {
		Color color_normal = registerBgConfig(DisplayModeEnum.NORMAL, SWT.COLOR_BLACK);
		registerBgConfig(DisplayModeEnum.NORMAL, "cell", SWT.COLOR_BLUE);  // type distraction
		registerBgConfig(DisplayModeEnum.SELECT, "cell", SWT.COLOR_YELLOW);  // type distraction
		
		Assert.assertEquals(color_normal, styleConfigRegistry.getStyleConfig(DisplayModeEnum.SELECT.toString(), null).getBackgroundColor(0, 0));
		Assert.assertEquals(color_normal, styleConfigRegistry.getStyleConfig(DisplayModeEnum.SELECT.toString(), "other_cell").getBackgroundColor(0, 0));
	}
	
	@Test
	public void testTypeDefaulting() {
		registerBgConfig(DisplayModeEnum.NORMAL, SWT.COLOR_BLACK);  // display mode distraction
		registerBgConfig(DisplayModeEnum.SELECT, SWT.COLOR_GRAY);  // display mode distraction
		registerBgConfig(DisplayModeEnum.NORMAL, "cell", SWT.COLOR_BLUE);  // type distraction
		Color color_cell_select = registerBgConfig(DisplayModeEnum.SELECT, "cell", SWT.COLOR_YELLOW);
		registerBgConfig(DisplayModeEnum.NORMAL, "sub-cell", SWT.COLOR_MAGENTA);  // sub-type distraction
		styleConfigRegistry.registerSuperType("sub-cell", "cell");
		
		Assert.assertEquals(color_cell_select, styleConfigRegistry.getStyleConfig(DisplayModeEnum.SELECT.toString(), "sub-cell").getBackgroundColor(0, 0));
	}
	
	///////////////////////////////////////////////////////////////////////////
	
	private Color registerBgConfig(DisplayModeEnum displayModeEnum, int colorIndex) {
		Color color = getSystemColor(display, colorIndex);
		IStyleConfig style = new DummyStyleConfig(color, null, null, null);
		styleConfigRegistry.registerDefaultStyleConfig(displayModeEnum.toString(), style);
		
		return color;
	}
	
	private Color registerBgConfig(DisplayModeEnum displayModeEnum, String configType, int colorIndex) {
		Color color = getSystemColor(display, colorIndex);
		IStyleConfig style = new DummyStyleConfig(color, null, null, null);
		styleConfigRegistry.registerStyleConfig(displayModeEnum.toString(), configType, style);
		
		return color;
	}
	
	private class DummyStyleConfig implements IStyleConfig {

		private static final long serialVersionUID = 1L;

		private Color bgColor;
		
		private Color fgColor;
		
		private Font font;
		
		private Image image;
		
		DummyStyleConfig(Color bgColor, Color fgColor, Font font, Image image) {
			this.bgColor = bgColor;
			this.fgColor = fgColor;
			this.font = font;
			this.image = image;
		}
		
		public Color getBackgroundColor(int row, int col) {
			return bgColor;
		}

		public Color getForegroundColor(int row, int col) {
			return fgColor;
		}

		public Font getFont(int row, int col) {
			return font;
		}

		public Image getImage(int row, int col) {
			return image;
		}
		
	}
	
	private Color getSystemColor(Display display, int colorIndex) {
		return display.getSystemColor(colorIndex);
	}
	
}
