package net.sourceforge.nattable.typeconfig;

import junit.framework.Assert;

import net.sourceforge.nattable.typeconfig.content.DefaultDisplayTypeConverter;

import org.junit.Test;

public class DefaultDisplayTypeConverterTest {

	private DefaultDisplayTypeConverter defaultDisplayTypeConverter = new DefaultDisplayTypeConverter();
	
	@Test
	public void testNonNullDataToDisplay() {
		Assert.assertEquals("abc", defaultDisplayTypeConverter.dataValueToDisplayValue("abc"));
	}
	
	@Test
	public void testNullDataToDisplay() {
		Assert.assertEquals("", defaultDisplayTypeConverter.dataValueToDisplayValue(null));
	}
	
	@Test
	public void testNonNullDisplayToData() {
		Assert.assertEquals("abc", defaultDisplayTypeConverter.displayValueToDataValue("abc"));
	}
	
	@Test
	public void testNullDisplayToData() {
		Assert.assertEquals(null, defaultDisplayTypeConverter.displayValueToDataValue(""));
	}
	
}
