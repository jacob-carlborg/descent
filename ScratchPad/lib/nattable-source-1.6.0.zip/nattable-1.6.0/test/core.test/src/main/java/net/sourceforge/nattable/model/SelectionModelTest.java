package net.sourceforge.nattable.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.eclipse.swt.graphics.Rectangle;
import org.junit.Before;
import org.junit.Test;


public class SelectionModelTest {

	private SelectionModel model;

	@Before
	public void before() {
		model = new SelectionModel();
	}
	
	@Test
	public void isCellSelected() {
		assertFalse("Empty model should have no selection.", model.isSelected(0, 0));
	}
	
	@Test
	public void addCellSelection() {
		model.addSelection(0,0);
		
		assertTrue("Failed to add selection.", model.isSelected(0, 0));
	}
	
	@Test
	public void addMultipleAdjacentCellSelection() {
		
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				model.addSelection(row, col);
			}
		}
		
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				assertTrue("Failed to add selection [" + row + ", " + col + "]", model.isSelected(row, col));
			}
		}
		
	}
	
	@Test
	public void addMultipleDisjointCellSelection() {
		model.addSelection(0, 0);
		model.addSelection(0, 2);
		model.addSelection(2, 0);
		
		assertTrue("Failed to add selection [0, 0]", model.isSelected(0, 0));
		assertTrue("Failed to add selection [0, 2]", model.isSelected(0, 2));
		assertTrue("Failed to add selection [2, 0]", model.isSelected(2, 0));
		
		assertFalse("Added too many cells to the range", model.isSelected(0, 1));
		assertFalse("Added too many cells to the range", model.isSelected(1, 0));
		assertFalse("Added too many cells to the range", model.isSelected(1, 1));
		assertFalse("Added too many cells to the range", model.isSelected(1, 2));
		assertFalse("Added too many cells to the range", model.isSelected(2, 1));
		assertFalse("Added too many cells to the range", model.isSelected(2, 2));
		assertFalse("Added too many cells to the range", model.isSelected(3, 3));
	}
	
	@Test
	public void clearSelection() {
		model.addSelection(0, 0);
		
		model.clearSelection();
		
		assertFalse("Failed to clear selection", model.isSelected(0, 0));
	}
	
	@Test
	public void addRangeSelection() {
		int col = 2;
		int row = 3;
		int numCols = 4;
		int numRows = 5;
		model.addSelection(new Rectangle(col, row, numCols, numRows));
		
		for (int rowIndex = row; rowIndex < row + numRows; rowIndex++) {
			for (int colIndex = col; colIndex < col + numCols; colIndex++) {
				assertTrue("Failed to add range [" + rowIndex + ", " + colIndex + "]", model.isSelected(rowIndex, colIndex));
			}
		}
		
		assertFalse("Added too many cells from range", model.isSelected(row + numRows, col));
	}

	@Test
	public void addNullRangeSelection() {
		model.addSelection(null);
		
		assertTrue(model.isEmpty());
	}
	
	@Test
	public void removeSingleCell() {
		model.addSelection(0, 0);
		model.removeSelection(0, 0);
		
		assertFalse("Failed to remove selection [0, 0].", model.isSelected(0, 0));
	}
	
	@Test
	public void removeSingleCellAfterMultipleAdds() {
		model.addSelection(0, 0);
		model.addSelection(1, 1);
		model.addSelection(1, 2);
		model.addSelection(3, 2);
		model.removeSelection(1, 1);
		
		assertFalse("Failed to remove selection [1, 1].", model.isSelected(1, 1));
	}
	
	private void removeSingleCellFromRange(int col, int row, int numCols, int numRows, int removedRow, int removedColumn) {
		model.addSelection(new Rectangle(col, row, numCols, numRows));

		model.removeSelection(removedRow, removedColumn);
		
		assertFalse("Failed to remove selection [" + removedRow + ", " + removedColumn + "]", model.isSelected(removedRow, removedColumn));
		
		for (int rowIndex = row; rowIndex < row + numRows; rowIndex++) {
			for (int colIndex = col; colIndex < col + numCols; colIndex++) {
				
				if (!(rowIndex == removedRow && colIndex == removedColumn))
					assertTrue("Failed to add range [" + rowIndex + ", " + colIndex + "]", model.isSelected(rowIndex, colIndex));
			}
		}
	}
	
	private void removeRangeFromRange(int col, int row, int numCols,
			int numRows, int removedRow, int removedColumn, int removedNumCols,
			int removedNumRows) {
		model.addSelection(new Rectangle(col, row, numCols, numRows));
		
		Rectangle removedSelection = new Rectangle(removedColumn, removedRow, removedNumCols, removedNumRows);
		model.removeSelection(removedSelection);
		
		for (int rowIndex = removedRow; rowIndex < removedRow + removedNumRows; rowIndex++) {
			for (int colIndex = removedColumn; colIndex < removedColumn + removedNumCols; colIndex++) {
				assertFalse("Failed to remove selection [" + rowIndex + ", " + colIndex + "]", model.isSelected(rowIndex, colIndex));
			}
		}
		
		for (int rowIndex = row; rowIndex < row + numRows; rowIndex++) {
			for (int colIndex = col; colIndex < col + numCols; colIndex++) {
				
				if (!removedSelection.contains(colIndex, rowIndex))
					assertTrue("Failed to add range [" + rowIndex + ", " + colIndex + "]", model.isSelected(rowIndex, colIndex));
			}
		}
		
	}
	
	@Test
	public void removeSingleCellFrom1x1Range() {
		int col = 2;
		int row = 3;
		int numCols = 1;
		int numRows = 1;
		
		int removedColumn = 2;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeSingleCellFromBeginning1x10Range() {
		int col = 2;
		int row = 3;
		int numCols = 10;
		int numRows = 1;
		
		int removedColumn = 2;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeSingleCellFromEnd1x10Range() {
		int col = 2;
		int row = 3;
		int numCols = 10;
		int numRows = 1;
		
		int removedColumn = 11;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}

	@Test
	public void removeSingleCellFromMiddle1x10Range() {
		int col = 2;
		int row = 3;
		int numCols = 10;
		int numRows = 1;
		
		int removedColumn = 8;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeSingleCellFromBeginning10x1Range() {
		int col = 2;
		int row = 3;
		int numCols = 1;
		int numRows = 10;
		
		int removedColumn = 2;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeSingleCellFromEnd10x1Range() {
		int col = 2;
		int row = 3;
		int numCols = 1;
		int numRows = 10;
		
		int removedColumn = 2;
		int removedRow = 12;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}

	@Test
	public void removeSingleCellFromMiddle10x1Range() {
		int col = 2;
		int row = 3;
		int numCols = 1;
		int numRows = 10;
		
		int removedColumn = 2;
		int removedRow = 7;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeTopLeftFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 2;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeTopRightFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 4;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeTopMiddleFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 3;
		int removedRow = 3;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeBottomLeftFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 2;
		int removedRow = 6;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeBottomRightFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 4;
		int removedRow = 6;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeBottomMiddleFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 3;
		int removedRow = 6;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeMidLeftFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 2;
		int removedRow = 5;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeMidRightFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 4;
		int removedRow = 5;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void removeMidMiddleFrom3x4Range() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 3;
		int removedRow = 5;
		
		removeSingleCellFromRange(col, row, numCols, numRows, removedRow, removedColumn);
	}
	
	@Test
	public void getSelectedRows() {
		int [] rows = new int [] {
				1,2,3,5,67,7,4
		};
		
		for (int row : rows) {
			model.addSelection(row, row % 3);
		}
		
		int [] selectedRows = model.getSelectedRows();
		
		Arrays.sort(rows);
		
		assertEquals(Arrays.toString(rows), Arrays.toString(selectedRows));
	}
	
	@Test
	public void getSelectedColumns() {
		int [] columns = new int [] {
				1,2,3,5,67,7,4
		};
		
		for (int column : columns) {
			model.addSelection(column % 3, column);
		}
		
		int [] selectedColumns = model.getSelectedColumns();
		
		Arrays.sort(columns);
		
		assertEquals(Arrays.toString(columns), Arrays.toString(selectedColumns));
	}
	
	@Test
	public void removeFromEmptySelection() {
		Rectangle removedSelection = new Rectangle(0, 0, 10, 10);
		model.removeSelection(removedSelection);
		
		assertTrue("Removal from empty selection failed.", model.isEmpty());
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				assertFalse("Selection was not removed [" + i + ", " + j + "]", model.isSelected(i, j));
			}
		}
	}
	
	@Test
	public void removeTopRange() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 4;
		
		int removedColumn = 2;
		int removedRow = 2;
		int removedNumCols = 3;
		int removedNumRows = 3;
		
		removeRangeFromRange(col, row, numCols, numRows, removedRow, removedColumn, removedNumCols, removedNumRows);
	}

	@Test
	public void removeMidRange() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 10;
		
		int removedColumn = 2;
		int removedRow = 7;
		int removedNumCols = 3;
		int removedNumRows = 3;
		
		removeRangeFromRange(col, row, numCols, numRows, removedRow, removedColumn, removedNumCols, removedNumRows);
	}
	
	@Test
	public void removeBottomRange() {
		int col = 2;
		int row = 3;
		int numCols = 3;
		int numRows = 10;
		
		int removedColumn = 2;
		int removedRow = 7;
		int removedNumCols = 3;
		int removedNumRows = 7;
		
		removeRangeFromRange(col, row, numCols, numRows, removedRow, removedColumn, removedNumCols, removedNumRows);
	}

	@Test
	public void removeLeftRange() {
		int col = 2;
		int row = 3;
		int numCols = 6;
		int numRows = 4;
		
		int removedColumn = 1;
		int removedRow = 3;
		int removedNumCols = 3;
		int removedNumRows = 4;
		
		removeRangeFromRange(col, row, numCols, numRows, removedRow, removedColumn, removedNumCols, removedNumRows);
	}
	
	@Test
	public void removeMiddleRange() {
		int col = 2;
		int row = 3;
		int numCols = 6;
		int numRows = 4;
		
		int removedColumn = 4;
		int removedRow = 3;
		int removedNumCols = 2;
		int removedNumRows = 4;
		
		removeRangeFromRange(col, row, numCols, numRows, removedRow, removedColumn, removedNumCols, removedNumRows);
		
	}

	@Test
	public void removeRightRange() {
		int col = 2;
		int row = 3;
		int numCols = 6;
		int numRows = 4;
		
		int removedColumn = 5;
		int removedRow = 3;
		int removedNumCols = 5;
		int removedNumRows = 4;
		
		removeRangeFromRange(col, row, numCols, numRows, removedRow, removedColumn, removedNumCols, removedNumRows);
		
	}
	
	@Test
	public void removeTopFromTwoRows() {
		int col = 0;
		int row = 0;
		int numCols = 10;
		int numRows = 2;
		
		int removedColumn = col;
		int removedRow = row;
		int removedNumCols = numCols;
		int removedNumRows = 1;
		
		removeRangeFromRange(col, row, numCols, numRows, removedRow, removedColumn, removedNumCols, removedNumRows);
	}
}
