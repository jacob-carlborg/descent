package net.sourceforge.nattable.support;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import net.sourceforge.nattable.GridRegionEnum;
import net.sourceforge.nattable.GridRegionEnumDataPoint;
import net.sourceforge.nattable.model.INatTableModel;

import org.junit.BeforeClass;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class RegionMetricsSupportTest {

	private static RegionMetricsSupport support;

	@BeforeClass
	public static void beforeClass() {
		support = new RegionMetricsSupport();
	}

	@Theory
	public void testModelGridToRegionRow(
			@GridRegionEnumDataPoint GridRegionEnum gridRegion,
			int modelGridRow, @ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		if (gridRegion == GridRegionEnum.CORNER
				|| gridRegion == GridRegionEnum.COLUMN_HEADER) {
			assertEquals("top of the table, so no translation is required",
					modelGridRow, support.modelGridToRegionRow(gridRegion,
							modelGridRow));
		} else {
			assertEquals(
					"need to translate by the number of rows in the column header",
					modelGridRow - model.getColumnHeaderRowCount(), support
							.modelGridToRegionRow(gridRegion, modelGridRow), 0);
		}
	}

	@Theory
	public void testModelGridToRegionColumn(
			@GridRegionEnumDataPoint GridRegionEnum gridRegion,
			int modelGridColumn, @ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		if (gridRegion == GridRegionEnum.CORNER
				|| gridRegion == GridRegionEnum.ROW_HEADER) {
			assertEquals(
					"left part of the table, so no translation is required",
					modelGridColumn, support.modelGridToRegionColumn(
							gridRegion, modelGridColumn));
		} else {
			assertEquals(
					"need to translate by the number of columns in the row header",
					modelGridColumn - model.getRowHeaderColumnCount(), support
							.modelGridToRegionColumn(gridRegion,
									modelGridColumn), 0);
		}
	}

	@Theory
	public void testModelBodyToGridRow(int modelBodyRow,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		assertEquals(
				"need to translate model body row by number of column header rows",
				modelBodyRow + model.getColumnHeaderRowCount(), support
						.modelBodyToGridRow(modelBodyRow));
	}

	@Theory
	public void testModelBodyToGridColumn(int modelBodyCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		assertEquals(
				"need to translate model body col by number of row header columns",
				modelBodyCol + model.getRowHeaderColumnCount(), support
						.modelBodyToGridColumn(modelBodyCol));
	}

	@Theory
	public void testIsModelHeaderColumn(int modelGridCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		boolean actualValue = support.isModelHeaderColumn(modelGridCol);

		if (modelGridCol < model.getRowHeaderColumnCount() && modelGridCol >= 0) {
			assertTrue(
					"grid column indexes less than row header column count should indicate a header column",
					actualValue);
		} else {
			assertFalse(
					"grid column indexes >= row header column count should not indicate a header column",
					actualValue);
		}

	}

	@Theory
	public void testIsModelBodyColumn(int modelGridCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		boolean actualValue = support.isModelBodyColumn(modelGridCol);

		if (modelGridCol >= model.getRowHeaderColumnCount()
				&& (modelGridCol < model.getRowHeaderColumnCount()
						+ model.getBodyColumnCount()) &&
						modelGridCol >= 0) {
			assertTrue(actualValue);
		} else {
			assertFalse(actualValue);
		}

	}

	@Theory
	public void testIsModelHeaderRow(int modelGridRow,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		boolean actualValue = support.isModelHeaderRow(modelGridRow);

		if (modelGridRow < model.getColumnHeaderRowCount() && modelGridRow >= 0)
			assertTrue(actualValue);
		else
			assertFalse(actualValue);
	}

	@Theory
	public void testIsModelBodyRow(int gridRow,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		boolean actualValue = support.isModelBodyRow(gridRow);

		if (gridRow >= model.getColumnHeaderRowCount()
				&& (gridRow < model.getColumnHeaderRowCount()
						+ model.getBodyRowCount()) && gridRow >= 0)
			assertTrue(actualValue);
		else
			assertFalse(actualValue);
	}

	@Theory
	public void testIsModelCornerCell(int modelGridRow, int modelGridCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		assertEquals(Boolean.valueOf(modelGridRow >= 0 && modelGridCol >= 0 &&
				modelGridRow < model
				.getColumnHeaderRowCount()
				&& modelGridCol < model.getRowHeaderColumnCount()), Boolean
				.valueOf(support.isModelCornerCell(modelGridRow, modelGridCol)));
	}

	@Theory
	public void testIsModelColumnHeaderCell(int modelGridRow, int modelGridCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		assertEquals(Boolean.valueOf(modelGridRow >= 0 && modelGridCol >= 0 &&
				modelGridRow < model.getColumnHeaderRowCount() &&
				modelGridCol >= model.getRowHeaderColumnCount() && 
				modelGridCol < model.getRowHeaderColumnCount() + model.getBodyColumnCount()),
				Boolean.valueOf(support.isModelColumnHeaderCell(modelGridRow, modelGridCol)));
	}

	@Theory
	public void testIsModelRowHeaderCell(int modelGridRow, int modelGridCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		assertEquals(Boolean.valueOf(modelGridRow >= 0 && modelGridCol >= 0 &&
				modelGridRow >= model.getColumnHeaderRowCount() &&
				modelGridRow < model.getColumnHeaderRowCount() + model.getBodyRowCount() &&
				modelGridCol < model.getRowHeaderColumnCount()),
				Boolean.valueOf(support.isModelRowHeaderCell(modelGridRow, modelGridCol)));
	}

	@Theory
	public void testIsModelBodyCell(int modelGridRow, int modelGridCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		assertEquals(Boolean.valueOf(modelGridRow >= 0 && modelGridCol >= 0 &&
				modelGridCol >= model.getRowHeaderColumnCount() &&
				modelGridCol < model.getRowHeaderColumnCount() + model.getBodyColumnCount() &&
				modelGridRow >= model.getColumnHeaderRowCount() &&
				modelGridRow < model.getColumnHeaderRowCount() + model.getBodyRowCount()),
				Boolean.valueOf(support.isModelBodyCell(modelGridRow, modelGridCol)));
	}

	@Theory
	public void testGetRegion(int gridRow, int gridCol,
			@ModelDataPoint INatTableModel model) {
		support.setNatTableModel(model);

		GridRegionEnum expected = null;

		if (gridRow >= 0 && gridCol >= 0) {
			if (gridRow < model.getColumnHeaderRowCount()
					&& gridCol < model.getRowHeaderColumnCount()) {
				expected = GridRegionEnum.CORNER;
			} else if (gridRow < model.getColumnHeaderRowCount() &&
					gridCol >= model.getRowHeaderColumnCount() &&
					gridCol < model.getRowHeaderColumnCount() + model.getBodyColumnCount()) {
				expected = GridRegionEnum.COLUMN_HEADER;
			} else if (gridCol < model.getRowHeaderColumnCount() &&
					gridRow >= model.getColumnHeaderRowCount() &&
					gridRow < model.getColumnHeaderRowCount() + model.getBodyRowCount()) {
				expected = GridRegionEnum.ROW_HEADER;
			} else if (gridRow < model.getBodyRowCount() + model.getColumnHeaderRowCount()
					&& gridCol < model.getBodyColumnCount() + model.getRowHeaderColumnCount()) {
				expected = GridRegionEnum.BODY;
			}
		}

		assertEquals("unexpected region", expected, support.getRegion(gridRow,
				gridCol));
	}

	@DataPoint
	public static final int NEGATIVE = -1;
	
	@DataPoint
	public static final int ZERO = 0;

	@DataPoint
	public static final int ONE = 1;

	@DataPoint
	public static final int FIVE = 5;

	@DataPoint
	public static final int TEN_THOUSAND = 10000;
	
	@DataPoint
	public static final int BIG = Integer.MAX_VALUE;
}
