package net.sourceforge.nattable.typeconfig;

import junit.framework.Assert;

import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.DefaultDisplayTypeConverter;
import net.sourceforge.nattable.typeconfig.content.IDisplayTypeConverter;

import org.junit.Before;
import org.junit.Test;

public class ConfigurationRegistryDisplayTypeConverterTest {

	private ContentConfigRegistry contentConfigRegistry;
	
	private IDisplayTypeConverter dtc1 = new DummyDisplayTypeConverter();
	
	@Before
	public void setup() {
		contentConfigRegistry = new ContentConfigRegistry();
		contentConfigRegistry.registerDisplayTypeConverter("alpha", dtc1);
	}
	
	@Test
	public void testGetDisplayTypeConverter() {
		Assert.assertEquals(dtc1, contentConfigRegistry.getDisplayTypeConverter("alpha"));
	}
	
	@Test
	public void testDefaultDisplayTypeConverter() {
		Assert.assertEquals(DefaultDisplayTypeConverter.class, contentConfigRegistry.getDisplayTypeConverter("zero").getClass());
	}
	
	@Test
	public void testSuperDisplayTypeConverter() {
		contentConfigRegistry.registerSuperType("sub-alpha", "alpha");
		contentConfigRegistry.registerSuperType("sub-sub-alpha", "sub-alpha");
		contentConfigRegistry.registerSuperType("alpha1", "alpha");
		
		Assert.assertEquals(dtc1, contentConfigRegistry.getDisplayTypeConverter("sub-alpha"));
		Assert.assertEquals(dtc1, contentConfigRegistry.getDisplayTypeConverter("sub-sub-alpha"));
		Assert.assertEquals(dtc1, contentConfigRegistry.getDisplayTypeConverter("alpha1"));
	}
	
	///////////////////////////////////////////////////////////////////////////
	
	private class DummyDisplayTypeConverter implements IDisplayTypeConverter {

		public Object dataValueToDisplayValue(Object dataValue) {
			return null;
		}

		public Object displayValueToDataValue(Object displayValue) {
			return null;
		}
		
	}
	
}
