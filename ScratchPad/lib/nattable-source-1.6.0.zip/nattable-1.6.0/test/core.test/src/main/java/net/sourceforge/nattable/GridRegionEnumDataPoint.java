package net.sourceforge.nattable;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.experimental.theories.ParametersSuppliedBy;

@Retention(RetentionPolicy.RUNTIME)
@ParametersSuppliedBy(GridRegionEnumSupplier.class)
public @interface GridRegionEnumDataPoint {
	// marker
}
