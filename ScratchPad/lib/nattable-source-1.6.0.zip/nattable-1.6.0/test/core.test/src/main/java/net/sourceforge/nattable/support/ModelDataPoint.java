package net.sourceforge.nattable.support;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.experimental.theories.ParametersSuppliedBy;

@Retention(RetentionPolicy.RUNTIME)
@ParametersSuppliedBy(ModelSupplier.class)
public @interface ModelDataPoint {
	ModelTestEnum columnWidth() default ModelTestEnum.NONE;

	ModelTestEnum rowHeaderColumnWidth() default ModelTestEnum.NONE;

	ModelTestEnum rowHeight() default ModelTestEnum.NONE;

	ModelTestEnum columnHeaderRowHeight() default ModelTestEnum.NONE;
	
	boolean withFrozenColumns() default false;
	
	boolean withFrozenRow() default false;
	
	boolean variableRowHeight() default false;
}
