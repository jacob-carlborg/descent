package net.sourceforge.nattable;

import java.util.ArrayList;
import java.util.List;

import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.PotentialParameterValue;

public class GridRegionEnumSupplier extends ParameterSupplier {

	@Override
	public List<PotentialParameterValue> getValueSources(Object test,
			ParameterSignature sig) {
		List<PotentialParameterValue> values = new ArrayList<PotentialParameterValue>();
		
		for (GridRegionEnum e : GridRegionEnum.values()) {
			values.add(PotentialParameterValue.forValue(e));
		}
		
		return values;
	}

	
}
