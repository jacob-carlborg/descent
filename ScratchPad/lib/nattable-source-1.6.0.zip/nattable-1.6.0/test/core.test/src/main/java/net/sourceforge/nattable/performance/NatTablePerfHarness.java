package net.sourceforge.nattable.performance;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.generator.NatTableDataGenerator;
import net.sourceforge.nattable.model.DefaultNatTableModel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class NatTablePerfHarness extends Shell {
	
	public NatTablePerfHarness(String dataFileName, Display display, int style) {
		super(display, style);
		
		createContents(dataFileName);
		final GridLayout gridLayout = new GridLayout();
		setLayout(gridLayout);
	}
	
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	
	private void createContents(String dataFileName) {
		setText("NatTable Perf Harness");
		setSize(5000, 1000);

		final Composite composite = new Composite(this, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		composite.setLayout(new FillLayout());

		NatTableDataGenerator dataGenerator = new NatTableDataGenerator();
		long start, stop;
		start = System.currentTimeMillis();
		IDataProvider dataProvider = dataGenerator.loadData(dataFileName);
		stop = System.currentTimeMillis();
		System.out.println((stop - start) + " milliseconds to load " + dataFileName);
		start = System.currentTimeMillis();
		DefaultRowHeaderConfig rowConfig = new DefaultRowHeaderConfig();
		rowConfig.setRowHeaderColumnCount(1);
		
		DefaultNatTableModel natModel = new DefaultNatTableModel();
		natModel.setBodyConfig(new DefaultBodyConfig(dataProvider));
		natModel.getBodyConfig().getColumnWidthConfig().setDefaultSize(75);
		natModel.getBodyConfig().getRowHeightConfig().setDefaultSize(20);
		natModel.setRowHeaderConfig(rowConfig);
		natModel.setFullRowSelection(true);
		natModel.setEnableMoveColumn(true);
		natModel.getBodyConfig().getColumnWidthConfig().setDefaultResizable(true);
		new NatTable(composite, SWT.BORDER | SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, natModel);
		stop = System.currentTimeMillis();
		System.out.println((stop - start) + " milliseconds to load data into NatTable");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length == 0) {
			System.err.println("Missing input file.");
			System.exit(-1);
		}
		try {
			Display display = Display.getDefault();
			NatTablePerfHarness shell = new NatTablePerfHarness(args[0], display, SWT.SHELL_TRIM);
			shell.setLayout(new GridLayout());
			shell.open();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		} catch (	Exception e) {
			e.printStackTrace();

		}
	}
}
