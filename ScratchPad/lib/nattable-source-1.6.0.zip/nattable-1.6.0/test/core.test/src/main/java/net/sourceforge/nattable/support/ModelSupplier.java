/**
 * 
 */
package net.sourceforge.nattable.support;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import net.sourceforge.nattable.model.DefaultNatTableModel;

import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.PotentialParameterValue;

public class ModelSupplier extends ParameterSupplier {

	private static final int [] NUMBERS = new int [] {
		0, 1, 10000};
	
	private static final HashMap<ModelDataPoint, List<PotentialParameterValue>> cache = new HashMap<ModelDataPoint, List<PotentialParameterValue>>();
	
	@Override
	public List<PotentialParameterValue> getValueSources(Object test,
			ParameterSignature sig) {
		ModelDataPoint dataPoint = (ModelDataPoint) sig.getSupplierAnnotation();

		if (cache.containsKey(dataPoint))
			return cache.get(dataPoint);
		
		List<PotentialParameterValue> values = new ArrayList<PotentialParameterValue>();

		ModelTestEnum[] modelTestEnums = ModelTestEnum.values();
		
		for (int rowHeaderColumnCountIndex = 0; rowHeaderColumnCountIndex < NUMBERS.length; rowHeaderColumnCountIndex++) {
			for (int columnHeaderRowCountIndex = 0; columnHeaderRowCountIndex < NUMBERS.length; columnHeaderRowCountIndex++) {
				for (int bodyRowCountIndex = 0; bodyRowCountIndex < NUMBERS.length; bodyRowCountIndex++) {
					for (int bodyColumnCountIndex = 0; bodyColumnCountIndex < NUMBERS.length; bodyColumnCountIndex++) {
						int rowHeaderColumnCount = NUMBERS[rowHeaderColumnCountIndex];
						int columnHeaderRowCount = NUMBERS[columnHeaderRowCountIndex];
						int bodyRowCount = rowHeaderColumnCount + NUMBERS[bodyRowCountIndex];
						int bodyColumnCount = columnHeaderRowCount + NUMBERS[bodyColumnCountIndex];

						for (int columnWidth = 0; columnWidth <= ModelTestEnum.getIndex(dataPoint.columnWidth()); columnWidth++) {
							for (int rowHeaderColumnWidth = 0; rowHeaderColumnWidth <= ModelTestEnum.getIndex(dataPoint.rowHeaderColumnWidth()); rowHeaderColumnWidth++) {
								for (int rowHeight = 0; rowHeight <= ModelTestEnum.getIndex(dataPoint.rowHeight()); rowHeight++) {
									for (int columnHeaderRowHeight = 0; columnHeaderRowHeight <= ModelTestEnum.getIndex(dataPoint.columnHeaderRowHeight()); columnHeaderRowHeight++) {
										
										for (int frozenColumnsIndex = 0; frozenColumnsIndex < NUMBERS.length; frozenColumnsIndex++) {
											
											for (int frozenRowsIndex = 0; NUMBERS[frozenColumnsIndex] <= NUMBERS[bodyColumnCountIndex]
													&& frozenRowsIndex < NUMBERS.length; frozenRowsIndex++) {
												
												if (NUMBERS[frozenRowsIndex] <= NUMBERS[bodyRowCountIndex]) {
													addToList(values, rowHeaderColumnCount, columnHeaderRowCount, bodyRowCount, bodyColumnCount,
															modelTestEnums[columnWidth], modelTestEnums[rowHeaderColumnWidth],
															modelTestEnums[rowHeight], modelTestEnums[columnHeaderRowHeight],
															NUMBERS[frozenColumnsIndex], NUMBERS[frozenRowsIndex], false);
													
													if (dataPoint.variableRowHeight())
														addToList(values, rowHeaderColumnCount, columnHeaderRowCount, bodyRowCount, bodyColumnCount,
																modelTestEnums[columnWidth], modelTestEnums[rowHeaderColumnWidth],
																modelTestEnums[rowHeight], modelTestEnums[columnHeaderRowHeight],
																NUMBERS[frozenColumnsIndex], NUMBERS[frozenRowsIndex], true);
												}
												
												if (!dataPoint.withFrozenRow())
													break;
											}
											
											if (!dataPoint.withFrozenColumns())
												break;
										}
										
									}
								}
							}
						}
						
					}
				}
			}
		}
		
		cache.put(dataPoint, values);
		
		return values;
	}
	
	private void addToList(List<PotentialParameterValue> list,
			final int rowHeaderColumnCount, final int columnHeaderRowCount,
			final int bodyRowCount, final int bodyColumnCount,
			final ModelTestEnum columnWidth,
			final ModelTestEnum rowHeaderColumnWidth,
			final ModelTestEnum rowHeight,
			final ModelTestEnum columnHeaderRowHeight,
			final int frozenColumnCount,
			final int frozenRowCount,
			final boolean sameRowHeight) {
		DefaultNatTableModel model = new DefaultNatTableModel() {
			@Override
			public int getRowHeaderColumnCount() {
				return rowHeaderColumnCount;
			}
			
			@Override
			public int getColumnHeaderRowCount() {
				return columnHeaderRowCount;
			}
			
			@Override
			public int getBodyColumnCount() {
				return bodyColumnCount;
			}
			
			@Override
			public int getBodyRowCount() {
				return bodyRowCount;
			}
			
			@Override
			public String toString() {
				return "[rowHeaderColumnCount: " + rowHeaderColumnCount
						+ "][columnHeaderRowCount: " + columnHeaderRowCount
						+ "][bodyColumnCount: " + bodyColumnCount
						+ "][bodyRowCount: " + bodyRowCount + "][columnWidth: "
						+ columnWidth + "][rowHeaderColumnWidth; "
						+ rowHeaderColumnWidth + "][rowHeight: " + rowHeight
						+ "][columnHeaderRowHeight: " + columnHeaderRowHeight
						+ "][frozenColumnCount: " + frozenColumnCount
						+ "][frozenRowCount: " + frozenRowCount + "]";
			}
			
			private int getSize(int seed, ModelTestEnum e) {
				if (e == ModelTestEnum.VARIABLE) {
					if (seed % 7 == 0)
						return 0;
					
					return (int) Math.pow(10, seed % 5);
				}
				
				return 0;
			}
			
			@Override
			public int getBodyColumnWidth(int col) {
				return getSize(col, columnWidth);
			}
			
			@Override
			public int getRowHeaderColumnWidth(int col) {
				return getSize(col, rowHeaderColumnWidth);
			}
			
			@Override
			public int getBodyRowHeight(int row) {
				return getSize(row, rowHeight);
			}
			
			@Override
			public int getColumnHeaderRowHeight(int row) {
				return getSize(row, columnHeaderRowHeight);
			}
			
			@Override
			public int getFreezeColumnCount() {
				return frozenColumnCount;
			}
			
			@Override
			public int getFreezeRowCount() {
				return frozenRowCount;
			}
			
			@Override
			public boolean isAllBodyRowsSameHeight() {
				return sameRowHeight;
			}
			
			@Override
			public int getInitialBodyRowHeight(int row) {
				return getBodyRowHeight(row);
			}
		};
		
		list.add(PotentialParameterValue.forValue(model));
	}
}