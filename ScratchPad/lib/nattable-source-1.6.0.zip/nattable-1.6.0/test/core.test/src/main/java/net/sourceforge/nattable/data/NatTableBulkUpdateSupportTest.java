package net.sourceforge.nattable.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;
import net.sourceforge.nattable.data.pricing.DataUpdateHelperCreator;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.data.pricing.PricingDataBeanGenerator;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;

import org.junit.Before;
import org.junit.Test;

public class NatTableBulkUpdateSupportTest {
	private static final int TOTAL = 10;
	private DataUpdateHelper<PricingDataBean> helper;
	private List<Serializable> rowIds;

	@Before
	public void init() {
		ContentConfigRegistry contentConfigRegistry = new ContentConfigRegistry();
		contentConfigRegistry.registerValidator("alias", new IDataValidator() {

			public boolean validate(Object oldValue, Object newValue) {
				return ((Double) newValue).doubleValue() < 20;
			}

		});
		helper = DataUpdateHelperCreator.getUpdateHelper(contentConfigRegistry);
	}
	
	@Test
	public void startBulkUpdateTransaction() {

		DefaultBulkUpdateSupport<PricingDataBean> bulkUpdater = (DefaultBulkUpdateSupport<PricingDataBean>)helper.getBulkUpdate();
		List<PricingDataBean> existingData = PricingDataBeanGenerator.getData(TOTAL * TOTAL);		

		// compile data
		createUpdateListFromClipboard(bulkUpdater);
		// add half of the copied data to the list, other half will be inserts		
		for (int i = 0; i < TOTAL / 2; i++) {
			PricingDataBean bean = existingData.get(i);
			bean.setIsin((String) rowIds.get(i));
		}

		
		// simulates obtaining lock on underlying list prior to committing
		// updates
		synchronized (existingData) {
			bulkUpdater.commitUpdates(existingData, helper);
		}
		// assert the list contains the inserts
		Assert.assertEquals(TOTAL * TOTAL + TOTAL / 2, existingData.size());
	}

	private void createUpdateListFromClipboard(IBulkUpdateSupport<PricingDataBean> updater) {
		// describe which properties to paste into
		List<String> props = new ArrayList<String>();
		props.add("isin");
		props.add("pricingModel");
		props.add("ask");

		List<PricingDataBean> gridData = PricingDataBeanGenerator.getData(TOTAL);
		rowIds = new ArrayList<Serializable>();
		for (PricingDataBean bean : gridData) {
			List<Object> cells = new ArrayList<Object>();
			Serializable id = (Serializable) bean.getIsin();
			rowIds.add(id);
			cells.add(id);
			cells.add(bean.getPricingModel());
			cells.add(Double.valueOf(bean.getAsk()));
			updater.addUpdates(id, cells, props, helper);
		}
	}
}
