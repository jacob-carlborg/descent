package net.sourceforge.nattable.typeconfig;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import junit.framework.Assert;

import org.junit.Test;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class StyleSyntaxSchemaLoaderTest {
	@Test
	public void testRGBRegularExpression() {
		String rgbCorrectPatterns[] = new String[] { "0,0,0", "255,255,255", "1,23,45", "2,234,123", "243,13,2", "1,4,1" };
		for(String rgbPattern : rgbCorrectPatterns) {
			Assert.assertTrue(Pattern.matches("(((\\d{1,2})|(1\\d{2})|(2[0-4]\\d)|(25[0-5])),){2}((\\d{1,2})|(1\\d{2})|(2[0-4]d)|(25[0-5]))", rgbPattern));
		}
		String rgbInCorrectPatterns[] = new String[] { "25555,255", "1232,23,45", "2 234 123", "243,13,1122", "1,4,2311" };
		for(String rgbPattern : rgbInCorrectPatterns) {
			Assert.assertFalse(Pattern.matches("(((\\d{1,2})|(1\\d{2})|(2[0-4]\\d)|(25[0-5])),){2}((\\d{1,2})|(1\\d{2})|(2[0-4]d)|(25[0-5]))", rgbPattern));
		}
	}
	
	@Test
	public void uniqueStyleDefForTypeXpathExprConstraintTest()throws Exception{
		XPath xpath = XPathFactory.newInstance().newXPath();
		xpath.setNamespaceContext(nsContext);
		Assert.assertEquals("NORMAL",(((NodeList)xpath.evaluate("t:grid/t:types/t:type/t:styles/t:style/@mode", getInputSource(), XPathConstants.NODESET)).item(0).getNodeValue()));
	}
	
	private InputSource getInputSource() throws Exception {
		return new InputSource(getClass().getResourceAsStream("styles.xml"));
	}
	
	private NamespaceContext nsContext = new NamespaceContext() {
		private Map<String, String>namespaces = new HashMap<String, String>();
		{
			namespaces.put("", "http://sourceforge.net/projects/nattable/typeconfig/style/1.0");
		}

		public String getNamespaceURI(String prefix) {
			return namespaces.get("");
		}

		public String getPrefix(String namespaceURI) {
			return "";
		}

		public Iterator<String> getPrefixes(String namespaceURI) {
			return namespaces.keySet().iterator();
		}
		
	};
}
