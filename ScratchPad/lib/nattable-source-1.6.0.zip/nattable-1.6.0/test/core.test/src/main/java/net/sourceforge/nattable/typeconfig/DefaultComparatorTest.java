package net.sourceforge.nattable.typeconfig;

import junit.framework.Assert;

import net.sourceforge.nattable.typeconfig.content.DefaultComparator;

import org.junit.Test;

public class DefaultComparatorTest {

	private DefaultComparator defaultComparator = DefaultComparator.getInstance();

	@Test
	public void testCompareNonNullComparables() {
		Assert.assertEquals("abc".compareTo("abc"), defaultComparator.compare("abc", "abc"));
		Assert.assertEquals("abc".compareTo("def"), defaultComparator.compare("abc", "def"));
		Assert.assertEquals("def".compareTo("abc"), defaultComparator.compare("def", "abc"));
	}

	@Test
	public void testCompareNullAB() {
		Assert.assertEquals(0, defaultComparator.compare(null, null));
	}

	@Test
	public void testCompareNullA() {
		Assert.assertEquals(-1, defaultComparator.compare(null, "abc"));
	}

	@Test
	public void testCompareNullB() {
		Assert.assertEquals(1, defaultComparator.compare("abc", null));
	}

	@Test
	public void testCompareNonComparables() {
		Assert.assertEquals(0, defaultComparator.compare(new Object(), new Object()));
	}
}
