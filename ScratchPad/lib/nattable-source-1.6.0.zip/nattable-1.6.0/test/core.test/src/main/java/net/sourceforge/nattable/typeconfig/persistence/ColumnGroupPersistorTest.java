package net.sourceforge.nattable.typeconfig.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.Assert;

import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.support.ColumnGroupSupport;
import net.sourceforge.nattable.support.ColumnTransformSupport;
import net.sourceforge.nattable.testutils.CoreObjectGenerator;

import org.junit.Before;
import org.junit.Test;

public class ColumnGroupPersistorTest {
	
	private ColumnGroupSupport colGroups;
	
	private ColumnGroupPersistor persistor;
	
	@Before
	public void init() {
		colGroups = initColumnGroups();
		persistor = new ColumnGroupPersistor(colGroups);
	}
	
	@Test
	public void persistAndRestoreBlankColumnGroups() throws Exception{
		File tmpStoreFile = getTmpFile();
		
		saveColumnGroupSettings(tmpStoreFile);
		
		colGroups = null;
		persistor = null;
		init();
		
		restoreColumnGroupSettings(tmpStoreFile);
		
		Assert.assertEquals(0, colGroups.getColumnGroupModelIndices().size());
	}
	
	@Test
	public void persistAndRestoreExpandedColumnGroups() throws Exception {
		File tmpStoreFile = getTmpFile();
		loadColumnGroups();
		reorderColumns();
		
		Map<String, List<Integer>> columnGroupModelIndices = new HashMap<String, List<Integer>>();
		columnGroupModelIndices.putAll(colGroups.getColumnGroupModelIndices());
		Assert.assertTrue(columnGroupModelIndices.size() > 0);
		
		Map<Integer, String> modelColumnToGroupMap = new HashMap<Integer, String>();
		modelColumnToGroupMap.putAll(colGroups.getModelColumnToGroupMap());
		Assert.assertTrue(modelColumnToGroupMap.size() > 0);
		
		Set<String> expandedColumns = new HashSet<String>();
		expandedColumns.addAll(colGroups.getExpandedColumnGroups());
		Assert.assertTrue(expandedColumns.size() > 0);
		
		saveColumnGroupSettings(tmpStoreFile);
		init();
		Assert.assertEquals(0, colGroups.getColumnGroupModelIndices().size());
		Assert.assertEquals(0, colGroups.getModelColumnToGroupMap().size());
		Assert.assertEquals(0, colGroups.getExpandedColumnGroups().size());
		restoreColumnGroupSettings(tmpStoreFile);
		
		Assert.assertEquals(columnGroupModelIndices.size(), colGroups.getColumnGroupModelIndices().size());
		for(String colGroup : columnGroupModelIndices.keySet()) {
			List<Integer> colIndices = columnGroupModelIndices.get(colGroup);
			List<Integer> restoredColIndcies = colGroups.getColumnGroupModelIndices().get(colGroup);
			for(int index=0; index < colIndices.size(); index++) {
				Assert.assertEquals(colIndices.get(index), restoredColIndcies.get(index));
			}
		}
		Assert.assertEquals(modelColumnToGroupMap.size(), colGroups.getModelColumnToGroupMap().size());
		for(Integer modelIndex : modelColumnToGroupMap.keySet()) {
			Assert.assertEquals(modelColumnToGroupMap.get(modelIndex), colGroups.getModelColumnToGroupMap().get(modelIndex));
		}
		Assert.assertEquals(expandedColumns.size(), colGroups.getExpandedColumnGroups().size());
		for(String column : expandedColumns) {
			colGroups.getExpandedColumnGroups().contains(column);
		}
		Assert.assertEquals(colGroups.isEnableAddColumns(), true);
		Assert.assertEquals(colGroups.isEnableColumnRemoval(), false);
		Assert.assertEquals(colGroups.isEnableReorderColumnGroup(), true);
	}
	
	private void loadColumnGroups() {
		Set<Integer> indices = new HashSet<Integer>();
		ColumnHeaders[] columns = ColumnHeaders.values();
		for(int groupIndex = 0; groupIndex < 2; groupIndex++) {
			List<Integer>colIndices = new ArrayList<Integer>();
			for(int colIndex = 0; colIndex < 3; colIndex++) {
				int randomColIndex = (int)(Math.random() *10) % (ColumnHeaders.values().length); 
				randomColIndex += groupIndex  * (ColumnHeaders.values().length/3);				
				if(!indices.contains(Integer.valueOf(randomColIndex))) {
					indices.add(Integer.valueOf(randomColIndex));
					colIndices.add(Integer.valueOf(columns[randomColIndex].ordinal()));
				}				
			}
			colGroups.addColumnGroup("Column Group " + groupIndex, colIndices);
		}
	}
	
	private void reorderColumns() {
		colGroups.reorderModelBodyColumn(5, 10);
		Map<String, List<Integer>> columnGroupModelIndices = new HashMap<String, List<Integer>>();
		columnGroupModelIndices.putAll(colGroups.getColumnGroupModelIndices());
		
		//move columns inside group
		Map<String, Integer> columnsToMoveMap = new HashMap<String, Integer>(2);
		for(String colGroup : columnGroupModelIndices.keySet()) {
			List<Integer> colIndices = columnGroupModelIndices.get(colGroup);
			for(int index=0; index < colIndices.size(); index++) {
				colGroups.reorderModelBodyColumn(index, colIndices.get(colIndices.size()-1).intValue());
				if(columnsToMoveMap.size() < 2) {
					columnsToMoveMap.put(colGroup, colIndices.get(index));
				}
			}
		}
		
		//move columns between groups
		for(String colGroup : columnGroupModelIndices.keySet()) {
			for(String fromColGroup : columnsToMoveMap.keySet()) {
				if(!colGroup.equals(fromColGroup)) {
					colGroups.moveColumnBetweenGroups(colGroup, 
							columnsToMoveMap.get(fromColGroup).intValue(), 
							colGroup, 
							colGroups.getColumnGroupMembers(colGroup).get(0).intValue());
				}
			}
		}
		
		//expand columns
		for(String columnGroup : columnsToMoveMap.keySet()) {
			colGroups.expandColumnGroup(columnGroup);
		}
	}
	
	private void restoreColumnGroupSettings(File tmpStoreFile) throws FileNotFoundException, IOException {
		//restore data
		FileInputStream in = new FileInputStream(tmpStoreFile);
		try {
			persistor.load(in);
		} finally {
			in.close();
		}
	}

	private void saveColumnGroupSettings(File tmpStoreFile) throws FileNotFoundException, IOException {
		//store data
		FileOutputStream out = new FileOutputStream(tmpStoreFile);
		try {
			persistor.save(out);			
		} finally{
			out.close();
		}
	}
	
	private ColumnGroupSupport initColumnGroups() {
		ColumnGroupSupport colGroups = new ColumnGroupSupport(new ColumnTransformSupport(CoreObjectGenerator.getNatTableModel().getBodyConfig()));
		colGroups.setEnableAddColumns(true);
		colGroups.setEnableColumnRemoval(false);
		colGroups.setEnableReorderColumnGroup(true);
		
		return colGroups;
	}
	
	private File getTmpFile() throws IOException {
		return File.createTempFile("colGroups", "store");
	}
}
