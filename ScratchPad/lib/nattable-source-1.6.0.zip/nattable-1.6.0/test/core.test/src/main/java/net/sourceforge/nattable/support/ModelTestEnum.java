package net.sourceforge.nattable.support;

public enum ModelTestEnum {

	NONE,
//	FIXED,
	VARIABLE;
	
	public static int getIndex(ModelTestEnum e) {
		ModelTestEnum[] values = values();
		for (int i = 0; i < values.length; i++) {
			if (values[i] == e)
				return i;
		}
		
		return -1;
	}
	
}
