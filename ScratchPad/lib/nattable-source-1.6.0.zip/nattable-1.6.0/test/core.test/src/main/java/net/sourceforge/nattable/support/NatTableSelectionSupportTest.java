package net.sourceforge.nattable.support;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.testutils.CoreObjectGenerator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class NatTableSelectionSupportTest {

	private SelectionModel model;
	private NatTable natTable;
	private Shell shell;
	private Display display;

	@Before
	public void setUpBefore() throws Exception {
		display = Display.getDefault();
		shell = new Shell(display);
		
		shell.setSize(1038, 300);
		shell.setLayout(new GridLayout());
		Composite tableComposite = new Composite( shell, SWT.NONE);
		tableComposite.setLayout(new FillLayout());
		tableComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		
		natTable = new NatTable(tableComposite, SWT.BORDER | SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, CoreObjectGenerator.getNatTableModel());
		shell.open();
		shell.layout();
		
		model = natTable.getSelectionModel();
	}
	
	@After
	public void tearDown() throws Exception {
		model.clearSelection();
		shell.dispose();
		display.dispose();
	}

	private void verifySelection(Rectangle selection) {
		ArrayList<Rectangle> list = new ArrayList<Rectangle>();
		list.add(selection);
		verifySelection(list);
	}
	
	private void verifySelection(List<Rectangle> selection) {
		int columnCount = natTable.getNatTableModel().getBodyColumnCount();
		int rowCount = natTable.getNatTableModel().getBodyRowCount();
		
		for (int row = 0; row < rowCount; row++) {
			for (int col = 0; col < columnCount; col++) {
				if (isInSelection(selection, row, col))
					assertTrue("Failed to select [" + row + ", " + col + "]", model.isSelected(row, col));
				else
					assertFalse("Failed to unselect [" + row + ", " + col + "]", model.isSelected(row, col));
			}
		}
	}
	
	private boolean isInSelection(List<Rectangle> selection, int row, int col) {
		if (selection != null) {
			for (Rectangle r : selection) {
				if (r.contains(col, row)) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	private Rectangle getColumnSelection(int column) {
		int rowCount = natTable.getNatTableModel().getBodyRowCount();
		
		return new Rectangle(column, 0, 1, rowCount);
	}
	
	private Rectangle getColumnSelection(int startColumn, int endColumn) {
		int rowCount = natTable.getNatTableModel().getBodyRowCount();
		
		return new Rectangle(Math.min(startColumn, endColumn), 0, Math.abs(startColumn - endColumn) + 1, rowCount);
	}
	
	private Rectangle getRowSelection(int row) {
		int columnCount = natTable.getNatTableModel().getBodyColumnCount();
		
		return new Rectangle(0, row, columnCount, 1);
	}
	
	private Rectangle getRowSelection(int startRow, int endRow) {
		int columnCount = natTable.getNatTableModel().getBodyColumnCount();
		
		return new Rectangle(0, Math.min(startRow, endRow), columnCount, Math.abs(startRow - endRow) + 1);
	}

	private Rectangle getCellSelection(int rowIndex, int columnIndex) {
		return new Rectangle(columnIndex, rowIndex, 1, 1);
	}
	
	private Rectangle getCellSelection(int startRowIndex, int startColumnIndex,
			int endRowIndex, int endColumnIndex) {
		int row = Math.min(startRowIndex, endRowIndex);
		int col = Math.min(startColumnIndex, endColumnIndex);
		int numRows = Math.abs(startRowIndex - endRowIndex) + 1;
		int numCols = Math.abs(startColumnIndex - endColumnIndex) + 1;
		
		return new Rectangle(col, row, numCols, numRows);
	}
	
	@Test
	public void setSelectedRow() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		
		verifySelection(getRowSelection(rowIndex));
	}

	@Test
	public void setSelectedCell() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		
		verifySelection(getCellSelection(rowIndex, columnIndex));
	}
	
	@Test
	public void setSelectedRowShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = true;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex);

		selectionSupport.setSelectedCell(rowIndex + 4, columnIndex, withShiftMask, withControlMask);
		
		verifySelection(getRowSelection(rowIndex, rowIndex + 4));
	}
	
	@Test
	public void setSelectedCellShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = true;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.setSelectedCell(rowIndex + 4, columnIndex + 3, withShiftMask, withControlMask);
		
		verifySelection(getCellSelection(rowIndex, columnIndex, rowIndex + 4, columnIndex + 3));
	}
	
	@Test
	public void setSelectedRowControl() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = true;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex);

		selectionSupport.setSelectedCell(rowIndex + 4, columnIndex, withShiftMask, withControlMask);
		
		ArrayList<Rectangle> selection = new ArrayList<Rectangle>();
		
		selection.add(getRowSelection(rowIndex));
		selection.add(getRowSelection(rowIndex + 4));
		
		verifySelection(selection);
	}
	
	@Test
	public void setSelectedCellControl() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = true;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.setSelectedCell(rowIndex + 4, columnIndex - 2, withShiftMask, withControlMask);
		
		ArrayList<Rectangle> selection = new ArrayList<Rectangle>();
		
		selection.add(getCellSelection(rowIndex, columnIndex));
		selection.add(getCellSelection(rowIndex + 4, columnIndex - 2));
		
		verifySelection(selection);
	}
	
	@Test
	public void setSelectedRowControlShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = true;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex);

		selectionSupport.setSelectedCell(rowIndex + 4, columnIndex, withShiftMask, withControlMask);
		
		selectionSupport.setSelectedCell(rowIndex + 6, columnIndex, true, withControlMask);
		
		ArrayList<Rectangle> selection = new ArrayList<Rectangle>();
		
		selection.add(getRowSelection(rowIndex));
		selection.add(getRowSelection(rowIndex + 4, rowIndex + 6));
		
		verifySelection(selection);
	}
	
	@Test
	public void setSelectedCellControlShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = true;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.setSelectedCell(rowIndex + 4, columnIndex, withShiftMask, withControlMask);
		
		selectionSupport.setSelectedCell(rowIndex + 6, columnIndex, true, withControlMask);
		
		ArrayList<Rectangle> selection = new ArrayList<Rectangle>();
		
		selection.add(getCellSelection(rowIndex, columnIndex));
		selection.add(getCellSelection(rowIndex + 4, columnIndex, rowIndex + 6, columnIndex));
		
		verifySelection(selection);
	}
	
	@Test
	public void moveUpSingleRow() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveUp(withShiftMask, withControlMask);

		verifySelection(getRowSelection(rowIndex - 1));
	}
	
	@Test
	public void moveUpSingleCell() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveUp(withShiftMask, withControlMask);
		
		verifySelection(getCellSelection(rowIndex - 1, columnIndex));
	}
	
	@Test
	public void moveUpMultiRow() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveUp(withShiftMask, withControlMask);
		
		verifySelection(getRowSelection(rowIndex - 1));
	}
	
	@Test
	public void moveUpMultiCell() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveUp(withShiftMask, withControlMask);
		
		verifySelection(getCellSelection(rowIndex - 1, columnIndex));
	}
	
	@Test
	public void moveUpMultiRowShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = true;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveUp(withShiftMask, withControlMask);
		verifySelection(getRowSelection(rowIndex, rowIndex - 1));

		selectionSupport.moveUp(withShiftMask, withControlMask);
		verifySelection(getRowSelection(rowIndex, rowIndex - 2));
	}
	
	@Test
	public void moveUpMultiCellShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = true;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveUp(withShiftMask, withControlMask);
		verifySelection(getCellSelection(rowIndex, columnIndex, rowIndex - 1, columnIndex));

		selectionSupport.moveUp(withShiftMask, withControlMask);
		verifySelection(getCellSelection(rowIndex, columnIndex, rowIndex - 2, columnIndex));
	}
	
	@Test
	public void moveDownSingleRow() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveDown(withShiftMask, withControlMask);

		verifySelection(getRowSelection(rowIndex + 1));
	}
	
	@Test
	public void moveDownSingleCell() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveDown(withShiftMask, withControlMask);
		
		verifySelection(getCellSelection(rowIndex + 1, columnIndex));
	}
	
	@Test
	public void moveDownMultiRow() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveDown(withShiftMask, withControlMask);
		
		verifySelection(getRowSelection(rowIndex + 1));
	}
	
	@Test
	public void moveDownMultiCell() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveDown(withShiftMask, withControlMask);
		
		verifySelection(getCellSelection(rowIndex + 1, columnIndex));
	}
	
	@Test
	public void moveDownMultiRowShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = true;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveDown(withShiftMask, withControlMask);
		verifySelection(getRowSelection(rowIndex, rowIndex + 1));

		selectionSupport.moveDown(withShiftMask, withControlMask);
		verifySelection(getRowSelection(rowIndex, rowIndex + 2));
	}
	
	@Test
	public void moveDownMultiCellShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = true;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveDown(withShiftMask, withControlMask);
		verifySelection(getCellSelection(rowIndex, columnIndex, rowIndex + 1, columnIndex));
		
		selectionSupport.moveDown(withShiftMask, withControlMask);
		verifySelection(getCellSelection(rowIndex, columnIndex, rowIndex + 2, columnIndex));
	}
	
	@Test
	public void moveLeftCell() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveLeft(withShiftMask, withControlMask);
		verifySelection(getCellSelection(rowIndex, columnIndex - 1));
	}
	
	@Test
	public void moveLeftColumn() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.COLUMN, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveLeft(withShiftMask, withControlMask);
		verifySelection(getColumnSelection(columnIndex - 1));
	}
	
	@Test
	public void moveRightCell() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveRight(withShiftMask, withControlMask);
		verifySelection(getCellSelection(rowIndex, columnIndex + 1));
	}
	
	@Test
	public void moveRightColumn() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.COLUMN, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		selectionSupport.setSelectedCell(rowIndex, columnIndex);
		
		selectionSupport.moveRight(withShiftMask, withControlMask);
		verifySelection(getColumnSelection(columnIndex + 1));
	}
	
	@Test
	public void setSelectedRowShiftUnselectControl() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.ROW, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = true;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex);

		selectionSupport.setSelectedCell(rowIndex + 4, columnIndex, withShiftMask, withControlMask);
		
		selectionSupport.toggleCell(rowIndex + 2, columnIndex, false, true);
		
		List<Rectangle> selections = new ArrayList<Rectangle>();
		selections.add(getRowSelection(rowIndex, rowIndex + 1));
		selections.add(getRowSelection(rowIndex + 3, rowIndex + 4));
		
		verifySelection(selections);
	}
	
	@Test
	public void setSelectedColumn() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.COLUMN, SelectionModeEnum.SINGLE);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		
		verifySelection(getColumnSelection(columnIndex));
	}
	
	@Test
	public void setSelectedColumnShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.COLUMN, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		selectionSupport.setSelectedCell(rowIndex, 6, true, withControlMask);
		
		verifySelection(getColumnSelection(columnIndex, 6));
	}
	
	@Test
	public void setSelectedColumnShiftUnselect() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.COLUMN, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		selectionSupport.setSelectedCell(rowIndex, 6, true, withControlMask);
		
		selectionSupport.toggleCell(rowIndex, columnIndex, false, true);
		selectionSupport.toggleCell(rowIndex, 7, false, true);
		
		verifySelection(getColumnSelection(columnIndex + 1, 7));
	}
	
	@Test
	public void setSelectedColumnControl() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.COLUMN, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		selectionSupport.setSelectedCell(rowIndex, 6, withShiftMask, !withControlMask);
		
		ArrayList<Rectangle> selections = new ArrayList<Rectangle>();
		selections.add(getColumnSelection(columnIndex));
		selections.add(getColumnSelection(6));
		
		verifySelection(selections);
	}
	
	@Test
	public void setSelectedColumnControlShift() {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.COLUMN, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		selectionSupport.setSelectedCell(rowIndex, 6, withShiftMask, !withControlMask);
		selectionSupport.setSelectedCell(rowIndex, 8, !withShiftMask, !withControlMask);
		
		ArrayList<Rectangle> selections = new ArrayList<Rectangle>();
		selections.add(getColumnSelection(columnIndex));
		selections.add(getColumnSelection(6, 8));
		
		verifySelection(selections);
	}
	
	@Test
	public void selectColumns() throws Exception {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		
		selectionSupport.selectColumns(new int[] {1,5,6});
		
		ArrayList<Rectangle> selections = new ArrayList<Rectangle>();
		selections.add(getColumnSelection(1));
		selections.add(getColumnSelection(5, 6));
		
		verifySelection(selections);
		
	}
	
	@Test
	public void clearSelection() throws Exception {
		SelectionSupport selectionSupport = new SelectionSupport(natTable, SelectionTypeEnum.CELL, SelectionModeEnum.MULTI);
		
		boolean withShiftMask = false;
		boolean withControlMask = false;
		
		int rowIndex = 3;
		int columnIndex = 4;
		
		selectionSupport.setSelectedCell(rowIndex, columnIndex, withShiftMask, withControlMask);
		
		selectionSupport.clear();
		
		verifySelection((List<Rectangle>)null);
	}
}
