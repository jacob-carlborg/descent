package net.sourceforge.nattable.support;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.renderer.ICellRenderer;

import org.easymock.classextension.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class BulkUpdateSelectionValidatorTest {

	private static final int[] EMPTY_INT_ARRAY = new int[0];
	private static BulkUpdateSelectionValidator columnSupport;
	private static NatTable table;
	private static SelectionModel selectionModel;
	private static INatTableModel natTableModel;
	private static Object[] classMocks;
	private static Object[] interfaceMocks;
	private static ICellRenderer bodyCellRenderer;

	@BeforeClass
	public static void beforeClass() {
		table = EasyMock.createStrictMock(NatTable.class);
		columnSupport = new BulkUpdateSelectionValidator(table);
		selectionModel = EasyMock.createStrictMock(SelectionModel.class);
		natTableModel = org.easymock.EasyMock.createStrictMock(INatTableModel.class);
		bodyCellRenderer = org.easymock.EasyMock.createMock(ICellRenderer.class);
		
		classMocks = new Object[] {table, selectionModel};
		interfaceMocks = new Object[] {natTableModel, bodyCellRenderer};
	}
	
	@Before
	public void before() {
		EasyMock.reset(classMocks);
		org.easymock.EasyMock.reset(interfaceMocks);
	}
	
	@Test
	public void testIsSlectionValidWithNoSelection() throws Exception {
		table.getSelectionModel();
		EasyMock.expectLastCall().andReturn(selectionModel);
		
		selectionModel.getSelectedColumns();
		EasyMock.expectLastCall().andReturn(EMPTY_INT_ARRAY);
		
		EasyMock.replay(selectionModel, table);
		assertFalse("An empty selection is not valid.", columnSupport.isSelectionValid());
		EasyMock.verify(selectionModel, table);
	}

	@Test
	public void testIsSlectionValidWithManyColumnsSelection() throws Exception {
		table.getSelectionModel();
		EasyMock.expectLastCall().andReturn(selectionModel);
		
		selectionModel.getSelectedColumns();
		EasyMock.expectLastCall().andReturn(new int[2]);
		
		replayMocks();
		assertFalse("Multiple column selection is not valid.", columnSupport.isSelectionValid());
		verifyMocks();
	}
	
	@Test
	public void testIsSelectionValidHomogeneousEditors() {
		int column = 4;
		int row1 = 2;
		int row2 = 5;
		
		table.getSelectionModel();
		EasyMock.expectLastCall().andReturn(selectionModel);
		
		selectionModel.getSelectedColumns();
		EasyMock.expectLastCall().andReturn(new int[] {column});
		
		selectionModel.getSelectedRows();
		EasyMock.expectLastCall().andReturn(new int[] {row1, row2});
		
		table.getNatTableModel();
		EasyMock.expectLastCall().andReturn(natTableModel);
		
		natTableModel.getBodyCellRenderer();
		org.easymock.EasyMock.expectLastCall().andReturn(bodyCellRenderer);
		
		bodyCellRenderer.isEditable(row1, column);
		org.easymock.EasyMock.expectLastCall().andReturn(Boolean.TRUE);
		bodyCellRenderer.isEditable(row2, column);
		org.easymock.EasyMock.expectLastCall().andReturn(Boolean.TRUE);
		
		ICellEditor natCellEditor = org.easymock.EasyMock.createStrictMock(ICellEditor.class);

		bodyCellRenderer.getCellEditor(row1, column);
		org.easymock.EasyMock.expectLastCall().andReturn(natCellEditor);
		bodyCellRenderer.getCellEditor(row2, column);
		org.easymock.EasyMock.expectLastCall().andReturn(natCellEditor);
		
		replayMocks();
		org.easymock.EasyMock.replay(natCellEditor);
		assertTrue("Homogeneous selection of editors should be valid.", columnSupport.isSelectionValid());
		org.easymock.EasyMock.verify(natCellEditor);
		verifyMocks();		
	}
	
	@Test
	public void testIsSelectionValidHeterogeneousEditors() {
		int column = 4;
		int row1 = 2;
		int row2 = 5;
		
		table.getSelectionModel();
		EasyMock.expectLastCall().andReturn(selectionModel);
		
		selectionModel.getSelectedColumns();
		EasyMock.expectLastCall().andReturn(new int[] {column});
		
		selectionModel.getSelectedRows();
		EasyMock.expectLastCall().andReturn(new int[] {row1, row2});
		
		table.getNatTableModel();
		EasyMock.expectLastCall().andReturn(natTableModel);
		
		natTableModel.getBodyCellRenderer();
		org.easymock.EasyMock.expectLastCall().andReturn(bodyCellRenderer);
		
		bodyCellRenderer.isEditable(row1, column);
		org.easymock.EasyMock.expectLastCall().andReturn(Boolean.TRUE);
		bodyCellRenderer.isEditable(row2, column);
		org.easymock.EasyMock.expectLastCall().andReturn(Boolean.TRUE);
		
		ICellEditor natCellEditor1 = org.easymock.EasyMock.createStrictMock(ICellEditor.class);
		ICellEditor natCellEditor2 = org.easymock.EasyMock.createStrictMock(ICellEditor.class);

		bodyCellRenderer.getCellEditor(row1, column);
		org.easymock.EasyMock.expectLastCall().andReturn(natCellEditor1);
		bodyCellRenderer.getCellEditor(row2, column);
		org.easymock.EasyMock.expectLastCall().andReturn(natCellEditor2);
		
		replayMocks();
		org.easymock.EasyMock.replay(natCellEditor1, natCellEditor2);
		assertFalse("Heterogeneous selection of editors should be invalid.", columnSupport.isSelectionValid());
		org.easymock.EasyMock.verify(natCellEditor1, natCellEditor2);
		verifyMocks();	
	}
	
	@Test
	public void testIsSelectionValidNotEditable() throws Exception {
		int column = 4;
		int row = 2;
		
		table.getSelectionModel();
		EasyMock.expectLastCall().andReturn(selectionModel);
		
		selectionModel.getSelectedColumns();
		EasyMock.expectLastCall().andReturn(new int[] {column});
		
		selectionModel.getSelectedRows();
		EasyMock.expectLastCall().andReturn(new int[] {row});
		
		table.getNatTableModel();
		EasyMock.expectLastCall().andReturn(natTableModel);
		
		natTableModel.getBodyCellRenderer();
		org.easymock.EasyMock.expectLastCall().andReturn(bodyCellRenderer);
		
		bodyCellRenderer.isEditable(row, column);
		org.easymock.EasyMock.expectLastCall().andReturn(Boolean.FALSE);
		
		
		replayMocks();
		assertFalse("Non-editable cells are invalid.", columnSupport.isSelectionValid());
		verifyMocks();	
	}
	
	private void replayMocks() {
		EasyMock.replay(classMocks);
		org.easymock.EasyMock.replay(interfaceMocks);
	}
	
	private void verifyMocks() {
		EasyMock.verify(classMocks);
		org.easymock.EasyMock.verify(interfaceMocks);
	}
	
	static class Person {
		private final String firstName;
		private final String lastName;
		private final Date dateOfBirth;
		
		public Person(Date dateOfBirth, String firstName, String lastName) {
			super();
			this.dateOfBirth = dateOfBirth;
			this.firstName = firstName;
			this.lastName = lastName;
		}

		public String getFirstName() {
			return firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public Date getDateOfBirth() {
			return dateOfBirth;
		}
		
	}
	
}
