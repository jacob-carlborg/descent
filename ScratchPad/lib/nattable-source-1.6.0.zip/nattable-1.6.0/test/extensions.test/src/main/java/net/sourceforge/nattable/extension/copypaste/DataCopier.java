package net.sourceforge.nattable.extension.copypaste;

import java.util.List;

import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.data.pricing.PricingDataBeanGenerator;

import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.widgets.Display;

public class DataCopier {
	/**
	 * Use this method to place auto generated pricing data into the clipboard.
	 * @param rowsToCopy
	 * @return
	 */
	public static Clipboard copyPricingData(int rowsToCopy) {
		List<PricingDataBean> pricingData = PricingDataBeanGenerator.getData(rowsToCopy);
		StringBuffer data = new StringBuffer();
		for (PricingDataBean bean : pricingData) {
			data.append(bean.serializeToString() + "\n");
		}

		// clipboard
		Clipboard cb = new Clipboard(Display.getDefault());
		cb.clearContents();
		cb.setContents(new Object[] { data.toString() }, new Transfer[] { TextTransfer.getInstance() });
		return cb;
	}
}
