package net.sourceforge.nattable.extension.copypaste;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import junit.framework.Assert;
import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnAccessor;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.DataUpdateHelperCreator;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.data.pricing.PricingDataBeanGenerator;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;

import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.junit.Before;
import org.junit.Test;

public class NatTableCopyPasteSupportTest {
	private ICopyPasteSupport<PricingDataBean> copyPasteHandler;
	private CopyPasteEventListener<PricingDataBean> copyPasteListener;
	private SelectionModel selectModel;
	private MyDataProvider<PricingDataBean> dataProvider;
	private int defaultRowCount = 10;

	@Before
	public void init() throws Exception {
		copyPasteHandler = new CopyPasteSupport<PricingDataBean>(new IRowIdAccessor<PricingDataBean>() {

			public Serializable getRowId(PricingDataBean rowObject) {
				return rowObject.getIsin();
			}

		});
		selectModel = new SelectionModel();
		dataProvider = new MyDataProvider<PricingDataBean>(PricingDataBeanGenerator.getData(defaultRowCount), new ReflectiveColumnAccessor<PricingDataBean>(ColumnHeaders.getProperties()));
		try {
			initListener();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void initListener() throws Exception {
		final DataUpdateHelper<PricingDataBean> helper = DataUpdateHelperCreator.getUpdateHelper(new ContentConfigRegistry());

		copyPasteListener = new CopyPasteEventListener<PricingDataBean>(
				selectModel,
				dataProvider,
				helper,
				copyPasteHandler,
				new IPasteExecutionSupport<PricingDataBean>() {
					public void doPaste(DataUpdateHelper<PricingDataBean> helper) {
						helper.getBulkUpdate().commitUpdates(
								dataProvider.getData(), helper);
					}
				},
				new ContentConfigRegistry()
		);
	}

	@Test
	public void pasteMoreColumnsThanSelected() throws Exception {
		// put data in cb
		final List<String> fields = getCommonFieldsToUpdate();
		copyPasteHandler.copySupport(dataProvider.getData().subList(0, 5), fields);

		final ICopyPasteSupport<PricingDataBean> supp = new ICopyPasteSupport<PricingDataBean>() {

			public Clipboard copySupport(List<?> dataToCopy, List<String> propertiesToCopy) {
				return null;
			}
			
			public void pasteSupport(List<List<Object>> rows, List<PricingDataBean> selectedRows, List<String> propertyNames, DataUpdateHelper<PricingDataBean> helper) {
				Assert.assertEquals(fields.size(), propertyNames.size());
			}

		};
		selectModel.addSelection(0, 0);
		copyPasteListener.setCopyPasterSupporter(supp);
		copyPasteListener.performPaste();
	}

	@Test
	public void pasteMoreRowsThanSelected() throws Exception {
		// put data in cb
		final List<String> fields = getCommonFieldsToUpdate();
		
		final List<PricingDataBean> rowData =  new ArrayList<PricingDataBean>();
		rowData.addAll(dataProvider.getData().subList(0, 5));
		rowData.addAll(PricingDataBeanGenerator.getData(defaultRowCount));
		
		copyPasteHandler.copySupport(rowData, fields);

		final ICopyPasteSupport<PricingDataBean> supp = new ICopyPasteSupport<PricingDataBean>() {

			public Clipboard copySupport(List<?> dataToCopy, List<String> propertiesToCopy) {
				return null;
			}

			public void pasteSupport(List<List<Object>> rows, List<PricingDataBean> selectedRows, List<String> propertyNames, DataUpdateHelper<PricingDataBean> helper) {
				Assert.assertEquals(15, rows.size());
			}

		};
		
		selectModel.addSelection(0, 0);
		selectModel.addSelection(1, 0);
		selectModel.addSelection(2, 0);
		copyPasteListener.setCopyPasterSupporter(supp);
		copyPasteListener.performPaste();
	}

	public List<String> getCommonFieldsToUpdate() {
		final List<String> fields = new ArrayList<String>();
		fields.add("isin");
		fields.add("bid");
		fields.add("ask");
		fields.add("pricingModel");

		return fields;
	}

	@Test
	public void pastePricingDataRowsIntoGrid() {
		int numOfRows = defaultRowCount + 5;

		// describe which properties to paste into
		List<String> props = new ArrayList<String>();
		props.add("isin");
		props.add("pricingModel");
		props.add("ask");

		DefaultClipboardDataParser cbParser = new DefaultClipboardDataParser();
		//set data to cb
		Clipboard cb = DataCopier.copyPricingData(numOfRows);
		List<List<Object>>cbData = cbParser.parseClipboard(cb);		
		cb.clearContents();
		
		DataUpdateHelper<PricingDataBean> helper = DataUpdateHelperCreator.getUpdateHelper(new ContentConfigRegistry());
		copyPasteHandler.pasteSupport(cbData, null, props, helper);
		helper.getBulkUpdate().commitUpdates(dataProvider.getData(), helper);
		
		Assert.assertEquals(numOfRows + defaultRowCount, dataProvider.getData().size());
	}
	
	@Test
	public void copyPricingData() {
		List<PricingDataBean> data = PricingDataBeanGenerator.getData(defaultRowCount);
		List<String> fields = new ArrayList<String>();
		fields.add("bid");
		fields.add("ask");
		fields.add("pricingModel");
		Clipboard cb = copyPasteHandler.copySupport(data, fields);
		try {
			String contents = (String) cb.getContents(TextTransfer.getInstance());
			StringTokenizer rows = new StringTokenizer(contents, "\n");
			Assert.assertEquals(data.size(), rows.countTokens());
			StringTokenizer cells = new StringTokenizer(rows.nextToken(), "\t");
			Assert.assertEquals(fields.size(), cells.countTokens());
		} finally {
			cb.clearContents();
			cb.dispose();
		}
	}

	@Test
	public void pasteRowInsertsAndUpdates() {
		// put data in cb
		final List<String> fields = getCommonFieldsToUpdate();
		
		final List<PricingDataBean> rowData =  new ArrayList<PricingDataBean>();
		rowData.addAll(dataProvider.getData().subList(0, 5));

		//add new data (inserts)
		rowData.addAll(PricingDataBeanGenerator.getData(defaultRowCount));
		
		//put data in clipboard
		copyPasteHandler.copySupport(rowData, fields);		
		selectModel.addSelection(0, 0);
		copyPasteListener.performPaste();
		
		Assert.assertTrue(dataProvider.getRowCount() > defaultRowCount);
	}
	
	class MyDataProvider<T> extends ListDataProvider<T> {
		private List<T> list;

		public MyDataProvider(List<T> list, IColumnAccessor<T> columnAccessor) {
			super(list, columnAccessor);
			this.list = list;
		}

		public List<T> getData() {
			return list;
		}
	}
}
