package net.sourceforge.nattable.test.style;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import junit.framework.Assert;
import net.sourceforge.nattable.extension.typeconfig.style.IStyleMarkupHandler;
import net.sourceforge.nattable.extension.typeconfig.style.XMLStyleMarkupHandler;
import net.sourceforge.nattable.typeconfig.style.AlternateRowColoringStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StaticStyleAssembler;
import net.sourceforge.nattable.typeconfig.style.StaticStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;
import org.junit.Before;
import org.junit.Test;

public class StaticStyleAssemblerTest {	
	private StyleConfigRegistry styleConfigRegistry = new StyleConfigRegistry();
	private StaticStyleConfig style;
	private static final String FILE_NAME = "tmpStyleStore.store";
	
	@Before
	public void initStyle() {
		style = new StaticStyleConfig();
		style.setFontAttributes("Arial", "12", "BOLD|ITALIC");
		style.setBGColorRGB("255,255,255");
		style.setFGColorRGB("123,123,124");
	}
	
	@Test
	public void testStyleAssembly() {		
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "GRIDx", style);
		Assert.assertTrue(styleConfigRegistry.getStyleConfig(DisplayModeEnum.NORMAL.name(), "GRIDx") != null);
		Assert.assertNotNull(style.getFont(0,0));
		Assert.assertNotNull(style.getForegroundColor(0,0));
		Assert.assertNotNull(style.getBackgroundColor(0,0));
		Assert.assertNull(style.getImage(0, 0));
	}
	
	@Test
	public void marshallAndUnmarshallStaticStyle() throws Exception {
		File tmp = new File(FILE_NAME);
		try {
			StaticStyleConfig tmpStyle = (StaticStyleConfig)saveAndRestoreStyle(style, tmp);

			Assert.assertNotNull(tmpStyle);
			int row = 0, col = 0;
			Assert.assertEquals(style.getFont(row, col).getFontData()[0].getName(), tmpStyle.getFont(row, col).getFontData()[0].getName());
			Assert.assertEquals(style.getFont(row, col).getFontData()[0].getHeight(), tmpStyle.getFont(row, col).getFontData()[0].getHeight());
			Assert.assertEquals(style.getFont(row, col).getFontData()[0].getStyle(), tmpStyle.getFont(row, col).getFontData()[0].getStyle());
		}finally {
			if(tmp != null) {
				tmp.delete();
			}
		}
	}
	
	@Test
	public void marshallAndUnmarshallAlternateRowColoringStyle() throws Exception {
		Color evenColor = StaticStyleAssembler.assembleColor(Display.getDefault(), "200,200,200");
		Color oddColor = StaticStyleAssembler.assembleColor(Display.getDefault(), "255,255,255");
		AlternateRowColoringStyleConfig altStyle = new AlternateRowColoringStyleConfig(evenColor, oddColor);
		altStyle.adaptExistingStyle(style);
		File tmp = new File(FILE_NAME);
		try {
			int row = 0, col = 0;
			AlternateRowColoringStyleConfig tmpAltStyle = (AlternateRowColoringStyleConfig)saveAndRestoreStyle(altStyle, tmp);
			Assert.assertEquals(altStyle.getBackgroundColor(row, col).getRed(), tmpAltStyle.getBackgroundColor(row, col).getRed());
			Assert.assertEquals(style.getFont(row, col).getFontData()[0].getName(), tmpAltStyle.getFont(row, col).getFontData()[0].getName());
			Assert.assertEquals(style.getFont(row, col).getFontData()[0].getHeight(), tmpAltStyle.getFont(row, col).getFontData()[0].getHeight());
			Assert.assertEquals(style.getFont(row, col).getFontData()[0].getStyle(), tmpAltStyle.getFont(row, col).getFontData()[0].getStyle());
			
		}finally {
			if(tmp != null) {
				tmp.delete();
			}
		}
	}

	private IStyleConfig saveAndRestoreStyle(IStyleConfig tmpStyle, File tmpFile) throws Exception{
		ObjectOutputStream objOut = null;
		try {
			objOut = new ObjectOutputStream(new FileOutputStream(tmpFile));
			objOut.writeObject(tmpStyle);
		}finally {
			objOut.close();
		}
		IStyleConfig config = null;
		ObjectInputStream objIn = null;
		try {
			objIn = new ObjectInputStream(new FileInputStream(FILE_NAME));
			config = (IStyleConfig)objIn.readObject();
		}finally {
			objIn.close();
		}
		
		return config;
	}
	
	public void testXMLConfigurationHandler() throws Exception {
		IStyleMarkupHandler styleLoader = new XMLStyleMarkupHandler(ClassLoader.getSystemResourceAsStream("styles.xml"));
		styleLoader.assembleConfiguration(styleConfigRegistry,  Display.getDefault());
		Assert.assertTrue(styleConfigRegistry.getStyleConfig(DisplayModeEnum.NORMAL.name(), null) != null);
		Assert.assertTrue(styleConfigRegistry.getStyleConfig(DisplayModeEnum.EDIT.name(), "price") != null);
	}
}
