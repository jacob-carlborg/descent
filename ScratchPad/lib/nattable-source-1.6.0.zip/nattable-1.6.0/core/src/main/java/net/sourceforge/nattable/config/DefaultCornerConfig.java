package net.sourceforge.nattable.config;

import net.sourceforge.nattable.renderer.DefaultCornerRenderer;
import net.sourceforge.nattable.renderer.ICellRenderer;

public class DefaultCornerConfig implements ICornerConfig {

	private static final DefaultCornerRenderer cornerRenderer = new DefaultCornerRenderer();
	
	public ICellRenderer getCellRenderer() {
		return cornerRenderer;
	}

}
