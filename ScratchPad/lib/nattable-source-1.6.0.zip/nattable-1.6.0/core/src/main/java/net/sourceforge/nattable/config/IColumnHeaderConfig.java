package net.sourceforge.nattable.config;

public interface IColumnHeaderConfig extends IRegionConfig {
	
	public int getColumnHeaderRowCount();
	
	public SizeConfig getColumnHeaderRowHeightConfig();

}
