package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.typeconfig.style.DefaultStyleConfig;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;

import org.eclipse.swt.graphics.Image;

public class DataBindingCellRenderer extends AbstractCellRenderer {

	private final DefaultStyleConfig defaultStyleConfig = new DefaultStyleConfig() {

		private static final long serialVersionUID = 1L;

		public Image getImage(final int row, final int col) {
			final Object value = getValue(row, col);
			return value instanceof Image ? (Image) value : null;
		}
		
	};
	
	private final IDataProvider dataProvider;

	public DataBindingCellRenderer(final IDataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}

	public String getDisplayText(final int row, final int col) {
		final Object value = getValue(row, col);
		return value != null ? value.toString() : "";
	}

	public Object getValue(final int row, final int col) {
		return dataProvider.getValue(row, col);
	}
	
	public IStyleConfig getStyleConfig(String displayMode, int row, int col) {
		return defaultStyleConfig;
	}

}
