package net.sourceforge.nattable.editor;

public enum EditorSelectionEnum {

	ALL,
	START,
	END
	
}
