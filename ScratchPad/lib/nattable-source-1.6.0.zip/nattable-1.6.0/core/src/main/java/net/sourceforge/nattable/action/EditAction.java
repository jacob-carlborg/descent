package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.events.MouseEvent;

public class EditAction extends SelectCellAction {

	private NatTable natTable;
	
	public EditAction(NatTable natTable) {
		super(natTable, false, false);
		
		this.natTable = natTable;
	}
	
	public void run(MouseEvent event) {
		super.run(event);
		
		int modelGridRow = natTable.getModelGridRowByY(event.y);
		int modelGridColumn = natTable.getModelGridColumnByX(event.x);
		
		natTable.getEditorSupport().activateCell(modelGridRow, modelGridColumn);
	}

}
