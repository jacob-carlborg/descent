package net.sourceforge.nattable.support;

import java.io.Serializable;

public interface IBulkUpdateResponseHandler {

	boolean applyBulkUpdate(BulkUpdateResponse response, Serializable [] rowIds, int fieldIndex);

}
