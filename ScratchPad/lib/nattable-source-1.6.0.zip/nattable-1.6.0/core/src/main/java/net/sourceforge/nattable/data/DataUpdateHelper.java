package net.sourceforge.nattable.data;

import java.util.Comparator;

public class DataUpdateHelper<T> {
	private DefaultBulkUpdateSupport<T> bulkUpdate;
	private IColumnPropertyProvider propertyResolver;
	private Comparator<T> rowComparator;
	private IRowObjectCreator<T> rowObjectCreator;
	private IBeanConfigTypeResolver<T> beanConfigResolver;
	private IPropertyInstanceCreator propertyInstanceCreator;
	private IRowIDPropertyResolver rowIdResolver;

	public DataUpdateHelper() {

	}

	public DataUpdateHelper(DefaultBulkUpdateSupport<T> bulkUpdate, IColumnPropertyProvider propertyResolver, Comparator<T> rowComparator, IRowObjectCreator<T> rowObjectCreator,
			IBeanConfigTypeResolver<T> beanConfigResolver, IPropertyInstanceCreator propertyCreator, IRowIDPropertyResolver rowIdResolver) {
		this.bulkUpdate = bulkUpdate;
		this.rowComparator = rowComparator;
		this.rowObjectCreator = rowObjectCreator;
		this.propertyResolver = propertyResolver;
		this.beanConfigResolver = beanConfigResolver;
		this.propertyInstanceCreator = propertyCreator;
		this.rowIdResolver = rowIdResolver;
	}

	public DefaultBulkUpdateSupport<T> getBulkUpdate() {
		return bulkUpdate;
	}

	public void setBulkUpdate(DefaultBulkUpdateSupport<T> bulkUpdate) {
		this.bulkUpdate = bulkUpdate;
	}

	public Comparator<T> getRowComparator() {
		return rowComparator;
	}

	public void setRowComparator(Comparator<T> rowComparator) {
		this.rowComparator = rowComparator;
	}

	public IRowObjectCreator<T> getRowObjectCreator() {
		return rowObjectCreator;
	}

	public void setRowObjectCreator(IRowObjectCreator<T> rowObjectCreator) {
		this.rowObjectCreator = rowObjectCreator;
	}

	public IColumnPropertyProvider getPropertyResolver() {
		return propertyResolver;
	}

	public void setPropertyResolver(IColumnPropertyProvider propertyResolver) {
		this.propertyResolver = propertyResolver;
	}

	public IBeanConfigTypeResolver<T> getBeanConfigResolver() {
		return beanConfigResolver;
	}

	public void setBeanConfigResolver(IBeanConfigTypeResolver<T> beanConfigResolver) {
		this.beanConfigResolver = beanConfigResolver;
	}

	public IPropertyInstanceCreator getPropertyInstanceCreator() {
		return propertyInstanceCreator;
	}

	public void setPropertyInstanceCreator(IPropertyInstanceCreator propertyInstanceCreator) {
		this.propertyInstanceCreator = propertyInstanceCreator;
	}

	public IRowIDPropertyResolver getRowIdResolver() {
		return rowIdResolver;
	}

	public void setRowIdResolver(IRowIDPropertyResolver rowIdResolver) {
		this.rowIdResolver = rowIdResolver;
	}
}
