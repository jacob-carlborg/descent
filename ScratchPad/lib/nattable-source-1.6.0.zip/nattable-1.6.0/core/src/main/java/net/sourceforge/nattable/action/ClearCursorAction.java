package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.events.MouseEvent;

public class ClearCursorAction implements IMouseEventAction {

	private NatTable natTable;
	
	public ClearCursorAction(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void run(MouseEvent event) {
		natTable.setCursor(null);
	}

}
