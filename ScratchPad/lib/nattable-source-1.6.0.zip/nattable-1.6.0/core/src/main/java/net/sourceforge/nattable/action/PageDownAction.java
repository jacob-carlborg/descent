package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.events.KeyEvent;

public class PageDownAction extends AbstractKeySelectAction {

	private NatTable natTable;
	
	public PageDownAction(NatTable natTable, boolean withShiftMask, boolean withControlMask) {
		super(natTable.getSelectionSupport(), withShiftMask, withControlMask);
		
		this.natTable = natTable;
	}
	
	public void run(KeyEvent event) {
		// TODO This can be made more efficient..
		int numVisibleBodyRows = natTable.getVisibleModelBodyRows().size();
		for (int i = 0; i < numVisibleBodyRows; i++) {
			selectionSupport.moveDown(withShiftMask, withControlMask);
		}
	}

}
