package net.sourceforge.nattable.support;

public enum BulkUpdateTypeEnum {

	SET,
	INCREASE,
	DECREASE
	
}
