package net.sourceforge.nattable.support;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.renderer.ICellRenderer;

public class BulkUpdateSelectionValidator implements ISelectionValidator {

	private final NatTable table;

	public BulkUpdateSelectionValidator(NatTable table) {
		this.table = table;
	}

	public boolean isSelectionValid() {
		SelectionModel selectionModel = getSelectionModel();
		int[] selectedColumns = selectionModel.getSelectedColumns();
		
		if (selectedColumns.length == 1) {
			int[] selectedRows = selectionModel.getSelectedRows();
			
			return areSelectedCellsValid(selectedRows, table.reorderedToModelBodyColumn(selectedColumns[0]));
		}
		
		return false;
	}
	
	private boolean areSelectedCellsValid(int[] selectedRows, int selectedColumn) {
		if (selectedRows.length > 0) {
			ICellRenderer bodyCellRenderer = table.getNatTableModel().getBodyCellRenderer();
			
			ICellEditor baseEditor = null;
			
			for (int row : selectedRows) {
				boolean cellEditable = bodyCellRenderer.isEditable(row, selectedColumn);
				if (cellEditable) {
					ICellEditor natCellEditor = bodyCellRenderer.getCellEditor(row, selectedColumn);

					if (baseEditor == null) {
						baseEditor = natCellEditor;
					} else if (!baseEditor.equals(natCellEditor)) {
						return false;
					}
					
				} else {
					return false;
				}
			}
			
			return true;
		}
		
		return false;
	}

	private SelectionModel getSelectionModel() {
		return table.getSelectionModel();
	}
	
}
