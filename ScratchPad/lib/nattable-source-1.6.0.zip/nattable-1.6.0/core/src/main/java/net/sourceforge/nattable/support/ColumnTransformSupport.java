package net.sourceforge.nattable.support;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import net.sourceforge.nattable.config.IBodyConfig;

import org.apache.log4j.Logger;

public class ColumnTransformSupport {

	public static final Logger log = Logger
			.getLogger(ColumnTransformSupport.class);

	private final Map<Integer, Integer> reorderedToModelBodyColumnMap = Collections
			.synchronizedMap(new TreeMap<Integer, Integer>());

	private final Map<Integer, Integer> modelToReorderedBodyColumnMap = Collections
			.synchronizedMap(new TreeMap<Integer, Integer>());
	
	private IBodyConfig bodyConfig;
	
	private Set<Integer> hiddenModelBodyColumns = new HashSet<Integer>();

	public ColumnTransformSupport(IBodyConfig bodyConfig) {
		this.bodyConfig = bodyConfig;
	}
	
	public void reorderModelBodyColumn(int dragFromModelBodyColumn,
			int dragToModelBodyColumn) {
		try {
			int[] oldBodyColumnOrder = getModelBodyColumnOrder();

			List<Integer> newBodyColumnOrder = new ArrayList<Integer>();

			boolean fromEncountered = false;

			for (int i = 0; i < oldBodyColumnOrder.length; i++) {
				Integer bodyColOrder = Integer.valueOf(oldBodyColumnOrder[i]);
				if (oldBodyColumnOrder[i] == dragFromModelBodyColumn) {
					fromEncountered = true;
				} else if (oldBodyColumnOrder[i] == dragToModelBodyColumn) {
					Integer dragFromColIndex = Integer.valueOf(dragFromModelBodyColumn);
					if (fromEncountered) {
						newBodyColumnOrder.add(bodyColOrder);
						newBodyColumnOrder.add(dragFromColIndex);
					} else {
						newBodyColumnOrder.add(dragFromColIndex);
						newBodyColumnOrder.add(bodyColOrder);
					}
				} else {
					newBodyColumnOrder.add(bodyColOrder);
				}
			}

			if (oldBodyColumnOrder.length == newBodyColumnOrder.size()) {
				for (int i = 0; i < oldBodyColumnOrder.length; i++) {
					oldBodyColumnOrder[i] = newBodyColumnOrder.get(i).intValue();
				}
				if (bodyConfig.getColumnCount() == oldBodyColumnOrder.length) {
					setModelBodyColumnOrder(oldBodyColumnOrder);
				} else {
					log.warn("Column ordering size not equal to model column count");
				}
			} else {
				log.warn("Column ordering size changed during reordering");
			}

		} catch (RuntimeException e) {
			log.error("error", e);
		}
	}

	public void setModelBodyColumnOrder(final int[] order) {
		for (int i = 0; i < order.length; i++) {
			reorderedToModelBodyColumnMap.put(Integer.valueOf(i), Integer.valueOf(order[i]));
			modelToReorderedBodyColumnMap.put(Integer.valueOf(order[i]), Integer.valueOf(i));
		}
	}
	
	public int modelToReorderedBodyColumn(final int modelBodyColumn) {
		return modelToReorderedBodyColumnMap.get(Integer.valueOf(modelBodyColumn)).intValue();
	}
	
	public int reorderedToModelBodyColumn(final int reorderedBodyColumn) {
		return reorderedToModelBodyColumnMap.get(Integer.valueOf(reorderedBodyColumn)).intValue();
	}
	
	public int[] getModelBodyColumnOrder() {
		final int modelBodyColumnCount = bodyConfig.getColumnCount();
		checkModelColumnMaps(modelBodyColumnCount);

		final int[] modelBodyColumnOrder = new int[modelBodyColumnCount];
		for (int i = 0; i < modelBodyColumnOrder.length; i++) {
			if (reorderedToModelBodyColumnMap.containsKey(Integer.valueOf(i))) {
				modelBodyColumnOrder[i] = reorderedToModelBodyColumnMap.get(Integer.valueOf(i)).intValue();
			}
		}

		return modelBodyColumnOrder;
	}

	private void checkModelColumnMaps(final int modelBodyColumnCount) {
		if (reorderedToModelBodyColumnMap.size() <= 0) {			

			modelToReorderedBodyColumnMap.clear();
			
			for (int i = 0; i < modelBodyColumnCount; i++) {
				Integer integer = Integer.valueOf(i);
				reorderedToModelBodyColumnMap.put(integer, integer);
				modelToReorderedBodyColumnMap.put(integer, integer);
			}
		}
	}
	
	// Hidden columns /////////////////////////////////////

	public void hideModelBodyColumn(final int modelBodyColumn) {
		hiddenModelBodyColumns.add(Integer.valueOf(modelBodyColumn));		
	}

	public void showModelBodyColumn(final int modelBodyColumn) {
		if(!isModelBodyColumnViewable(modelBodyColumn)) {
			hiddenModelBodyColumns.remove(Integer.valueOf(modelBodyColumn));
		} else {
			log.warn("Calling show for visible column");
		}
	}

	public Set<Integer> getHiddenModelBodyColumns() {
		
		return hiddenModelBodyColumns;
	}

	public boolean isModelBodyColumnViewable(final int modelBodyColumn) {
		if (hiddenModelBodyColumns == null)
			return true;

		return !hiddenModelBodyColumns.contains(Integer.valueOf(modelBodyColumn));
	}

}
