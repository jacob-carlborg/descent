package net.sourceforge.nattable.editor;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.data.IDataValidator;

public class DefaultEditController implements IEditController {

	private NatTable natTable;
	
	private IDataValidator dataValidator;
	
	private int row;
	
	private int col;
	
	private Object oldValue;
	
	public DefaultEditController(NatTable natTable, IDataValidator dataValidator, int row, int col, Object oldValue) {
		this.natTable = natTable;
		this.dataValidator = dataValidator;
		this.row = row;
		this.col = col;
		this.oldValue = oldValue;
	}

	public boolean validate(Object oldValue, Object newValue) {
		if (dataValidator != null) {
			return dataValidator.validate(oldValue, newValue);
		} else {
			return true;
		}
	}
	
	public void commit(Object newValue) {
		natTable.fireValueChanged(row, col, oldValue, newValue);
		natTable.redrawUpdatedBodyRow(row, row);
	}
	
}
