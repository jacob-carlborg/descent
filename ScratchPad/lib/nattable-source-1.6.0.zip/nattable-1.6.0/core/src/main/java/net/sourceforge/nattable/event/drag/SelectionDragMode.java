package net.sourceforge.nattable.event.drag;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.SelectionSupport;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;

public class SelectionDragMode implements IDragMode {

	private NatTable natTable;

	private SelectionSupport selectionSupport;
	
	private int lastModelBodyRow = -1;
	
	private int lastModelBodyColumn = -1;

	public SelectionDragMode(NatTable natTable) {
		this.natTable = natTable;
		this.selectionSupport = natTable.getSelectionSupport();
	}
	
	public void mouseDown(MouseEvent event) {
		// In order to trigger a lost focus of cell editor
		natTable.forceFocus();
		
		boolean shiftMask = ((event.stateMask & SWT.SHIFT) == SWT.SHIFT);
		boolean controlMask = ((event.stateMask & SWT.CONTROL) == SWT.CONTROL);

		int modelBodyRow = natTable.getModelBodyRowByY(event.y);
		int modelBodyColumn = natTable.getModelBodyColumnByX(event.x);
		
		selectionSupport.toggleCell(modelBodyRow, modelBodyColumn, shiftMask, controlMask);
	}
	
	public void mouseMove(MouseEvent event) {
		int modelBodyRow = natTable.getModelBodyRowByY(event.y);
		int modelBodyColumn = natTable.getModelBodyColumnByX(event.x);
		
		if (modelBodyRow >= 0 && modelBodyColumn >= 0 && !(lastModelBodyRow == modelBodyRow && lastModelBodyColumn == modelBodyColumn)) {
			lastModelBodyRow = modelBodyRow;
			lastModelBodyColumn = modelBodyColumn;
			selectionSupport.setSelectedCell(modelBodyRow, modelBodyColumn, true, false);
		}
	}
	
	public void mouseUp(MouseEvent event) {
		cleanup();
	}
	
	private void cleanup() {
		lastModelBodyRow = -1;
		lastModelBodyColumn = -1;
	}
	
}
