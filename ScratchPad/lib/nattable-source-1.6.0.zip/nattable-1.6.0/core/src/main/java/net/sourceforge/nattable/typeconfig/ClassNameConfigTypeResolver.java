package net.sourceforge.nattable.typeconfig;

import net.sourceforge.nattable.data.IRowDataProvider;

public class ClassNameConfigTypeResolver implements IConfigTypeResolver {

	private IRowDataProvider<?> dataProvider;
	
	public ClassNameConfigTypeResolver(IRowDataProvider<?> dataProvider) {
		this.dataProvider = dataProvider;
	}
	
	public String getConfigType(int row, int col) {
		Object value = dataProvider.getValue(row, col);
		if (value != null) {
			return value.getClass().getName();
		} else {
			return null;
		}
	}

}
