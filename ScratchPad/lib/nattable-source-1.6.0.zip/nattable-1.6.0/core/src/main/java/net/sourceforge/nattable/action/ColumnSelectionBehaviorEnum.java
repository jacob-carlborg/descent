package net.sourceforge.nattable.action;

public enum ColumnSelectionBehaviorEnum {

	NO_SELECTION_NO_SORTING(0, 0),
	NO_SELECTION_SINGLE_CLICK_SORTING(0, 1),
	NO_SELECTION_DOUBLE_CLICK_SORTING(0, 2),
	SINGLE_CLICK_SELECTION_NO_SORTING(1, 0),
	SINGLE_CLICK_SELECTION_DOUBLE_CLICK_SORTING(1, 2),
	DOUBLE_CLICK_SELECTION_NO_SORTING(2, 0),
	DOUBLE_CLICK_SELECTION_SINGLE_CLICK_SORTING(2, 1)
	;
	
	private final int selectionClicks;
	private final int sortingClicks;

	private ColumnSelectionBehaviorEnum(int selectionClicks, int sortingClicks) {
		this.selectionClicks = selectionClicks;
		this.sortingClicks = sortingClicks;
	}

	public int getSelectionClicks() {
		return selectionClicks;
	}

	public int getSortingClicks() {
		return sortingClicks;
	}
}
