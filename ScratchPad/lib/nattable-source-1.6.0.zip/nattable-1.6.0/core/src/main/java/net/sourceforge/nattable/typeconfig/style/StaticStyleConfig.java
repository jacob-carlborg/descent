package net.sourceforge.nattable.typeconfig.style;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

public class StaticStyleConfig implements IStyleConfig {
	private static final long serialVersionUID = 1L;

	private String bgColorRGB;
	private Color bgColor;

	private String fgColorRGB;
	private Color fgColor;

	private String fontName;
	private String fontSize;
	private String fontStyle;
	private Font font;

	private String imgUri;
	private Image image;

	public StaticStyleConfig() {

	}

	public StaticStyleConfig(Color bgColor, Color fgColor, Font font, Image image) {
		this.bgColor = bgColor;
		this.fgColor = fgColor;
		this.font = font;
		this.image = image;
	}

	public void setBGColorRGB(String rgb) {
		bgColorRGB = rgb;
	}

	public Color getBackgroundColor(int row, int col) {
		if (bgColor == null) {
			bgColor =  bgColorRGB != null && !bgColorRGB.trim().equals("") ? StaticStyleAssembler.assembleColor(Display.getCurrent(), bgColorRGB) : null;
		}
		return bgColor;
	}

	public void setFGColorRGB(String rgb) {
		fgColorRGB = rgb;
	}

	public Color getForegroundColor(int row, int col) {
		if (fgColor == null) {
			fgColor = fgColorRGB != null && !fgColorRGB.trim().equals("") ? StaticStyleAssembler.assembleColor(Display.getCurrent(), fgColorRGB) : null;
		}
		return fgColor;
	}

	public void setFontAttributes(String fontName, String fontSize, String fontStyle) {
		this.fontName = fontName;
		this.fontSize = fontSize;
		this.fontStyle = fontStyle;
	}

	public Font getFont(int row, int col) {
		if(font == null) {
			initFont();
		}
		return font;
	}

	private void initFont() {
		if (fontName != null && fontStyle != null && fontSize != null) {
			font = StaticStyleAssembler.assembleFont(Display.getCurrent(), fontName, fontStyle, fontSize);
		}
	}

	public void setImageURI(String imgUri) {
		this.imgUri = imgUri;
	}

	public Image getImage(int row, int col) {
		if (image == null && imgUri != null) {
			try {
				image = StaticStyleAssembler.assembleImage(Display.getCurrent(), imgUri);
			} catch (IOException e) {
				throw new RuntimeException("Unable to create image from uri : " + imgUri + 
						".  Faile with message : " + e.getMessage(), e);
			}
		}
		return image;
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		StyleStorer storer = new StyleStorer();
		storer.storedBgColor = StaticStyleDisassembler.getFormattedBackgroundRGB(this);
		storer.storedFgColor = StaticStyleDisassembler.getFormattedForegroundRGB(this);
		if(font == null) {
			initFont();
		}
		if(font != null){
			storer.storedFontName = StaticStyleDisassembler.getFontName(this);
			storer.storedFontSize = StaticStyleDisassembler.getFontSize(this);
			storer.storedFontStyle = StaticStyleDisassembler.getFontStyle(this);
		}
		storer.storedImgUri = imgUri;
		stream.writeObject(storer);
	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		StyleStorer restorer = (StyleStorer)stream.readObject();
		//restoring font attributes
		this.fontName = restorer.storedFontName;
		this.fontSize = restorer.storedFontSize;		
		this.fontStyle = restorer.storedFontStyle;
		
		//restoring colors
		this.bgColorRGB = restorer.storedBgColor;
		this.fgColorRGB = restorer.storedFgColor;
		
		//restoring image uri
		this.imgUri = restorer.storedImgUri;
	}

	@SuppressWarnings("unused")
	private void readObjectNoData() throws ObjectStreamException {

	}
	
	class StyleStorer implements Serializable{
		private static final long serialVersionUID = 1L;
		String storedBgColor;
		String storedFgColor;
		
		String storedFontName;
		String storedFontSize;
		String storedFontStyle;
		
		String storedImgUri;
	}

}
