package net.sourceforge.nattable.data;

public interface IDataValidator {

	public boolean validate(Object oldValue, Object newValue);

}
