package net.sourceforge.nattable.typeconfig.content;

public abstract class ReadOnlyDisplayTypeConverter implements IDisplayTypeConverter {

	public Object displayValueToDataValue(Object displayValue) {
		return null;
	}
	
}
