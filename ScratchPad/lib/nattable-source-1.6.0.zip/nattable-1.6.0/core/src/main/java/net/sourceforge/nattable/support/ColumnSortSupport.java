package net.sourceforge.nattable.support;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.sorting.ISortingDirectionChangeListener;
import net.sourceforge.nattable.sorting.SortingDirection;

import org.apache.log4j.Logger;

/**
 * Author : Andy Tsoi<br>
 * Created Date : Oct 6, 2007<br>
 */
public class ColumnSortSupport {

	public static final Logger log = Logger.getLogger(ColumnSortSupport.class);

	protected NatTable natTable = null;

	protected Map<Integer, SortingDirection> sortingColumnMap = new LinkedHashMap<Integer, SortingDirection>();

	/**
	 * @param natTable
	 */
	public ColumnSortSupport(final NatTable natTable) {
		this.natTable = natTable;
	}

	public Map<Integer, SortingDirection> getSortingColumnMap() {
		return sortingColumnMap;
	}

	public void sortModelBodyColumn(final int selectedModelBodyCol, final boolean accumulate) {
		final INatTableModel model = natTable.getNatTableModel();
		if (model.isSortingEnabled() && selectedModelBodyCol >= 0) {
			final Integer colIndex = Integer.valueOf(selectedModelBodyCol);

			final SortingDirection originalDirection = sortingColumnMap.get(colIndex);

			if (!accumulate) {
				sortingColumnMap.clear();
			}

			if (originalDirection == null) {
				final SortingDirection direction = new SortingDirection(SortingDirection.DirectionEnum.DOWN,
						selectedModelBodyCol);
				sortingColumnMap.put(colIndex, direction);
			} else {
				if (originalDirection.getDirection() == SortingDirection.DirectionEnum.DOWN) {
					final SortingDirection direction = new SortingDirection(SortingDirection.DirectionEnum.UP,
							selectedModelBodyCol);
					sortingColumnMap.put(colIndex, direction);
				} else {
					sortingColumnMap.remove(colIndex);
				}
			}

			SortingDirection[] newSortingDirections = getSortingDirections();

			final ICellRenderer columnHeaderCellRenderer = model.getColumnHeaderCellRenderer();
			if (columnHeaderCellRenderer instanceof ISortingDirectionChangeListener) {
				final ISortingDirectionChangeListener sortingColumnHeaderRenderer = (ISortingDirectionChangeListener) columnHeaderCellRenderer;
				sortingColumnHeaderRenderer.sortingDirectionChanged(newSortingDirections);
			}
			
			natTable.fireSortingDirectionChanged(newSortingDirections);
		}
	}
	
	public SortingDirection[] getSortingDirections() {
		// Rebuild the list by using map
		final ArrayList<SortingDirection> newSortingDirections = new ArrayList<SortingDirection>();
		for (final Integer key : sortingColumnMap.keySet()) {
			final SortingDirection direction = sortingColumnMap.get(key);
			newSortingDirections.add(direction);
		}
		return newSortingDirections.toArray(new SortingDirection[0]);
	}

}
