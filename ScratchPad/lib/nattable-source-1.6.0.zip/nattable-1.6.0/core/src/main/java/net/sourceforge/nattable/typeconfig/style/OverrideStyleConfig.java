package net.sourceforge.nattable.typeconfig.style;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;

public class OverrideStyleConfig implements IStyleConfig {

	private static final long serialVersionUID = 1L;

	private IStyleConfig styleConfig;
	
	public OverrideStyleConfig(IStyleConfig styleConfig) {
		this.styleConfig = styleConfig;
	}
	
	public Color getBackgroundColor(int row, int col) {
		return styleConfig.getBackgroundColor(row, col);
	}

	public Color getForegroundColor(int row, int col) {
		return styleConfig.getForegroundColor(row, col);
	}

	public Font getFont(int row, int col) {
		return styleConfig.getFont(row, col);
	}

	public Image getImage(int row, int col) {
		return styleConfig.getImage(row, col);
	}

}
