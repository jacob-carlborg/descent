package net.sourceforge.nattable.event.drag;

import org.eclipse.swt.events.MouseEvent;

import net.sourceforge.nattable.event.mode.AbstractModeEventHandler;
import net.sourceforge.nattable.event.mode.ModeEnum;
import net.sourceforge.nattable.support.ModeSupport;

public class DragModeEventHandler extends AbstractModeEventHandler {

	private IDragMode dragMode;
	
	public DragModeEventHandler(ModeSupport modeSupport, IDragMode dragMode) {
		super(modeSupport);
		
		this.dragMode = dragMode;
	}
	
	@Override
	public void mouseMove(MouseEvent event) {
		dragMode.mouseMove(event);
	}
	
	@Override
	public void mouseUp(MouseEvent event) {
		dragMode.mouseUp(event);
		switchMode(ModeEnum.NORMAL_MODE);
	}
	
}
