package net.sourceforge.nattable.model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.eclipse.swt.graphics.Rectangle;

public class SelectionModel {

	private final List<Rectangle> selections;

	private final ReadWriteLock selectionsLock;
	
	public SelectionModel() {
		selections = new LinkedList<Rectangle>();
		selectionsLock = new ReentrantReadWriteLock();
	}

	public boolean isSelected(int rowIndex, int columnIndex) {
		selectionsLock.readLock().lock();
		
		try {
			for (Rectangle r : selections) {
				if (r.contains(columnIndex, rowIndex))
					return true;
			}
		} finally {
			selectionsLock.readLock().unlock();
		}

		return false;
	}

	public void addSelection(int rowIndex, int columnIndex) {
		addSelectionIntoList(new Rectangle(columnIndex, rowIndex, 1, 1));
	}

	public void addSelection(final Rectangle range) {
		if (range != null) {
			addSelectionIntoList(range);
		}
		
	}

	private void addSelectionIntoList(Rectangle selection) {
		selectionsLock.writeLock().lock();
		try {
			ArrayList<Rectangle> itemsToRemove = null;
			for (Rectangle r : selections) {
				if (selection.intersects(r)) {
					if (r.equals(selection)) {
						break;
					}
					
					Rectangle intersection = selection.intersection(r);
					if (intersection.equals(r)) {
						// r is a subset of intersection
						if (itemsToRemove == null)
							itemsToRemove = new ArrayList<Rectangle>();
						
						itemsToRemove.add(r);
					} else if (intersection.equals(selection)) {
						// selection is a subset of r
						break;
					}
				}
			}
			
			if (itemsToRemove != null) {
				selections.removeAll(itemsToRemove);
			}
			
			selections.add(selection);
		} finally {
			selectionsLock.writeLock().unlock();
		}
		
	}
	
	public void clearSelection() {
		selectionsLock.writeLock().lock();
		try {
			selections.clear();
		} finally {
			selectionsLock.writeLock().unlock();
		}
	}

	public void removeSelection(Rectangle removedSelection) {

		List<Rectangle> removedItems = new LinkedList<Rectangle>();
		List<Rectangle> addedItems = new LinkedList<Rectangle>();

		selectionsLock.readLock().lock();
		
		try {
			for (Rectangle r : selections) {
				if (r.intersects(removedSelection)) {
					Rectangle intersection = removedSelection.intersection(r);
					removedItems.add(r);

					Rectangle topSelection = getTopSelection(intersection, r);
					if (topSelection != null) {
						addedItems.add(topSelection);
					}

					Rectangle rightSelection = getRightSelection(intersection, r);
					if (rightSelection != null)
						addedItems.add(rightSelection);

					Rectangle leftSelection = getLeftSelection(intersection, r);
					if (leftSelection != null)
						addedItems.add(leftSelection);

					Rectangle bottomSelection = getBottomSelection(intersection, r);
					if (bottomSelection != null)
						addedItems.add(bottomSelection);
				}
			}
		} finally {
			selectionsLock.readLock().unlock();
		}

		if (removedItems != null) {
			selectionsLock.writeLock().lock();
			try {
				selections.removeAll(removedItems);
			} finally {
				selectionsLock.writeLock().unlock();
			}
			
			removedItems.clear();
		}

		if (addedItems != null) {
			selectionsLock.writeLock().lock();
			try {
				selections.addAll(addedItems);
			} finally {
				selectionsLock.writeLock().unlock();
			}
			
			addedItems.clear();
		}
	
	}

	private Rectangle getLeftSelection(Rectangle intersection, Rectangle selection) {
		if (intersection.x > selection.x) {
			Rectangle leftSelection = new Rectangle(selection.x, selection.y,
					intersection.x - selection.x, selection.height);
			return leftSelection;
		}
		
		return null;
	}
	
	private Rectangle getRightSelection(Rectangle intersection, Rectangle selection) {
		int newX = intersection.x + intersection.width;
		
		if (newX < selection.x + selection.width) {
			Rectangle rightSelection = new Rectangle(newX, selection.y,
					selection.x + selection.width - newX, selection.height);

			return rightSelection;
		}
		
		return null;
	}
	
	private Rectangle getTopSelection(Rectangle intersection,
			Rectangle selectoin) {
		if (intersection.y > selectoin.y) {
			Rectangle topSelection = new Rectangle(selectoin.x, selectoin.y,
					selectoin.width, intersection.y - selectoin.y);
			return topSelection;
		}		
		return null;
	}
	
	private Rectangle getBottomSelection(Rectangle intersection,
			Rectangle selection) {
		int newY = intersection.y + intersection.height;

		if (newY < selection.y + selection.height) {
			Rectangle bottomSelection = new Rectangle(selection.x, newY,
					selection.width, selection.y + selection.height - newY);
			return bottomSelection;
		}

		return null;
	}
	
	public void removeSelection(int rowIndex, int columnIndex) {
		removeSelection(new Rectangle(columnIndex, rowIndex, 1, 1));
	}

	public boolean isEmpty() {
		selectionsLock.readLock().lock();
		try {
			return selections.isEmpty();
		} finally {
			selectionsLock.readLock().unlock();
		}
	}

	public int[] getSelectedRows() {
		TreeSet<Integer> selectedRows = new TreeSet<Integer>();

		selectionsLock.readLock().lock();
		
		try {
			for (Rectangle r : selections) {
				int startRow = r.y;
				int numRows = r.height;

				// Change from row < startRow to row < startRow+numRows
				for (int row = startRow; row < startRow + numRows; row++) {
					selectedRows.add(Integer.valueOf(row));
				}
			}
		} finally {
			selectionsLock.readLock().unlock();
		}

		int[] results = new int[selectedRows.size()];

		int index = 0;
		for (Integer row : selectedRows) {
			results[index] = row.intValue();
			index++;
		}

		return results;
	}

	public int[] getSelectedColumns() {
		TreeSet<Integer> selectedColumns = new TreeSet<Integer>();

		selectionsLock.readLock().lock();
		
		try {
			for (Rectangle r : selections) {
				int startColumn = r.x;
				int numColumns = r.width;

				// Change from row < startRow to row < startRow+numRows
				for (int column = startColumn; column < startColumn + numColumns; column++) {
					selectedColumns.add(Integer.valueOf(column));
				}
			}
		} finally {
			selectionsLock.readLock().unlock();
		}

		int[] results = new int[selectedColumns.size()];

		int index = 0;
		for (Integer column : selectedColumns) {
			results[index] = column.intValue();
			index++;
		}

		return results;
	}
	
	@Override
	public String toString() {
		selectionsLock.readLock().lock();
		
		try {
			return selections.toString();
		} finally {
			selectionsLock.readLock().unlock();
		}
	}

}
