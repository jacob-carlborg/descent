package net.sourceforge.nattable.action;

import net.sourceforge.nattable.support.SelectionSupport;

import org.eclipse.swt.events.KeyEvent;

public class SelectAllAction implements IKeyEventAction {
	
	private SelectionSupport selectionSupport;
	
	public SelectAllAction(SelectionSupport selectionSupport) {
		this.selectionSupport = selectionSupport;
	}
	
	public void run(KeyEvent event) {
		selectionSupport.selectAll();
	}

}
