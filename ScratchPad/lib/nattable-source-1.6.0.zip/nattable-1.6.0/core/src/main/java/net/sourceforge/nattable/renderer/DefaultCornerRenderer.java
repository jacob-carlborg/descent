package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.painter.cell.HeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;

import org.eclipse.swt.SWT;

public class DefaultCornerRenderer extends AbstractCellRenderer{
	private static final HeaderCellPainter cornerCellPainter = new HeaderCellPainter(SWT.CENTER | SWT.BORDER);
	
	public String getDisplayText(int row, int col) {
		return "";
	}
	
	public Object getValue(int row, int col) {
		return "";
	}

	public ICellPainter getCellPainter(int row, int col) {
		return cornerCellPainter;
	}
}
