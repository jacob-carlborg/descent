package net.sourceforge.nattable.config;

import net.sourceforge.nattable.renderer.ICellRenderer;

public interface IRegionConfig {

	public ICellRenderer getCellRenderer();
	
}
