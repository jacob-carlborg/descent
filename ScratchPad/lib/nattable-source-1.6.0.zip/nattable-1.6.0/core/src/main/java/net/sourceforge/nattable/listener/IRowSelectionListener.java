package net.sourceforge.nattable.listener;

/**
 * Author: Andy Tsoi<br>
 * Created Date : 2007�~9��23��
 */
public interface IRowSelectionListener {
	/**
	 * Is called if table row style is in full selection
	 * 
	 * @param row
	 */
	public void fireSelected(int[] row);

	/**
	 * Is called if table row style is in single cell selection
	 * 
	 * @param row
	 */
	public void fireSelected(int row[], int col[]);

}
