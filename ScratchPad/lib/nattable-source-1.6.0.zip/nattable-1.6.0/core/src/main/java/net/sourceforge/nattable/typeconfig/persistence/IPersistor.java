package net.sourceforge.nattable.typeconfig.persistence;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;

public interface IPersistor extends Serializable {
	public void load(InputStream store);

	public void save(OutputStream store);
}