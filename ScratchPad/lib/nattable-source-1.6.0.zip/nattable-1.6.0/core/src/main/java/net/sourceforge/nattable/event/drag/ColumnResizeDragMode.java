package net.sourceforge.nattable.event.drag;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.event.util.CellHandleUtil;

import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Rectangle;

public class ColumnResizeDragMode implements IDragMode {
	
	private NatTable natTable;
	
	private ResizeData resizeData = null;
	
	public ColumnResizeDragMode(NatTable natTable) {
		this.natTable = natTable;
	}

	public void mouseDown(MouseEvent event) {
		natTable.forceFocus();
		
		int modelGridRow = natTable.getModelGridRowByY(event.y);
		int modelGridColumn = natTable.getModelGridColumnByX(event.x);
		int selectedModelBodyColumn = natTable.getRegionMetricsSupport().modelGridToBodyColumn(modelGridColumn);
		int resizeModelBodyColumn = getResizeModelBodyColumn(selectedModelBodyColumn, event.x, event.y);
		
		Rectangle resizeModelBodyColumnRect = natTable.getModelBodyCellBound(modelGridRow, resizeModelBodyColumn);
		resizeData = new ResizeData(resizeModelBodyColumn, resizeModelBodyColumnRect, event.x);
	}
	
	public void mouseMove(MouseEvent event) {
		natTable.getColumnResizeSupport().resizeModelBodyColumn(resizeData.modelBodyColumn, resizeData.modelColumnHeaderCellRect, event.x - resizeData.startX);
	}

	public void mouseUp(MouseEvent event) {
		cleanup();
	}
	
	private int getResizeModelBodyColumn(int selectedModelBodyColumn, int x,
			int y) {
		return CellHandleUtil.getResizeModelBodyColumn(natTable, selectedModelBodyColumn, x, y);
	}
	
	private void cleanup() {
		resizeData = null;
	}
	
	static class ResizeData {
		
		int modelBodyColumn;
		
		Rectangle modelColumnHeaderCellRect;
		
		int startX;
		
		public ResizeData(int modelBodyColumn, Rectangle modelColumnHeaderCellRect, int startX) {
			this.modelBodyColumn = modelBodyColumn;
			this.modelColumnHeaderCellRect = modelColumnHeaderCellRect;
			this.startX = startX;
		}
		
	}

}
