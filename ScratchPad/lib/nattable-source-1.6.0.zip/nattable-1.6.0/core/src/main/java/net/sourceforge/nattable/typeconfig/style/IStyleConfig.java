package net.sourceforge.nattable.typeconfig.style;

import java.io.Serializable;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;

public interface IStyleConfig extends Serializable{
	
	public Color getBackgroundColor(int row, int col);
	
	public Color getForegroundColor(int row, int col);

	public Font getFont(int row, int col);
	
	public Image getImage(int row, int col);
	
}
