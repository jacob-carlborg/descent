package net.sourceforge.nattable.config;

import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.renderer.DefaultColumnHeaderRenderer;
import net.sourceforge.nattable.renderer.ICellRenderer;

public class DefaultColumnHeaderConfig implements IColumnHeaderConfig {

	private IColumnHeaderLabelProvider columnHeaderLabelProvider;
	
	private ICellRenderer columnHeaderRenderer;

	private int columnHeaderRowCount;
	
	private SizeConfig columnHeaderRowHeightConfig;
	
	public DefaultColumnHeaderConfig(IColumnHeaderLabelProvider columnHeaderLabelProvider) {
		this.columnHeaderLabelProvider = columnHeaderLabelProvider;
		initialize();
	}
	
	protected void initialize() {
		columnHeaderRenderer = new DefaultColumnHeaderRenderer(columnHeaderLabelProvider);
		
		columnHeaderRowCount = 1;
		
		// TODO calculate column header height based on column header text height
		columnHeaderRowHeightConfig = new SizeConfig(40);
	}

	// column header renderer
	
	public ICellRenderer getCellRenderer() {
		return columnHeaderRenderer;
	}
	
	public void setCellRenderer(ICellRenderer cellRenderer) {
		this.columnHeaderRenderer = cellRenderer;
	}
	
	// column header row count
	
	public int getColumnHeaderRowCount() {
		return columnHeaderRowCount;
	}
	
	public void setColumnHeaderRowCount(int columnHeaderRowCount) {
		this.columnHeaderRowCount = columnHeaderRowCount;
	}
	
	// column header row height
	
	public SizeConfig getColumnHeaderRowHeightConfig() {
		return columnHeaderRowHeightConfig;
	}
	
	public void setColumnHeaderRowHeightConfig(SizeConfig columnHeaderRowHeightConfig) {
		this.columnHeaderRowHeightConfig = columnHeaderRowHeightConfig;
	}

}
