package net.sourceforge.nattable.typeconfig.style;

public enum DisplayModeEnum {

	NORMAL,
	SELECT,
	EDIT;
	
}
