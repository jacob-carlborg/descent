package net.sourceforge.nattable.event.drag;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.event.util.CellHandleUtil;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.painter.IOverlayPainter;
import net.sourceforge.nattable.support.ColumnGroupSupport;
import net.sourceforge.nattable.util.GUIHelper;

import org.apache.log4j.Logger;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

public class ColumnReorderDragMode implements IDragMode {

	private NatTable natTable;
	
	private int dragFromModelBodyColumn = -1;
	
	private int dragToModelBodyColumn;
	
	private int dragToModelBodyColumnHandleX;
	
	private ColumnReorderOverlayPainter columnReorderOverlayPainter = new ColumnReorderOverlayPainter();
	
	Logger log = Logger.getLogger(ColumnReorderDragMode.class);
	
	public ColumnReorderDragMode(NatTable natTable) {
		this.natTable = natTable;
		cleanup();
		natTable.addOverlayPainter(columnReorderOverlayPainter);
	}
	
	public void mouseDown(MouseEvent event) {
		natTable.forceFocus();
		
		dragFromModelBodyColumn = natTable.getModelBodyColumnByX(event.x);
	}

	public void mouseMove(MouseEvent event) {
		Point dragPt = new Point(event.x, event.y);
		
		int modelGridColumn = natTable.getModelGridColumnByX(event.x);
		int modelGridRow = natTable.getModelGridRowByY(event.y);
		int selectedModelBodyColumn = natTable.getRegionMetricsSupport().modelGridToBodyColumn(modelGridColumn);
		Rectangle selectedModelBodyColumnRect = natTable.getModelGridCellBound(modelGridRow, modelGridColumn);
		
		if (selectedModelBodyColumn >= 0) {
			int reorderedDragFromColumn = natTable.modelToReorderedBodyColumn(dragFromModelBodyColumn);
			int reorderedSelectedColumn = natTable.modelToReorderedBodyColumn(selectedModelBodyColumn);
			
			switch (CellHandleUtil.getHorizontalCellHandle(selectedModelBodyColumnRect, dragPt)) {
			case LEFT:
				if (reorderedDragFromColumn < reorderedSelectedColumn) {
					int leftAdjacentReorderedBodyColumn = reorderedSelectedColumn - 1;
					dragToModelBodyColumn = natTable.reorderedToModelBodyColumn(leftAdjacentReorderedBodyColumn);
				} else {
					dragToModelBodyColumn = selectedModelBodyColumn;
				}
				
				dragToModelBodyColumnHandleX = selectedModelBodyColumnRect.x;
				break;
			case RIGHT:
				if (reorderedDragFromColumn > reorderedSelectedColumn) {
					int rightAdjacentReorderedBodyColumn = reorderedSelectedColumn + 1;
					dragToModelBodyColumn = natTable.reorderedToModelBodyColumn(rightAdjacentReorderedBodyColumn);
				} else {
					dragToModelBodyColumn = selectedModelBodyColumn;
				}
				
				dragToModelBodyColumnHandleX = selectedModelBodyColumnRect.x + selectedModelBodyColumnRect.width;
				break;
			}
		}

		natTable.redrawColumnHeaders();
	}
	
	public void mouseUp(MouseEvent event) {
		INatTableModel model = natTable.getNatTableModel();

		if (dragToModelBodyColumn >= 0
				&& dragToModelBodyColumn < model.getBodyColumnCount()
				&& dragToModelBodyColumn != dragFromModelBodyColumn) {
			if (dragFromModelBodyColumn >= 0) {
				if (natTable.isColumnGroupsEnabled()) {
					ColumnGroupSupport columnGroupSupport = natTable.getColumnGroupSupport();
					columnGroupSupport.reorderModelBodyColumn(dragFromModelBodyColumn, dragToModelBodyColumn);
				} else {
					natTable.getReorderSupport().reorderModelBodyColumn(dragFromModelBodyColumn, dragToModelBodyColumn);
				}
			}
			natTable.updateResize();
		} else {
			natTable.redrawColumnHeaders();
		}
		
		cleanup();
	}

	private void cleanup() {
		dragFromModelBodyColumn = -1;
		dragToModelBodyColumnHandleX = -1;
	}
	
	
	private class ColumnReorderOverlayPainter implements IOverlayPainter {
		
		public void paintOverlay(GC gc) {
			if (dragFromModelBodyColumn >= 0) {
				if (!natTable.isColumnGroupsEnabled() || natTable.getColumnGroupSupport().isColumnDragOperationSupported(dragFromModelBodyColumn, dragToModelBodyColumn)) {
					Color orgBgColor = gc.getBackground();
					gc.setBackground(GUIHelper.COLOR_DARK_GRAY);

					gc.fillRectangle(dragToModelBodyColumnHandleX, 0, 3, natTable.getTotalColumnHeaderHeight());

					gc.setBackground(orgBgColor);
				}
			}
			
		}
	
	}
}
