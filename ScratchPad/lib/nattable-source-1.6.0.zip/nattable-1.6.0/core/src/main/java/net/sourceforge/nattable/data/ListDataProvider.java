package net.sourceforge.nattable.data;

import java.util.List;

public class ListDataProvider<T> implements IRowDataProvider<T> {

	private List<T> list;
	
	private IColumnAccessor<T> columnAccessor;
	
	public ListDataProvider(List<T> list, IColumnAccessor<T> columnAccessor) {
		this.list = list;
		this.columnAccessor = columnAccessor;
	}
	
	public int getColumnCount() {
		return columnAccessor.getColumnCount();
	}
	
	public int getRowCount() {
		return list.size();
	}

	public Object getValue(int row, int col) {
		T rowObj = list.get(row);
		return columnAccessor.getColumnValue(rowObj, col);
	}
	
	public T getRowObject(int row) {
		return list.get(row);
	}

	public IColumnAccessor<T> getColumnAccessor() {
		return columnAccessor;
	}

}
