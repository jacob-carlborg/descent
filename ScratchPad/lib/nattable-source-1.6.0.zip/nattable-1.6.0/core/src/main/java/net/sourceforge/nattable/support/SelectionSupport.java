package net.sourceforge.nattable.support;

import java.util.List;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

public class SelectionSupport {

	private static final int NO_SELECTION = -1;
	private final NatTable natTable;
	private SelectionTypeEnum selectionType;
	private final SelectionModeEnum selectionMode;

	private final Point lastSelectedCell;
	private final Point selectionAnchor;
	private Rectangle lastSelectedRegion;

	public SelectionSupport(NatTable natTable, SelectionTypeEnum selectionType, SelectionModeEnum selectionMode) {

		this.natTable = natTable;
		this.selectionType = selectionType;
		this.selectionMode = selectionMode;

		lastSelectedCell = new Point(NO_SELECTION, NO_SELECTION);
		selectionAnchor = new Point(NO_SELECTION, NO_SELECTION);

	}

	public SelectionTypeEnum getSelectionType() {
		return selectionType;
	}
	
	public void setSelectionType(SelectionTypeEnum selectionType) {
		this.selectionType = selectionType;
	}
	
	public SelectionModeEnum getSelectionMode() {
		return selectionMode;
	}
	
	private void setLastSelectedCell(int bodyRowIndex, int bodyColumnIndex) {
		lastSelectedCell.x = bodyColumnIndex;
		lastSelectedCell.y = bodyRowIndex;
	}

	public Point getLastSelectedCell() {
		return lastSelectedCell;
	}

	public void moveLeft(boolean withShiftMask, boolean withControlMask) {
		if (hasColumnSelection()) {
			int viewIndex = lastSelectedCell.x;
			
			if (viewIndex > 0) {
				int newSelectedCol = - 1;
				
				for (int i = viewIndex - 1; i >= 0; i--) {
					int bodyColumnIndex = natTable.reorderedToModelBodyColumn(i);
					
					if (natTable.isModelBodyColumnViewable(bodyColumnIndex)) {
						newSelectedCol = i;
						break;
					}
				}
				
				if (newSelectedCol >= 0) {
					setSelectedCellWithViewIndexes(lastSelectedCell.y, newSelectedCol, withShiftMask, withControlMask);
					natTable.showBodyColumn(newSelectedCol, OrderEnum.FIRST);
				}
			}
			
		}
	}
	
	public void moveRight(boolean withShiftMask, boolean withControlMask) {
		if (hasColumnSelection()) {
			int bodyColumnCount = natTable.getNatTableModel().getBodyColumnCount();
			int viewIndex = lastSelectedCell.x;
			
			if (viewIndex < bodyColumnCount - 1) {
				int newSelectedCol = -1;
				
				for (int i = viewIndex + 1; i < bodyColumnCount; i++) {
					int bodyColumnIndex = natTable.reorderedToModelBodyColumn(i);
					
					if (natTable.isModelBodyColumnViewable(bodyColumnIndex)) {
						newSelectedCol = i;
						break;
					}
				}
				
				if (newSelectedCol >= 0) {
					setSelectedCellWithViewIndexes(lastSelectedCell.y, newSelectedCol, withShiftMask, withControlMask);
					natTable.showBodyColumn(newSelectedCol, OrderEnum.LAST);
				}
			}
		}
	}

	public void moveUp(boolean withShiftMask, boolean withControlMask) {
		if (hasRowSelection()) {

			if (lastSelectedCell.y > 0) {
				int newSelectedRow = lastSelectedCell.y - 1;
				setSelectedCellWithViewIndexes(newSelectedRow, lastSelectedCell.x, withShiftMask, withControlMask);
				List<Integer> visibleRowList = natTable.getVisibleModelBodyRows();

				if (visibleRowList != null) {
					if (!visibleRowList.contains(Integer.valueOf(newSelectedRow))) {
						int row = visibleRowList.get(0).intValue() - 1;
						if (row >= 0)
							natTable.showBodyRow(Integer.valueOf(row));
					}
				}

			}

		}
	}

	public void moveDown(boolean withShiftMask, boolean withControlMask) {
		if (hasRowSelection()) {

			if (lastSelectedCell.y < natTable.getNatTableModel().getBodyRowCount()) {
				int newSelectedRow = lastSelectedCell.y + 1;
				if (newSelectedRow < natTable.getNatTableModel().getBodyRowCount()) {
					setSelectedCellWithViewIndexes(newSelectedRow, lastSelectedCell.x, withShiftMask, withControlMask);

					List<Integer> visibleRowList = natTable.getVisibleModelBodyRows();
					List<Integer> visibleColList = natTable.getVisibleModelBodyColumns();

					if (visibleRowList != null) {
						if (!visibleRowList.contains(Integer.valueOf(newSelectedRow))) {

							natTable.showBodyRow(visibleRowList.get(1));
						} else if (visibleColList.size() > 0) {
							Rectangle cellBound = natTable.getModelBodyCellBound(newSelectedRow, visibleColList.get(0).intValue());
							boolean leftTopCorner = natTable.getClientArea().contains(cellBound.x, cellBound.y);
							boolean rightBottomCorner = natTable.getClientArea().contains(cellBound.x + cellBound.width,
									cellBound.y + cellBound.height);

							if (!leftTopCorner || !rightBottomCorner) {
								natTable.showBodyRow(visibleRowList.get(1));
							}
						}
					}
				}
			}

		}
	}

	private boolean hasRowSelection() {
		return lastSelectedCell.y != NO_SELECTION;
	}

	private boolean hasColumnSelection() {
		return lastSelectedCell.x != NO_SELECTION;
	}
	
	/**
	 * Toggles the selection state of the given (row, col).
	 * @param bodyRowIndex
	 * @param bodyColumnIndex
	 * @param withShiftMask
	 * @param withControlMask
	 * @return <code>false</code> if the cell was unselected.
	 */
	public boolean toggleCell(int bodyRowIndex, int bodyColumnIndex, boolean withShiftMask, boolean withControlMask) {
		if (selectionMode == SelectionModeEnum.MULTI) {
			if (!withShiftMask && withControlMask) {
				int bodyViewColumnIndex = natTable.modelToReorderedBodyColumn(bodyColumnIndex);
				
				if (natTable.getSelectionModel().isSelected(bodyRowIndex, bodyViewColumnIndex)) {
					if (selectionType == SelectionTypeEnum.ROW) {
						Rectangle selectedRow = new Rectangle(0, bodyRowIndex,
								natTable.getNatTableModel().getBodyColumnCount(), 1);
						
						natTable.getSelectionModel().removeSelection(selectedRow);
						natTable.redrawUpdatedBodyRow(bodyRowIndex, bodyRowIndex);
						return false;
					} else if (selectionType == SelectionTypeEnum.CELL) {
						natTable.getSelectionModel().removeSelection(bodyRowIndex, bodyViewColumnIndex);
						natTable.redrawUpdatedBodyRow(bodyRowIndex, bodyRowIndex);
						return false;
					} else if (selectionType == SelectionTypeEnum.COLUMN) {
						int rowCount = natTable.getNatTableModel().getBodyRowCount();
						Rectangle selectedColumn = new Rectangle(bodyViewColumnIndex, 0,
								1, rowCount);
						
						natTable.getSelectionModel().removeSelection(selectedColumn);
						natTable.redrawUpdatedBodyRow(0, rowCount - 1);
						
						return false;
					}
				}
			}
		}
		
		setSelectedCell(bodyRowIndex, bodyColumnIndex, withShiftMask, withControlMask);
		
		return true;
	}
	
	
	public void setSelectedCell(int bodyRowIndex, int bodyColumnIndex) {
		setSelectedCell(bodyRowIndex, bodyColumnIndex, false, false);
	}

	public void setSelectedCell(int bodyRowIndex, int bodyColumnIndex, boolean withShiftMask, boolean withControlMask) {
		int bodyViewColumnIndex = natTable.modelToReorderedBodyColumn(bodyColumnIndex);
		setSelectedCellWithViewIndexes(bodyRowIndex, bodyViewColumnIndex, withShiftMask, withControlMask);
	}
	
	private void setSelectedCellWithViewIndexes(int bodyRowIndex, int bodyViewColumnIndex, boolean withShiftMask, boolean withControlMask) {
		int[] previousSelectedRows = null;

		
		previousSelectedRows = natTable.getSelectionModel().getSelectedRows();
		
		if (selectionMode == SelectionModeEnum.SINGLE || (!withShiftMask && !withControlMask)) {
			natTable.getSelectionModel().clearSelection();
		}

		setLastSelectedCell(bodyRowIndex, bodyViewColumnIndex);

		if (selectionMode == SelectionModeEnum.MULTI && withShiftMask && lastSelectedRegion != null
				&& hasRowSelection()) {

			if (selectionType == SelectionTypeEnum.CELL || selectionType == SelectionTypeEnum.ROW) {
				lastSelectedRegion.height = Math.abs(selectionAnchor.y - bodyRowIndex) + 1;
				lastSelectedRegion.y = Math.min(selectionAnchor.y, bodyRowIndex);
			}
			
			if (selectionType == SelectionTypeEnum.CELL || selectionType == SelectionTypeEnum.COLUMN) {
				lastSelectedRegion.width = Math.abs(selectionAnchor.x - bodyViewColumnIndex) + 1;
				lastSelectedRegion.x = Math.min(selectionAnchor.x, bodyViewColumnIndex);
			}
			
			addSelection(lastSelectedRegion);
		} else {

			lastSelectedRegion = null;

			Rectangle selection = null;
			
			if (selectionType == SelectionTypeEnum.ROW) {
				selection = new Rectangle(0, lastSelectedCell.y, natTable.getNatTableModel().getBodyColumnCount(), 1);
			} else if (selectionType == SelectionTypeEnum.CELL) {
				selection = new Rectangle(lastSelectedCell.x, lastSelectedCell.y, 1, 1);
			} else if (selectionType == SelectionTypeEnum.COLUMN) {
				selection = new Rectangle(lastSelectedCell.x, 0, 1, natTable.getNatTableModel().getBodyRowCount());
			}

			addSelection(selection);
		}

		// Clean the previous selected rows
		if (previousSelectedRows != null) {
			int len = previousSelectedRows != null ? previousSelectedRows.length : 0;
			if (len > 0) {
				natTable.redrawUpdatedBodyRow(previousSelectedRows[0], previousSelectedRows[len - 1]);
			}
		}

		// Redraw the new selected rows

		if (!natTable.getSelectionModel().isEmpty()) {
			if (selectionMode == SelectionModeEnum.SINGLE ) {
				if (lastSelectedRegion != null)
					natTable.redrawUpdatedBodyRow(lastSelectedRegion.y, lastSelectedRegion.y);
			} else {
				int[] selected = natTable.getSelectionModel().getSelectedRows();
				if (selected != null && selected.length > 0) {
					natTable.redrawUpdatedBodyRow(selected[0], selected[selected.length - 1]);
				}
			}
		} else {
			// In case something wrong
			natTable.redraw();
		}
		
	}

	private void addSelection(Rectangle selection) {
		if (selection != lastSelectedRegion) {
			selectionAnchor.x = lastSelectedCell.x;
			selectionAnchor.y = lastSelectedCell.y;

			lastSelectedRegion = selection;
		}
		
		natTable.getSelectionModel().addSelection(selection);
	}

	public void selectAll() {
		Rectangle selection = new Rectangle(0, 0, natTable.getNatTableModel().getBodyColumnCount(), natTable
				.getNatTableModel().getBodyRowCount());
		addSelection(selection);
		natTable.redraw();
	}

	public void selectColumns(int[] columns) {
		SelectionTypeEnum oldSelectionType = getSelectionType();
		setSelectionType(SelectionTypeEnum.COLUMN);
		
		for (int i = 0; i < columns.length; i++) {
			boolean withControl = (i != 0);
			
			int viewIndex = natTable.modelToReorderedBodyColumn(columns[i]);
			setSelectedCellWithViewIndexes(0, viewIndex, false, withControl);
		}
		
		setSelectionType(oldSelectionType);
	}

	public void clear() {
		int[] previousSelectedRows = null;
		previousSelectedRows = natTable.getSelectionModel().getSelectedRows();
		
		natTable.getSelectionModel().clearSelection();
		
		// Clean the previous selected rows
		if (previousSelectedRows != null) {
			int len = previousSelectedRows != null ? previousSelectedRows.length : 0;
			if (len > 0) {
				natTable.redrawUpdatedBodyRow(previousSelectedRows[0], previousSelectedRows[len - 1]);
			}
		}
	}

}
