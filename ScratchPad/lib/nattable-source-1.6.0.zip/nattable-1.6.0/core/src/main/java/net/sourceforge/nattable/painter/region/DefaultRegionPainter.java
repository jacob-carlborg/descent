package net.sourceforge.nattable.painter.region;

import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.renderer.ICellRenderer;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;

public abstract class DefaultRegionPainter implements IRegionPainter {

	private NatTable natTable;
	
	public DefaultRegionPainter(NatTable natTable) {
		this.natTable = natTable;
	}
	
	protected abstract ICellRenderer getCellRenderer();

	protected abstract int getRowHeight(int row);

	protected abstract int getColumnWidth(int col);
	
	public void drawRegion(final int numRows, final int numCols, final int xOffset,
			final int yOffset, final List<Integer> visibleRowList, final List<Integer> visibleColList, final GC gc,
			final Rectangle client) {
		int currentHeight = yOffset;
		final ICellRenderer cellRenderer = getCellRenderer();
		
		for (int regionRow = 0; regionRow < numRows; regionRow++) {
			final int visibleRow = visibleRowList != null ? visibleRowList.get(regionRow).intValue() : regionRow;

			final int height = getRowHeight(visibleRow);
			if (cellRenderer != null) {
				int currentWidth = xOffset;
				for (int regionCol = 0; regionCol < numCols; regionCol++) {
					final int visibleCol = visibleColList != null ? visibleColList.get(regionCol).intValue() : regionCol;

					final int width = getColumnWidth(visibleCol);

					final Rectangle rectangle = new Rectangle(currentWidth, currentHeight, width, height);

					final ICellPainter cellPainter = cellRenderer.getCellPainter(visibleRow, visibleCol);

					if (client.intersects(rectangle)) {
						drawCell(gc, cellRenderer, visibleRow, visibleCol,
								rectangle, cellPainter);
					}

					currentWidth += width;
				}
			}
			currentHeight += height;
		}
	}

	protected void drawCell(final GC gc, final ICellRenderer cellRenderer,
			final int visibleRow, final int visibleCol,
			final Rectangle rectangle, final ICellPainter cellPainter) {
		cellPainter.drawCell(gc, rectangle, natTable, cellRenderer, visibleRow, visibleCol, false);
	}

}
