package net.sourceforge.nattable.painter.region;

import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.support.ColumnGroupSupport;

import org.apache.log4j.Logger;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;


public class ColumnGroupHeaderRegionPainter extends DefaultColumnHeaderRegionPainter {

	private INatTableModel model;
	private NatTable natTable;
	Logger log = Logger.getLogger(ColumnGroupHeaderRegionPainter.class);
	
	public ColumnGroupHeaderRegionPainter(NatTable natTable) {
		super(natTable);
		this.natTable = natTable;
		this.model = natTable.getNatTableModel();
	}

	public void drawRegion(final int numRows, final int numCols, final int xOffset,
			final int yOffset, final List<Integer> visibleRowList, final List<Integer> visibleColList, final GC gc,
			final Rectangle client) {
		int currentHeight = yOffset;
		final ICellRenderer cellRenderer = getCellRenderer();
		
		ColumnGroupSupport support = natTable.getColumnGroupSupport();
		String currentColumnGroup = null;
		for (int regionRow = 0; regionRow < numRows; regionRow++) {
			final int visibleRow = visibleRowList != null ? visibleRowList.get(regionRow).intValue() : regionRow;

			final int height = getRowHeight(visibleRow);
			if (cellRenderer != null) {
				int currentWidth = xOffset;
				for (int regionCol = 0; regionCol < numCols; regionCol++) {
					final int visibleCol = visibleColList != null ? visibleColList.get(regionCol).intValue() : regionCol;
				
					final int width = getColumnWidth(visibleCol);
					
					final Rectangle rectangle = new Rectangle(currentWidth, currentHeight, width, height);

					final ICellPainter cellPainter = cellRenderer.getCellPainter(visibleRow, visibleCol);

					if (client.intersects(rectangle)) {
						if (visibleRow == 0 && support.isColumnInColumnGroup(visibleCol)) {
							String columnGroup = support.getColumnGroupName(visibleCol);
							if (columnGroup != null && !columnGroup.equals(currentColumnGroup)) {
								int colGroupWidth = getColumnGroupWidth(columnGroup, visibleColList);
								currentColumnGroup = columnGroup;
								Rectangle colGroupRectangle = new Rectangle(currentWidth, currentHeight, colGroupWidth, height);		
								cellPainter.drawCell(gc, colGroupRectangle, natTable, cellRenderer, visibleRow, visibleCol, false);
							}
						} else {
							cellPainter.drawCell(gc, rectangle, natTable, cellRenderer, visibleRow, visibleCol, false);
						}
					}

					currentWidth += width;
				}
			}
			currentHeight += height;
		}
	}

	private int getColumnGroupWidth(String columnGroup, List<Integer> visibleColumns) {
		int width = 0;
		
		ColumnGroupSupport columnGroupSupport = natTable.getColumnGroupSupport();
		List<Integer> columnGroupMembers = columnGroupSupport.getColumnGroupMembers(columnGroup);
		if (columnGroupSupport.isExpanded(columnGroup)) {
			
			for (Integer columnGroupMember : columnGroupMembers) {
				if (visibleColumns != null && visibleColumns.contains(columnGroupMember))
					width += model.getBodyColumnWidth(columnGroupMember.intValue());
			}
		} else {
			width = model.getBodyColumnWidth(columnGroupMembers.get(0).intValue());
		}
		return width;
	}
}
