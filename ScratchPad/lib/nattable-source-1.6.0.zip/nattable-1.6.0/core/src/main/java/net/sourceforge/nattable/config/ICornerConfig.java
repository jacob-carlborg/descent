package net.sourceforge.nattable.config;

public interface ICornerConfig extends IRegionConfig {

}
