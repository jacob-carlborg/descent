package net.sourceforge.nattable.support;

public interface ISelectionValidator {
	
	boolean isSelectionValid();
	
}
