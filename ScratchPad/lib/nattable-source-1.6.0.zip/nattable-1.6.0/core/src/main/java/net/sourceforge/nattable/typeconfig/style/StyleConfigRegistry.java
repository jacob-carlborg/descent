package net.sourceforge.nattable.typeconfig.style;

import java.util.HashMap;
import java.util.Map;


import net.sourceforge.nattable.typeconfig.AbstractConfigRegistry;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;

public class StyleConfigRegistry extends AbstractConfigRegistry {

	public StyleConfigRegistry() {
	}
	
	public StyleConfigRegistry(IConfigTypeResolver styleConfigTypeResolver) {
		super(styleConfigTypeResolver);
	}
	
	// Display mode ordering //////////////////////////////////////////////////

	private IDisplayModeOrdering displayModeOrdering = new DefaultDisplayModeOrdering();

	public IDisplayModeOrdering getDisplayModeOrdering() {
		return displayModeOrdering;
	}

	public void setDisplayModeOrdering(IDisplayModeOrdering displayModeOrdering) {
		this.displayModeOrdering = displayModeOrdering;
	}
	
	// Cell painter ///////////////////////////////////////////////////////////
	
	// TODO
	
	// Style config ///////////////////////////////////////////////////////////

	private Map<String, IStyleConfig> defaultStyleConfigMap = new HashMap<String, IStyleConfig>();

	private Map<String, Map<String, IStyleConfig>> styleConfigMap = new HashMap<String, Map<String, IStyleConfig>>();

	public Map<String, IStyleConfig> getDefaultStyleConfigMap() {
		return defaultStyleConfigMap;
	}

	public Map<String, Map<String, IStyleConfig>> getStyleConfigMap() {
		return styleConfigMap;
	}

	public void registerDefaultStyleConfig(String displayMode, IStyleConfig styleConfig) {
		defaultStyleConfigMap.put(displayMode, styleConfig);
	}

	public void registerStyleConfig(String displayMode, String styleConfigType, IStyleConfig styleConfig) {
		Map<String, IStyleConfig> typeStyleConfigMap = styleConfigMap.get(displayMode);
		if (typeStyleConfigMap == null) {
			typeStyleConfigMap = new HashMap<String, IStyleConfig>();
			styleConfigMap.put(displayMode, typeStyleConfigMap);
		}
		typeStyleConfigMap.put(styleConfigType, styleConfig);
	}
	
	public void unregisterStyleConfig(String displayMode, String styleConfigType) {
		Map<String, IStyleConfig> typeStyleConfigMap = styleConfigMap.get(displayMode);
		if (typeStyleConfigMap != null) {
			typeStyleConfigMap.remove(styleConfigType);
		}
	}

	public IStyleConfig getDefaultStyleConfig(String displayMode) {
		return defaultStyleConfigMap.get(displayMode);
	}

	public IStyleConfig getStyleConfig(String targetDisplayMode, int modelBodyRow, int modelBodyColumn) {
		return new StyleConfigProxy(targetDisplayMode, getConfigType(modelBodyRow, modelBodyColumn));
	}

	public IStyleConfig getStyleConfig(String targetDisplayMode, String styleConfigType) {
		return new StyleConfigProxy(targetDisplayMode, styleConfigType);
	}

	private class StyleConfigProxy implements IStyleConfig {

		private static final long serialVersionUID = 1L;

		private String targetDisplayMode;

		private String styleConfigType;

		public StyleConfigProxy(String targetDisplayMode, String styleConfigType) {
			this.targetDisplayMode = targetDisplayMode;
			this.styleConfigType = styleConfigType;
		}

		public Color getBackgroundColor(int row, int col) {
			return (Color) getStyleAttribute(backgroundStyleAccessor, targetDisplayMode, styleConfigType, row, col);
		}

		public Color getForegroundColor(int row, int col) {
			return (Color) getStyleAttribute(foregroundStyleAccessor, targetDisplayMode, styleConfigType, row, col);
		}

		public Font getFont(int row, int col) {
			return (Font) getStyleAttribute(fontStyleAccessor, targetDisplayMode, styleConfigType, row, col);
		}

		public Image getImage(int row, int col) {
			return (Image) getStyleAttribute(imageStyleAccessor, targetDisplayMode, styleConfigType, row, col);
		}

	}

	private Object getStyleAttribute(IStyleAttributeAccessor<?> styleAttributeAccessor, String targetDisplayMode, String targetStyleConfigType, int row, int col) {
		// scan display mode ordering
		for (String displayMode : displayModeOrdering.getDisplayModeOrdering(targetDisplayMode)) {
			String styleConfigType = targetStyleConfigType;
			// scan configType hierarchy
			while (styleConfigType != null) {
				Object styleAttribute = null;

				Map<String, IStyleConfig> typeStyleConfigMap = styleConfigMap.get(displayMode);
				if (typeStyleConfigMap != null) {
					styleAttribute = getStyleAttributeFromAccessor(styleAttributeAccessor, typeStyleConfigMap.get(styleConfigType), row, col);
				}
				
				if (styleAttribute != null) {
					return styleAttribute;
				} else {
					styleConfigType = getSuperType(styleConfigType);
				}
			}
		}
		// if no attribute is found scan the display mode defaults
		for (String displayMode : displayModeOrdering.getDisplayModeOrdering(targetDisplayMode)) {
			Object styleAttribute = getStyleAttributeFromAccessor(styleAttributeAccessor, defaultStyleConfigMap.get(displayMode), row, col);
			if (styleAttribute != null) {
				return styleAttribute;
			}
		}
		return null;
	}

	private Object getStyleAttributeFromAccessor(IStyleAttributeAccessor<?> styleAttributeAccessor, IStyleConfig styleConfig, int row, int col) {
		if (styleConfig != null) {
			Object styleAttribute = styleAttributeAccessor.getStyleAttribute(styleConfig, row, col);
			if (styleAttribute != null) {
				return styleAttribute;
			}
		}
		return null;
	}

	private interface IStyleAttributeAccessor<T> {
		T getStyleAttribute(IStyleConfig styleConfig, int row, int col);
	}

	private IStyleAttributeAccessor<Color> backgroundStyleAccessor = new IStyleAttributeAccessor<Color>() {

		public Color getStyleAttribute(IStyleConfig styleConfig, int row, int col) {
			return styleConfig.getBackgroundColor(row, col);
		}

	};

	private IStyleAttributeAccessor<Color> foregroundStyleAccessor = new IStyleAttributeAccessor<Color>() {

		public Color getStyleAttribute(IStyleConfig styleConfig, int row, int col) {
			return styleConfig.getForegroundColor(row, col);
		}

	};

	private IStyleAttributeAccessor<Font> fontStyleAccessor = new IStyleAttributeAccessor<Font>() {

		public Font getStyleAttribute(IStyleConfig styleConfig, int row, int col) {
			return styleConfig.getFont(row, col);
		}

	};

	private IStyleAttributeAccessor<Image> imageStyleAccessor = new IStyleAttributeAccessor<Image>() {

		public Image getStyleAttribute(IStyleConfig styleConfig, int row, int col) {
			return styleConfig.getImage(row, col);
		}

	};
	
}
