package net.sourceforge.nattable.typeconfig;

import java.io.Serializable;

import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.IRowIdAccessor;

public class TypedRowOverrider<T> extends AbstractOverrider {
	
	private IRowDataProvider<T> dataProvider;
	private IRowIdAccessor<T> idAccessor;

	public TypedRowOverrider(IRowDataProvider<T> dataProvider, IRowIdAccessor<T> idAccessor) {
		this.dataProvider = dataProvider;
		this.idAccessor = idAccessor;
	}
	
	public String getConfigType(int row, int col) {
		return overrides.get(idAccessor.getRowId(dataProvider.getRowObject(row)));
	}

	public void registerOverride(String value, int row) {
		Serializable id = idAccessor.getRowId(dataProvider.getRowObject(row));
		overrides.put(id, value);
	}
}
