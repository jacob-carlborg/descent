package net.sourceforge.nattable.event;

import net.sourceforge.nattable.action.IKeyEventAction;
import net.sourceforge.nattable.event.matcher.IKeyEventMatcher;

public class KeyBinding {

	private IKeyEventMatcher keyEventMatcher;
	
	private IKeyEventAction action;
	
	public KeyBinding(IKeyEventMatcher keyEventMatcher, IKeyEventAction action) {
		this.keyEventMatcher = keyEventMatcher;
		this.action = action;
	}
	
	public IKeyEventMatcher getKeyEventMatcher() {
		return keyEventMatcher;
	}
	
	public IKeyEventAction getAction() {
		return action;
	}
	
}
