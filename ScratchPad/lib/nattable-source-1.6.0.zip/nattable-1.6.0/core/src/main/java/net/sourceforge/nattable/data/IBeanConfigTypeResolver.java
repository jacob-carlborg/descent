package net.sourceforge.nattable.data;


public interface IBeanConfigTypeResolver<T> {

	public String getConfigType(T rowObject, String fieldName);
}