package net.sourceforge.nattable.listener;

import org.eclipse.swt.events.MouseEvent;

import net.sourceforge.nattable.GridRegionEnum;
import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.RegionMetricsSupport;

public class NatEventData {
	
	private Object originalEventData;

	private final NatTable natTable;
	
	private final GridRegionEnum region;

	int rowIndex;

	int colIndex;

	public static NatEventData createInstanceFromEvent(MouseEvent event) {
		NatTable natTable = (NatTable) event.widget;
		
		int modelGridRow = natTable.getModelGridRowByY(event.y);
		int modelGridCol = natTable.getModelGridColumnByX(event.x);
		RegionMetricsSupport metricsSupport = natTable.getRegionMetricsSupport();
		GridRegionEnum region = metricsSupport.getRegion(modelGridRow, modelGridCol);		
		return new NatEventData(
				natTable,
				region,
				metricsSupport.modelGridToRegionRow(region, modelGridRow),
				metricsSupport.modelGridToRegionColumn(region, modelGridCol),
				event.data
		);
	}
	
	public NatEventData(NatTable natTable, GridRegionEnum region, int gridRow, int gridCol, Object originalEventData) {
		this.natTable = natTable;
		this.region = region;
		this.rowIndex = gridRow;
		this.colIndex = gridCol;
		this.originalEventData = originalEventData;
	}

	public NatTable getNatTable() {
		return natTable;
	}

	public GridRegionEnum getRegion() {
		return region;
	}

	public int getRowIndex() {
		return rowIndex;
	}

	public int getColumnIndex() {
		return colIndex;
	}
	
	public Object getOriginalEventData() {
		return originalEventData;
	}

}