package net.sourceforge.nattable.support;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.util.RowHeightIndex;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

public class VisibleMetricsSupport {
	
	private IClientAreaProvider clientAreaProvider;
	
	private final RowHeightIndex heightIndex;
	
	private final INatTableModel model;
	
	private final ReentrantLock lock = new ReentrantLock();
	
	private List<Integer> cachedVisibleBodyColIndices;

	private List<Integer> cachedVisibleBodyRowList;
	
	private ColumnTransformSupport gridTransformSupport;
	
	private final Point origin = new Point(0, 0);
	
	private boolean regenColumnsCache = true;
	
	private boolean regenRowsCache = true;
	
	public VisibleMetricsSupport(IClientAreaProvider clientAreaProvider, INatTableModel model, ColumnTransformSupport gridTransformSupport) {
		this.clientAreaProvider = clientAreaProvider;		
		this.model = model;
		this.heightIndex = new RowHeightIndex(this.model);
		this.gridTransformSupport = gridTransformSupport;
	}
	
	private Rectangle getClientArea() {
		return clientAreaProvider.getClientArea();
	}
	
	public void setOriginX(int x) {
		origin.x = x;
	}
	
	public void setOriginY(int y) {
		origin.y = y;
	}

	public void refresh() {
		lock.lock();
		try {
			regenColumnsCache = true;
			regenRowsCache = true;
			heightIndex.refresh();
		} finally {
			lock.unlock();
		}		
	}
	
	public void reset() {
		lock.lock();
		try {
			regenColumnsCache = true;
			regenRowsCache = true;
		} finally {
			lock.unlock();
		}
	}
	
// Visible ////////////////////////////////////////////////////////////////
	
	/**
	 * Get visible body column indexes.
	 * 
	 * @return List of visible body column indexes.
	 */
	public List<Integer> getVisibleModelBodyColumns() {
		lock.lock();
		try {
			if (regenColumnsCache) {
				regenColumnsCache = false;

				internalSetVisibleModelBodyColumns();

			}
		} finally {
			lock.unlock();
		}
		return cachedVisibleBodyColIndices;
	}
	
	private void internalSetVisibleModelBodyColumns() {
		final List<Integer> arrayList = new ArrayList<Integer>();

		// Calculate row header column widths
		int availableColumnWidth = getClientArea().width;
		for (int col = 0; col < model.getRowHeaderColumnCount(); col++) {
			final int width = model.getRowHeaderColumnWidth(col);
			availableColumnWidth -= width;
		}

		final int start = Math.abs(origin.x);
		int current = 0;// model.getColumnCount() > 0 ?
		// model.getColumnWidth(0) : 0;
		int used = 0;

		final int[] modelBodyColumnOrder = gridTransformSupport.getModelBodyColumnOrder();
		Set<Integer> hiddenModelBodyColumns = gridTransformSupport.getHiddenModelBodyColumns();
		if (model.getFreezeColumnCount() > 0) {
			int len = model.getFreezeColumnCount();
			for (int i = 0; i < len && used < availableColumnWidth; i++) {
				if (i < modelBodyColumnOrder.length &&
						(hiddenModelBodyColumns == null || !hiddenModelBodyColumns.contains(Integer.valueOf(modelBodyColumnOrder[i])))) {
					final int width = model.getBodyColumnWidth(modelBodyColumnOrder[i]);
					used += width;
					current += width;
					arrayList.add(Integer.valueOf(modelBodyColumnOrder[i]));
				}
			}					
		}

		for (int col = model.getFreezeColumnCount(); col < modelBodyColumnOrder.length && used < availableColumnWidth; col++) {
			if (hiddenModelBodyColumns == null || !hiddenModelBodyColumns.contains(Integer.valueOf(modelBodyColumnOrder[col]))) {
				final int width = model.getBodyColumnWidth(modelBodyColumnOrder[col]);

				if (start <= current) {
					used += width;
					arrayList.add(Integer.valueOf(modelBodyColumnOrder[col]));
					if (used >= availableColumnWidth) {
						break;
					}
				}
				current += width;
			}
		}
		cachedVisibleBodyColIndices = arrayList;
	}

	public List<Integer> getVisibleModelBodyRows() {
		lock.lock();
		try {
			if (regenRowsCache) {
				regenRowsCache = false;
				internalSetVisisbleModelBodyRows();
			}
		} finally {
			lock.unlock();
		}
		
		return cachedVisibleBodyRowList;
	}
	
	private void internalSetVisisbleModelBodyRows() {		
		final Rectangle client = getClientArea();

		final int y = Math.abs(origin.y); // TODO Should this be abs?
		// Maybe
		// instead: y = origin.y >=0 ?
		// origin.y : 0
		final List<Integer> arrayList = new ArrayList<Integer>();

		// Find total height of column headers
		final int totalColumnHeaderRowHeight = getTotalColumnHeaderHeight();

		// TFH - client.Height = available height to display rows
		final int availableHeight = client.height - totalColumnHeaderRowHeight;

		// use y to find the first row
		final int rowCount = model.getBodyRowCount();
		int current = 0;// model.getRowCount() > 0 ?
		// model.getRowHeight(0) :
		// 0;
		int used = 0;

		final int start = heightIndex.getBestStartingSearchRow(y);
		current = heightIndex.getHeightByStartIndex(start);
		
		if (model.getFreezeRowCount() > 0) {
			int len = model.getFreezeRowCount();
			for (int i = 0; i < len && used < availableHeight; i++) {
				final int height = model.getBodyRowHeight(i);
				current += height;
				used += height;
				arrayList.add(Integer.valueOf(i));
			}
		}

		for (int i = start; i < rowCount && used < availableHeight; i++) {
			final int height = model.getBodyRowHeight(model.isAllBodyRowsSameHeight() ? 0 : i);
			current += height;
			// Change from <= to <
			if (y < current) {
				used += height;
				arrayList.add(Integer.valueOf(i));
				if (used > availableHeight) {
					break;
				}
			}

		}
		cachedVisibleBodyRowList = arrayList;
	}
	
	// Calculate aggregate region extents /////////////////////////////////////

	public int getTotalColumnHeaderHeight() {
		int totalColHeaderHeight = 0;

		final int colHeaderRowCount = model.getColumnHeaderRowCount();
		for (int i = 0; i < colHeaderRowCount; i++) {
			totalColHeaderHeight += model.getColumnHeaderRowHeight(i);
		}

		return totalColHeaderHeight;
	}

	public int getBodyScrollableViewWidth() {
		int width = getClientArea().width - getTotalRowHeaderWidth() - getFrozenColumnsWidth();
		
		return Math.max(0, width);
	}
	
	private int getFrozenColumnsWidth() {
		int freezeColumnCount = model.getFreezeColumnCount();
		
		if (freezeColumnCount == 0)
			return 0;
		
		int width = 0;
		
		for (int i = 0; i < freezeColumnCount; i++) {
			int modelBodyColumn = gridTransformSupport.reorderedToModelBodyColumn(i);
			width += model.getBodyColumnWidth(modelBodyColumn);
		}
		
		return width;
	}
	
	public int getTotalRowHeaderWidth() {
		int totalRowHeaderWidth = 0;

		final int rowHeaderColumnCount = model.getRowHeaderColumnCount();
		for (int col = 0; col < rowHeaderColumnCount; col++) {
			totalRowHeaderWidth += model.getRowHeaderColumnWidth(col);
		}

		return totalRowHeaderWidth;
	}

	public int getTotalBodyHeight() {
		int totalBodyHeight = 0;

		final int bodyRowCount = model.getBodyRowCount();
		for (int row = 0; row < bodyRowCount; row++) {
			totalBodyHeight += model.getBodyRowHeight(row);
		}

		return totalBodyHeight;
	}

	public int getTotalBodyWidth() {
		int totalBodyWidth = 0;

		final int[] modelBodyColumnOrder = gridTransformSupport.getModelBodyColumnOrder();
		
		for (int col = 0; col < modelBodyColumnOrder.length; col++) {
			totalBodyWidth += model.getBodyColumnWidth(modelBodyColumnOrder[col]);
		}

		return totalBodyWidth;
	}
	
	public int getTotalViewableBodyWidth() {
		int totalBodyWidth = 0;

		final int[] modelBodyColumnOrder = gridTransformSupport.getModelBodyColumnOrder();
		
		for (int col = 0; col < modelBodyColumnOrder.length; col++) {
			if (gridTransformSupport.isModelBodyColumnViewable(modelBodyColumnOrder[col])) {
				totalBodyWidth += model.getBodyColumnWidth(modelBodyColumnOrder[col]);
			}
		}

		return totalBodyWidth;

	}

	public int getHeightByStartIndex(int startBodyRow) {
		return heightIndex.getHeightByStartIndex(startBodyRow);
	}
	
	public RowHeightIndex getHeightIndex() {
		return heightIndex;
	}
}
