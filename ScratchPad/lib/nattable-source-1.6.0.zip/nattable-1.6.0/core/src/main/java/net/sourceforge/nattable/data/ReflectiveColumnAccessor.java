package net.sourceforge.nattable.data;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class ReflectiveColumnAccessor<R> implements IColumnPropertyAccessor<R> {

	private String[] propertyNames;
	
	private Map<String, Field> propertyFieldMap = new HashMap<String, Field>();
	
	public ReflectiveColumnAccessor(String[] propertyNames) throws SecurityException, NoSuchFieldException {
		this.propertyNames = propertyNames;
	}
	
	public int getColumnCount() {
		return propertyNames.length;
	}
	
	public Object getColumnValue(R rowObj, int col) {
		try {
			Field propertyField = propertyFieldMap.get(propertyNames[col]);
			if (propertyField == null) {
				propertyField = rowObj.getClass().getDeclaredField(propertyNames[col]);
				propertyField.setAccessible(true);
				propertyFieldMap.put(propertyNames[col], propertyField);
			}
			return propertyField.get(rowObj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public String getColumnProperty(int col) {
		return propertyNames[col];
	}
	
}
