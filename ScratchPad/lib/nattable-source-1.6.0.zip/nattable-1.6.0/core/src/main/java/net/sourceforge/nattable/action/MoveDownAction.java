package net.sourceforge.nattable.action;

import net.sourceforge.nattable.support.SelectionSupport;

import org.eclipse.swt.events.KeyEvent;

public class MoveDownAction extends AbstractKeySelectAction {
	
	public MoveDownAction(SelectionSupport selectionSupport, boolean withShiftMask, boolean withControlMask) {
		super(selectionSupport, withShiftMask, withControlMask);
	}
	
	public void run(KeyEvent event) {
		selectionSupport.moveDown(withShiftMask, withControlMask);
	}

}
