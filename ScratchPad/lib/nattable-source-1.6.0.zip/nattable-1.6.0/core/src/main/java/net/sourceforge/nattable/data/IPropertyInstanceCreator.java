package net.sourceforge.nattable.data;

public interface IPropertyInstanceCreator {
	public <T> T getPropertyInstance(Class<T> propertyClass, Object property);
}
