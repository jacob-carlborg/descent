package net.sourceforge.nattable.event.drag;

import org.eclipse.swt.events.MouseEvent;

public interface IDragMode {

	public void mouseDown(MouseEvent event);
	
	public void mouseMove(MouseEvent event);
	
	public void mouseUp(MouseEvent event);
	
}
