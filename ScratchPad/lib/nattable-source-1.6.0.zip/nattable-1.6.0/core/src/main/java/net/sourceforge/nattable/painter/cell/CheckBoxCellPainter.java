package net.sourceforge.nattable.painter.cell;

import net.sourceforge.nattable.renderer.ICellRenderer;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~9��23��<br>
 */
public class CheckBoxCellPainter extends TextCellPainter {

	public final static Image checkedImage = new Image(Display.getDefault(), CheckBoxCellPainter.class.getClassLoader()
			.getResourceAsStream("checked.gif"));
	public final static Image uncheckedImage = new Image(Display.getDefault(), CheckBoxCellPainter.class
			.getClassLoader().getResourceAsStream("unchecked.gif"));

	public CheckBoxCellPainter() {
	}

	public CheckBoxCellPainter(int style) {
		this.style = style;
	}

	@Override
	protected Image getImage(ICellRenderer natCellRenderer, int row, int col) {
		Object obj = natCellRenderer.getValue(row, col);
		if (obj instanceof Boolean) {
			Boolean ans = (Boolean) obj;
			if (ans.booleanValue()) {
				return checkedImage;
			} else {
				return uncheckedImage;
			}
		} else {
			return uncheckedImage;
		}
	}
}
