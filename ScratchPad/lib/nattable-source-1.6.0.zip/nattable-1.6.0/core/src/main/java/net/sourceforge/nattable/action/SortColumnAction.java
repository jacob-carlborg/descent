package net.sourceforge.nattable.action;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.RegionMetricsSupport;

public class SortColumnAction implements IMouseEventAction {

	private NatTable natTable;
	
	public SortColumnAction(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void run(MouseEvent event) {
		natTable.forceFocus();
		
		int modelGridRow = natTable.getModelGridRowByY(event.y);
		int modelGridColumn = natTable.getModelGridColumnByX(event.x);

		RegionMetricsSupport metricsSupport = natTable.getRegionMetricsSupport();
		if (metricsSupport.isModelColumnHeaderCell(modelGridRow, modelGridColumn)) {
			int selectedModelBodyColumn = metricsSupport.modelGridToBodyColumn(modelGridColumn);

			natTable.getSelectionSupport().clear();

			boolean accumulate = (event.stateMask & SWT.ALT) == SWT.ALT;
			
			natTable.getColumnSortSupport().sortModelBodyColumn(selectedModelBodyColumn, accumulate);
			natTable.updateResize();
		}
	}

}
