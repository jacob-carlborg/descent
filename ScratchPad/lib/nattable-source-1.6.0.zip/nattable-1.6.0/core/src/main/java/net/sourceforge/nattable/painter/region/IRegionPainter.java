package net.sourceforge.nattable.painter.region;

import java.util.List;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;

public interface IRegionPainter {

	public void drawRegion(int numRows, int numCols, int xOffset,
			int yOffset, List<Integer> visibleRowList, List<Integer> visibleColList, GC gc,
			Rectangle client);
	
}
