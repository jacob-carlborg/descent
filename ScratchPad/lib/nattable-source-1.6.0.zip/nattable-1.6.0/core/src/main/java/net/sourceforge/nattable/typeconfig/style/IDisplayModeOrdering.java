package net.sourceforge.nattable.typeconfig.style;

import java.util.List;

public interface IDisplayModeOrdering {
	
	public List<String> getDisplayModeOrdering(String targetDisplayMode);

}
