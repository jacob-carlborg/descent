package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.IDisplayTypeConverter;
import net.sourceforge.nattable.typeconfig.content.IEditableRule;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

public class ConfigDrivenCellRenderer extends DataBindingCellRenderer {
	
	private ContentConfigRegistry contentConfigRegistry;

	private StyleConfigRegistry styleConfigRegistry;
	
	public ConfigDrivenCellRenderer(
			IDataProvider dataProvider,
			ContentConfigRegistry contentConfigRegistry,
			StyleConfigRegistry styleConfigRegistry
	) {
		super(dataProvider);
		this.contentConfigRegistry = contentConfigRegistry;
		this.styleConfigRegistry = styleConfigRegistry;
	}
	
	// Content ////////////////////////////////////////////////////////////////

	public boolean isEditable(int row, int col) {
		IEditableRule editableRule = contentConfigRegistry.getEditableRule(row, col);
		if (editableRule != null) {
			return editableRule.isEditable(row, col);
		} else {
			return super.isEditable(row, col);
		}
	}

	@Override
	public String getDisplayText(int row, int col) {
		Object cellObj = getValue(row, col);
		IDisplayTypeConverter displayTypeConverter = contentConfigRegistry.getDisplayTypeConverter(row, col);
		if (displayTypeConverter != null) {
			return displayTypeConverter.dataValueToDisplayValue(cellObj).toString();
		}
		return super.getDisplayText(row, col);
	}
	
	@Override
	public ICellEditor getCellEditor(int row, int col) {
		ICellEditor cellEditor = contentConfigRegistry.getCellEditor(row, col);
		if (cellEditor != null) {
			return cellEditor;
		} else {
			return super.getCellEditor(row, col);
		}
	}
	
	// Style //////////////////////////////////////////////////////////////////
	
	public IStyleConfig getStyleConfig(String displayMode, int row, int col) {
		return styleConfigRegistry.getStyleConfig(displayMode, row, col);
	}

// TODO
//	@Override
//	public ICellPainter getCellPainter(int row, int col) {
//		return styleConfigRegistry.getCellPainter(row, col);
//	}

}
