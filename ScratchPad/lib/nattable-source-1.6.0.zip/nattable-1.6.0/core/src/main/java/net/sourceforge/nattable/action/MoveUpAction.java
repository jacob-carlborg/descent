package net.sourceforge.nattable.action;

import net.sourceforge.nattable.support.SelectionSupport;

import org.eclipse.swt.events.KeyEvent;

public class MoveUpAction extends AbstractKeySelectAction {
	
	public MoveUpAction(SelectionSupport selectionSupport, boolean withShiftMask, boolean withControlMask) {
		super(selectionSupport, withShiftMask, withControlMask);
	}
	
	public void run(KeyEvent event) {
		selectionSupport.moveUp(withShiftMask, withControlMask);
	}

}
