package net.sourceforge.nattable.config;

public interface IBodyConfig extends IRegionConfig {
	
	/**
	 * @return total number of columns
	 */
	public int getColumnCount();
	
	public SizeConfig getColumnWidthConfig();
	
	/**
	 * @return total number of rows
	 */
	public int getRowCount();
	
	public SizeConfig getRowHeightConfig();

}
