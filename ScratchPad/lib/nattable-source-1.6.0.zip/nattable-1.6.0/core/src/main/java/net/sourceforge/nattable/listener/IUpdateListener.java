package net.sourceforge.nattable.listener;

public interface IUpdateListener {

	public void updateRowAdded(int from, int to);

	public void updateRowUpdated(int from, int to);

	public void updateRowRemoved(int from, int to);

}
