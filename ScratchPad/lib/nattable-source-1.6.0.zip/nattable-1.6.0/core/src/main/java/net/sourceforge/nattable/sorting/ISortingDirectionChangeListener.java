package net.sourceforge.nattable.sorting;

public interface ISortingDirectionChangeListener {

	public void sortingDirectionChanged(SortingDirection[] directions);
	
}
