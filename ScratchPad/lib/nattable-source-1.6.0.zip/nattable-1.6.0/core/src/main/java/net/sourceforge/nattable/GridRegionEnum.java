package net.sourceforge.nattable;

public enum GridRegionEnum {

	CORNER,
	COLUMN_HEADER,
	ROW_HEADER,
	BODY
	
}
