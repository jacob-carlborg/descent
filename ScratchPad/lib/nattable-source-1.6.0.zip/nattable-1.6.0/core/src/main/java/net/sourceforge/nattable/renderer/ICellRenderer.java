package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;

public interface ICellRenderer {

	// Content ////////////////////////////////////////////////////////////////
	
	public boolean isEditable(int row, int col);

	public String getDisplayText(int row, int col);

	public Object getValue(int row, int col);

	public ICellEditor getCellEditor(int row, int col);
	
	// Style //////////////////////////////////////////////////////////////////
	
	public IStyleConfig getStyleConfig(String displayMode, int row, int col);

	public ICellPainter getCellPainter(int row, int col);
	
}
