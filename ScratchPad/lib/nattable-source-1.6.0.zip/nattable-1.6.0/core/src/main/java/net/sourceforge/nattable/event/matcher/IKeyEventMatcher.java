package net.sourceforge.nattable.event.matcher;

import org.eclipse.swt.events.KeyEvent;

public interface IKeyEventMatcher {

	public boolean matches(KeyEvent event);
	
}
