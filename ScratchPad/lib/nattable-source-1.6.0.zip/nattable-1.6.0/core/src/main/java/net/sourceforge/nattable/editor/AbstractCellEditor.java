package net.sourceforge.nattable.editor;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

public abstract class AbstractCellEditor implements ICellEditor {

	private IEditController editController;
	
	private Object oldValue;
	
	private EditorSelectionEnum selectionMode = EditorSelectionEnum.ALL;

	public final Control activateCell(IEditController editController,
			Composite parent, Rectangle rectangle, Object oldValue) {
		this.editController = editController;
		this.oldValue = oldValue;
		
		return activateCell(parent, rectangle, oldValue);
	}
	
	protected abstract Control activateCell(Composite parent, Rectangle rectangle, Object oldValue);
	
	public final void setSelectionMode(EditorSelectionEnum selectionMode) {
		this.selectionMode = selectionMode;
	}
	
	public final EditorSelectionEnum getSelectionMode() {
		return selectionMode;
	}
	
	protected final void commit(Object newValue) {
		editController.validate(oldValue, newValue);
		editController.commit(newValue);
		close();
	}
	
}
