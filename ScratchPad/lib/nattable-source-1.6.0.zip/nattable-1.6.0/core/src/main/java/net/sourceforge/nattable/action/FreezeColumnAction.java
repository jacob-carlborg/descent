package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class FreezeColumnAction extends SelectionAdapter {

	private final NatTable table;

	public FreezeColumnAction(NatTable table) {
		this.table = table;
	}
	
	@Override
	public void widgetSelected(SelectionEvent e) {
		int[] selectedColumns = table.getSelectionModel().getSelectedColumns();
		
		if (selectedColumns != null && selectedColumns.length > 0) {
			
			int maxIndex = 0;
			
			for (int column : selectedColumns) {
				if (column > maxIndex) {
					maxIndex = column;
				}
			}
			
			table.getNatTableModel().setFreezeColumnCount(maxIndex);
			table.reset();
			table.updateResize(true);
		}
	}
	
}
