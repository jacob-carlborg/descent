package net.sourceforge.nattable.editor;

import net.sourceforge.nattable.data.IDataValidator;

public interface IEditController extends IDataValidator {
	
	public void commit(Object newValue);

}
