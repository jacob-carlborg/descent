package net.sourceforge.nattable.support;

import net.sourceforge.nattable.GridRegionEnum;
import net.sourceforge.nattable.model.INatTableModel;

public class RegionMetricsSupport {
	private INatTableModel model;

	public void setNatTableModel(INatTableModel model) {
		this.model = model;
	}

	public int modelGridToRegionRow(final GridRegionEnum gridRegion, int modelGridRow) {
		if (gridRegion != null) {
			switch (gridRegion) {
			case CORNER:
			case COLUMN_HEADER:
				break;
			case ROW_HEADER:
			case BODY:
				modelGridRow -= model.getColumnHeaderRowCount();
				break;
			default:
				throw new IllegalArgumentException("Unknown grid region " + gridRegion);
			}
		}

		return modelGridRow;
	}

	public int modelGridToRegionColumn(final GridRegionEnum gridRegion, int modelGridCol) {
		if (gridRegion != null) {
			switch (gridRegion) {
			case CORNER:
			case ROW_HEADER:
				break;
			case COLUMN_HEADER:
			case BODY:
				modelGridCol -= model.getRowHeaderColumnCount();
				break;
			default:
				throw new IllegalArgumentException("Unknown grid region " + gridRegion);
			}
		}
		return modelGridCol;
	}

	public int modelGridToBodyRow(int modelGridRow) {
		return modelGridToRegionRow(GridRegionEnum.BODY, modelGridRow);
	}

	public int modelGridToBodyColumn(int modelGridCol) {
		return modelGridToRegionColumn(GridRegionEnum.BODY, modelGridCol);
	}

	public int modelBodyToGridRow(int modelBodyRow) {
		return model.getColumnHeaderRowCount() + modelBodyRow;
	}

	public int modelBodyToGridColumn(int modelBodyCol) {
		return model.getRowHeaderColumnCount() + modelBodyCol;
	}

	// Grid Region detection ////////////////////////////////
	public boolean isModelCornerCell(final int modelGridRow,
			final int modelGridCol) {
		return modelGridRow >= 0 && modelGridCol >= 0
				&& isModelHeaderRow(modelGridRow)
				&& isModelHeaderColumn(modelGridCol);
	}

	public boolean isModelColumnHeaderCell(final int modelGridRow, final int modelGridCol) {
		return modelGridRow >= 0 && modelGridCol >= 0
		&& isModelHeaderRow(modelGridRow) && isModelBodyColumn(modelGridCol);
	}

	public boolean isModelRowHeaderCell(final int modelGridRow, final int modelGridCol) {
		return modelGridRow >= 0 && modelGridCol >= 0
		&& isModelBodyRow(modelGridRow) && isModelHeaderColumn(modelGridCol);
	}

	public boolean isModelBodyCell(final int modelGridRow, final int modelGridCol) {
		return modelGridRow >= 0 && modelGridCol >= 0
		&& isModelBodyRow(modelGridRow) && isModelBodyColumn(modelGridCol);
	}

	public boolean isModelHeaderColumn(int modelGridCol) {
		return modelGridCol >= 0
		&& modelGridCol < model.getRowHeaderColumnCount();
	}

	public boolean isModelBodyColumn(int modelGridCol) {
		return modelGridCol >= 0
		&& modelGridCol >= model.getRowHeaderColumnCount() && modelGridCol < (model.getRowHeaderColumnCount() + model.getBodyColumnCount());
	}

	public boolean isModelHeaderRow(int modelGridRow) {
		return modelGridRow >= 0 && modelGridRow < model.getColumnHeaderRowCount();
	}

	public boolean isModelBodyRow(int gridRow) {
		return gridRow >= 0 && gridRow >= model.getColumnHeaderRowCount() && gridRow < (model.getColumnHeaderRowCount() + model.getBodyRowCount());
	}

	public GridRegionEnum getRegion(int gridRow, int gridCol) {
		if (gridRow >= 0 && gridCol >= 0) {
			if (isModelColumnHeaderCell(gridRow, gridCol)) {
				return GridRegionEnum.COLUMN_HEADER;
			} else if (isModelCornerCell(gridRow, gridCol)) {
				return GridRegionEnum.CORNER;
			} else if (isModelRowHeaderCell(gridRow, gridCol)) {
				return GridRegionEnum.ROW_HEADER;
			} else if (isModelBodyCell(gridRow, gridCol)) {
				return GridRegionEnum.BODY;
			}
		}
		
		return null;
	}
	
}
