package net.sourceforge.nattable.typeconfig;

public interface IConfigTypeResolver {
	
	public String getConfigType(int modelBodyRow, int modelBodyColumn);
	
}
