package net.sourceforge.nattable.painter.cell;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.util.GUIHelper;

import org.apache.log4j.Logger;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;

/**
 * Author : Rich Vera<br>
 * Created Date : 20080717<br>
 */
public class ColumnGroupHeaderCellPainter extends HeaderCellPainter {

	Logger log = Logger.getLogger(ColumnGroupHeaderCellPainter.class);
	
	public ColumnGroupHeaderCellPainter() {
	}

	/**
	 * It supports SWT.BORDER, SWT.FLAT and SWT.NONE(as Black Gradient)
	 * 
	 * @param style
	 */
	public ColumnGroupHeaderCellPainter(int style) {
		this.style = style;
	}

	public void drawCell(GC gc, Rectangle rectangle, NatTable natTable, ICellRenderer natCellRenderer, 
			int row, int col, boolean selected) {
		Color orgFG = gc.getForeground();
		Color orgBG = gc.getBackground();
		Font orgFont = gc.getFont();
		
		INatTableModel tableModel = natTable.getNatTableModel();

		// Selection Color
		IStyleConfig normalStyleConfig = natCellRenderer.getStyleConfig(DisplayModeEnum.NORMAL.toString(), row, col);
		IStyleConfig selectionStyleConfig = natCellRenderer.getStyleConfig(DisplayModeEnum.SELECT.toString(), row, col);
		
		Color fg = selected && !tableModel.isSingleCellSelection() ? selectionStyleConfig.getForegroundColor(row, col)
				: normalStyleConfig.getForegroundColor(row, col);
		Color bg = selected && !tableModel.isSingleCellSelection() ? selectionStyleConfig.getBackgroundColor(row, col)
				: normalStyleConfig.getBackgroundColor(row, col);
		Font font = normalStyleConfig.getFont(row, col);
		
		String text = natCellRenderer.getDisplayText(row, col);

		text = text == null ? "" : text;

		Image icon = getImage(natCellRenderer, row, col);

		gc.setFont(font);
		gc.setForeground(fg != null ? fg : GUIHelper.COLOR_LIST_FOREGROUND);
		gc.setBackground(bg != null ? bg : GUIHelper.COLOR_LIST_BACKGROUND);

		drawBackground(gc, rectangle);
		
		int imageWidth = icon != null ? icon.getBounds().width : 0;
		// Support Multiple Line
		int multiple = ((gc.getFontMetrics().getHeight() * GUIHelper.getNumberOfNewLine(text) + SPACE));

		int topAlign = rectangle.y + rectangle.height / 2
				- ((multiple > rectangle.height ? rectangle.height / 2 : multiple / 2));

		if (imageWidth > 0) {
			imageWidth = imageWidth + SPACE;
			if (row == 0)
				gc.drawImage(icon, rectangle.x + rectangle.width - imageWidth, topAlign);
			else
				gc.drawImage(icon, rectangle.x + SPACE, topAlign);
		}

		// Draw Text

		drawText(gc, rectangle, text, imageWidth, topAlign);

		gc.setForeground(orgFG);
		gc.setBackground(orgBG);
		gc.setFont(orgFont);
	}
	
	protected Color getGradientBackground() {
		return GUIHelper.COLOR_WIDGET_DARK_SHADOW;
	}

	protected Color getGradientForeground() {
		return COLOR_BACKGROUND;
	}	
}
