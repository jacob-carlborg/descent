package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.painter.cell.ColumnGroupHeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.sorting.SortingDirection;
import net.sourceforge.nattable.support.ColumnGroupSupport;
import net.sourceforge.nattable.typeconfig.style.DefaultStyleConfig;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;

public class ColumnGroupHeaderRenderer extends AbstractColumnHeaderRenderer {

	private final DefaultStyleConfig defaultStyleConfig = new DefaultStyleConfig() {
		
		private static final long serialVersionUID = 1L;

		public Image getImage(int row, int col) {
			if (row == 0 && colGroupSupport.isColumnInColumnGroup(col)) { 
				if (colGroupSupport.isExpanded(colGroupSupport.getColumnGroupName(col))) {
					return GUIHelper.LEFT_IMAGE;
				} else {				
					return GUIHelper.RIGHT_IMAGE;
				}
			}
			if (directions != null && row == 1) {
				for (int i = 0; i < directions.length; i++) {
					if (directions[i].getColumn() == col) {
						switch (directions[i].getDirection()) {
						case UP:
							return GUIHelper.UP_IMAGE;
						case DOWN:
							return GUIHelper.DOWN_IMAGE;
						}
					}
				}
			} 
			return null;
		}
		
	};
	
	private ColumnGroupHeaderCellPainter groupHeaderPainter = new ColumnGroupHeaderCellPainter(SWT.CENTER | SWT.BORDER);

	private SortingDirection[] directions = null;
	
	private IColumnHeaderLabelProvider columnHeaderLabelProvider;
	
	private ColumnGroupSupport colGroupSupport;
	
	public ColumnGroupHeaderRenderer(IColumnHeaderLabelProvider columnHeaderLabelProvider, ColumnGroupSupport support) {
		this.columnHeaderLabelProvider = columnHeaderLabelProvider;
		this.colGroupSupport = support;
	}

	public String getDisplayText(int row, int col) {
		if (row == 0 && colGroupSupport.isColumnInColumnGroup(col)) {
			return colGroupSupport.getColumnGroupName(col);
		}
		if (row == 1) {
			return columnHeaderLabelProvider.getColumnHeaderLabel(col); 
		}
		return "";
	}
	
	public IStyleConfig getStyleConfig(String displayMode, int row, int col) {
		return defaultStyleConfig;
	}
	
	public ICellPainter getCellPainter(int row, int col) {
		return groupHeaderPainter;
	}
}
