package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;

public class DefaultColumnHeaderRenderer extends AbstractColumnHeaderRenderer {

	private IColumnHeaderLabelProvider columnHeaderLabelProvider;
	
	public DefaultColumnHeaderRenderer(IColumnHeaderLabelProvider columnHeaderLabelProvider) {
		this.columnHeaderLabelProvider = columnHeaderLabelProvider;
	}
	
	public String getDisplayText(int row, int col) {
		return columnHeaderLabelProvider.getColumnHeaderLabel(col);
	}
	
}
