package net.sourceforge.nattable.support;

import org.eclipse.swt.graphics.Rectangle;

public interface IClientAreaProvider {

	public Rectangle getClientArea();
	
	public void updateResize();
}
