package net.sourceforge.nattable.action;

import net.sourceforge.nattable.support.SelectionSupport;

public abstract class AbstractKeySelectAction implements IKeyEventAction {

	protected SelectionSupport selectionSupport;
	
	protected boolean withShiftMask;
	
	protected boolean withControlMask;
	
	public AbstractKeySelectAction(SelectionSupport selectionSupport, boolean withShiftMask, boolean withControlMask) {
		this.selectionSupport = selectionSupport;
		this.withShiftMask = withShiftMask;
		this.withControlMask = withControlMask;
	}

}
