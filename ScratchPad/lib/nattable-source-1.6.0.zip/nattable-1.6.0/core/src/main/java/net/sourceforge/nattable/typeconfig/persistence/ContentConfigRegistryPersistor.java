package net.sourceforge.nattable.typeconfig.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;

import net.sourceforge.nattable.data.IDataValidator;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.IDisplayTypeConverter;
import net.sourceforge.nattable.typeconfig.content.IEditableRule;

public class ContentConfigRegistryPersistor<T> extends AbstractPersistor {
	private static final long serialVersionUID = 1L;

	private ContentRegStorer persistor;

	private ContentConfigRegistry registry;

	public ContentConfigRegistryPersistor(ContentConfigRegistry registry) {
		this.registry = registry;
	}

	@SuppressWarnings("unchecked")
	public void load(InputStream store) {
		try {
			ContentConfigRegistryPersistor<T> restorer = (ContentConfigRegistryPersistor<T>) restore(store);
			ContentRegStorer storer = restorer.persistor;
			registry.getComparatorRegistry().putAll(storer.comparatorMap);
			registry.getValidatorRegistry().putAll(storer.validatorMap);
			registry.getEditableRulesRegistry().putAll(storer.editableRulesMap);
			registry.getDisplayTypeConverterRegistry().putAll(storer.displayTypeConverterMap);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public void save(OutputStream store) {
		try {
			store(store);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		ContentRegStorer storer = new ContentRegStorer();
		storer.comparatorMap = registry.getComparatorRegistry();
		storer.editableRulesMap = registry.getEditableRulesRegistry();
		storer.validatorMap = registry.getValidatorRegistry();
		storer.displayTypeConverterMap = registry.getDisplayTypeConverterRegistry();
		stream.writeObject(storer);
	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		persistor = (ContentRegStorer) stream.readObject();
	}

	class ContentRegStorer implements Serializable {
		private static final long serialVersionUID = 1L;
		Map<Integer, Comparator<?>> comparatorMap;
		Map<String, IDataValidator> validatorMap;
		Map<String, IEditableRule> editableRulesMap;
		Map<String, IDisplayTypeConverter> displayTypeConverterMap;
	}
}
