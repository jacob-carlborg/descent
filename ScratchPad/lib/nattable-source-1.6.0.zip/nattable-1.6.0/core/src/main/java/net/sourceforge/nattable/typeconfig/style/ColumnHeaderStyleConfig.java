package net.sourceforge.nattable.typeconfig.style;

import net.sourceforge.nattable.sorting.ISortingDirectionChangeListener;
import net.sourceforge.nattable.sorting.SortingDirection;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.graphics.Image;

public class ColumnHeaderStyleConfig extends DefaultStyleConfig implements ISortingDirectionChangeListener {

	private static final long serialVersionUID = 1L;

	private SortingDirection[] sortingDirections;
	
	public Image getImage(int row, int col) {
		if (sortingDirections != null) {
			for (int i = 0; i < sortingDirections.length; i++) {
				if (sortingDirections[i].getColumn() == col) {
					switch (sortingDirections[i].getDirection()) {
					case UP:
						return GUIHelper.UP_IMAGE;
					case DOWN:
						return GUIHelper.DOWN_IMAGE;
					}
				}
			}
		}
		return null;
	}
	
	public void sortingDirectionChanged(SortingDirection[] sortingDirections) {
		this.sortingDirections = sortingDirections;
	}

}
