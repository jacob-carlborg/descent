package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.OrderEnum;

import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.graphics.Point;

public class MoveToFirstColumnAction extends AbstractKeySelectAction {

	private NatTable natTable;
	
	public MoveToFirstColumnAction(NatTable natTable, boolean withShiftMask) {
		super(natTable.getSelectionSupport(), withShiftMask, false);
		
		this.natTable = natTable;
	}
	
	public void run(KeyEvent event) {
		Point lastSelectedCell = natTable.getSelectionSupport().getLastSelectedCell();
		
		selectionSupport.setSelectedCell(lastSelectedCell.y, natTable.viewableToModelBodyColumn(0),
				withShiftMask, withControlMask);
		natTable.showBodyColumn(0, OrderEnum.FIRST);
	}

}
