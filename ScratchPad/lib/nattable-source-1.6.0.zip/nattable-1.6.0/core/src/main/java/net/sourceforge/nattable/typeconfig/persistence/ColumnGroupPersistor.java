package net.sourceforge.nattable.typeconfig.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sourceforge.nattable.support.ColumnGroupSupport;

public class ColumnGroupPersistor extends AbstractPersistor {

	private static final long serialVersionUID = 1L;

	private ColumnGroupSupport columnGroups;
	private ColumnGroupStorer persistor;

	public ColumnGroupPersistor(ColumnGroupSupport columnGroups) {
		this.columnGroups = columnGroups;
	}

	public void load(InputStream store) {
		try {
			if(columnGroups != null) {
				ColumnGroupPersistor restorer = (ColumnGroupPersistor) restore(store);
				ColumnGroupSupport support = columnGroups;
				ColumnGroupStorer restoredData = restorer.persistor;
				support.getColumnGroupModelIndices().putAll(restoredData.columnGroupModelIndices);
				support.getExpandedColumnGroups().addAll(restoredData.expandedColumnGroups);
				support.getModelColumnToGroupMap().putAll(restoredData.modelColumnToGroupMap);
				support.setEnableAddColumns(restoredData.enableAddColumns);
				support.setEnableColumnRemoval(restoredData.enableColumnRemoval);
				support.setEnableReorderColumnGroup(restoredData.enableReorderColumnGroup);
			}
			
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e.getMessage(), e);
		}		
	}

	public void save(OutputStream store) {
		try {
			store(store);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		ColumnGroupStorer storer = new ColumnGroupStorer();
		if(columnGroups != null) {
			storer.columnGroupModelIndices = columnGroups.getColumnGroupModelIndices();
			storer.expandedColumnGroups = columnGroups.getExpandedColumnGroups();
			storer.modelColumnToGroupMap = columnGroups.getModelColumnToGroupMap();
			storer.enableAddColumns = columnGroups.isEnableAddColumns();
			storer.enableColumnRemoval = columnGroups.isEnableColumnRemoval();
			storer.enableReorderColumnGroup = columnGroups.isEnableReorderColumnGroup();
			stream.writeObject(storer);
		}
	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		persistor = (ColumnGroupStorer) stream.readObject();
	}

	@SuppressWarnings("unused")
	private void readObjectNoData() throws ObjectStreamException {

	}

	class ColumnGroupStorer implements Serializable {
		private static final long serialVersionUID = 1L;
		Map<String, List<Integer>> columnGroupModelIndices;
		Map<Integer, String> modelColumnToGroupMap;
		Set<String> expandedColumnGroups;
		boolean enableColumnRemoval;
		boolean enableReorderColumnGroup;
		boolean enableAddColumns;
	}
}