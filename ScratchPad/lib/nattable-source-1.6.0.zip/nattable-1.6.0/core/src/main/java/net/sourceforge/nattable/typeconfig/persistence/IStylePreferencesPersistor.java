package net.sourceforge.nattable.typeconfig.persistence;

import java.util.Map;

import org.eclipse.swt.widgets.Display;

/**
 * Objects who wish to persist their user configurations should implement this
 * interface.
 * 
 * @author cmartine
 * 
 */
public interface IStylePreferencesPersistor {

	public final static String FONT_NAME_KEY = "fontName";

	public final static String FONT_SIZE_KEY = "fontSize";

	public final static String FONT_STYLE_KEY = "fontStyle";

	public final static String BG_COLOR_KEY = "bgColor";

	public final static String FG_COLOR_KEY = "fgColor";

	/**
	 * Return all of the overwritten attributes which are persistable.
	 * @param cellTypeKeys TODO
	 * @param rowTypeKeys TODO
	 * 
	 * @return
	 */
	public Map<String, Map<String, Map<String, String>>> getOverrides(String[] cellTypeKeys, String[] rowTypeKeys);
	
	/**
	 * The method loads the previous persisted state of this object. The logic
	 * should first check if a specific attribute is being restored, if not use
	 * the default configuration.
	 * 
	 * @param preferences
	 * @param display TODO
	 * @param owRule TODO
	 */
	public void restoreOverrides(Map<String, Map<String, Map<String, String>>> preferences, Display display);
}
