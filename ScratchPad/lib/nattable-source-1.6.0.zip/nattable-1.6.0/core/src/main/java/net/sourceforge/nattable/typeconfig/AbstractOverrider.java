package net.sourceforge.nattable.typeconfig;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public abstract class AbstractOverrider implements IConfigTypeResolver {
	protected Map<Serializable, String> overrides = new HashMap<Serializable, String>();

	public void removeOverride(Serializable key) {
		overrides.remove(key);
	}

	public void registerOverride(Serializable key, String configType) {
		overrides.put(key, configType);
	}

	public Map<Serializable, String> getOverrides() {
		return overrides;
	}

	public void addOverrides(Map<Serializable, String> overrides) {
		this.overrides.putAll(overrides);
	}
}
