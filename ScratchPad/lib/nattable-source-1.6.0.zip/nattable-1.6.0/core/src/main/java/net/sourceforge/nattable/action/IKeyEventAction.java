package net.sourceforge.nattable.action;

import org.eclipse.swt.events.KeyEvent;

public interface IKeyEventAction {

	public void run(KeyEvent event);
	
}
