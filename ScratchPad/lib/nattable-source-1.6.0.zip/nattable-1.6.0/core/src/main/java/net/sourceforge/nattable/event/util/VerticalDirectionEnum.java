package net.sourceforge.nattable.event.util;

public enum VerticalDirectionEnum {

	UP,
	DOWN,
	NONE
	
}
