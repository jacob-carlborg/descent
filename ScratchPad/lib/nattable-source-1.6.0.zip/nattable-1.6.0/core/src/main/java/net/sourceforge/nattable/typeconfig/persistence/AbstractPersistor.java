package net.sourceforge.nattable.typeconfig.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

/**
 * This class assumes the implementer is persistable and has overriden the wirteObject, readObject and 
 * readObjectNoData methods see @link{java.io.ObjectOutputStream}
 * @author cmartine
 *
 */
public abstract class AbstractPersistor implements IPersistor {
	
	private static final long serialVersionUID = 1L;

	protected Object restore(InputStream in) throws IOException, ClassNotFoundException {
		ObjectInputStream restorer = null;
		try {
			restorer = new ObjectInputStream(in);
			return restorer.readObject();
		}finally {
			restorer.close();
		}
	}
	
	protected void store(OutputStream out) throws IOException {
		ObjectOutputStream storer = null;
		try {
			storer = new ObjectOutputStream(out);
			storer.writeObject(this);
		} finally {
			if (storer != null) {
				storer.close();
			}
		}
	}

	protected String getFileName() {
		return this.getClass().getName() + ".store";
	}
}
