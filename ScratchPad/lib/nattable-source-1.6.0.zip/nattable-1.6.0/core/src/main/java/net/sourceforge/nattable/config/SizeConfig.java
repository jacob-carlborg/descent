package net.sourceforge.nattable.config;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SizeConfig implements Serializable{

	private static final long serialVersionUID = 1L;

	private int defaultSize;

	private Map<Integer, Integer> initialSizeMap;
	
	private Map<Integer, Integer> sizeMap;
	
	private boolean defaultResizable;
	
	private boolean allIndexesSameSize;
	
	public SizeConfig() {}
	
	public SizeConfig(int defaultSize) {
		this.defaultSize = defaultSize;
	}
	
	// default size
	
	public int getDefaultSize() {
		return defaultSize;
	}
	
	public void setDefaultSize(int defaultSize) {
		this.defaultSize = defaultSize;
	}
	
	// initial size
	
	public int getInitialSize(int index) {
		int size = getSize(initialSizeMap, index);
		if (size >= 0) {
			return size;
		} else {
			return getDefaultSize();
		}
	}

	public void setInitialSize(int index, int size) {
		if (initialSizeMap == null) {
			initialSizeMap = new HashMap<Integer, Integer>();
		}
		initialSizeMap.put(Integer.valueOf(index), Integer.valueOf(size));
	}
	
	// size
	
	public int getSize(int index) {
		int size = getSize(sizeMap, index);
		if (size >= 0) {
			return size;
		} else {
			return getInitialSize(index);
		}
	}

	public void setSize(int index, int size) {
		if (sizeMap == null) {
			sizeMap = new HashMap<Integer, Integer>();
		}
		sizeMap.put(Integer.valueOf(index), Integer.valueOf(size));
	}
	
	// default resizable
	
	public boolean getDefaultResizable() {
		return defaultResizable;
	}
	
	public void setDefaultResizable(boolean resizable) {
		resizablesMap.clear();
		this.defaultResizable = resizable;
	}
	
	// resizable
	
	private Map<Integer, Boolean> resizablesMap = new HashMap<Integer, Boolean>();

	public boolean isIndexResizable(int index) {
		Boolean resizable = resizablesMap.get(Integer.valueOf(index));
		if (resizable != null) {
			return resizable.booleanValue();
		}
		return defaultResizable;
	}
	
	public void setIndexResizable(int index, boolean resizable) {
		resizablesMap.put(Integer.valueOf(index), Boolean.valueOf(resizable));
	}
	
	// all indexes same size
	
	public boolean isAllIndexesSameSize() {
		return allIndexesSameSize;
	}
	
	public void setAllIndexesSameSize(boolean allIndexesSameSize) {
		this.allIndexesSameSize = allIndexesSameSize;
	}
	
	///////////////////////////////////////////////////////////////////////////
	
	private int getSize(Map<Integer, Integer> map, int index) {
		Integer size = null;
		if (map != null) {
			size = map.get(Integer.valueOf(index));
		}
		
		if (size != null) {
			return size.intValue();
		} else {
			return -1;
		}
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		SizeStorer storer = new SizeStorer();
		storer.storedAllIndexesSameSize = allIndexesSameSize;
		storer.storedDefaultResizable = defaultResizable;
		storer.storedDefaultSize = defaultSize;
		storer.storedInitialSizeMap = initialSizeMap;
		storer.storedSizeMap = sizeMap;
		storer.storedResizablesMap = resizablesMap;
		stream.writeObject(storer);
	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		SizeStorer storer = (SizeStorer)stream.readObject();
		
		//restoring all
		this.allIndexesSameSize = storer.storedAllIndexesSameSize;
		this.defaultResizable = storer.storedDefaultResizable;
		this.defaultSize = storer.storedDefaultSize;
		this.initialSizeMap = storer.storedInitialSizeMap;
		this.resizablesMap = storer.storedResizablesMap;
		this.sizeMap = storer.storedSizeMap;
	}

	@SuppressWarnings("unused")
	private void readObjectNoData() throws ObjectStreamException {
	}
	
	class SizeStorer implements Serializable{
		private static final long serialVersionUID = 1L;
		
		int storedDefaultSize;
		Map<Integer, Integer> storedInitialSizeMap;
		Map<Integer, Integer> storedSizeMap;
		Map<Integer, Boolean> storedResizablesMap;
		boolean storedDefaultResizable;
		boolean storedAllIndexesSameSize;
	}

}
