package net.sourceforge.nattable.model;

import net.sourceforge.nattable.action.ColumnSelectionBehaviorEnum;
import net.sourceforge.nattable.config.IBodyConfig;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

public interface INatTableModel {

	public String getModelID();
	
	// Config registries //////////////////////////////////////////////////////
	
	public ContentConfigRegistry getContentConfigRegistry();
	
	public StyleConfigRegistry getStyleConfigRegistry();

	// Corner /////////////////////////////////////////////////////////////////
	
	public ICellRenderer getCornerCellRenderer();
	
	// Column Header Row //////////////////////////////////////////////////////

	public ICellRenderer getColumnHeaderCellRenderer();

	/**
	 * <h1> Definition of Header Row</h1>
	 * <p>
	 * Used to support column width resize<br>
	 * Whole column will be selected if click on the column header<br>
	 * It doesn't call rowrenderer to get selection bg & fg color<br>
	 * It doesn't support cell editing<br>
	 * </p>
	 * 
	 * Number of rows to be displayed in a table column.<br>
	 * For Example: Header Row Count is 2 <br>
	 * <table border="1">
	 * <tr>
	 * <td>Col1</td>
	 * <td>Col2</td>
	 * <td>Col3</td>
	 * <td>Col4</td>
	 * </tr>
	 * <tr>
	 * <td>Col1</td>
	 * <td>Col2</td>
	 * <td>Col3</td>
	 * <td>Col4</td>
	 * </tr>
	 * <tr>
	 * <td colspan="4" align="center">Rows</td>
	 * </tr>
	 * </table>
	 */
	public int getColumnHeaderRowCount();

	public int getColumnHeaderRowHeight(int row);

	// Header Column //////////////////////////////////////////////////////////

	public ICellRenderer getRowHeaderCellRenderer();
	
	/**
	 * Number of columns to be displayed as a table header in a table column.<br>
	 */
	public int getRowHeaderColumnCount();
	
	public int getRowHeaderColumnWidth(int col);
	
	// Body ///////////////////////////////////////////////////////////////////
	
	public IBodyConfig getBodyConfig();
	
	public ICellRenderer getBodyCellRenderer();

	// Columns ----------------------------------------------------------------

	/**
	 * @return total number of columns
	 */
	public int getBodyColumnCount();

	public int getInitialBodyColumnWidth(int col);

	public int getBodyColumnWidth(int col);

	public void setBodyColumnWidth(int col, int width);

	public boolean isBodyColumnResizable(int col);

	/**
	 * <h1>Definition of Freeze Column </h1>
	 * <p>
	 * It is a normal row body and displays data content <br>
	 * It calls rowrenderer to get selection bg & fg color <br>
	 * Should not select the whole row while single cell selection is choose
	 * <br>
	 * Doesnt support row height resize <br>
	 * It supports cell editing <br>
	 * <p>
	 * 
	 * @return
	 */
	public int getFreezeColumnCount();

	public void setFreezeColumnCount(int col);

	// Rows -------------------------------------------------------------------

	/**
	 * @return total number of rows
	 */
	public int getBodyRowCount();

	public int getInitialBodyRowHeight(int row);

	public int getBodyRowHeight(int row);

	public void setBodyRowHeight(int row, int height);

	/**
	 * Used to boost up the row height calculation. <br>
	 * Return true if the total number of rows is bigger than 100 thousand.
	 */
	public boolean isAllBodyRowsSameHeight();

	public boolean isBodyRowResizable(int row);

	public int getFreezeRowCount();

	public void setFreezeRowCount(int row);

	// Table configuration ////////////////////////////////////////////////////

	/**
	 * @return true to allow move column by mouse drag
	 */
	public boolean isMoveColumnEnabled();

	/**
	 * @return true to display grid line
	 */
	public boolean isGridLineEnabled();

	public void setGridLineEnabled(boolean enable);

	/**
	 * @return true to enable sorting
	 */
	public boolean isSortingEnabled();

	// Selection //////////////////////////////////////////////////////////////

	/**
	 * @return true to allow whole row selection
	 */
	public boolean isFullRowSelection();

	/**
	 * @return true to allow single cell selection
	 */
	public boolean isSingleCellSelection();

	/**
	 * @return true to allow multiple selection
	 */
	public boolean isMultpleSelection();

	public ColumnSelectionBehaviorEnum getColumnSelectionBehavior();

}
