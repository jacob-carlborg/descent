package net.sourceforge.nattable.typeconfig.style;

import org.eclipse.swt.graphics.RGB;

public class StaticStyleDisassembler {

	public static String getFontName(IStyleConfig style) {

		return style.getFont(1, 1).getFontData()[0].getName();
	}

	public static String getFontSize(IStyleConfig style) {

		return Integer.toString(style.getFont(1, 1).getFontData()[0].getHeight());
	}

	public static String getFontStyle(IStyleConfig style) {
		
		return Integer.toString(style.getFont(1, 1).getFontData()[0].getStyle());
	}

	public static String getFormattedBackgroundRGB(IStyleConfig style) {

		RGB rgb = style.getBackgroundColor(1, 1) != null ? style.getBackgroundColor(1, 1).getRGB() : null;
		return rgb != null ? colorToString(rgb) : "";
	}

	public static String getFormattedForegroundRGB(IStyleConfig style) {

		RGB rgb = style.getForegroundColor(1, 1) != null ? style.getForegroundColor(1, 1).getRGB() : null;
		return rgb != null ? colorToString(rgb) : "";
	}

	public static String colorToString(RGB color) {
		return color != null ? color.red + "," + color.green + "," + color.blue : "";
	}
}