package net.sourceforge.nattable.data;

public interface IDataProvider {

	public Object getValue(int row, int col);

	public int getColumnCount();
	
	public int getRowCount();

}
