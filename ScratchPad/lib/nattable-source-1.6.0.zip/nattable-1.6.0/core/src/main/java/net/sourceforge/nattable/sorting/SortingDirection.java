package net.sourceforge.nattable.sorting;

import java.io.Serializable;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2008�~3��15��<br>
 */
public class SortingDirection implements Serializable {
	private static final long serialVersionUID = 1L;

	public static enum DirectionEnum implements Serializable {
		UP, DOWN;
	}

	private DirectionEnum direction;
	private int column;

	public SortingDirection(DirectionEnum direction, int column) {
		this.direction = direction;
		this.column = column;
	}

	public DirectionEnum getDirection() {
		return direction;
	}

	public void setDirection(DirectionEnum direction) {
		this.direction = direction;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

}
