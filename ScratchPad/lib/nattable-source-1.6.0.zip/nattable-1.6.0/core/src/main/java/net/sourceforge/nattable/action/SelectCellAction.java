package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.SelectionSupport;

import org.eclipse.swt.events.MouseEvent;

public class SelectCellAction implements IMouseEventAction {

	private NatTable natTable;
	
	private boolean withShiftMask;
	
	private boolean withControlMask;
	
	public SelectCellAction(NatTable natTable, boolean withShiftMask, boolean withControlMask) {
		this.natTable = natTable;
		this.withShiftMask = withShiftMask;
		this.withControlMask = withControlMask;
	}
	
	public void run(MouseEvent event) {
		natTable.forceFocus();
		
		int modelBodyRow = natTable.getModelBodyRowByY(event.y);
		int modelBodyColumn = natTable.getModelBodyColumnByX(event.x);
		
		SelectionSupport selectionSupport = natTable.getSelectionSupport();
		
		selectionSupport.toggleCell(modelBodyRow, modelBodyColumn, withShiftMask, withControlMask);
	}

}
