package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.SelectionSupport;

import org.eclipse.swt.events.MouseEvent;

public class SelectColumnAction implements IMouseEventAction {

	private NatTable natTable;
	
	public SelectColumnAction(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void run(MouseEvent event) {
		SelectionSupport selectionSupport = natTable.getSelectionSupport();
		int modelGridColumn = natTable.getModelGridColumnByX(event.x);
		int bodyColumnIndex = natTable.getRegionMetricsSupport().modelGridToBodyColumn(modelGridColumn);
		
		selectionSupport.selectColumns(new int [] {bodyColumnIndex});
	}

}
