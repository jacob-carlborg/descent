package net.sourceforge.nattable.data;

import java.io.Serializable;

public interface IRowObjectCreator<T> {

	public T createRowObject(Serializable rowObjectId);
	
	public Class<T> getRowClass(); 

}