package net.sourceforge.nattable.util;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��11��<br>
 */
public class TimeUtil {
	private static long current = 0;
	private static String text = "";

	public static void start(String text) {
		TimeUtil.text = text;
		TimeUtil.current = System.currentTimeMillis();
	}

	public static void end() {
		System.out.println("Total time " + text + " = " + (System.currentTimeMillis() - current) / 1000f);
	}
}
