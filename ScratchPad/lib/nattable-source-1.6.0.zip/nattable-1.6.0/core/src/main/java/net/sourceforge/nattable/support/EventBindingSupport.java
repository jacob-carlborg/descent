package net.sourceforge.nattable.support;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.action.IKeyEventAction;
import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.event.DragBinding;
import net.sourceforge.nattable.event.KeyBinding;
import net.sourceforge.nattable.event.MouseBinding;
import net.sourceforge.nattable.event.drag.IDragMode;
import net.sourceforge.nattable.event.matcher.IKeyEventMatcher;
import net.sourceforge.nattable.event.matcher.IMouseEventMatcher;
import net.sourceforge.nattable.event.region.IEventRegionResolver;

import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseEvent;

public class EventBindingSupport {
	
	private IEventRegionResolver eventRegionResolver;
	
	private List<KeyBinding> keyBindings = new ArrayList<KeyBinding>();
	
	private Map<MouseEventTypeEnum, List<MouseBinding>> mouseBindingsMap = new HashMap<MouseEventTypeEnum, List<MouseBinding>>();
	
	private List<DragBinding> dragBindings = new ArrayList<DragBinding>();
	
	public EventBindingSupport(IEventRegionResolver eventRegionResolver) {
		this.eventRegionResolver = eventRegionResolver;
	}
	
	// Lookup /////////////////////////////////////////////////////////////////
	
	public IKeyEventAction getKeyEventAction(KeyEvent event) {
		for (KeyBinding keyBinding : keyBindings) {
			if (keyBinding.getKeyEventMatcher().matches(event)) {
				return keyBinding.getAction();
			}
		}
		return null;
	}
	
	public IDragMode getDragMode(MouseEvent event) {
		String eventRegion = eventRegionResolver.getEventRegion(event.x, event.y);
		
		for (DragBinding dragBinding : dragBindings) {
			if (dragBinding.getMouseEventMatcher().matches(event, eventRegion)) {
				return dragBinding.getDragMode();
			}
		}
		return null;
	}
	
	public IMouseEventAction getMouseMoveAction(MouseEvent event) {
		return getMouseEventAction(MouseEventTypeEnum.MOUSE_MOVE, event);
	}
	
	public IMouseEventAction getMouseDownAction(MouseEvent event) {
		return getMouseEventAction(MouseEventTypeEnum.MOUSE_DOWN, event);
	}
	
	public IMouseEventAction getSingleClickAction(MouseEvent event) {
		return getMouseEventAction(MouseEventTypeEnum.MOUSE_SINGLE_CLICK, event);
	}
	
	public IMouseEventAction getDoubleClickAction(MouseEvent event) {
		return getMouseEventAction(MouseEventTypeEnum.MOUSE_DOUBLE_CLICK, event);
	}
	
	///////////////////////////////////////////////////////////////////////////
	
	private IMouseEventAction getMouseEventAction(MouseEventTypeEnum mouseEventType, MouseEvent event) {
		List<MouseBinding> mouseEventBindings = mouseBindingsMap.get(mouseEventType);
		if (mouseEventBindings != null) {
			String eventRegion = eventRegionResolver.getEventRegion(event.x, event.y);
			
			for (MouseBinding mouseBinding : mouseEventBindings) {
				if (mouseBinding.getMouseEventMatcher().matches(event, eventRegion)) {
					return mouseBinding.getAction();
				}
			}
		}
		return null;
	}
	
	// Registration ///////////////////////////////////////////////////////////

	// Key
	
	public List<KeyBinding> getKeyBindings() {
		return keyBindings;
	}
	
	public void registerKeyBinding(IKeyEventMatcher keyMatcher, IKeyEventAction action) {
		keyBindings.add(new KeyBinding(keyMatcher, action));
	}
	
	public void unregisterKeyBinding(KeyBinding keyBinding) {
		keyBindings.remove(keyBinding);
	}
	
	// Drag

	public List<DragBinding> getDragBindings() {
		return dragBindings;
	}
	
	public void registerMouseDragMode(IMouseEventMatcher regionEventBinding, IDragMode dragMode) {
		dragBindings.add(new DragBinding(regionEventBinding, dragMode));
	}
	
	public void unregisterMouseDragMode(DragBinding dragBinding) {
		dragBindings.remove(dragBinding);
	}
	
	// Mouse move
	
	public List<MouseBinding> getMouseMoveBindings() {
		return mouseBindingsMap.get(MouseEventTypeEnum.MOUSE_MOVE);
	}
	
	public void registerMouseMoveBinding(IMouseEventMatcher mouseEventMatcher, IMouseEventAction action) {
		registerMouseBinding(MouseEventTypeEnum.MOUSE_MOVE, mouseEventMatcher, action);
	}
	
	public void unregisterMouseMoveBinding(IMouseEventMatcher mouseEventMatcher) {
		unregisterMouseBinding(MouseEventTypeEnum.MOUSE_MOVE, mouseEventMatcher);
	}
	
	// Mouse down
	
	public List<MouseBinding> getMouseDownBindings() {
		return mouseBindingsMap.get(MouseEventTypeEnum.MOUSE_DOWN);
	}
	
	public void registerMouseDownBinding(IMouseEventMatcher mouseEventMatcher, IMouseEventAction action) {
		registerMouseBinding(MouseEventTypeEnum.MOUSE_DOWN, mouseEventMatcher, action);
	}
	
	public void unregisterMouseDownBinding(IMouseEventMatcher mouseEventMatcher) {
		unregisterMouseBinding(MouseEventTypeEnum.MOUSE_DOWN, mouseEventMatcher);
	}
	
	// Single click
	
	public List<MouseBinding> getSingleClickBindings() {
		return mouseBindingsMap.get(MouseEventTypeEnum.MOUSE_SINGLE_CLICK);
	}
	
	public void registerSingleClickBinding(IMouseEventMatcher mouseEventMatcher, IMouseEventAction action) {
		registerMouseBinding(MouseEventTypeEnum.MOUSE_SINGLE_CLICK, mouseEventMatcher, action);
	}
	
	public void unregisterSingleClickBinding(IMouseEventMatcher mouseEventMatcher) {
		unregisterMouseBinding(MouseEventTypeEnum.MOUSE_SINGLE_CLICK, mouseEventMatcher);
	}
	
	// Double click
	
	public List<MouseBinding> getDoubleClickBindings() {
		return mouseBindingsMap.get(MouseEventTypeEnum.MOUSE_DOUBLE_CLICK);
	}
	
	public void registerDoubleClickBinding(IMouseEventMatcher mouseEventMatcher, IMouseEventAction action) {
		registerMouseBinding(MouseEventTypeEnum.MOUSE_DOUBLE_CLICK, mouseEventMatcher, action);
	}
	
	public void unregisterDoubleClickBinding(IMouseEventMatcher mouseEventMatcher) {
		unregisterMouseBinding(MouseEventTypeEnum.MOUSE_DOUBLE_CLICK, mouseEventMatcher);
	}
	
	///////////////////////////////////////////////////////////////////////////
	
	private void registerMouseBinding(MouseEventTypeEnum mouseEventType, IMouseEventMatcher mouseEventMatcher, IMouseEventAction action) {
		List<MouseBinding> mouseEventBindings = mouseBindingsMap.get(mouseEventType);
		if (mouseEventBindings == null) {
			mouseEventBindings = new ArrayList<MouseBinding>();
			mouseBindingsMap.put(mouseEventType, mouseEventBindings);
		}
		mouseEventBindings.add(new MouseBinding(mouseEventMatcher, action));
	}
	
	private void unregisterMouseBinding(MouseEventTypeEnum mouseEventType, IMouseEventMatcher mouseEventMatcher) {
		List<MouseBinding> mouseEventBindings = mouseBindingsMap.get(mouseEventType);
		if (mouseEventBindings != null) {
			mouseEventBindings.remove(mouseEventMatcher);
		}
	}
	
	private enum MouseEventTypeEnum {

		MOUSE_DOWN,
		MOUSE_MOVE,
		MOUSE_SINGLE_CLICK,
		MOUSE_DOUBLE_CLICK
		
	}

}
