package net.sourceforge.nattable.action;

import org.eclipse.swt.events.KeyEvent;

import net.sourceforge.nattable.NatTable;

public class ForceFocusAction implements IKeyEventAction {

	private NatTable natTable;
	
	public ForceFocusAction(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void run(KeyEvent event) {
		natTable.forceFocus();
	}

}
