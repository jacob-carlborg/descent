package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.RegionMetricsSupport;

import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.graphics.Point;

public class EditWithCharAction implements IKeyEventAction {

	private NatTable natTable;
	
	private RegionMetricsSupport metrics;
	
	public EditWithCharAction(NatTable natTable) {
		this.natTable = natTable;
		this.metrics = natTable.getRegionMetricsSupport();
	}
	
	public void run(KeyEvent event) {
		Point lastSelectedCell = natTable.getSelectionSupport().getLastSelectedCell();
		natTable.getEditorSupport().activateCell(
				metrics.modelBodyToGridRow(lastSelectedCell.y),
				metrics.modelBodyToGridColumn(
						natTable.viewableToModelBodyColumn(lastSelectedCell.x)),
						Character.valueOf(event.character));
	}

}
