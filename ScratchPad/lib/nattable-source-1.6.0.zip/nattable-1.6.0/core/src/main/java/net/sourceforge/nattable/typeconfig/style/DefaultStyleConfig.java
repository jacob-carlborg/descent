package net.sourceforge.nattable.typeconfig.style;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;

public class DefaultStyleConfig implements IStyleConfig {

	private static final long serialVersionUID = 1L;

	private Color defaultBackgroundColor;
	
	private Color defaultForegroundColor;

	private Font defaultFont;
	
	private Image defaultImage;
	
	public DefaultStyleConfig() {
	}
	
	public DefaultStyleConfig(
			Color defaultBackgroundColor,
			Color defaultForegroundColor,
			Font defaultFont,
			Image defaultImage
	) {
		this.defaultBackgroundColor = defaultBackgroundColor;
		this.defaultForegroundColor = defaultForegroundColor;
		this.defaultFont = defaultFont;
		this.defaultImage = defaultImage;
	}
	
	public Color getBackgroundColor(int row, int col) {
		return defaultBackgroundColor;
	}
	
	public void setDefaultBackgroundColor(Color defaultBackgroundColor) {
		this.defaultBackgroundColor = defaultBackgroundColor;
	}

	public Color getForegroundColor(int row, int col) {
		return defaultForegroundColor;
	}
	
	public void setDefaultForegroundColor(Color defaultForegroundColor) {
		this.defaultForegroundColor = defaultForegroundColor;
	}

	public Font getFont(int row, int col) {
		return defaultFont;
	}
	
	public void setDefaultFont(Font defaultFont) {
		this.defaultFont = defaultFont;
	}

	public Image getImage(int row, int col) {
		return defaultImage;
	}
	
	public void setDefaultImage(Image defaultImage) {
		this.defaultImage = defaultImage;
	}

}
