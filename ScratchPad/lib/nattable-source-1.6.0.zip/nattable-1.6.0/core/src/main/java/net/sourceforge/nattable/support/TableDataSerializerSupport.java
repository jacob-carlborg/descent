package net.sourceforge.nattable.support;

import java.lang.reflect.Method;
import java.util.List;

/**
 * This class can be used to serialize the table's data to any delimited format.
 *
 * @param <T>
 */
public class TableDataSerializerSupport<T> {
	public String rowDelimiter;
	public String cellDelimiter;

	public TableDataSerializerSupport(String rowDelimiter, String cellDelimiter) {
		this.rowDelimiter = rowDelimiter;
		this.cellDelimiter = cellDelimiter;
	}

	/**
	 * Serialize the list data to strings
	 * @param dataToSerialize
	 * @param methodsToSerialize
	 * @return
	 */
	public StringBuffer serializeAndDelimit(List<?> dataToSerialize, List<String> methodsToSerialize) {
		StringBuffer rows = new StringBuffer();

		// following int's are to track the final cell and row so as to not add
		// an extra delimiter.
		int cellLimit = methodsToSerialize.size();
		int rowLimit = dataToSerialize.size();
		int rowIndex = 0;

		// iterate through each bean representing a row in the clipboard
		for (Object bean : dataToSerialize) {
			StringBuffer cells = new StringBuffer();
			int cellIndex = 0;

			// iterate through each method represent cells for a given row in
			// the clipboard
			for (String method : methodsToSerialize) {
				try {
					Method mInstance = bean.getClass().getDeclaredMethod(method, new Class[] {});
					mInstance.setAccessible(true);
					cells.append(String.valueOf(mInstance.invoke(bean, new Object[] {})) + (++cellIndex < cellLimit ? cellDelimiter : ""));
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage(), e);
				}
			}
			rows.append(cells.toString() + (++rowIndex < rowLimit ? rowDelimiter : ""));
		}

		return rows;
	}
	
	/**
	 * Use to override default row delimiter
	 * 
	 * @param rowDelimiter
	 */
	public void setRowDelimiter(String rowDelimiter) {
		this.rowDelimiter = rowDelimiter;
	}

	/**
	 * Use to override default cell delimiter
	 * 
	 * @param cellDelimiter
	 */
	public void setCellDelimiter(String cellDelimiter) {
		this.cellDelimiter = cellDelimiter;
	}
}