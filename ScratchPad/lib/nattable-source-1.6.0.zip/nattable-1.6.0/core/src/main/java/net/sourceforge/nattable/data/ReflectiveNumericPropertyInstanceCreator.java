package net.sourceforge.nattable.data;

import net.sourceforge.nattable.util.PrimitiveClassResolver;

public class ReflectiveNumericPropertyInstanceCreator implements IPropertyInstanceCreator {

	public <T> T getPropertyInstance(Class<T> propertyClass, Object property) {
		try {
			Class<?> targetClass = PrimitiveClassResolver.checkClassForPrimitives(propertyClass); 
			if (targetClass.isPrimitive() && !targetClass.equals(char.class)) {
				String propStr = null;
				if (property != null) {
					propStr = String.valueOf(property);
					propStr = propStr.equals("") ? "0" : propStr;
				}
				return propertyClass.getConstructor(new Class[] { String.class }).newInstance(propStr);
			}
			return null;

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

}
