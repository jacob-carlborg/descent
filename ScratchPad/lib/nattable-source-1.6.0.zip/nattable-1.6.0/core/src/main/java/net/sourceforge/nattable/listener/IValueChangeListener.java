package net.sourceforge.nattable.listener;

public interface IValueChangeListener {

	public void valueChanged(int row, int col, Object oldValue, Object newValue);

}
