package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.painter.cell.HeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.sorting.ISortingDirectionChangeListener;
import net.sourceforge.nattable.sorting.SortingDirection;
import net.sourceforge.nattable.typeconfig.style.ColumnHeaderStyleConfig;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;

import org.eclipse.swt.SWT;

public abstract class AbstractColumnHeaderRenderer implements ICellRenderer, ISortingDirectionChangeListener {

	private IStyleConfig columnHeaderStyleConfig;

	HeaderCellPainter columnCellPainter = new HeaderCellPainter(SWT.CENTER | SWT.BORDER);

	public AbstractColumnHeaderRenderer() {
		columnHeaderStyleConfig = new ColumnHeaderStyleConfig();
	}

	public IStyleConfig getStyleConfig(String displayMode, int row, int col) {
		return columnHeaderStyleConfig;
	}

	public ICellEditor getCellEditor(int row, int col) {
		return null;
	}

	public ICellPainter getCellPainter(int row, int col) {
		return columnCellPainter;
	}

	public Object getValue(int row, int col) {
		return null;
	}

	public boolean isEditable(int row, int col) {
		return false;
	}

	public void sortingDirectionChanged(SortingDirection[] directions) {
		if (columnHeaderStyleConfig instanceof ISortingDirectionChangeListener) {
			ISortingDirectionChangeListener sortingColumnHeaderStyleConfig = (ISortingDirectionChangeListener) columnHeaderStyleConfig;
			sortingColumnHeaderStyleConfig.sortingDirectionChanged(directions);
		}
	}

}
