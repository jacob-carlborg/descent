package net.sourceforge.nattable.typeconfig.style;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.StringTokenizer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

/**
 * This class delegates the instantiation of objects from the style xml.
 * 
 * @author cmartine
 * 
 */
public class StaticStyleAssembler {
	
	public static Font assembleFont(Display display, String fontName, String fontStyle, String height) {		
		int style = SWT.NORMAL;
		StringTokenizer fontStyleTokens = new StringTokenizer(fontStyle, "|");
		while(fontStyleTokens.hasMoreTokens()) {
			String fontToken = fontStyleTokens.nextToken();
			if (fontToken.equalsIgnoreCase("BOLD") || fontToken.equals("1")) {
				style = style | SWT.BOLD;
			} else if (fontToken.equalsIgnoreCase("ITALIC") || fontToken.equals("2")) {
				style = style | SWT.ITALIC;
			} else if(fontToken.equals("3")) {
				style = style | SWT.BOLD | SWT.ITALIC;
			}else {
				style = style | SWT.NORMAL;
			}			
		}
		return new Font(display, new FontData(fontName, Integer.parseInt(height), style));
	}

	/**
	 * Throw AssertionException if the rgbString is not formatted correctly.
	 * Must follow format: [0-255],[0-255],[0-255]
	 * 
	 * @param rgbString
	 */
	public static  Color assembleColor(Display display, String rgbString) {
		return new Color(display, parseRGB(rgbString));
	}

	public static Image assembleImage(Display display, String imgUri) throws IOException{
		Image img = null;
		InputStream imageStream = null;
		try {			
			if(ClassLoader.getSystemResource(imgUri) != null) {
				imageStream = ClassLoader.getSystemResourceAsStream(imgUri);
			}
			else {
				// create url and try to download image.
				URL imageLocator = new URL(imgUri);
				if (imageLocator != null) {
					imageStream = imageLocator.openStream();
				}			
			}
			img = new Image(display, new ImageData(imageStream));
		}finally {
			if(imageStream != null) {
				imageStream.close();
			}
		}
		return img;
	}

	public static RGB parseRGB(String rgbString) {
		StringTokenizer tokenizedRGB = new StringTokenizer(rgbString, ",");
		assert tokenizedRGB.countTokens() == 3;
		int[] rgb = new int[3];
		int colorCounter = 0;
		while (tokenizedRGB.hasMoreElements()) {
			rgb[colorCounter++] = Integer.parseInt(tokenizedRGB.nextToken());
		}
		return new RGB(rgb[0], rgb[1], rgb[2]);
	}
}
