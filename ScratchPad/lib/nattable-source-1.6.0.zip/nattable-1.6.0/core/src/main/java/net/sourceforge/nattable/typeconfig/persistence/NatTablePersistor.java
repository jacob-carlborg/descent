package net.sourceforge.nattable.typeconfig.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Map;
import java.util.Set;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.sorting.ISortingDirectionChangeListener;
import net.sourceforge.nattable.sorting.SortingDirection;
import net.sourceforge.nattable.support.ColumnSortSupport;

public class NatTablePersistor extends AbstractPersistor {
	private static final long serialVersionUID = 1L;
	
	private NatTable grid;
	
	private StoredInstance restoredInstance;
	
	public NatTablePersistor(NatTable grid) {
		this.grid = grid;
	}
	
	public void load(InputStream in) {
		try {
			NatTablePersistor restorer = (NatTablePersistor)restore(in);
			Set<Integer> hiddenColumns = restorer.restoredInstance.hiddenColumns;
			
			if(hiddenColumns != null && hiddenColumns.size() > 0) {
				grid.getHiddenModelBodyColumns().addAll(hiddenColumns);
			}
			int[] columnOrder = restorer.restoredInstance.columnOrder;
			grid.setModelBodyColumnOrder(columnOrder);
			Map<Integer, SortingDirection> sortDir = restorer.restoredInstance.sortDir;
			final ColumnSortSupport sorter = grid.getColumnSortSupport();
			if(sorter!= null) {
				sorter.getSortingColumnMap().putAll(sortDir);
				ISortingDirectionChangeListener sortingColumnHeaderRenderer = (ISortingDirectionChangeListener) grid.getNatTableModel().getColumnHeaderCellRenderer();
				sortingColumnHeaderRenderer.sortingDirectionChanged(sorter.getSortingDirections());
			}
		}catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public void save(OutputStream store) {
		try {
			store(store);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		StoredInstance storer = new StoredInstance();
		//hidden columns
		storer.hiddenColumns = grid.getHiddenModelBodyColumns();
		//column order
		storer.columnOrder = grid.getModelBodyColumnOrder();	
		//sort direction
		storer.sortDir = grid.getColumnSortSupport().getSortingColumnMap();
		
		stream.writeObject(storer);
	}
	
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		restoredInstance =  (StoredInstance)stream.readObject();
	}

	@SuppressWarnings("unused")
	private void readObjectNoData() throws ObjectStreamException {

	}
	
	class StoredInstance implements Serializable{
		private static final long serialVersionUID = 1L;
		Set<Integer> hiddenColumns;
		int[] columnOrder;
		Map<Integer, SortingDirection> sortDir;
	}
}
