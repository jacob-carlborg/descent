package net.sourceforge.nattable.event.mode;

public enum ModeEnum {

	NORMAL_MODE,
	COLUMN_RESIZE_MODE,
	COLUMN_SORT_MODE,
	COLUMN_REORDER_MODE,
	COLUMN_HEADER_MODE,
	COLUMN_GROUP_MODE,
	ROW_RESIZE_MODE,
	MOUSE_SELECTION_MODE
	
}
