package net.sourceforge.nattable.data;

import java.util.Arrays;
import java.util.List;

public class ColumnHeaderLabelProvider implements IColumnHeaderLabelProvider {

	private final List<String> columnLabels;

	public ColumnHeaderLabelProvider(String[] columnLabels) {
		this(Arrays.asList(columnLabels));
	}

	public ColumnHeaderLabelProvider(List<String> columnLabels) {
		this.columnLabels = columnLabels;
	}
	
	public String getColumnHeaderLabel(int col) {
		return columnLabels.get(col);
	}
	
}
