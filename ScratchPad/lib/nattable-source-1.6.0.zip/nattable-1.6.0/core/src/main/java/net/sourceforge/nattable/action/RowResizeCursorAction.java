package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.widgets.Display;

public class RowResizeCursorAction implements IMouseEventAction {

	private NatTable natTable;
	
	private Cursor cursorNS = new Cursor(Display.getDefault(), SWT.CURSOR_SIZENS);
	
	public RowResizeCursorAction(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void run(MouseEvent event) {
		natTable.setCursor(cursorNS);
	}

}
