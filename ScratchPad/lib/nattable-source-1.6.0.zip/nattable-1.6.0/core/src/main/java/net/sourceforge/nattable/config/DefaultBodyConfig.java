package net.sourceforge.nattable.config;

import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.renderer.ConfigDrivenCellRenderer;
import net.sourceforge.nattable.renderer.DataBindingCellRenderer;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

public class DefaultBodyConfig implements IBodyConfig {
	
	protected ICellRenderer cellRenderer;
	
	private SizeConfig columnWidthConfig;
	
	private SizeConfig rowHeightConfig;

	private IDataProvider dataProvider;

	public DefaultBodyConfig(IDataProvider dataProvider) {
		this(dataProvider, null, null);
	}
	
	public DefaultBodyConfig(IDataProvider dataProvider, ContentConfigRegistry contentConfigRegistry, StyleConfigRegistry styleConfigRegistry) {
		this.dataProvider = dataProvider;
		
		if (contentConfigRegistry != null && styleConfigRegistry != null) {
			cellRenderer = new ConfigDrivenCellRenderer(dataProvider, contentConfigRegistry, styleConfigRegistry);
		} else {
			cellRenderer = new DataBindingCellRenderer(dataProvider);
		}
		
		initialize();
	}
	
	protected void initialize() {
		// TODO calculate column width based on column text width
		columnWidthConfig = new SizeConfig(200);
		
		// TODO calculate default row height based on row text height
		this.rowHeightConfig = new SizeConfig(40);
	}
	
	public ICellRenderer getCellRenderer() {
		return cellRenderer;
	}
	
	public void setCellRenderer(ICellRenderer cellRenderer) {
		this.cellRenderer = cellRenderer;
	}
	
	public int getColumnCount() {
		return dataProvider.getColumnCount();
	}
	
	public SizeConfig getColumnWidthConfig() {
		return columnWidthConfig;
	}
	
	public void setColumnWidthConfig(SizeConfig columnWidthConfig) {
		this.columnWidthConfig = columnWidthConfig;
	}
	
	public int getRowCount() {
		return dataProvider.getRowCount();
	}
	
	public SizeConfig getRowHeightConfig() {
		return rowHeightConfig;
	}
	
	public void setRowHeightConfig(SizeConfig rowHeightConfig) {
		this.rowHeightConfig = rowHeightConfig;
	}

}
