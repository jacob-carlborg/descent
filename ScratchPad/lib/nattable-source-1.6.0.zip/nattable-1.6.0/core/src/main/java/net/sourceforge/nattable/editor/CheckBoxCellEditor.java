package net.sourceforge.nattable.editor;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��13��<br>
 */
public class CheckBoxCellEditor extends AbstractCellEditor {
	
	private Object oldValue;

	@Override
	protected Control activateCell(Composite control, Rectangle rectangle, Object oldValue) {
		this.oldValue = oldValue;
		commit();
		return null;
	}
	
	public void commit() {
		commit(Boolean.valueOf(!((Boolean) oldValue).booleanValue()));
	}
	
	public void close() {
		// no-op
	}

}
