package net.sourceforge.nattable.event.mode;

import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.event.drag.DragModeEventHandler;
import net.sourceforge.nattable.event.drag.IDragMode;
import net.sourceforge.nattable.listener.NatEventData;
import net.sourceforge.nattable.support.ModeSupport;
import net.sourceforge.nattable.event.util.CancelableRunnable;

import org.eclipse.swt.events.MouseEvent;

public class MouseModeEventHandler extends AbstractModeEventHandler {
	
	private MouseEvent initialMouseDownEvent;
	
	private IMouseEventAction singleClickAction;
	
	private IMouseEventAction doubleClickAction;
	
	private boolean mouseDown;
	
	private IDragMode dragMode;
	
	private SingleClickRunnable singleClickRunnable;
	
	// TODO Placeholder to enable single/double click disambiguation
	private boolean exclusive = false;
	
	public MouseModeEventHandler(ModeSupport modeSupport, MouseEvent initialMouseDownEvent, IMouseEventAction singleClickAction, IMouseEventAction doubleClickAction, IDragMode dragMode) {
		super(modeSupport);
		
		mouseDown = true;
		
		this.initialMouseDownEvent = initialMouseDownEvent;
		
		this.singleClickAction = singleClickAction;
		this.doubleClickAction = doubleClickAction;
		this.dragMode = dragMode;
	}
	
	@Override
	public void mouseUp(MouseEvent event) {
		mouseDown = false;
		
		if (singleClickAction != null) {
			if (exclusive && doubleClickAction != null) {
				// If a doubleClick action is registered, wait to see if this mouseUp is part of a doubleClick or not.
				singleClickRunnable = new SingleClickRunnable(singleClickAction, event);
				event.display.timerExec(event.display.getDoubleClickTime(), singleClickRunnable);
			} else {
				executeSingleClickAction(singleClickAction, event);
			}
		} else if (doubleClickAction == null) {
			// No single or double click action registered when mouseUp detected. Switch back to normal mode.
			switchMode(ModeEnum.NORMAL_MODE);
		}
	}
	
	@Override
	public void mouseDoubleClick(MouseEvent event) {
		if (doubleClickAction != null) {
			if (singleClickRunnable != null) {
				// Cancel any pending singleClick action.
				singleClickRunnable.cancel();
			}
			
			event.data = NatEventData.createInstanceFromEvent(event);
			doubleClickAction.run(event);
			// Double click action complete. Switch back to normal mode.
			switchMode(ModeEnum.NORMAL_MODE);
		}
	}
	
	@Override
	public synchronized void mouseMove(MouseEvent event) {
		if (mouseDown && dragMode != null) {
			dragMode.mouseDown(initialMouseDownEvent);
			switchMode(new DragModeEventHandler(getModeSupport(), dragMode));
		} else {
			// No drag mode registered when mouseMove detected. Switch back to normal mode.
			switchMode(ModeEnum.NORMAL_MODE);
		}
	}
	
	private void executeSingleClickAction(IMouseEventAction action, MouseEvent event) {
		event.data = NatEventData.createInstanceFromEvent(event);
		action.run(event);
		// Single click action complete. Switch back to normal mode.
		switchMode(ModeEnum.NORMAL_MODE);
	}
	
	class SingleClickRunnable extends CancelableRunnable {

		private IMouseEventAction action;
		
		private MouseEvent event;
		
		public SingleClickRunnable(IMouseEventAction action, MouseEvent event) {
			this.action = action;
			this.event = event;
		}
		
		public void run() {
			if (!isCancelled()) {
				executeSingleClickAction(action, event);
			}
		}
		
	}
	
}
