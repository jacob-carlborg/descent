package net.sourceforge.nattable.data;

public interface IColumnPropertyProvider {
	
	public String getPropertyName(int col);
	
	public Class<?> getPropertyType(String propertyName);
	
}
