package net.sourceforge.nattable.support;

import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.INatTableModel;

import org.apache.log4j.Logger;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.ScrollBar;

public class ScrollSupport {
	public static final Logger log = Logger.getLogger(ScrollSupport.class);

	private NatTable natTable;
	
	private INatTableModel model;
	
	private ScrollBar hBar;
	
	private ScrollBar vBar;
	
	public ScrollSupport(NatTable natTable) {
		this.natTable = natTable;

		this.model = natTable.getNatTableModel();
		
		this.hBar = natTable.getHorizontalBar();
		this.vBar = natTable.getVerticalBar();
		
		recalculate();
		
		hBar.addListener(SWT.Selection, new HorizontalScrollBarListener());

		vBar.addListener(SWT.Selection, new VerticalScrollBarListener());
	}
	
	public void recalculate() {
		int gridRowCount = model.getBodyRowCount();
		int maxHeight = natTable.getTotalGridHeight();
		if (gridRowCount > 0) {
			vBar.setIncrement(maxHeight / gridRowCount);
		}
		vBar.setMaximum(maxHeight + hBar.getSize().y);  // hack to fix last row not showing w/vertical scrolling

		int gridColumnCount = model.getBodyColumnCount();
		int maxWidth = natTable.getTotalViewableBodyWidth();
		if (gridColumnCount > 0) {
			hBar.setIncrement(maxWidth / gridColumnCount);
		}
		hBar.setMaximum(maxWidth);
	}

	private class HorizontalScrollBarListener implements Listener {
		
		public void handleEvent(Event e) {
			int targetViewableBodyColumn;
			
			List<Integer> visibleModelBodyColumns = natTable.getVisibleModelBodyColumns();
			if (visibleModelBodyColumns != null && visibleModelBodyColumns.size() > 0) {
				int firstVisibleModelBodyColumn = visibleModelBodyColumns.get(0).intValue();
				targetViewableBodyColumn = natTable.modelToViewableBodyColumn(firstVisibleModelBodyColumn);
			} else {
				targetViewableBodyColumn = natTable.getViewableBodyColumnCount();
			}
			
			switch (e.detail) {
			case SWT.PAGE_UP:
				adjustHorizontalScrollPosition(targetViewableBodyColumn - hBar.getPageIncrement());
				break;
			case SWT.PAGE_DOWN:
				adjustHorizontalScrollPosition(targetViewableBodyColumn + hBar.getPageIncrement());
				break;
			case SWT.ARROW_UP:
				adjustHorizontalScrollPosition(targetViewableBodyColumn - 1);
				break;
			case SWT.ARROW_DOWN:
				adjustHorizontalScrollPosition(targetViewableBodyColumn + 1);
				break;
			default:
				natTable.scrollHBarUpdate(hBar);
			}
		}

		private void adjustHorizontalScrollPosition(int targetViewableBodyColumn) {
			int currentWidth = 0;
			
			int viewableIndex = -1;
			
			int[] modelBodyColumnOrder = natTable.getModelBodyColumnOrder();
			for (int i = 0; i < modelBodyColumnOrder.length; i++) {
				int modelBodyColumn = modelBodyColumnOrder[i];
				if (natTable.isModelBodyColumnViewable(modelBodyColumn)) {
					viewableIndex++;
					if (viewableIndex < targetViewableBodyColumn) {
						currentWidth += model.getBodyColumnWidth(modelBodyColumn);
					} else {
						break;
					}
				}
			}
			
			hBar.setSelection(currentWidth);
			natTable.scrollHBarUpdate(hBar);
		}

	}

	private class VerticalScrollBarListener implements Listener {
		
		public void handleEvent(Event e) {
			List<Integer> visibleBodyRows = natTable.getVisibleModelBodyRows();
			if (visibleBodyRows != null && visibleBodyRows.size() > 0) {
				switch (e.detail) {
				case SWT.PAGE_UP:
					adjustVerticalScrollPosition(visibleBodyRows.get(0).intValue() - vBar.getPageIncrement());
					break;
				case SWT.PAGE_DOWN:
					adjustVerticalScrollPosition(visibleBodyRows.get(0).intValue() + vBar.getPageIncrement());
					break;
				case SWT.ARROW_UP:
					adjustVerticalScrollPosition(visibleBodyRows.get(0).intValue() - 1);
					break;
				case SWT.ARROW_DOWN:
					adjustVerticalScrollPosition(visibleBodyRows.get(0).intValue() + 1);
					break;
				default:
					// TODO Improve Performance
					int select = vBar.getSelection();

					if ((select + vBar.getThumb()) == vBar.getMaximum()) {
						vBar.setSelection(vBar.getMaximum());
						natTable.scrollVBarUpdate(vBar);
					} else {
						int start = natTable.getHeightIndex().getBestStartingSearchRow(select);
						int last = select;
						int currentHeight = natTable.getHeightIndex().getHeightByStartIndex(start);
						
						int row = model.getBodyRowCount();
						for (int i = start; i < row; i++) {
							currentHeight += model.getBodyRowHeight(i);
							if (currentHeight > select) {
								vBar.setSelection(last);
								natTable.scrollVBarUpdate(vBar);
								break;
							}
							last = currentHeight;
						}
					}
				}
			}
		}

		private void adjustVerticalScrollPosition(int toIndex) {
//			int currentHeight = 0;
//			for (int i = 0; i < toIndex; i++) {
//				currentHeight += model.getBodyRowHeight(i);
//			}
			int height = natTable.getHeightIndex().getHeightByStartIndex(toIndex);
			
			vBar.setSelection(height);
			natTable.scrollVBarUpdate(vBar);
		}

	}

}
