package net.sourceforge.nattable.data;

public interface IColumnHeaderLabelProvider {
	
	public String getColumnHeaderLabel(int col);
	
}
