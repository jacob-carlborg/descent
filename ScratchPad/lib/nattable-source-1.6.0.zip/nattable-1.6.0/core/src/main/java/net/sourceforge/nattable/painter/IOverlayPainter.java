package net.sourceforge.nattable.painter;

import org.eclipse.swt.graphics.GC;

public interface IOverlayPainter {

	public void paintOverlay(GC gc);
	
}
