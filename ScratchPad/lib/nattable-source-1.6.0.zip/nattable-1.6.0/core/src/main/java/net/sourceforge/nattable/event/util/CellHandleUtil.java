package net.sourceforge.nattable.event.util;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

public class CellHandleUtil {

	public static int getResizeModelBodyColumn(NatTable natTable, int selectedModelBodyColumn, int x, int y) {
		if (selectedModelBodyColumn >= 0) {
			switch (CellHandleUtil.getHorizontalCellHandle(natTable, x, y, 4)) {
			case LEFT:
				if (selectedModelBodyColumn == 0) {
					// can't resize left edge of first column
					break;
				}
				selectedModelBodyColumn = natTable.getPreviousAdjacentVisibleModelBodyColumn(selectedModelBodyColumn);
				// drop through to RIGHT case
			case RIGHT:
				if (natTable.getNatTableModel().isBodyColumnResizable(selectedModelBodyColumn)) {
					return selectedModelBodyColumn;
				}
			}
		}
		
		return -1;
	}
	
	public static HorizontalDirectionEnum getHorizontalCellHandle(NatTable natTable, int x, int y) {
		return getHorizontalCellHandle(natTable, x, y, -1);
	}

	public static HorizontalDirectionEnum getHorizontalCellHandle(NatTable natTable, int x, int y, int handleWidth) {
		Point clickPt = new Point(x, y);
		
		Rectangle cellRect =
			natTable.getModelGridCellBound(natTable.getModelGridRowByY(y), natTable.getModelGridColumnByX(x));
		
		return getHorizontalCellHandle(cellRect, clickPt, handleWidth);
	}
	
	public static HorizontalDirectionEnum getHorizontalCellHandle(Rectangle uiCellRect, Point clickPt) {
		return getHorizontalCellHandle(uiCellRect, clickPt, -1);
	}
	
	public static HorizontalDirectionEnum getHorizontalCellHandle(Rectangle uiCellRect, Point clickPt, int handleWidth) {
		if (handleWidth < 0) {
			handleWidth = uiCellRect.width / 2;
		}
		
		Rectangle left =
			new Rectangle(
					uiCellRect.x,
					uiCellRect.y,
					handleWidth,
					uiCellRect.height);
		
		Rectangle right =
			new Rectangle(
					uiCellRect.x + uiCellRect.width - handleWidth,
					uiCellRect.y,
					handleWidth,
					uiCellRect.height);
		
		if (left.contains(clickPt)) {
			return HorizontalDirectionEnum.LEFT;
		} else if (right.contains(clickPt)) {
			return HorizontalDirectionEnum.RIGHT;
		} else {
			return HorizontalDirectionEnum.NONE;
		}
	}
	
	public static VerticalDirectionEnum getVerticalCellHandle(NatTable natTable, int x, int y) {
		return getVerticalCellHandle(natTable, x, y, -1);
	}
	
	public static VerticalDirectionEnum getVerticalCellHandle(NatTable natTable, int x, int y, int handleHeight) {
		Point clickPt = new Point(x, y);
		
		Rectangle cellRect =
			natTable.getModelGridCellBound(natTable.getModelGridRowByY(y), natTable.getModelGridColumnByX(x));
		
		return getVerticalCellHandle(cellRect, clickPt, handleHeight);
	}
	
	public static VerticalDirectionEnum getVerticalCellHandle(Rectangle uiCellRect, Point clickPt) {
		return getVerticalCellHandle(uiCellRect, clickPt, -1);
	}
	
	public static VerticalDirectionEnum getVerticalCellHandle(Rectangle uiCellRect, Point clickPt, int handleHeight) {
		if (handleHeight < 0) {
			handleHeight = uiCellRect.height / 2;
		}
		
		Rectangle top =
			new Rectangle(
					uiCellRect.x,
					uiCellRect.y,
					uiCellRect.width,
					handleHeight);
		
		Rectangle bottom =
			new Rectangle(
					uiCellRect.x,
					uiCellRect.y + uiCellRect.height - handleHeight,
					uiCellRect.width,
					handleHeight);
		
		if (top.contains(clickPt)) {
			return VerticalDirectionEnum.UP;
		} else if (bottom.contains(clickPt)) {
			return VerticalDirectionEnum.DOWN;
		} else {
			return VerticalDirectionEnum.NONE;
		}
	}
	
}
