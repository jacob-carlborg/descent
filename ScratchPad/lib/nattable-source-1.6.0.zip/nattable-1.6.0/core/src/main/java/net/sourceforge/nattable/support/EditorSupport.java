package net.sourceforge.nattable.support;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.data.IDataValidator;
import net.sourceforge.nattable.editor.DefaultEditController;
import net.sourceforge.nattable.editor.EditorSelectionEnum;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.editor.IEditController;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;

public class EditorSupport {

	private NatTable natTable = null;
	
	private ContentConfigRegistry contentConfigRegistry;
	
	private final ScrollListener scrollListener;
	
	private ICellEditor cellEditor;
	
	public EditorSupport(NatTable natTable) {
		this.natTable = natTable;
		
		INatTableModel model = natTable.getNatTableModel();
		this.contentConfigRegistry = model.getContentConfigRegistry();
		
		scrollListener = new ScrollListener();
		natTable.getHorizontalBar().addSelectionListener(scrollListener);
		natTable.getVerticalBar().addSelectionListener(scrollListener);
	}

	public void activateCell(int gridRow, int gridCol) {
		activateCell(gridRow, gridCol, null);
	}
	
	public void activateCell(int gridRow, int gridCol, Object defaultValue) {
		RegionMetricsSupport metricsSupport = natTable.getRegionMetricsSupport();
		if (metricsSupport.isModelBodyCell(gridRow, gridCol)) {
			int bodyRow = metricsSupport.modelGridToBodyRow(gridRow);
			int bodyCol = metricsSupport.modelGridToBodyColumn(gridCol);
			
			ICellRenderer bodyCellRenderer = natTable.getNatTableModel().getBodyCellRenderer();
			if (bodyCellRenderer.isEditable(bodyRow, bodyCol)
					&& natTable.getVisibleModelBodyRows().contains(Integer.valueOf(bodyRow))
					&& natTable.getVisibleModelBodyColumns().contains(Integer.valueOf(bodyCol))) {
	
				cellEditor = bodyCellRenderer.getCellEditor(bodyRow, bodyCol);

				if (cellEditor != null) {
					Rectangle rectangle = getEditorRectangle(gridRow, gridCol);
					Object oldValue = defaultValue;
					
					if (oldValue == null) {
						oldValue = bodyCellRenderer.getValue(bodyRow, bodyCol);
						cellEditor.setSelectionMode(EditorSelectionEnum.ALL);
					}
					else {
						cellEditor.setSelectionMode(EditorSelectionEnum.END);
					}
					
					IDataValidator dataValidator = null;
					if (contentConfigRegistry != null) {
						dataValidator = contentConfigRegistry.getDataValidator(bodyRow, bodyCol);
					}
					IEditController editController = new DefaultEditController(natTable, dataValidator, bodyRow, bodyCol, oldValue);
					Control control = cellEditor.activateCell(editController, natTable, rectangle, oldValue);
					
					if (control != null && !control.isDisposed()) {
						scrollListener.setControl(control);
						scrollListener.setGridRow(gridRow);
						scrollListener.setGridCol(gridCol);
						
						control.addFocusListener(focusListener);
						control.addKeyListener(keyListener);
						control.addTraverseListener(new TraverseListener() {

							public void keyTraversed(TraverseEvent e) {
								e.doit = false;
							}
							
						});
						control.forceFocus();
					}
				}
			}
		}
	}

	private Rectangle getEditorRectangle(int gridRow, int gridCol) {
		Rectangle rectangle = natTable.getModelGridCellBound(gridRow, gridCol);
		rectangle.height = rectangle.height - 1;
		rectangle.width = rectangle.width - 1;
		rectangle.y = rectangle.y + 1;
		rectangle.x = rectangle.x + 1;
		return rectangle;
	}

	private KeyListener keyListener = new KeyAdapter() {
		
		@Override
		public void keyPressed(KeyEvent event) {
			if (event.keyCode == SWT.CR ||
					event.keyCode == SWT.ESC ||
					event.keyCode == SWT.TAB) {
				natTable.getModeSupport().keyPressed(event);
				event.doit = false;
			}
		}
	
	};

	private FocusListener focusListener = new FocusAdapter() {
		
		@Override
		public void focusLost(FocusEvent event) {
			close();
		}
		
	};

	public void close() {
		scrollListener.setGridCol(-1);
		scrollListener.setGridRow(-1);
		scrollListener.setControl(null);
		
		if (cellEditor != null) {
			cellEditor.close();
		}
	}

	class ScrollListener extends SelectionAdapter {

		private int gridRow = -1;
		private int gridCol = -1;
		private Control control = null;
		
		public void setGridRow(int gridRow) {
			this.gridRow = gridRow;
		}
		
		public void setGridCol(int gridCol) {
			this.gridCol = gridCol;
		}

		public void setControl(Control control) {
			this.control = control;
		}
		
		@Override
		public void widgetSelected(SelectionEvent e) {
			if (gridRow >= 0 && gridCol >= 0 && control != null) {
				Rectangle editorRectangle = getEditorRectangle(gridRow, gridCol);
				control.setBounds(editorRectangle);
				control.redraw();
			}
		}
	}
}
