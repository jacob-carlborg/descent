package net.sourceforge.nattable.editor;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��13��<br>
 */
public class TextCellEditor extends AbstractCellEditor {
	
	Text text = null;
	boolean selectAll = true;
	boolean enterClose = true;
	boolean editable = true;

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

	public boolean isEnterClose() {
		return enterClose;
	}

	public void setEnterClose(boolean enterClose) {
		this.enterClose = enterClose;
	}

	public boolean isSelectAll() {
		return getSelectionMode() == EditorSelectionEnum.ALL;
	}

	@Override
	protected Control activateCell(Composite parent, Rectangle rectangle, Object oldValue) {
		Object str = oldValue;

		text = createTextControl(parent);
		text.setBounds(rectangle);
		text.setText(str != null ? str.toString() : "");
		
		selectText();

		if (!isEditable()) {
			text.setEditable(false);
		}

		if (isEnterClose()) {
			text.addKeyListener(new KeyAdapter() {

				@Override
				public void keyPressed(KeyEvent event) {
					if ((event.keyCode == SWT.CR && event.stateMask == 0)
							|| (event.keyCode == SWT.KEYPAD_CR && event.stateMask == 0)) {
						commit();
					}
				}

			});
		}
		
		return text;
	}
	
	public void commit() {
		commit(getValue());
	}
	
	public void close() {
		text.dispose();
	}

	private void selectText() {
		int textLength = text.getText().length();
		
		if (textLength > 0) {
			if (isSelectAll()) {
				text.setSelection(0, textLength);
			} else if (getSelectionMode() == EditorSelectionEnum.END) {
				text.setSelection(textLength, textLength);
			}
		}
	}

	protected Text createTextControl(Composite parent) {
		return new Text(parent, SWT.None);
	}

	protected Object getValue() {
		if (text != null && !text.isDisposed()) {
			return text.getText();
		}
		return "";
	}

}
