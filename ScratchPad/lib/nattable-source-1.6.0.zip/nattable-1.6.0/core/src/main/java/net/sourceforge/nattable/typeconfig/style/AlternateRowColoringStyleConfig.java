package net.sourceforge.nattable.typeconfig.style;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;

import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

/**
 * This implementation of IStyleConfiguration wraps grid level configurations and adds the logic to
 * handle alternate row coloring.
 * @author cmartine
 *
 */
public class AlternateRowColoringStyleConfig implements IStyleConfig {
	private static final long serialVersionUID = 1L;
	private String oddColorRGB;
	private Color oddRowColor;
	private String evenColorRGB;
	private Color evenRowColor;
	private IStyleConfig adaptedStyle;

	public AlternateRowColoringStyleConfig() {
		this(GUIHelper.COLOR_GRAY, GUIHelper.COLOR_WHITE);
	}

	public AlternateRowColoringStyleConfig(Color evenRowColor, Color oddRowColor) {
		this.evenRowColor = evenRowColor;
		this.oddRowColor = oddRowColor;
	}
	
	public Color getBackgroundColor(int row, int col) {
		if (row % 2 == 0) {
			return getOddRowColor();
		} else {
			return getEvenRowColor();
		}
	}
	
	public Color getOddRowColor() {
		if(oddRowColor == null) {
			oddRowColor = StaticStyleAssembler.assembleColor(Display.getCurrent(), oddColorRGB);
		}
		return oddRowColor;
	}

	public Color getEvenRowColor() {
		if(evenRowColor == null) {
			evenRowColor = StaticStyleAssembler.assembleColor(Display.getCurrent(), evenColorRGB);
		}
		return evenRowColor;
	}

	public void adaptExistingStyle(IStyleConfig gridStyle) {
		this.adaptedStyle = gridStyle;
	}
	
	public Font getFont(int row, int col) {
		return adaptedStyle != null ? adaptedStyle.getFont(row, col) : null;
	}

	public Color getForegroundColor(int row, int col) {
		return adaptedStyle != null ? adaptedStyle.getForegroundColor(row, col) : null;
	}

	public Image getImage(int row, int col) {
		return adaptedStyle != null ? adaptedStyle.getImage(row, col) : null;
	}
	
	private void writeObject(ObjectOutputStream stream) throws IOException {
		StyleStorer storer = new StyleStorer();
		if(oddColorRGB == null) {
			oddColorRGB = StaticStyleDisassembler.colorToString(oddRowColor.getRGB());
		}
		if(evenColorRGB == null) {
			evenColorRGB = StaticStyleDisassembler.colorToString(evenRowColor.getRGB());
		}
		storer.restoredOddColorRGB = oddColorRGB;
		storer.restoredEvenColorRGB = evenColorRGB;
		if(adaptedStyle != null && adaptedStyle instanceof Serializable) {
			storer.restoredAdaptedStyle = adaptedStyle;
		}
		
		stream.writeObject(storer);
	}

	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		StyleStorer restorer = (StyleStorer)stream.readObject();
		this.oddColorRGB = restorer.restoredOddColorRGB;
		this.evenColorRGB = restorer.restoredEvenColorRGB;
		if(restorer.restoredAdaptedStyle != null) {
			this.adaptedStyle = restorer.restoredAdaptedStyle;
		}
	}

	@SuppressWarnings("unused")
	private void readObjectNoData() throws ObjectStreamException {

	}
	
	class StyleStorer implements Serializable {
		private static final long serialVersionUID = 1L;
		String restoredOddColorRGB;
		String restoredEvenColorRGB;
		IStyleConfig restoredAdaptedStyle;
	}
}