package net.sourceforge.nattable.action;

import net.sourceforge.nattable.support.SelectionSupport;

import org.eclipse.swt.events.KeyEvent;

public class MoveRightAction extends AbstractKeySelectAction {
	
	public MoveRightAction(SelectionSupport selectionSupport, boolean withShiftMask, boolean withControlMask) {
		super(selectionSupport, withShiftMask, withControlMask);
	}
	
	public void run(KeyEvent event) {
		selectionSupport.moveRight(withShiftMask, withControlMask);
	}

}
