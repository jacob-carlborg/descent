package net.sourceforge.nattable.typeconfig;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import net.sourceforge.nattable.data.IRowDataProvider;

/*
 * First Map's key is displayMode, inner Map's key is fieldName, the inner Map's value is cellValue
 */
public class TypedCellOverrider<T> extends AbstractOverrider {
	private IRowDataProvider<T> dataProvider;

	public TypedCellOverrider(IRowDataProvider<T> dataProvider) {
		this.dataProvider = dataProvider;
	}

	public String getConfigType(int row, int col) {
		CellValueOverrideKey key = new CellValueOverrideKey(dataProvider.getValue(row, col), col);
		return overrides.get(key);
	}

	public void registerOverride(Object cellValue, int col, String configType) {
		registerOverride(new CellValueOverrideKey(cellValue, col), configType);
	}
}

class CellValueOverrideKey implements Serializable {
	private static final long serialVersionUID = 1L;
	Object cellValue;
	int col;

	CellValueOverrideKey(Object cellValue, int col) {
		this.cellValue = cellValue;
		this.col = col;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof CellValueOverrideKey == false) {
			return false;
		}
		if (this == obj) {
			return true;
		}
		CellValueOverrideKey rhs = ((CellValueOverrideKey) obj);
		return new EqualsBuilder().append(cellValue, rhs.cellValue).append(col, rhs.col).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(1, 3).append(cellValue).append(col).toHashCode();
	}

	public String getComposite() {
		return cellValue + String.valueOf(col);
	}
}