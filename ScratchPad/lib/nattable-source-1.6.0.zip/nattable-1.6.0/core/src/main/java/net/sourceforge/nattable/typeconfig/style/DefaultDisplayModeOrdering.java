package net.sourceforge.nattable.typeconfig.style;

import java.util.ArrayList;
import java.util.List;


public class DefaultDisplayModeOrdering implements IDisplayModeOrdering {

	public List<String> getDisplayModeOrdering(String targetDisplayMode) {
		List<String> displayModeOrdering = new ArrayList<String>();
		displayModeOrdering.add(targetDisplayMode);
		
		switch (DisplayModeEnum.valueOf(targetDisplayMode)) {
		case NORMAL:
			break;
		case EDIT:
			displayModeOrdering.add(DisplayModeEnum.NORMAL.toString());
			break;
		case SELECT:
			displayModeOrdering.add(DisplayModeEnum.NORMAL.toString());
			break;
		default:
			throw new IllegalStateException("Unknown display mode " + targetDisplayMode);
		}
		
		return displayModeOrdering;
	}

}
