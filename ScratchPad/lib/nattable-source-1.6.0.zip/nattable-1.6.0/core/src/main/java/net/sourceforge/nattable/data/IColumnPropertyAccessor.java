package net.sourceforge.nattable.data;

public interface IColumnPropertyAccessor<T> extends IColumnAccessor<T> {
	public String getColumnProperty(int col);
}
