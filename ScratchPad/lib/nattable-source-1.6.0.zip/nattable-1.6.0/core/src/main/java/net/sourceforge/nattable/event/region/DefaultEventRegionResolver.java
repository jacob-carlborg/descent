package net.sourceforge.nattable.event.region;

import java.util.List;

import net.sourceforge.nattable.GridRegionEnum;
import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.event.util.CellHandleUtil;
import net.sourceforge.nattable.event.util.HorizontalDirectionEnum;
import net.sourceforge.nattable.event.util.VerticalDirectionEnum;
import net.sourceforge.nattable.support.RegionMetricsSupport;

public class DefaultEventRegionResolver implements IEventRegionResolver {

	private NatTable natTable;
	
	private RegionMetricsSupport metrics;
	
	public DefaultEventRegionResolver(NatTable natTable) {
		this.natTable = natTable;
		this.metrics = natTable.getRegionMetricsSupport();
	}
	
	public String getEventRegion(int x, int y) {
		int modelGridRow = natTable.getModelGridRowByY(y);
		int modelGridColumn = natTable.getModelGridColumnByX(x);
		
		int selectedModelBodyColumn = metrics.modelGridToBodyColumn(modelGridColumn);

		if (natTable.isColumnGroupsEnabled() && modelGridRow == 0 && natTable.getColumnGroupSupport().isColumnInColumnGroup(selectedModelBodyColumn)) {
			return "COLUMN_GROUP_HEADER";
		}
		
		if (natTable.getNatTableModel().isBodyColumnResizable(selectedModelBodyColumn) && metrics.isModelColumnHeaderCell(modelGridRow, modelGridColumn)) {
			boolean matched = false;

			HorizontalDirectionEnum handle = CellHandleUtil.getHorizontalCellHandle(natTable, x, y, 4);
			if (handle != HorizontalDirectionEnum.NONE) {
				List<Integer> visibleModelBodyColumns = natTable.getVisibleModelBodyColumns();
				
				if (handle == HorizontalDirectionEnum.LEFT) {
					matched = visibleModelBodyColumns.indexOf(Integer.valueOf(selectedModelBodyColumn)) > 0;
				} else if (handle == HorizontalDirectionEnum.RIGHT) {
					matched = true;
				}
			}
			
			if (matched) {
				return "COLUMN_RESIZE_HANDLE";
			}
		}
		
		int selectedModelBodyRow = metrics.modelGridToBodyRow(modelGridRow);
		
		if (natTable.getNatTableModel().isBodyRowResizable(selectedModelBodyRow) && metrics.isModelRowHeaderCell(modelGridRow, modelGridColumn)) {
			boolean matched = false;

			VerticalDirectionEnum handle = CellHandleUtil.getVerticalCellHandle(natTable, x, y, 4);
			if (handle != VerticalDirectionEnum.NONE) {
				List<Integer> visibleModelBodyRows = natTable.getVisibleModelBodyRows();
				
				if (handle == VerticalDirectionEnum.UP) {
					matched = visibleModelBodyRows.indexOf(Integer.valueOf(selectedModelBodyRow)) > 0;
				} else if (handle == VerticalDirectionEnum.DOWN) {
					matched = true;
				}
			}
			
			if (matched) {
				return "ROW_RESIZE_HANDLE";
			}
		}
		
		GridRegionEnum gridRegion = metrics.getRegion(natTable.getModelGridRowByY(y), natTable.getModelGridColumnByX(x));
		if (gridRegion != null) {
			return gridRegion.toString();
		} else {
			return null;
		}
	}
	
}
