package net.sourceforge.nattable.support;

public class BulkUpdateResponse {
	
	private final BulkUpdateTypeEnum type;
	private final Object newValue;
	
	public BulkUpdateResponse(Object newValue, BulkUpdateTypeEnum type) {
		this.newValue = newValue;
		this.type = type;
	}

	public BulkUpdateTypeEnum getType() {
		return type;
	}

	public Object getNewValue() {
		return newValue;
	}

	@Override
	public String toString() {
		return "[" + type + ":" + newValue + "]";
	}
}
