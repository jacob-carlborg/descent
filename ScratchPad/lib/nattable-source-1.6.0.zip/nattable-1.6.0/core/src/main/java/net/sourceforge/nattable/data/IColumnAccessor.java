package net.sourceforge.nattable.data;

public interface IColumnAccessor<T> {

	public Object getColumnValue(T rowObj, int col);
	
	public int getColumnCount();
	
}
