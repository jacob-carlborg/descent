package net.sourceforge.nattable.event.matcher;

import net.sourceforge.nattable.GridRegionEnum;
import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.editor.ICellEditor;

import org.eclipse.swt.events.MouseEvent;

public class BodyCellEditorMouseEventMatcher implements IMouseEventMatcher {

	private NatTable natTable;
	
	private Class<?> cellEditorClass;
	
	public BodyCellEditorMouseEventMatcher(NatTable natTable, Class<?> cellEditorClass) {
		this.natTable = natTable;
		this.cellEditorClass = cellEditorClass;
	}
	
	public boolean matches(MouseEvent event, String eventRegion) {
		if (GridRegionEnum.BODY.toString().equals(eventRegion)) {
			int modelBodyRow = natTable.getModelBodyRowByY(event.y);
			int modelBodyColumn = natTable.getModelBodyColumnByX(event.x);
			
			ICellEditor cellEditor = natTable.getNatTableModel().getBodyCellRenderer().getCellEditor(modelBodyRow, modelBodyColumn);
			if (cellEditorClass.isInstance(cellEditor)) {
				return true;
			}
		}
		return false;
	}

}
