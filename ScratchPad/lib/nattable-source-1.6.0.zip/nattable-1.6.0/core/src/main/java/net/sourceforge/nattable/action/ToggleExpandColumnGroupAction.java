package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.apache.log4j.Logger;
import org.eclipse.swt.events.MouseEvent;

public class ToggleExpandColumnGroupAction implements IMouseEventAction {

	private NatTable natTable;
	
	Logger log = Logger.getLogger(ToggleExpandColumnGroupAction.class);
	
	public ToggleExpandColumnGroupAction(NatTable natTable) {
		this.natTable = natTable;
	}

	public void run(MouseEvent event) {
		natTable.getColumnGroupSupport().toggleExpandColumnGroup(getGroupName(event));

		natTable.updateResize();
	}

	private String getGroupName(MouseEvent event) {
		int modelGridColumn = natTable.getModelGridColumnByX(event.x);
		int selectedModelBodyColumn = natTable.getRegionMetricsSupport().modelGridToBodyColumn(modelGridColumn);
		String groupName = natTable.getColumnGroupSupport().getColumnGroupName(selectedModelBodyColumn);
		return groupName;
	}

}
