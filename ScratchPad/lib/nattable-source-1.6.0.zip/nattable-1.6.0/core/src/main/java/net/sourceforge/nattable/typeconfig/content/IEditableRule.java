package net.sourceforge.nattable.typeconfig.content;

public interface IEditableRule {
	
	public boolean isEditable(int row, int col);

}
