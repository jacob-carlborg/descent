package net.sourceforge.nattable.painter.cell;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~9��23��<br>
 */
public class ComboBoxCellPainter extends TextCellPainter {

	public ComboBoxCellPainter() {
	}

	public ComboBoxCellPainter(int style) {
		this.style = style;
	}

	@Override
	public void drawCell(GC gc, Rectangle rectangle, NatTable natTable, ICellRenderer natCellRenderer, int row,
			int col, boolean selected) {
		super.drawCell(gc, rectangle, natTable, natCellRenderer, row, col, selected);
		Color orgFG = gc.getForeground();
		Color orgBG = gc.getBackground();
		Font orgFont = gc.getFont();

		// Draw Combobox button
		if (rectangle.width >= 20) {
			GUIHelper.drawComboButton(gc, rectangle, natTable.getNatTableModel(), row, col);
		}

		gc.setForeground(orgFG);
		gc.setBackground(orgBG);
		gc.setFont(orgFont);
	}

}
