package net.sourceforge.nattable.event.util;

public enum HorizontalDirectionEnum {

	LEFT,
	RIGHT,
	NONE
	
}
