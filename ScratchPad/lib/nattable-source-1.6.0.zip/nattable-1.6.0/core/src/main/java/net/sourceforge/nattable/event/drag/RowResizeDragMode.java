package net.sourceforge.nattable.event.drag;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.event.util.CellHandleUtil;
import net.sourceforge.nattable.support.RegionMetricsSupport;

import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Rectangle;

public class RowResizeDragMode implements IDragMode {
	
	private NatTable natTable;
	
	private ResizeData resizeData;
	
	public RowResizeDragMode(NatTable natTable) {
		this.natTable = natTable;
	}

	public void mouseDown(MouseEvent event) {
		natTable.forceFocus();
		
		int modelGridRow = natTable.getModelGridRowByY(event.y);
		int modelGridColumn = natTable.getModelGridColumnByX(event.x);
		RegionMetricsSupport metricsSupport = natTable.getRegionMetricsSupport();
		int selectedModelBodyRow = metricsSupport.modelGridToBodyRow(modelGridRow);
		int resizeModelBodyRow = getResizeModelBodyRow(selectedModelBodyRow, event.x, event.y);
		Rectangle resizeRowRect = natTable.getModelGridCellBound(metricsSupport.modelBodyToGridRow(resizeModelBodyRow), modelGridColumn);
		
		resizeData = new ResizeData(resizeModelBodyRow, resizeRowRect, event.y);
	}
	
	public void mouseMove(MouseEvent event) {
		natTable.getRowResizeSupport().resizeRow(resizeData.row, resizeData.rowHeaderCellRect, event.y - resizeData.startY);
	}

	public void mouseUp(MouseEvent event) {
		cleanup();
	}
	
	private int getResizeModelBodyRow(int selectedModelBodyRow, int x, int y) {
		if (selectedModelBodyRow >= 0) {
			switch (CellHandleUtil.getVerticalCellHandle(natTable, x, y, 4)) {
			case UP:
				if (selectedModelBodyRow == 0) {
					// can't resize top edge of first row
					break;
				}
				selectedModelBodyRow = selectedModelBodyRow - 1;
				// drop through to BOTTOM case
			case DOWN:
				if (natTable.getNatTableModel().isBodyRowResizable(selectedModelBodyRow)) {
					return selectedModelBodyRow;
				}
			}
		}
		
		return -1;
	}

	private void cleanup() {
		resizeData = null;
	}
	
	static class ResizeData {
		
		int row;
		
		Rectangle rowHeaderCellRect;
		
		int startY;
		
		public ResizeData(int row, Rectangle rowHeaderCellRect, int startY) {
			this.row = row;
			this.rowHeaderCellRect = rowHeaderCellRect;
			this.startY = startY;
		}
		
	}
	
}
