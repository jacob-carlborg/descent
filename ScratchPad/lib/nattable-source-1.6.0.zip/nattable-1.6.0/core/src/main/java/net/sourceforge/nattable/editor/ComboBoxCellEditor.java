package net.sourceforge.nattable.editor;

import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class ComboBoxCellEditor extends TextCellEditor {

	private Shell shell;

	private List list;
	
	@Override
	protected Control activateCell(Composite control, Rectangle rectangle, Object oldValue) {
		final int width = rectangle.width;
		rectangle.width = rectangle.width - GUIHelper.COMBO_BUTTON_WIDTH - 1;

		final Text text = (Text) super.activateCell(control, rectangle, oldValue);
		
		shell = new Shell(text.getShell(), SWT.NONE);
		shell.setLayout(new FillLayout());
		list = new List(shell, SWT.V_SCROLL | SWT.BORDER);
		list.setItems(getItems(oldValue));
		if (oldValue != null)
			list.setSelection(new String[] { oldValue.toString() });
		list.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (list.getSelectionCount() > 0) {
					text.setText(list.getSelection()[0]);
				}
			}

		});
		list.addKeyListener(new KeyAdapter() {

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.keyCode == SWT.CR && e.stateMask == 0) {
					commit();
				}
			}

		});

		Point point = text.toDisplay(0, 0);
		shell.setBounds(point.x, point.y + text.getSize().y, width, 100);
		shell.open();

		text.addDisposeListener(new DisposeListener() {

			public void widgetDisposed(DisposeEvent arg0) {
				close();
			}

		});
		
		return null;
	}
	
	@Override
	public void close() {
		super.close();
		shell.dispose();
	}

	@Override
	protected Text createTextControl(Composite control) {
		Text text = new Text(control, SWT.None) {
			/*
			 * (non-Javadoc)
			 * 
			 * @see org.eclipse.swt.widgets.Control#addFocusListener(org.eclipse.swt.events.FocusListener)
			 */
			@Override
			public void addFocusListener(final FocusListener listener) {
				super.addFocusListener(new FocusListener() {

					public void focusLost(final FocusEvent arg0) {
						// List.isFocusControl() must be called in asyn call
						Display.getDefault().asyncExec(new Runnable() {

							public void run() {
								if (list.isFocusControl()) {

								} else {
									listener.focusLost(arg0);
								}
							}

						});

					}

					public void focusGained(FocusEvent arg0) {
						listener.focusGained(arg0);
					}

				});
			}

			@Override
			protected void checkSubclass() {
			}

		};

		return text;
	}

	/**
	 * Override this method to return a list of items for combo
	 * 
	 * @param row
	 * @param col
	 * @param oldValue
	 * @return
	 */
	protected String[] getItems(Object oldValue) {
		return new String[] { oldValue.toString() };
	}
	
}
