package net.sourceforge.nattable.util;

import java.util.Collections;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import net.sourceforge.nattable.model.INatTableModel;

import org.apache.log4j.Logger;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��9��<br>
 */
public class RowHeightIndex {
	public static final Logger log = Logger.getLogger(RowHeightIndex.class);
	private INatTableModel model = null;
	// row , height
	private SortedMap<Integer, Integer> bodyRowHeightMap = Collections.synchronizedSortedMap(new TreeMap<Integer, Integer>());
	public static int BASE = 1000;

	private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

	public RowHeightIndex(INatTableModel model) {
		this.model = model;
	}

	public void refresh() {
		if (!model.isAllBodyRowsSameHeight()) {

			UpdateQueue.getInstance().addRunnable("RowHeightIndex" + model.getModelID(), new Runnable() {

				public void run() {
					update();
				}

			});

		}
	}

	/**
	 * package level to allow for direct updating from test code to remove complexity of cached refreshes
	 */
	void update() {
		lock.writeLock().lock();
		try {
			bodyRowHeightMap.clear();
			int currentHeight = 0;
			int bodyRowCount = model.getBodyRowCount();
			for (int row = 0; row < bodyRowCount; row++) {

				if (row % BASE == 0) {
					bodyRowHeightMap.put(Integer.valueOf(row), Integer.valueOf(currentHeight));
				}
				currentHeight += model.getBodyRowHeight(row);
			}
		} catch (Exception e) {
			log.error(e);
		} finally {
			lock.writeLock().unlock();
		}
	}

	public int getBestStartingSearchRow(int height) {
		lock.readLock().lock();
		try {
			if (!model.isAllBodyRowsSameHeight()) {
				// TODO improve performance
				Set<Integer> bodyRowIndexes = bodyRowHeightMap.keySet();
				Integer[] integerRowIndexes = bodyRowIndexes.toArray(new Integer[bodyRowIndexes.size()]);
				int bodyRowCount = bodyRowIndexes.size();
				for (int row = 0; row < bodyRowCount; row++) {
					Integer currentheight = bodyRowHeightMap.get(integerRowIndexes[row]);
					if (currentheight.intValue() > height) {
						return integerRowIndexes[row > 0 ? row - 1 : 0].intValue();
					}
				}
				
				if (integerRowIndexes.length > 0 &&
						bodyRowHeightMap.get(integerRowIndexes[integerRowIndexes.length - 1]).intValue() > 0)
					return integerRowIndexes[integerRowIndexes.length - 1].intValue();
				
			} else {
				if (model.getBodyRowCount() > 0) {
					int bodyRowHeight = model.getBodyRowHeight(0);
					if (bodyRowHeight > 0) {
						int row = (height / bodyRowHeight);
						return Math.min(row > 0 ? row : 0, model.getBodyRowCount() - 1);
					}
				}

			}
		} catch (Exception e) {
			log.error("Failed to find starting search row for height: " + height, e);
		} finally {
			lock.readLock().unlock();
		}
		return 0;
	}

	public int getHeightByStartIndex(int index) {
		lock.readLock().lock();
		try {
			if (!model.isAllBodyRowsSameHeight()) {
				if (bodyRowHeightMap.containsKey(Integer.valueOf(index))) {
					return bodyRowHeightMap.get(Integer.valueOf(index)).intValue();
				}
				
				int startIndex = index - (index % BASE);
				int height = 0;
				
				if (!bodyRowHeightMap.isEmpty()) {
					if (bodyRowHeightMap.containsKey(Integer.valueOf(startIndex))) {
						height = bodyRowHeightMap.get(Integer.valueOf(startIndex)).intValue();
					} else {
						Integer lastKey = bodyRowHeightMap.lastKey();
						if (bodyRowHeightMap.containsKey(lastKey)) {
							height = bodyRowHeightMap.get(lastKey).intValue();
							startIndex = lastKey.intValue();
						}
					}

					for (int i = startIndex; i < Math.min(index, model.getBodyRowCount()); i++) {
						height += model.getBodyRowHeight(i);
					}

					return height;
				}
			} else {
				int rowHeight = model.getBodyRowHeight(0);
				if (rowHeight > 0) {
					return index * rowHeight;
				}
			}
		} catch (Exception e) {
			log.error("Failed to get height for index: " + index, e);
		} finally {
			lock.readLock().unlock();
		}

		return 0;
	}

}
