package net.sourceforge.nattable.painter.cell;

import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~9��23��<br>
 */
public class HeaderCellPainter extends TextCellPainter {

	public HeaderCellPainter() {
	}

	/**
	 * It supports SWT.BORDER, SWT.FLAT and SWT.NONE(as Black Gradient)
	 * 
	 * @param style
	 */
	public HeaderCellPainter(int style) {
		this.style = style;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see net.sourceforge.nattable.painter.TextCellPainter#drawBackground(org.eclipse.swt.graphics.GC,
	 *      org.eclipse.swt.graphics.Rectangle)
	 */
	@Override
	public void drawBackground(GC gc, Rectangle rectangle) {
		Color orgFG = gc.getForeground();
		Color orgBG = gc.getBackground();

		if ((style & SWT.BORDER) == SWT.BORDER) {
			GUIHelper.drawBorder(gc, rectangle);

		} else if ((style & SWT.FLAT) == SWT.FLAT) {
			gc.setForeground(COLOR_BACKGROUND);
			gc.setBackground(GUIHelper.COLOR_WIDGET_LIGHT_SHADOW);
			gc.fillRectangle(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
		} else {

			gc.setForeground(getGradientForeground());
			gc.setBackground(getGradientBackground());
			gc.fillGradientRectangle(rectangle.x, rectangle.y, rectangle.width, rectangle.height, true);
		}
		gc.setForeground(orgFG);
		gc.setBackground(orgBG);
	}

	protected Color getGradientBackground() {
		return GUIHelper.COLOR_WIDGET_DARK_SHADOW;
	}

	protected Color getGradientForeground() {
		return COLOR_BACKGROUND;
	}

}
