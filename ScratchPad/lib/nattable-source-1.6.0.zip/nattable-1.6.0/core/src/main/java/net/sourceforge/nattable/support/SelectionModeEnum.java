package net.sourceforge.nattable.support;

public enum SelectionModeEnum {
	
	OFF,
	SINGLE,
	MULTI
	
}
