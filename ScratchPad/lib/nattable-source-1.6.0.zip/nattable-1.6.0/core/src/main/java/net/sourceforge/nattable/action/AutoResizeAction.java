package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.event.util.CellHandleUtil;
import net.sourceforge.nattable.model.INatTableModel;

import org.eclipse.swt.events.MouseEvent;

public class AutoResizeAction implements IMouseEventAction {

	private NatTable natTable;
	
	public AutoResizeAction(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void run(MouseEvent event) {
		// Auto fit column width
		int modelBodyColumn = natTable.getModelBodyColumnByX(event.x);
		
		switch (CellHandleUtil.getHorizontalCellHandle(natTable, event.x, event.y)) {
		case LEFT:
			modelBodyColumn = natTable.getPreviousAdjacentVisibleModelBodyColumn(modelBodyColumn);
			// drop through to RIGHT case
		case RIGHT:
			INatTableModel natTableModel = natTable.getNatTableModel();
			if (modelBodyColumn >= 0 && natTableModel.isBodyColumnResizable(modelBodyColumn)) {
				natTable.getColumnResizeSupport().resizeModelBodyColumnWidthByMaxText(natTableModel, modelBodyColumn);
			}
			break;
		}
		// mouseUp is called as a matter of course after mouseDoubleClick, which will switch back to normal mode
	}

}
