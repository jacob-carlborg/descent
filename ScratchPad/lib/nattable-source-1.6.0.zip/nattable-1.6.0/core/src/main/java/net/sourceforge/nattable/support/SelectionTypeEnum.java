package net.sourceforge.nattable.support;

public enum SelectionTypeEnum {

	OFF,
	ROW,
	CELL,
	COLUMN
	
}
