package net.sourceforge.nattable.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.painter.cell.HeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.painter.cell.TextCellPainter;
import net.sourceforge.nattable.renderer.ICellRenderer;

import org.apache.log4j.Logger;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007-9-23<br>
 */
public class GUIHelper {
	/**
	 * 
	 */
	public static final int COMBO_BUTTON_WIDTH = 20;
	public static final Logger log = Logger.getLogger(GUIHelper.class);
	public static final String EMPTY = "";
	public static final String DOT = "...";
	public static final Color COLOR_GRAY = Display.getDefault().getSystemColor(SWT.COLOR_GRAY);
	public static final Color COLOR_WHITE = Display.getDefault().getSystemColor(SWT.COLOR_WHITE);
	public static final Color COLOR_DARK_GRAY = Display.getDefault().getSystemColor(SWT.COLOR_DARK_GRAY);
	public static final Color COLOR_BLACK = Display.getDefault().getSystemColor(SWT.COLOR_BLACK);
	public static final Color COLOR_BLUE = Display.getDefault().getSystemColor(SWT.COLOR_BLUE);
	public static final Color COLOR_RED = Display.getDefault().getSystemColor(SWT.COLOR_RED);
	public static final Color COLOR_YELLOW = Display.getDefault().getSystemColor(SWT.COLOR_YELLOW);
	public static final Color COLOR_GREEN = Display.getDefault().getSystemColor(SWT.COLOR_GREEN);
	public static final Color COLOR_LIST_BACKGROUND = Display.getDefault().getSystemColor(SWT.COLOR_LIST_BACKGROUND);
	public static final Color COLOR_LIST_FOREGROUND = Display.getDefault().getSystemColor(SWT.COLOR_LIST_FOREGROUND);
	public static final Color COLOR_WIDGET_BACKGROUND = Display.getDefault()
			.getSystemColor(SWT.COLOR_WIDGET_BACKGROUND);
	public static final Color COLOR_WIDGET_FOREGROUND = Display.getDefault()
			.getSystemColor(SWT.COLOR_WIDGET_FOREGROUND);
	public static final Color COLOR_WIDGET_BORDER = Display.getDefault().getSystemColor(SWT.COLOR_WIDGET_BORDER);
	public static final Color COLOR_WIDGET_DARK_SHADOW = Display.getDefault().getSystemColor(
			SWT.COLOR_WIDGET_DARK_SHADOW);
	public static final Color COLOR_WIDGET_LIGHT_SHADOW = Display.getDefault().getSystemColor(
			SWT.COLOR_WIDGET_LIGHT_SHADOW);
	public static final Color COLOR_WIDGET_HIGHLIGHT_SHADOW = Display.getDefault().getSystemColor(
			SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW);
	public final static Pattern newLinePattern = Pattern.compile("\n");
	public static final Image UP_IMAGE = new Image(Display.getDefault(), GUIHelper.class.getClassLoader()
			.getResourceAsStream("up.gif"));
	public static final Image DOWN_IMAGE = new Image(Display.getDefault(), GUIHelper.class.getClassLoader()
			.getResourceAsStream("down.gif"));
	public static final Image LEFT_IMAGE = new Image(Display.getDefault(), GUIHelper.class.getClassLoader()
			.getResourceAsStream("left.gif"));
	public static final Image RIGHT_IMAGE = new Image(Display.getDefault(), GUIHelper.class.getClassLoader()
			.getResourceAsStream("right.gif"));
	public static AtomicLong atomicLong = new AtomicLong(0);

	public static String getSequenceNumber() {
		long id = atomicLong.addAndGet(1);
		return String.valueOf(id);
	}

	public static int getNumberOfNewLine0(String text) {
		String[] s = text.split("\n");
		return s.length;
	}

	public static int getNumberOfNewLine(String text) {
		char[] charArray = text.toCharArray();
		int lineCount = 1;
		for (char c : charArray) {
			if (c == '\n') {
				lineCount++;
			}
		}

		return lineCount;
	}

	public static String getAvailableTextToDisplay(GC gc, Rectangle rectangle, String text) {
		int width = gc.textExtent(text).x;
		boolean displayDot = width > rectangle.width;

		try {
			if (displayDot) {
				BufferedReader bufferedReader = new BufferedReader(new StringReader(text));
				StringBuffer output = new StringBuffer();
				String line = "";
				while ((line = bufferedReader.readLine()) != null) {
					width = gc.textExtent(line).x;
					if (width > rectangle.width) {
						int textLen = line.length();
						for (int i = textLen - 1; i >= 0; i--) {
							String temp = line.substring(0, i) + DOT;
							width = gc.textExtent(temp).x;
							if (width < rectangle.width) {
								line = temp;
								break;
							} else if (i == 0) {
								line = EMPTY;
							}
						}
					}
					output.append(line);
					output.append("\n");
				}
				text = output.toString();
			}
		} catch (IOException e) {
			log.error(e, e);
		}

		return text;
	}

	public static void drawColumnGroupBorder(GC gc, Rectangle rectangle, 
			boolean left, boolean right, boolean top, boolean bottom) {
		gc.setBackground(TextCellPainter.COLOR_BACKGROUND);
		gc.fillRectangle(rectangle);

		// Up
		gc.setForeground(TextCellPainter.COLOR_WIDGET_LIGHT_SHADOW);
		if (bottom)
			gc.drawLine(rectangle.x, rectangle.y, rectangle.x + rectangle.width - 1, rectangle.y);
		if (left)
			gc.drawLine(rectangle.x, rectangle.y, rectangle.x, rectangle.y + rectangle.height - 1);

		gc.setForeground(TextCellPainter.COLOR_WIDGET_HIGHLIGHT_SHADOW);
		if (bottom)
			gc.drawLine(rectangle.x + 1, rectangle.y + 1, rectangle.x + rectangle.width - 1, rectangle.y + 1);
		if (left)
			gc.drawLine(rectangle.x + 1, rectangle.y + 1, rectangle.x + 1, rectangle.y + rectangle.height - 1);

		// Down
		gc.setForeground(TextCellPainter.COLOR_WIDGET_DARK_SHADOW);
		if (top)
			gc.drawLine(rectangle.x, rectangle.y + rectangle.height - 1, rectangle.x + rectangle.width - 1, rectangle.y
					+ rectangle.height - 1);
		if (right)
		gc.drawLine(rectangle.x + rectangle.width - 1, rectangle.y, rectangle.x + rectangle.width - 1, rectangle.y
				+ rectangle.height - 1);

		gc.setForeground(TextCellPainter.COLOR_WIDGET_NORMAL_SHADOW);
		if (top)
			gc.drawLine(rectangle.x, rectangle.y + rectangle.height - 2, rectangle.x + rectangle.width - 1, rectangle.y
					+ rectangle.height - 2);
		if (right)
			gc.drawLine(rectangle.x + rectangle.width - 2, rectangle.y, rectangle.x + rectangle.width - 2, rectangle.y
					+ rectangle.height - 2);
	}

	public static void drawBorder(GC gc, Rectangle rectangle) {
		gc.setBackground(TextCellPainter.COLOR_BACKGROUND);
		gc.fillRectangle(rectangle);

		// Up
		gc.setForeground(TextCellPainter.COLOR_WIDGET_LIGHT_SHADOW);
		gc.drawLine(rectangle.x, rectangle.y, rectangle.x + rectangle.width - 1, rectangle.y);
		gc.drawLine(rectangle.x, rectangle.y, rectangle.x, rectangle.y + rectangle.height - 1);

		gc.setForeground(TextCellPainter.COLOR_WIDGET_HIGHLIGHT_SHADOW);
		gc.drawLine(rectangle.x + 1, rectangle.y + 1, rectangle.x + rectangle.width - 1, rectangle.y + 1);
		gc.drawLine(rectangle.x + 1, rectangle.y + 1, rectangle.x + 1, rectangle.y + rectangle.height - 1);

		// Down
		gc.setForeground(TextCellPainter.COLOR_WIDGET_DARK_SHADOW);
		gc.drawLine(rectangle.x, rectangle.y + rectangle.height - 1, rectangle.x + rectangle.width - 1, rectangle.y
				+ rectangle.height - 1);
		gc.drawLine(rectangle.x + rectangle.width - 1, rectangle.y, rectangle.x + rectangle.width - 1, rectangle.y
				+ rectangle.height - 1);

		gc.setForeground(TextCellPainter.COLOR_WIDGET_NORMAL_SHADOW);
		gc.drawLine(rectangle.x, rectangle.y + rectangle.height - 2, rectangle.x + rectangle.width - 1, rectangle.y
				+ rectangle.height - 2);
		gc.drawLine(rectangle.x + rectangle.width - 2, rectangle.y, rectangle.x + rectangle.width - 2, rectangle.y
				+ rectangle.height - 2);
	}

	public static void drawComboButton(GC gc, Rectangle rectangle, INatTableModel tableModel, int row, int col) {
		Rectangle rec = new Rectangle(rectangle.x + rectangle.width - COMBO_BUTTON_WIDTH - 1, rectangle.y,
				COMBO_BUTTON_WIDTH, rectangle.height);

		ICellRenderer columnHeaderRenderer = tableModel.getColumnHeaderCellRenderer();
		ICellPainter cellPainter = columnHeaderRenderer.getCellPainter(row, col);
		if (cellPainter instanceof HeaderCellPainter) {
			((HeaderCellPainter) cellPainter).drawBackground(gc, rec);
			gc.setForeground(GUIHelper.COLOR_DARK_GRAY);
			gc.drawRectangle(rec);
		} else {
			GUIHelper.drawBorder(gc, rec);
		}

		gc.drawImage(GUIHelper.DOWN_IMAGE, rectangle.x + rectangle.width - 18, rectangle.y + rectangle.height / 2
				- GUIHelper.DOWN_IMAGE.getBounds().height / 2 + 2);
	}
}
