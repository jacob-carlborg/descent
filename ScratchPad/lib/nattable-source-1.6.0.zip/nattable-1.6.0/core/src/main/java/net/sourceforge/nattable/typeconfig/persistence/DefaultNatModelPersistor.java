package net.sourceforge.nattable.typeconfig.persistence;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.model.DefaultNatTableModel;

public class DefaultNatModelPersistor extends AbstractPersistor {
	
	private static final long serialVersionUID = 1L;

	public static final String GRID_LINE_ENABLED = "gridLineEnabled";

	public static final String MOVABLE_COLS_ENABLED = "movableColumnsEnabled";

	public static final String CELL_SELECTION_ENABLED = "cellSelectionEnabled";

	public static final String MULTI_SELECTION_ENABLED = "multiSelectionEnabled";

	public static final String ROW_SELECTION_ENABLED = "rowSelectionEnabled";

	public static final String SORT_ENABLED = "sortEnabled";

	public static final String FREEZE_COLUMN_INDEX = "freezeColumn";

	public static final String FREEZE_ROW_INDEX = "freezeRow";

	public static final String ODD_ROW_COLOR = "oddRowRGBColor";

	public static final String EVEN_ROW_COLOR = "evenRowRGBColor";

	private DefaultNatTableModel natModel;
	
	private StoredInstance restoredInstance;

	public DefaultNatModelPersistor(DefaultNatTableModel natModel) {
		this.natModel = natModel;
	}

	public void load(InputStream source) {
		try {
			restoredInstance = ((DefaultNatModelPersistor)restore(source)).restoredInstance;
			restoreState(restoredInstance.restoredState);
			if(restoredInstance.restoredColumnSize != null) {
				((DefaultColumnHeaderConfig)natModel.getColumnHeaderConfig()).setColumnHeaderRowHeightConfig(restoredInstance.restoredColumnSize);
			}
			if(restoredInstance.restoredRowHeaderSize != null) {
				((DefaultRowHeaderConfig)natModel.getRowConfig()).setRowHeaderColumnWidthConfig(restoredInstance.restoredRowHeaderSize);
			}			
			if(restoredInstance.restoredBodyColSize != null) {
				((DefaultBodyConfig)natModel.getBodyConfig()).setColumnWidthConfig(restoredInstance.restoredBodyColSize);
				((DefaultBodyConfig)natModel.getBodyConfig()).setRowHeightConfig(restoredInstance.restoredBodyRowSize);
			}			
		}catch(IOException ioe) {
			throw new RuntimeException(ioe.getMessage());
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void save(OutputStream store) {
		try {
			store(store);
		}catch(IOException ioe) {
			throw new RuntimeException(ioe.getMessage());
		}
	}

	public String getFileName() {
		return this.getClass().getName() + ".store";
	}

	// Persistence
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		restoredInstance = (StoredInstance) stream.readObject();
	}

	private void restoreState(Map<String, String> states) {
		// set grid line enabled
		natModel.setGridLineEnabled(parseBoolean(states.get(GRID_LINE_ENABLED)));

		// set cell selection
		natModel.setSingleCellSelection(parseBoolean(states.get(CELL_SELECTION_ENABLED)));

		// set row selection
		natModel.setFullRowSelection(parseBoolean(states.get(ROW_SELECTION_ENABLED)));

		// set mutli-selection
		natModel.setMultipleSelection(parseBoolean(states.get(MULTI_SELECTION_ENABLED)));

		// set sort enabled
		natModel.setSortingEnabled(parseBoolean(states.get(SORT_ENABLED)));

		// set movable columns
		natModel.setEnableMoveColumn(parseBoolean(states.get(MOVABLE_COLS_ENABLED)));

		// set frozen rows and/or columns
		natModel.setFreezeColumnCount(parseInt(states.get(FREEZE_COLUMN_INDEX)));
		natModel.setFreezeRowCount(parseInt(states.get(FREEZE_ROW_INDEX)));
	}

	private boolean parseBoolean(String value) {
		return value != null ? Boolean.parseBoolean(value) : false;
	}

	private int parseInt(String value) {
		return value != null ? Integer.parseInt(value) : 0;
	}

	private void writeObject(ObjectOutputStream stream) throws IOException {
		Map<String, String> state = new HashMap<String, String>();
		state.put(GRID_LINE_ENABLED, String.valueOf(natModel.isGridLineEnabled()));
		state.put(MOVABLE_COLS_ENABLED, String.valueOf(natModel.isMoveColumnEnabled()));
		state.put(CELL_SELECTION_ENABLED, String.valueOf(natModel.isSingleCellSelection()));
		state.put(MULTI_SELECTION_ENABLED, String.valueOf(natModel.isMultpleSelection()));
		state.put(ROW_SELECTION_ENABLED, String.valueOf(natModel.isFullRowSelection()));
		state.put(SORT_ENABLED, String.valueOf(natModel.isSortingEnabled()));
		state.put(FREEZE_COLUMN_INDEX, String.valueOf(natModel.getFreezeColumnCount()));
		state.put(FREEZE_ROW_INDEX, String.valueOf(natModel.getFreezeRowCount()));
		
		restoredInstance = new StoredInstance();
		restoredInstance.restoredState = state;
		restoredInstance.restoredBodyColSize = natModel.getBodyConfig().getColumnWidthConfig();
		restoredInstance.restoredBodyRowSize = natModel.getBodyConfig().getRowHeightConfig();
		restoredInstance.restoredColumnSize = natModel.getColumnHeaderConfig().getColumnHeaderRowHeightConfig();
		restoredInstance.restoredRowHeaderSize = natModel.getRowConfig().getRowHeaderColumnWidthConfig();
		stream.writeObject(restoredInstance);
	}

	@SuppressWarnings("unused")
	private void readObjectNoData() throws ObjectStreamException {

		// load defaults when no data
		// set grid line enabled
		natModel.setGridLineEnabled(true);

		// set cell selection
		natModel.setSingleCellSelection(false);

		// set row selection
		natModel.setFullRowSelection(true);

		// set mutli-selection
		natModel.setMultipleSelection(true);

		// set sort enabled
		natModel.setSortingEnabled(false);

		// set movable columns
		natModel.setEnableMoveColumn(true);

		// set frozen rows and/or columns
		natModel.setFreezeColumnCount(0);
		natModel.setFreezeRowCount(0);
	}
	
	class StoredInstance implements Serializable{
		private static final long serialVersionUID = 1L;
		Map<String,String> restoredState;
		SizeConfig restoredColumnSize;
		SizeConfig restoredBodyColSize;
		SizeConfig restoredBodyRowSize;
		SizeConfig restoredRowHeaderSize;
	}
}
