package net.sourceforge.nattable.painter.cell;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.renderer.ICellRenderer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

/**
 * Author: Andy Tsoi<br>
 * Created Date : 2007�~9��23��
 */
public interface ICellPainter {
	public static Color COLOR_BACKGROUND = Display.getDefault().getSystemColor(SWT.COLOR_WIDGET_BACKGROUND);
	public static Color COLOR_LIST_SELECTION = Display.getDefault().getSystemColor(SWT.COLOR_LIST_SELECTION);
	public static Color COLOR_WIDGET_BORDER = Display.getDefault().getSystemColor(SWT.COLOR_WIDGET_BORDER);
	public static Color COLOR_WIDGET_DARK_SHADOW = Display.getDefault().getSystemColor(SWT.COLOR_WIDGET_DARK_SHADOW);
	public static Color COLOR_WIDGET_HIGHLIGHT_SHADOW = Display.getDefault().getSystemColor(
			SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW);
	public static Color COLOR_WIDGET_LIGHT_SHADOW = Display.getDefault().getSystemColor(SWT.COLOR_WIDGET_LIGHT_SHADOW);
	public static Color COLOR_WIDGET_NORMAL_SHADOW = Display.getDefault()
			.getSystemColor(SWT.COLOR_WIDGET_NORMAL_SHADOW);

	public static int SPACE = 2;

	public void drawCell(GC gc, Rectangle rectangle, NatTable natTable, ICellRenderer cellRenderer, int row, int col, boolean selected);
}
