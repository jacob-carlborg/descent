package net.sourceforge.nattable.typeconfig.content;


public class DefaultDisplayTypeConverter implements IDisplayTypeConverter {

	public String dataValueToDisplayValue(Object dataValue) {
		return dataValue == null ? "" : dataValue.toString();
	}

	public Object displayValueToDataValue(Object displayValue) {
		return displayValue == "" ? null : displayValue;
	}

}
