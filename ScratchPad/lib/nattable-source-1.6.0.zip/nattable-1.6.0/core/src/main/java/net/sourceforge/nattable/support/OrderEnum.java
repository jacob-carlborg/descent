package net.sourceforge.nattable.support;

public enum OrderEnum {

	FIRST,
	LAST
	
}
