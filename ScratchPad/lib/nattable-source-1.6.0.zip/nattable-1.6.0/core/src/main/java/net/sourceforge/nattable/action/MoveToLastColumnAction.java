package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.support.OrderEnum;

import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.graphics.Point;

public class MoveToLastColumnAction extends AbstractKeySelectAction {

	private NatTable natTable;
	
	public MoveToLastColumnAction(NatTable natTable, boolean withShiftMask) {
		super(natTable.getSelectionSupport(), withShiftMask, false);
		
		this.natTable = natTable;
	}
	
	public void run(KeyEvent event) {
		Point lastSelectedCell = natTable.getSelectionSupport().getLastSelectedCell();
		int bodyColumnCount = natTable.getNatTableModel().getBodyColumnCount();
		int bodyColumnIndex = bodyColumnCount - 1;
		int bodyRowIndex = lastSelectedCell.y;
		
		selectionSupport.setSelectedCell(bodyRowIndex, 
				natTable.viewableToModelBodyColumn(bodyColumnIndex), withShiftMask, withControlMask);
		natTable.showBodyColumn(bodyColumnIndex, OrderEnum.LAST);
	}

}
