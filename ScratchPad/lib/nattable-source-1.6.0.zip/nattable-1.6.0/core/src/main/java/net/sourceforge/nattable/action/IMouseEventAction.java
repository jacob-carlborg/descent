package net.sourceforge.nattable.action;

import org.eclipse.swt.events.MouseEvent;

public interface IMouseEventAction {

	public void run(MouseEvent event);
	
}
