package net.sourceforge.nattable.support;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

public class ColumnGroupSupport {

	private final Map<String, List<Integer>> columnGroupModelIndices = Collections
			.synchronizedMap(new HashMap<String, List<Integer>>());

	private final Map<Integer, String> modelColumnToGroupMap = Collections
			.synchronizedMap(new HashMap<Integer, String>());

	private Set<String> expandedColumnGroups = new HashSet<String>();

	private Logger log = Logger.getLogger(ColumnGroupSupport.class);

	private ColumnTransformSupport gridTransformSupport;

	private boolean enableColumnRemoval = true;

	private boolean enableReorderColumnGroup = true;

	private boolean enableAddColumns = true;

	public ColumnGroupSupport(ColumnTransformSupport gridTransformSupport) {
		this.gridTransformSupport = gridTransformSupport;
	}

	// Accessors //////////////////////////////////////////////////////////////

	public String getColumnGroupName(final int modelBodyColumn) {
		return modelColumnToGroupMap.get(Integer.valueOf(modelBodyColumn));
	}

	public boolean isColumnInColumnGroup(int modelBodyColumn) {
		return getColumnGroupName(modelBodyColumn) != null;
	}
	
	public List<Integer> getColumnGroupMembers(String columnGroup) {
		return columnGroupModelIndices.get(columnGroup);
	}
	
	public Map<String, List<Integer>> getColumnGroupModelIndices() {
		return columnGroupModelIndices;
	}
	
	public Set<String> getExpandedColumnGroups() {
		return expandedColumnGroups;
	}

	public Map<Integer, String> getModelColumnToGroupMap() {
		return modelColumnToGroupMap;
	}
	// Setup //////////////////////////////////////////////////////////////////

	public void addColumnGroup(final String columnGroup, final List<Integer> modelColumnIndices) {

		// make sure columns are positioned in the table next to each other.
		if (modelColumnIndices.size() == 0)
			throw new IllegalArgumentException("No columns in group.");

		Integer groupAnchorModelCol = modelColumnIndices.get(0);

		List<Integer> columnOrder = new ArrayList<Integer>();

		int[] cols = gridTransformSupport.getModelBodyColumnOrder();

		// reorder columns in group in case column has been inserted in middle
		// of group
		for (int i = 0; i < cols.length; i++) {
			Integer column = Integer.valueOf(cols[i]);
			if (column.compareTo(groupAnchorModelCol) == 0) {
				columnOrder.addAll(modelColumnIndices);
			} else if (!modelColumnIndices.contains(column)) {
				columnOrder.add(column);
			}
		}

		updateNatTableColumnOrder(columnOrder, cols);

		for (Integer modelIdx : modelColumnIndices) {
 			modelColumnToGroupMap.put(modelIdx, columnGroup);
		}

		columnGroupModelIndices.put(columnGroup, modelColumnIndices);
	}

	private void addColumnToGroup(String columnGroup, int fromModelBodyColumn, int toModelBodyColumn) {
		if (columnGroup == null) {
			return;
		}

		Integer modelBodyColumn = Integer.valueOf(fromModelBodyColumn);

		List<Integer> modelCols = columnGroupModelIndices.get(columnGroup);
		if (modelCols == null) {
			modelCols = new ArrayList<Integer>();
			columnGroupModelIndices.put(columnGroup, modelCols);
		}

		if (!modelCols.contains(modelBodyColumn))
			modelCols.add(modelBodyColumn);

		List<Integer> newModelCols = new ArrayList<Integer>();

		int[] cols = gridTransformSupport.getModelBodyColumnOrder();
		Integer currentModelBodyColumn;
		for (int i = 0; i < cols.length; i++) {
			currentModelBodyColumn = Integer.valueOf(cols[i]);
			if (modelCols.contains(currentModelBodyColumn)) {
				newModelCols.add(currentModelBodyColumn);
			}
		}

		if (!gridTransformSupport.isModelBodyColumnViewable(newModelCols.get(0).intValue())) {
			gridTransformSupport.showModelBodyColumn(newModelCols.get(0).intValue());
		}
		columnGroupModelIndices.put(columnGroup, newModelCols);

		modelColumnToGroupMap.put(modelBodyColumn, columnGroup);

		if (!isExpanded(columnGroup)) {
			collapseColumnGroup(columnGroup);
		}
	}

	private void removeColumnFromGroup(String columnGroup, int modelBodyColumnInt) {
		if (columnGroup == null) {
			return;
		}

		Integer modelBodyColumn = Integer.valueOf(modelBodyColumnInt);

		List<Integer> modelCols = columnGroupModelIndices.get(columnGroup);
		if (modelCols == null) {
			log.info("Removing col[" + modelBodyColumnInt + "] from missing column group[" + columnGroup + "]");
			return;
		}
		
		int newGroupAnchorListIndex = 1;
		if (modelCols.get(0).intValue() == modelBodyColumnInt 
			&& !isExpanded(columnGroup) 
			&& modelCols.size() > 1 
			&& !gridTransformSupport.isModelBodyColumnViewable(modelCols.get(newGroupAnchorListIndex).intValue())) {
			gridTransformSupport.showModelBodyColumn(modelCols.get(newGroupAnchorListIndex).intValue());
		}
		modelCols.remove(modelBodyColumn);

		
		modelColumnToGroupMap.remove(modelBodyColumn);
		
		if (modelCols.size() == 0)
			columnGroupModelIndices.remove(columnGroup);
	}

	private void updateNatTableColumnOrder(List<Integer> columnOrder, int[] cols) {
		for (int i = 0; i < cols.length; i++) {
			cols[i] = columnOrder.get(i).intValue();
			// log.info("cols[" + i + "] = " + cols[i]);
		}
		gridTransformSupport.setModelBodyColumnOrder(cols);
	}

	// Expand/Collapse ////////////////////////////////////////////////////////

	public boolean isExpanded(String columnGroup) {
		return expandedColumnGroups.contains(columnGroup);
	}

	public void setExpanded(boolean expand, String columnGroup) {
		if (expand && !isExpanded(columnGroup)) {
			expandColumnGroup(columnGroup);
		} else if (!expand) {
			collapseColumnGroup(columnGroup);
		}
	}

	public void toggleExpandColumnGroup(String columnGroup) {
		if (expandedColumnGroups.contains(columnGroup)) {
			collapseColumnGroup(columnGroup);
		} else {
			expandColumnGroup(columnGroup);
		}
	}

	public void expandColumnGroup(String columnGroup) {
		// Show all of the columns in the group
		showMembers(1, columnGroup);

		expandedColumnGroups.add(columnGroup);
	}

	private void collapseColumnGroup(String columnGroup) {
		// hide all, but the first, columns in the group
		hideMembers(1, columnGroup);

		expandedColumnGroups.remove(columnGroup);
	}

	private void hideMembers(int startIndex, String columnGroup) {
		List<Integer> groupMembers = columnGroupModelIndices.get(columnGroup);
		for (int i = startIndex; i < groupMembers.size(); i++) {
			gridTransformSupport.hideModelBodyColumn(groupMembers.get(i).intValue());
		}
	}

	private void showMembers(int startIndex, String columnGroup) {
		List<Integer> groupMembers = getColumnGroupMembers(columnGroup);
		for (int i = startIndex; i < groupMembers.size(); i++) {
			int groupMember = groupMembers.get(i).intValue();
			if (!gridTransformSupport.isModelBodyColumnViewable(groupMember)) {
				gridTransformSupport.showModelBodyColumn(groupMember);
			}
		}
	}

	public void showColumnGroup(final String columnGroup) {
		List<Integer> groupMembers = getColumnGroupMembers(columnGroup);
		if (isExpanded(columnGroup)) {
			showMembers(0, columnGroup);
		} else {
			gridTransformSupport.showModelBodyColumn(groupMembers.get(0).intValue());
		}
	}

	public void hideColumnGroup(final String columnGroup) {
		hideMembers(0, columnGroup);
	}

	// Rendering //////////////////////////////////////////////////////////////

	public void reorderModelBodyColumn(int fromModelBodyColumn, int toModelBodyColumn) {
		if (isColumnDragOperationSupported(fromModelBodyColumn, toModelBodyColumn)) {
			String fromColumnGroup = getColumnGroupName(fromModelBodyColumn);
			String toColumnGroup = getColumnGroupName(toModelBodyColumn);

			gridTransformSupport.reorderModelBodyColumn(fromModelBodyColumn, toModelBodyColumn);

			if (fromColumnGroup != null || toColumnGroup != null) {
				moveColumnBetweenGroups(fromColumnGroup, fromModelBodyColumn, toColumnGroup, toModelBodyColumn);
			}
		}
	}

	public void moveColumnBetweenGroups(String fromColumnGroup, int fromModelBodyColumn, String toColumnGroup,
			int toModelBodyColumn) {
		if (fromColumnGroup != null && !fromColumnGroup.equals(toColumnGroup)) {
			removeColumnFromGroup(fromColumnGroup, fromModelBodyColumn);
		}
		if (toColumnGroup != null) {
			addColumnToGroup(toColumnGroup, fromModelBodyColumn, toModelBodyColumn);
		}
	}

	// Configuration//// ////////////////////////////////////////////////////////////

	public boolean isEnableColumnRemoval() {
		return enableColumnRemoval;
	}

	public void setEnableColumnRemoval(boolean enableColumnRemoval) {
		this.enableColumnRemoval = enableColumnRemoval;
	}

	public boolean isEnableReorderColumnGroup() {
		return enableReorderColumnGroup;
	}

	public void setEnableReorderColumnGroup(boolean enableReorderColumnGroup) {
		this.enableReorderColumnGroup = enableReorderColumnGroup;
	}

	public boolean isEnableAddColumns() {
		return enableAddColumns;
	}

	public void setEnableAddColumns(boolean enableAddColumns) {
		this.enableAddColumns = enableAddColumns;
	}

	private boolean isDragToOperationSupported(int dragFromModelBodyColumn, int dragToModelBodyColumn) {
		String toGroupName = getColumnGroupName(dragToModelBodyColumn);
		String fromGroupName = getColumnGroupName(dragFromModelBodyColumn);
		
		if (isColumnInColumnGroup(dragToModelBodyColumn) && !isEnableAddColumns() && !toGroupName.equals(fromGroupName)) {
			return false;
		}
		return true;
	}

	private boolean isDragFromOperationSupported(int dragFromModelBodyColumn, int dragToModelBodyColumn) {
		String toGroupName = getColumnGroupName(dragToModelBodyColumn);
		String fromGroupName = getColumnGroupName(dragFromModelBodyColumn);
		
		if (isColumnInColumnGroup(dragFromModelBodyColumn) && !isEnableColumnRemoval() && !fromGroupName.equals(toGroupName)) {
			return false;
		}

		return true;
	}

	private boolean columnGroupReorderCheck(int dragFromModelBodyColumn, int dragToModelBodyColumn) {
		String toGroupName = getColumnGroupName(dragToModelBodyColumn);
		String fromGroupName = getColumnGroupName(dragFromModelBodyColumn);
		
		if (!isEnableReorderColumnGroup() && isColumnInColumnGroup(dragToModelBodyColumn) && isColumnInColumnGroup(dragFromModelBodyColumn)
				&& toGroupName.equals(fromGroupName)) {
			return false;
		}
		return true;
	}

	public boolean isColumnDragOperationSupported(int dragFromModelBodyColumn, int dragToModelBodyColumn) {
		if (!isDragFromOperationSupported(dragFromModelBodyColumn, dragToModelBodyColumn)) {
			return false;
		}
		if (!isDragToOperationSupported(dragFromModelBodyColumn, dragToModelBodyColumn)) {
			return false;
		}
		if (!columnGroupReorderCheck(dragFromModelBodyColumn, dragToModelBodyColumn)) {
			return false;
		}
		return true;
	}
}