package net.sourceforge.nattable.model;

import net.sourceforge.nattable.action.ColumnSelectionBehaviorEnum;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultCornerConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.IBodyConfig;
import net.sourceforge.nattable.config.IColumnHeaderConfig;
import net.sourceforge.nattable.config.ICornerConfig;
import net.sourceforge.nattable.config.IRowHeaderConfig;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;
import net.sourceforge.nattable.util.GUIHelper;

public class DefaultNatTableModel implements INatTableModel {
	
	private ContentConfigRegistry contentConfigRegistry;
	
	private StyleConfigRegistry styleConfigRegistry;

	protected int freezeRow = 0;
	
	protected int freezeCol = 0;
	
	protected String id = GUIHelper.getSequenceNumber();

	public DefaultNatTableModel() {
		// default constructor. no-op
	}
	
	/**
	 * Constructor for table configuration (column header and body region only).
	 * @param columnHeaderConfig
	 * @param bodyConfig
	 */
	public DefaultNatTableModel(
			IColumnHeaderConfig columnHeaderConfig,
			IBodyConfig bodyConfig
	) {
		this(null, null, null, columnHeaderConfig, null, bodyConfig);
	}

	public DefaultNatTableModel(
			ICornerConfig cornerConfig,
			IColumnHeaderConfig columnHeaderConfig,
			IRowHeaderConfig rowHeaderConfig,
			IBodyConfig bodyConfig
	) {
		this(null, null, cornerConfig, columnHeaderConfig, rowHeaderConfig, bodyConfig);
	}
	
	public DefaultNatTableModel(
			ContentConfigRegistry contentConfigRegistry,
			StyleConfigRegistry styleConfigRegistry,
			IColumnHeaderConfig columnHeaderConfig,
			IBodyConfig bodyConfig
	) {
		this(contentConfigRegistry, styleConfigRegistry, null, columnHeaderConfig, null, bodyConfig);
	}

	public DefaultNatTableModel(
			ContentConfigRegistry contentConfigRegistry,
			StyleConfigRegistry styleConfigRegistry,
			ICornerConfig cornerConfig,
			IColumnHeaderConfig columnHeaderConfig,
			IRowHeaderConfig rowHeaderConfig,
			IBodyConfig bodyConfig
	) {
		this.contentConfigRegistry = contentConfigRegistry;
		this.styleConfigRegistry = styleConfigRegistry;
		this.cornerConfig = cornerConfig;
		this.columnHeaderConfig = columnHeaderConfig;
		this.rowHeaderConfig = rowHeaderConfig;
		this.bodyConfig = bodyConfig;
	}

	public String getModelID() {
		return id;
	}
	
	// Config registries //////////////////////////////////////////////////////
	
	/**
	 * Use this method if you want to modify the current active content registry.
	 * @return
	 */
	public ContentConfigRegistry getContentConfigRegistry() {
		if(contentConfigRegistry == null) {
			contentConfigRegistry = new ContentConfigRegistry();
		}
		return contentConfigRegistry;
	}
	
	public void setContentConfigRegistry(ContentConfigRegistry contentConfigRegistry) {
		this.contentConfigRegistry = contentConfigRegistry;
	}
	/**
	 * Use this method if you want to modify the current active style registry.
	 * @return
	 */
	public StyleConfigRegistry getStyleConfigRegistry() {
		if(styleConfigRegistry == null) {
			styleConfigRegistry = new StyleConfigRegistry();
		}
		return styleConfigRegistry;
	}

	public void setStyleConfigRegistry(StyleConfigRegistry styleConfigRegistry) {
		this.styleConfigRegistry = styleConfigRegistry;
	}
	// Corner /////////////////////////////////////////////////////////////////

	private ICornerConfig cornerConfig;
	
	public ICornerConfig getCornerConfig() {
		if (cornerConfig == null) {
			cornerConfig = new DefaultCornerConfig();
		}
		return cornerConfig;
	}
	
	public void setCornerConfig(ICornerConfig cornerConfig) {
		this.cornerConfig = cornerConfig;
	}
	
	public ICellRenderer getCornerCellRenderer() {
		return getCornerConfig().getCellRenderer();
	}

	// Column header //////////////////////////////////////////////////////////

	private IColumnHeaderConfig columnHeaderConfig;

	public IColumnHeaderConfig getColumnHeaderConfig() {
		if (columnHeaderConfig == null) {
			columnHeaderConfig = new DefaultColumnHeaderConfig(
					new IColumnHeaderLabelProvider() {

						public String getColumnHeaderLabel(int col) {
							return "Col " + col;
						}
						
					}
			);
		}
		return columnHeaderConfig;
	}

	public void setColumnHeaderConfig(IColumnHeaderConfig columnConfig) {
		this.columnHeaderConfig = columnConfig;
	}

	public ICellRenderer getColumnHeaderCellRenderer() {
		return getColumnHeaderConfig().getCellRenderer();
	}

	public int getColumnHeaderRowCount() {
		return getColumnHeaderConfig().getColumnHeaderRowCount();
	}

	public int getColumnHeaderRowHeight(int row) {
		return getColumnHeaderConfig().getColumnHeaderRowHeightConfig().getSize(row);
	}

	// Row header /////////////////////////////////////////////////////////////

	private IRowHeaderConfig rowHeaderConfig;

	public IRowHeaderConfig getRowConfig() {
		if (rowHeaderConfig == null) {
			rowHeaderConfig = new DefaultRowHeaderConfig();
		}
		return rowHeaderConfig;
	}

	public void setRowHeaderConfig(IRowHeaderConfig rowConfig) {
		this.rowHeaderConfig = rowConfig;
	}
	
	public ICellRenderer getRowHeaderCellRenderer() {
		return getRowConfig().getCellRenderer();
	}

	public int getRowHeaderColumnCount() {
		return getRowConfig().getRowHeaderColumnCount();
	}
	
	public int getRowHeaderColumnWidth(int col) {
		return getRowConfig().getRowHeaderColumnWidthConfig().getSize(col);
	}

	// Body ///////////////////////////////////////////////////////////////////

	private IBodyConfig bodyConfig;

	public IBodyConfig getBodyConfig() {
		if (bodyConfig == null) {
			bodyConfig = new DefaultBodyConfig(new IDataProvider() {
				
				public int getColumnCount() {
					return 3;
				}

				public int getRowCount() {
					return 3;
				}

				public Object getValue(int row, int col) {
					return "Row " + row + ", Col " + col;
				}

			});
		}
		return bodyConfig;
	}

	public void setBodyConfig(IBodyConfig bodyConfig) {
		this.bodyConfig = bodyConfig;
	}

	public ICellRenderer getBodyCellRenderer() {
		return getBodyConfig().getCellRenderer();
	}

	// Column -----------------------------------------------------------------

	public int getBodyColumnCount() {
		return getBodyConfig().getColumnCount();
	}

	public int getInitialBodyColumnWidth(int col) {
		return getBodyConfig().getColumnWidthConfig().getInitialSize(col);
	}

	public int getBodyColumnWidth(int col) {
		return getBodyConfig().getColumnWidthConfig().getSize(col);
	}

	public void setBodyColumnWidth(int col, int width) {
		getBodyConfig().getColumnWidthConfig().setSize(col, width);
	}

	public boolean isBodyColumnResizable(int col) {
		return getBodyConfig().getColumnWidthConfig().isIndexResizable(col);
	}

	// Row --------------------------------------------------------------------

	public int getBodyRowCount() {
		return getBodyConfig().getRowCount();
	}

	public int getInitialBodyRowHeight(int row) {
		return getBodyConfig().getRowHeightConfig().getInitialSize(row);
	}

	public int getBodyRowHeight(int row) {
		return getBodyConfig().getRowHeightConfig().getSize(row);
	}

	public void setBodyRowHeight(int row, int height) {
		getBodyConfig().getRowHeightConfig().setSize(row, height);
	}

	public boolean isAllBodyRowsSameHeight() {
		return getBodyConfig().getRowHeightConfig().isAllIndexesSameSize();
	}

	public boolean isBodyRowResizable(int row) {
		return getBodyConfig().getRowHeightConfig().isIndexResizable(row);
	}

	// Table configuration ////////////////////////////////////////////////////

	private boolean enableMoveColumn;

	public boolean isMoveColumnEnabled() {
		return enableMoveColumn;
	}

	public void setEnableMoveColumn(boolean enableMoveColumn) {
		this.enableMoveColumn = enableMoveColumn;
	}

	private boolean gridLinesEnabled = true;

	public boolean isGridLineEnabled() {
		return gridLinesEnabled;
	}

	public void setGridLineEnabled(boolean enable) {
		gridLinesEnabled = enable;
	}

	private boolean sortingEnabled;

	public boolean isSortingEnabled() {
		return sortingEnabled;
	}

	public void setSortingEnabled(boolean enable) {
		sortingEnabled = enable;
	}

	// Selection //////////////////////////////////////////////////////////////

	private boolean fullRowSelection;

	public boolean isFullRowSelection() {
		return fullRowSelection;
	}

	public void setFullRowSelection(boolean fullRowSelection) {
		this.fullRowSelection = fullRowSelection;
	}

	private boolean singleCellSelection;

	public boolean isSingleCellSelection() {
		return singleCellSelection;
	}

	public void setSingleCellSelection(boolean singleCellSelection) {
		this.singleCellSelection = singleCellSelection;
	}

	private boolean multipleSelection;
	public boolean isMultpleSelection() {
		return multipleSelection;
	}

	public void setMultipleSelection(boolean multipleSelection) {
		this.multipleSelection = multipleSelection;
	}
	
	// Freeze column/row

	public void setFreezeColumnCount(int col) {
		freezeCol = col;
	}

	public void setFreezeRowCount(int row) {
		freezeRow = row;
	}

	public int getFreezeColumnCount() {
		return freezeCol;
	}

	public int getFreezeRowCount() {
		return freezeRow;
	}

	private ColumnSelectionBehaviorEnum columnSelectionBehavior = ColumnSelectionBehaviorEnum.NO_SELECTION_SINGLE_CLICK_SORTING;
	
	public ColumnSelectionBehaviorEnum getColumnSelectionBehavior() {
		return columnSelectionBehavior;
	}
	
	public void setColumnSelectionBehavior(
			ColumnSelectionBehaviorEnum columnSelectionBehavior) {
		this.columnSelectionBehavior = columnSelectionBehavior;
	}
}
