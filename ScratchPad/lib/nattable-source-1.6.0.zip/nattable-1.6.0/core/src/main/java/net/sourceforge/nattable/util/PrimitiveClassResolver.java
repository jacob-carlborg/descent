package net.sourceforge.nattable.util;

public class PrimitiveClassResolver {
	public static Class<?> checkClassForPrimitives(Class<?> target) {
		Class<?> prim = null;
		if (!target.isPrimitive() && !target.equals(String.class)) {
			if (target.equals(Double.class)) {
				prim = double.class;
			} else if (target.equals(Integer.class)) {
				prim = int.class;
			} else if (target.equals(Long.class)) {
				prim = long.class;
			} else if (target.equals(Float.class)) {
				prim = float.class;
			} else if (target.equals(Boolean.class)) {
				prim = boolean.class;
			} else if (target.equals(Short.class)) {
				prim = short.class;
			} else if (target.equals(Byte.class)) {
				prim = byte.class;
			} else if (target.equals(Character.class)) {
				prim = char.class;
			} else {
				prim = target;
			}
		} else {
			return target;
		}
		return prim;
	}
}
