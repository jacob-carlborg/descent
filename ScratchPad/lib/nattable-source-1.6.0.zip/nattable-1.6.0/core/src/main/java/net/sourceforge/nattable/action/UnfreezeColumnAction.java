package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class UnfreezeColumnAction extends SelectionAdapter {

	private final NatTable table;

	public UnfreezeColumnAction(NatTable table) {
		this.table = table;
	}
	
	@Override
	public void widgetSelected(SelectionEvent e) {
		table.getNatTableModel().setFreezeColumnCount(0);
		table.reset();
		table.updateResize(true);
	}
	
}
