package net.sourceforge.nattable.typeconfig.content;

public class DefaultEditableRule implements IEditableRule {

	private boolean defaultEditable;
	
	public DefaultEditableRule(boolean defaultEditable) {
		this.defaultEditable = defaultEditable;
	}
	
	public boolean isEditable(int row, int col) {
		return defaultEditable;
	}

}
