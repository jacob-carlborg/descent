package net.sourceforge.nattable.typeconfig.content;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.data.IDataValidator;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.typeconfig.AbstractConfigRegistry;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;

public class ContentConfigRegistry extends AbstractConfigRegistry {

	public ContentConfigRegistry() {
	}
	
	public ContentConfigRegistry(IConfigTypeResolver contentConfigTypeResolver) {
		super(contentConfigTypeResolver);
	}
	
	// Comparator /////////////////////////////////////////////////////////////

	private Map<Integer, Comparator<?>> comparatorMap = new HashMap<Integer, Comparator<?>>();

	public Comparator<?> getComparator(int col) {
		Comparator<?> comparator = comparatorMap.get(Integer.valueOf(col));
		if (comparator == null) {
			comparator = DefaultComparator.getInstance();
		}
		return comparator;
	}

	public void registerComparator(int col, Comparator<?> comparator) {
		comparatorMap.put(Integer.valueOf(col), comparator);
	}

	public void unregisterComparator(int col) {
		comparatorMap.remove(Integer.valueOf(col));
	}
	
	public Map<Integer, Comparator<?>> getComparatorRegistry() {
		return comparatorMap;
	}

	// CellEditors ////////////////////////////////////////////////////////////
	
	private ICellEditor defaultCellEditor;
	
	private Map<String, ICellEditor> cellEditorMap = new HashMap<String, ICellEditor>();
	
	public ICellEditor getCellEditor(int modelBodyRow, int modelBodyColumn) {
		return (ICellEditor) getConfigTypeAttribute(modelBodyRow, modelBodyColumn, cellEditorMap, defaultCellEditor);
	}
	
	public ICellEditor getCellEditor(String configType) {
		return (ICellEditor) getConfigTypeAttribute(configType, cellEditorMap, null);
	}
	
	public void registerDefaultCellEditor(ICellEditor defaultCellEditor) {
		this.defaultCellEditor = defaultCellEditor;
	}
	
	public void registerCellEditor(String configType, ICellEditor cellEditor) {
		cellEditorMap.put(configType, cellEditor);
	}
	
	public void removeCellEditor(String configType) {
		cellEditorMap.remove(configType);
	}
	
	// Validators //////////////////////////////////////////////////////////////
	
	private IDataValidator defaultDataValidator;
	
	private Map<String, IDataValidator> dataValidatorMap = new HashMap<String, IDataValidator>();
	
	public IDataValidator getDataValidator(int modelBodyRow, int modelBodyColumn) {
		return (IDataValidator) getConfigTypeAttribute(modelBodyRow, modelBodyColumn, dataValidatorMap, defaultDataValidator);
	}
	
	public IDataValidator getDataValidator(String configType) {
		return (IDataValidator) getConfigTypeAttribute(configType, dataValidatorMap, null);
	}
	
	public void registerDefaultDataValidator(IDataValidator defaultDataValidator) {
		this.defaultDataValidator = defaultDataValidator;
	}
	
	/**
	 * Validators must be registered in correct column sequence to use with the getValidator method.
	 * @param configType
	 * @param validator
	 */
	public void registerValidator(String configType, IDataValidator validator) {
		dataValidatorMap.put(configType, validator);
	}
	
	public void removeValidator(String configType) {
		dataValidatorMap.remove(configType);
	}
	
	public Map<String, IDataValidator> getValidatorRegistry() {
		return dataValidatorMap;
	}
	
	// Editable rules /////////////////////////////////////////////////////////
	private IEditableRule defaultEditableRule;
	
	private Map<String, IEditableRule> editableRuleMap = new HashMap<String, IEditableRule>();

	public IEditableRule getEditableRule(int modelBodyRow, int modelBodyColumn) {
		return (IEditableRule) getConfigTypeAttribute(modelBodyRow, modelBodyColumn, editableRuleMap, defaultEditableRule);
	}

	public IEditableRule getEditableRule(String configType) {
		return (IEditableRule) getConfigTypeAttribute(configType, editableRuleMap, null);
	}
	
	public void registerDefaultEditableRule(IEditableRule defaultEditableRule) {
		this.defaultEditableRule = defaultEditableRule;
	}

	public void registerEditableRule(String configType, IEditableRule rule) {
		editableRuleMap.put(configType, rule);
	}

	public void removeEditableRule(String configType) {
		editableRuleMap.remove(configType);
	}
	
	public Map<String, IEditableRule> getEditableRulesRegistry() {
		return editableRuleMap;
	}

	// Display type converter /////////////////////////////////////////////////

	private IDisplayTypeConverter defaultDisplayTypeConverter = new DefaultDisplayTypeConverter();

	private Map<String, IDisplayTypeConverter> displayTypeConverterMap = new HashMap<String, IDisplayTypeConverter>();

	public IDisplayTypeConverter getDisplayTypeConverter(int modelBodyRow, int modelBodyColumn) {
		return (IDisplayTypeConverter) getConfigTypeAttribute(modelBodyRow, modelBodyColumn, displayTypeConverterMap, defaultDisplayTypeConverter);
	}
	
	public IDisplayTypeConverter getDisplayTypeConverter(String configType) {
		return (IDisplayTypeConverter) getConfigTypeAttribute(configType, displayTypeConverterMap, defaultDisplayTypeConverter);
	}
	
	public void registerDefaultDisplayTypeConverter(IDisplayTypeConverter defaultDisplayTypeConverter) {
		this.defaultDisplayTypeConverter = defaultDisplayTypeConverter;
	}

	public void registerDisplayTypeConverter(String configType, IDisplayTypeConverter displayTypeConverter) {
		displayTypeConverterMap.put(configType, displayTypeConverter);
	}

	public void unregisterDisplayTypeConverter(String configType) {
		displayTypeConverterMap.remove(configType);
	}

	private Object getConfigTypeAttribute(int modelBodyRow, int modelBodyColumn, Map<String, ?> typeConfigMap, Object defaultAttribute) {
		return getConfigTypeAttribute(getConfigType(modelBodyRow, modelBodyColumn), typeConfigMap, defaultAttribute);
	}
	
	private Object getConfigTypeAttribute(String targetConfigType, Map<String, ?> typeConfigMap, Object defaultAttribute) {
		String configType = targetConfigType;
		while (configType != null) {
			Object attribute = typeConfigMap.get(configType);
			if (attribute != null) {
				return attribute;
			}
			// look for attributes registered under supertype of configType
			configType = getSuperType(configType);
		}
		// if no attribute is found use the default
		return defaultAttribute;
	}

	public Map<String, IDisplayTypeConverter> getDisplayTypeConverterRegistry() {
		return displayTypeConverterMap;
	}
}
