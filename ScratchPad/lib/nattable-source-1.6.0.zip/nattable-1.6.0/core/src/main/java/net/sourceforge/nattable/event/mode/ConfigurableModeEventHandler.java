package net.sourceforge.nattable.event.mode;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.IKeyEventAction;
import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.event.drag.IDragMode;
import net.sourceforge.nattable.listener.NatEventData;
import net.sourceforge.nattable.support.EventBindingSupport;

import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseEvent;

public class ConfigurableModeEventHandler extends AbstractModeEventHandler {

	private NatTable natTable;
	
	private EventBindingSupport eventBindingSupport;
	
	public ConfigurableModeEventHandler(NatTable natTable) {
		super(natTable.getModeSupport());
		
		this.natTable = natTable;
		this.eventBindingSupport = natTable.getEventBindingSupport();
	}
	
	// Event handling /////////////////////////////////////////////////////////
	
	@Override
	public void keyPressed(KeyEvent event) {
		IKeyEventAction keyAction = eventBindingSupport.getKeyEventAction(event);
		if (keyAction != null) {
			natTable.forceFocus();
			keyAction.run(event);
		}
	}
	
	@Override
	public void mouseDown(MouseEvent event) {
		IMouseEventAction mouseDownAction = eventBindingSupport.getMouseDownAction(event);
		if (mouseDownAction != null) {
			event.data = NatEventData.createInstanceFromEvent(event);
			mouseDownAction.run(event);
		}
		
		IMouseEventAction singleClickAction = eventBindingSupport.getSingleClickAction(event);
		IMouseEventAction doubleClickAction = eventBindingSupport.getDoubleClickAction(event);
		IDragMode dragMode = eventBindingSupport.getDragMode(event);
		
		if (singleClickAction != null || doubleClickAction != null || dragMode != null) {
			switchMode(new MouseModeEventHandler(natTable.getModeSupport(), event, singleClickAction, doubleClickAction, dragMode));
		}
	}

	@Override
	public synchronized void mouseMove(MouseEvent event) {
		IMouseEventAction mouseMoveAction = eventBindingSupport.getMouseMoveAction(event);
		if (mouseMoveAction != null) {
			event.data = NatEventData.createInstanceFromEvent(event);
			mouseMoveAction.run(event);
		}
	}

}
