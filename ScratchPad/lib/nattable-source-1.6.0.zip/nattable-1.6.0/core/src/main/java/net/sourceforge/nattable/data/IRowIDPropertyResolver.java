package net.sourceforge.nattable.data;

import java.io.Serializable;
import java.util.Map;

public interface IRowIDPropertyResolver {
	
	public Serializable resolveRowIdProperty(Map<String, Object> propertyToValue);
	
}