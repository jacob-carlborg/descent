package net.sourceforge.nattable.editor;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

public interface ICellEditor {
	
	public Control activateCell(IEditController editController, Composite parent, Rectangle rectangle, Object oldValue);

	public void close();
	
	public void setSelectionMode(EditorSelectionEnum selectionMode);
	
	public EditorSelectionEnum getSelectionMode();

	public void commit();
}
