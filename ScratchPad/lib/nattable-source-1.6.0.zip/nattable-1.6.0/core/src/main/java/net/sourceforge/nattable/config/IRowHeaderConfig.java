package net.sourceforge.nattable.config;

public interface IRowHeaderConfig extends IRegionConfig {

	public int getRowHeaderColumnCount();
	
	public SizeConfig getRowHeaderColumnWidthConfig();

}
