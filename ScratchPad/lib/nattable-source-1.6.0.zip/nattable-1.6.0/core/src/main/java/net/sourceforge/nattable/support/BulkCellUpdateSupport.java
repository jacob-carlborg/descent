package net.sourceforge.nattable.support;

import java.io.Serializable;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.renderer.ICellRenderer;

public class BulkCellUpdateSupport <T> {

	private final NatTable table;
	private final ISelectionValidator validator;
	private final IRowIdAccessor<T> rowIdAccessor;
	private final IRowDataProvider<T> dataProvider;

	public BulkCellUpdateSupport(NatTable table, IRowDataProvider<T> dataProvider, IRowIdAccessor<T> rowIdAccessor) {
		this(table, dataProvider, rowIdAccessor, new BulkUpdateSelectionValidator(table));
	}
	
	public BulkCellUpdateSupport(NatTable table,
			IRowDataProvider<T> dataProvider, IRowIdAccessor<T> rowIdAccessor,
			ISelectionValidator validator) {
				this.table = table;
				this.dataProvider = dataProvider;
				this.validator = validator;
				this.rowIdAccessor = rowIdAccessor;
	}

	public boolean bulkUpdateSelection(IBulkUpdateRequestHandler requestHandler,
			IBulkUpdateResponseHandler responseHandler) {
		if (isSelectionValid()) {
			SelectionModel selectionModel = table.getSelectionModel();
			
			int[] columns = selectionModel.getSelectedColumns();
			int[] rows = selectionModel.getSelectedRows();
			
			Serializable [] rowIds = new Serializable[rows.length];
			
			for (int i = 0; i < rows.length; i++) {
				T rowObject = dataProvider.getRowObject(rows[i]);
				rowIds[i] = rowIdAccessor.getRowId(rowObject);
			}
			
			INatTableModel natTableModel = table.getNatTableModel();
			ICellRenderer bodyCellRenderer = natTableModel.getBodyCellRenderer();
			int column = table.reorderedToModelBodyColumn(columns[0]);
			
			String fieldName = natTableModel.getColumnHeaderCellRenderer().getDisplayText(0, column);
			
			BulkUpdateResponse response = requestHandler.bulkUpdate(fieldName, bodyCellRenderer, rows[0], column);
			
			if (response != null) {
				int fieldIndex = column;
				return responseHandler.applyBulkUpdate(response, rowIds, fieldIndex);
			}
		}
		
		return false;
	}

	public boolean isSelectionValid() {
		return validator.isSelectionValid();
	}
}
