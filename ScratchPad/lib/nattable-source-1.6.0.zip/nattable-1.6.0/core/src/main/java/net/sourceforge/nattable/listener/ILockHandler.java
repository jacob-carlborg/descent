package net.sourceforge.nattable.listener;

public interface ILockHandler {

	public void lockReadOperation();

	public void lockWriteOperation();

	public void unlockReadOperation();

	public void unlockWriteOperation();

}
