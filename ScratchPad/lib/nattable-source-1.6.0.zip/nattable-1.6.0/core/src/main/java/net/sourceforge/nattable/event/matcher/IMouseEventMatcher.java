package net.sourceforge.nattable.event.matcher;

import org.eclipse.swt.events.MouseEvent;

public interface IMouseEventMatcher {

	public boolean matches(MouseEvent event, String eventRegion);

}
