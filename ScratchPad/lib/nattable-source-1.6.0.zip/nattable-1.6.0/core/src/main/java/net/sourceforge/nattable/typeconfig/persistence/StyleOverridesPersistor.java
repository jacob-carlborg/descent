package net.sourceforge.nattable.typeconfig.persistence;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.prefs.BackingStoreException;

public class StyleOverridesPersistor<T> {
	private final Object lock = new Object();
	private DefaultNatModelPersistor natModel;
	private NatTablePersistor natPersistor;
	private StyleConfigRegistryPersistor<T> stylePersistor;

	public StyleOverridesPersistor(DefaultNatModelPersistor natModel, NatTablePersistor natPersistor, StyleConfigRegistryPersistor<T> stylePersistor) {
		this.natModel = natModel;
		this.natPersistor = natPersistor;
		this.stylePersistor = stylePersistor;
	}

	public void restorePreferences() throws IOException {
		synchronized (lock) {
			try {
				natModel.load(new FileInputStream(natModel.getFileName()));
				natPersistor.load(new FileInputStream(natPersistor.getFileName()));
				stylePersistor.load(new FileInputStream(stylePersistor.getFileName()));
			} catch (Exception e) {
				e.printStackTrace();
				throw new IOException("Unable to restore preferences." + e.getMessage());
			}
		}
	}

	/**
	 * This method will delegate to each {@link IStylePreferencesStore} it
	 * contains. Once the store is loaded, then it will serialize using the
	 * {@link Preferences} class.
	 * 
	 * @param source
	 * @throws BackingStoreException
	 * @throws IOException
	 */
	public void persistePreferences() throws IOException {
		synchronized (lock) {
			try {
				natModel.save(new FileOutputStream(natModel.getFileName()));
				natPersistor.save(new FileOutputStream(natPersistor.getFileName()));
				stylePersistor.save(new FileOutputStream(stylePersistor.getFileName()));
			} catch (Exception e) {
				e.printStackTrace();
				throw new IOException("Unable to load blank preference." + e.getMessage());
			}
		}
	}
}