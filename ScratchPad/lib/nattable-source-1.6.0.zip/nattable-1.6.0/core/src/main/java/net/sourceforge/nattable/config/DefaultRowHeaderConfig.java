package net.sourceforge.nattable.config;

import net.sourceforge.nattable.renderer.DefaultRowHeaderRenderer;
import net.sourceforge.nattable.renderer.ICellRenderer;

public class DefaultRowHeaderConfig implements IRowHeaderConfig {
	
	protected ICellRenderer rowHeaderRenderer;

	private int rowHeaderColumnCount;
	
	private SizeConfig rowHeaderColumnWidthConfig;

	public DefaultRowHeaderConfig() {
		initialize();
	}
	
	protected void initialize() {
		// TODO calculate default row header width based on row header text width
		this.rowHeaderColumnWidthConfig = new SizeConfig(40);
		rowHeaderRenderer = new DefaultRowHeaderRenderer();
	}

	// row header renderer
	
	public ICellRenderer getCellRenderer() {
		return rowHeaderRenderer;
	}

	public void setCellRenderer(ICellRenderer cellRenderer) {
		this.rowHeaderRenderer = cellRenderer;
	}
	
	// row header column count

	public int getRowHeaderColumnCount() {
		return rowHeaderColumnCount;
	}
	
	public void setRowHeaderColumnCount(int rowHeaderColumnCount) {
		this.rowHeaderColumnCount = rowHeaderColumnCount;
	}

	// row header column width
	
	public SizeConfig getRowHeaderColumnWidthConfig() {
		return rowHeaderColumnWidthConfig;
	}
	
	public void setRowHeaderColumnWidthConfig(SizeConfig rowHeaderColumnWidthConfig) {
		this.rowHeaderColumnWidthConfig = rowHeaderColumnWidthConfig;
	}

}
