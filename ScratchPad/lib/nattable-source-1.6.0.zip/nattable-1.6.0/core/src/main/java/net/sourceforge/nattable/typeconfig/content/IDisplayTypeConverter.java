package net.sourceforge.nattable.typeconfig.content;

public interface IDisplayTypeConverter {

	public Object dataValueToDisplayValue(Object dataValue);
	
	public Object displayValueToDataValue(Object displayValue);
	
}
