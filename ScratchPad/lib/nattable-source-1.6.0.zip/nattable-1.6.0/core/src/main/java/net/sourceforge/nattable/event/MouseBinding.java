package net.sourceforge.nattable.event;

import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.event.matcher.IMouseEventMatcher;

public class MouseBinding {

	private IMouseEventMatcher mouseEventMatcher;
	
	private IMouseEventAction action;
	
	public MouseBinding(IMouseEventMatcher mouseEventMatcher, IMouseEventAction action) {
		this.mouseEventMatcher = mouseEventMatcher;
		this.action = action;
	}
	
	public IMouseEventMatcher getMouseEventMatcher() {
		return mouseEventMatcher;
	}
	
	public IMouseEventAction getAction() {
		return action;
	}
	
}
