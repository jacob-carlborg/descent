package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.editor.TextCellEditor;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.painter.cell.TextCellPainter;
import net.sourceforge.nattable.typeconfig.style.DefaultStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��17��<br>
 */
public abstract class AbstractCellRenderer implements ICellRenderer {
	
	private static final DefaultStyleConfig selectStyleConfig = new DefaultStyleConfig(TextCellPainter.COLOR_LIST_SELECTION, GUIHelper.COLOR_WHITE, null, null);
	
	private static final DefaultStyleConfig defaultStyleConfig = new DefaultStyleConfig();
	
	private TextCellPainter cellPainter = new TextCellPainter(SWT.CENTER);
	
	private TextCellEditor textCellEditor = new TextCellEditor();

	public IStyleConfig getStyleConfig(String displayMode, int row, int col) {
		switch (DisplayModeEnum.valueOf(displayMode)) {
		case SELECT:
			return selectStyleConfig;
		default:
			return defaultStyleConfig;
		}
	}

	public ICellEditor getCellEditor(int row, int col) {
		return textCellEditor;
	}

	public ICellPainter getCellPainter(int row, int col) {
		return cellPainter;
	}

	public boolean isEditable(int row, int col) {
		return false;
	}

}
