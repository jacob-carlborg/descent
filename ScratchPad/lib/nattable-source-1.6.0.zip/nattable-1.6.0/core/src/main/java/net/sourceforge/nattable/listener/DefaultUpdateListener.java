package net.sourceforge.nattable.listener;

import net.sourceforge.nattable.NatTable;

public class DefaultUpdateListener implements IUpdateListener {

	private NatTable natTable;
	
	public DefaultUpdateListener(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void updateRowAdded(int from, int to) {
		// List<Integer> rows = getNatTable().getVisibleRow();
		// if (rows != null) {
		// int start = rows.size() > 0 ? rows.get(0) : 0;
		// int end = rows.size() > 1 ? rows.get(rows.size() - 1) : 0;
		//
		// if (from < start && to < start) {
		// getNatTable().redraw();
		// } else if (from > end && to > end) {
		// // ignore
		// } else if (start <= from && to <= end) {
		// // inside Range
		// getNatTable().redraw(from, end);
		// } else if (start >= from && to >= end && from < end) {
		// getNatTable().redraw();
		// } else if (start <= from && to > end && from < end) {
		// getNatTable().redraw(from, end);
		// }
		// }
		natTable.updateResize();
	}

	public void updateRowUpdated(int from, int to) {
		natTable.redrawUpdatedBodyRow(from, to);
	}

	public void updateRowRemoved(int from, int to) {
		// List<Integer> rows = getNatTable().getVisibleRow();
		// if (rows != null) {
		// int start = rows.get(0);
		// int end = rows.get(rows.size() - 1);
		//
		// if (from < start && to < start) {
		// getNatTable().redraw();
		// } else if (from > end && to > end) {
		// getNatTable().redraw(from, to);
		// } else if (start <= from && to <= end) {
		// // inside Range
		// getNatTable().redraw(from, end);
		// } else if (start >= from && to >= end && from < end) {
		// getNatTable().redraw();
		// } else if (start <= from && to > end && from < end) {
		// getNatTable().redraw(from, end);
		// }
		// }
		natTable.updateResize();
	}

}
