package net.sourceforge.nattable.renderer;

import net.sourceforge.nattable.painter.cell.HeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;

import org.eclipse.swt.SWT;

public class DefaultRowHeaderRenderer extends AbstractCellRenderer{
	HeaderCellPainter rowHeaderCellPainter = new HeaderCellPainter(SWT.CENTER | SWT.FLAT);
	
	public String getDisplayText(int row, int col) {
		return String.valueOf(row + 1);
	}
	
	public Object getValue(int row, int col) {
		return new Integer(row + 1);
	}

	public ICellPainter getCellPainter(int row, int col) {
		return rowHeaderCellPainter;
	}
}
