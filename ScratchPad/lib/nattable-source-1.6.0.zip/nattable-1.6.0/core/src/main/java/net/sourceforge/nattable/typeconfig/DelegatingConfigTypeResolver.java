package net.sourceforge.nattable.typeconfig;

import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;

public class DelegatingConfigTypeResolver implements IConfigTypeResolver {
	
	private final IConfigTypeResolver[] configTypeResolvers;

	public DelegatingConfigTypeResolver(IConfigTypeResolver... configTypeResolvers) {
		this.configTypeResolvers = configTypeResolvers;
	}
	
	public String getConfigType(int row, int col) {
		for (IConfigTypeResolver configTypeResolver : configTypeResolvers) {
			String configType = configTypeResolver.getConfigType(row, col);
			if (configType != null) {
				return configType;
			}
		}
		return null;
	}

}
