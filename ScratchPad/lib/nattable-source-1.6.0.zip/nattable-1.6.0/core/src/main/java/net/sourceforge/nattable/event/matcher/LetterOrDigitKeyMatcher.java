package net.sourceforge.nattable.event.matcher;


import org.eclipse.swt.events.KeyEvent;

public class LetterOrDigitKeyMatcher implements IKeyEventMatcher {

	public boolean matches(KeyEvent event) {
		return Character.isLetterOrDigit(event.character);
	}

}
