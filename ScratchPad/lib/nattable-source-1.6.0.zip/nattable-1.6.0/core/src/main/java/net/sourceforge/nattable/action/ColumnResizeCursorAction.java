package net.sourceforge.nattable.action;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.widgets.Display;

public class ColumnResizeCursorAction implements IMouseEventAction {

	private NatTable natTable;
	
	private Cursor cursorWE = new Cursor(Display.getDefault(), SWT.CURSOR_SIZEWE);
	
	public ColumnResizeCursorAction(NatTable natTable) {
		this.natTable = natTable;
	}
	
	public void run(MouseEvent event) {
		natTable.setCursor(cursorWE);
	}

}
