package net.sourceforge.nattable.support;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.util.UpdateQueue;

import org.apache.log4j.Logger;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class RowResizeSupport {

	public static final Logger log = Logger.getLogger(RowResizeSupport.class);

	protected int rowMinHeight = 1;
	
	private NatTable natTable;
	
	public RowResizeSupport(NatTable natTable) {
		this.natTable = natTable;
	}

	public void resizeRow(int selectedRow, Rectangle selectedRowRect, int offset) {
		INatTableModel model = natTable.getNatTableModel();
		int newHeight = selectedRowRect.height + offset;
		model.setBodyRowHeight(selectedRow,
				newHeight <= rowMinHeight ? rowMinHeight : newHeight);

		// TODO Are both redraw and updateResize necessary here?
		natTable.redraw();

		UpdateQueue.getInstance().addRunnable("NatTableRowResizeSupport" + natTable.getNatTableModel().getModelID(),
				new Runnable() {

					public void run() {
						Display.getDefault().asyncExec(new Runnable() {

							public void run() {
								natTable.updateResize();
							}

						});
					}

				});
	}

}
