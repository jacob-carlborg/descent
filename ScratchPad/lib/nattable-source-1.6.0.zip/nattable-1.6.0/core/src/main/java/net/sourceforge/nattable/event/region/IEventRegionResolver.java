package net.sourceforge.nattable.event.region;

public interface IEventRegionResolver {

	public String getEventRegion(int x, int y);
	
}
