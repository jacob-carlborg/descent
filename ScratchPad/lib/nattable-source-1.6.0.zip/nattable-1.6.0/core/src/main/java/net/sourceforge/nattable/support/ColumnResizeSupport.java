package net.sourceforge.nattable.support;

import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.util.UpdateQueue;

import org.apache.log4j.Logger;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class ColumnResizeSupport {

	public static final Logger log = Logger.getLogger(ColumnResizeSupport.class);

	protected int columnMinWidth = 1;
	
	private NatTable natTable;
	
	public ColumnResizeSupport(NatTable natTable) {
		this.natTable = natTable;
	}

	public void resizeModelBodyColumnWidthByMaxText(INatTableModel natTableModel, int col) {
		Map<Font, String> longestTexts = new HashMap<Font, String>();
		
		ICellRenderer bodyCellRenderer = natTableModel.getBodyCellRenderer();
		int rows = natTableModel.getBodyRowCount();
		for (int row = 0; row < rows; row++) {
			Font font = bodyCellRenderer.getStyleConfig(DisplayModeEnum.NORMAL.toString(), row, col).getFont(row, col);
			String text = bodyCellRenderer.getDisplayText(row, col);
			String longestText = longestTexts.get(font);
			if (longestText == null || text.length() > longestText.length()) {
				longestTexts.put(font, text);
			}
		}
		
		int maxWidth = 0;
		for (Font font : longestTexts.keySet()) {
			GC gc = new GC(Display.getDefault());
			gc.setFont(font);
			int width = gc.textExtent(longestTexts.get(font) + "XX").x;
			if (width > maxWidth) {
				maxWidth = width;
			}
		}
		natTableModel.setBodyColumnWidth(col, maxWidth);
		natTable.updateResize();
	}

	public void resizeModelBodyColumn(int selectedCol, Rectangle selectedColumnRect, int offset) {
		INatTableModel model = natTable.getNatTableModel();
		int newWidth = selectedColumnRect.width + offset;
		model.setBodyColumnWidth(selectedCol,
				newWidth <= columnMinWidth ? columnMinWidth : newWidth);

		// TODO Are both redraw and updateResize necessary here?
		natTable.redraw();

		UpdateQueue.getInstance().addRunnable("NatTableColumnResizeSupport" + natTable.getNatTableModel().getModelID(),
				new Runnable() {

					public void run() {
						Display.getDefault().asyncExec(new Runnable() {

							public void run() {
								natTable.updateResize();
							}

						});
					}

				});
	}

}
