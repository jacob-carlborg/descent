/**
 *
 */
package net.sourceforge.nattable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sourceforge.nattable.action.AutoResizeAction;
import net.sourceforge.nattable.action.ClearCursorAction;
import net.sourceforge.nattable.action.ColumnResizeCursorAction;
import net.sourceforge.nattable.action.EditAction;
import net.sourceforge.nattable.action.EditLastSelectedAction;
import net.sourceforge.nattable.action.EditWithCharAction;
import net.sourceforge.nattable.action.ForceFocusAction;
import net.sourceforge.nattable.action.MoveDownAction;
import net.sourceforge.nattable.action.MoveLeftAction;
import net.sourceforge.nattable.action.MoveRightAction;
import net.sourceforge.nattable.action.MoveToFirstColumnAction;
import net.sourceforge.nattable.action.MoveToFirstRowAction;
import net.sourceforge.nattable.action.MoveToLastColumnAction;
import net.sourceforge.nattable.action.MoveToLastRowAction;
import net.sourceforge.nattable.action.MoveUpAction;
import net.sourceforge.nattable.action.PageDownAction;
import net.sourceforge.nattable.action.PageUpAction;
import net.sourceforge.nattable.action.RowResizeCursorAction;
import net.sourceforge.nattable.action.SelectAllAction;
import net.sourceforge.nattable.action.SelectCellAction;
import net.sourceforge.nattable.action.SelectColumnAction;
import net.sourceforge.nattable.action.SortColumnAction;
import net.sourceforge.nattable.action.ToggleExpandColumnGroupAction;
import net.sourceforge.nattable.editor.CheckBoxCellEditor;
import net.sourceforge.nattable.editor.ComboBoxCellEditor;
import net.sourceforge.nattable.editor.TextCellEditor;
import net.sourceforge.nattable.event.drag.ColumnReorderDragMode;
import net.sourceforge.nattable.event.drag.ColumnResizeDragMode;
import net.sourceforge.nattable.event.drag.RowResizeDragMode;
import net.sourceforge.nattable.event.drag.SelectionDragMode;
import net.sourceforge.nattable.event.matcher.BodyCellEditorMouseEventMatcher;
import net.sourceforge.nattable.event.matcher.KeyEventMatcher;
import net.sourceforge.nattable.event.matcher.LetterOrDigitKeyMatcher;
import net.sourceforge.nattable.event.matcher.MouseEventMatcher;
import net.sourceforge.nattable.event.mode.ConfigurableModeEventHandler;
import net.sourceforge.nattable.event.mode.ModeEnum;
import net.sourceforge.nattable.event.region.DefaultEventRegionResolver;
import net.sourceforge.nattable.listener.ILockHandler;
import net.sourceforge.nattable.listener.IRowSelectionListener;
import net.sourceforge.nattable.listener.IValueChangeListener;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.painter.IOverlayPainter;
import net.sourceforge.nattable.painter.region.ColumnGroupHeaderRegionPainter;
import net.sourceforge.nattable.painter.region.DefaultBodyRegionPainter;
import net.sourceforge.nattable.painter.region.DefaultColumnHeaderRegionPainter;
import net.sourceforge.nattable.painter.region.DefaultCornerRegionPainter;
import net.sourceforge.nattable.painter.region.DefaultRowHeaderRegionPainter;
import net.sourceforge.nattable.painter.region.IRegionPainter;
import net.sourceforge.nattable.sorting.ISortingDirectionChangeListener;
import net.sourceforge.nattable.sorting.SortingDirection;
import net.sourceforge.nattable.support.ColumnGroupSupport;
import net.sourceforge.nattable.support.ColumnResizeSupport;
import net.sourceforge.nattable.support.ColumnSortSupport;
import net.sourceforge.nattable.support.ColumnTransformSupport;
import net.sourceforge.nattable.support.ConflationSupport;
import net.sourceforge.nattable.support.EditorSupport;
import net.sourceforge.nattable.support.EventBindingSupport;
import net.sourceforge.nattable.support.IClientAreaProvider;
import net.sourceforge.nattable.support.ModeSupport;
import net.sourceforge.nattable.support.OrderEnum;
import net.sourceforge.nattable.support.RegionMetricsSupport;
import net.sourceforge.nattable.support.RowResizeSupport;
import net.sourceforge.nattable.support.ScrollSupport;
import net.sourceforge.nattable.support.SelectionModeEnum;
import net.sourceforge.nattable.support.SelectionSupport;
import net.sourceforge.nattable.support.SelectionTypeEnum;
import net.sourceforge.nattable.support.VisibleMetricsSupport;
import net.sourceforge.nattable.util.GUIHelper;
import net.sourceforge.nattable.util.RowHeightIndex;

import org.apache.log4j.Logger;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.ScrollBar;

/**
 * Author : Andy Tsoi <br>
 * Created Date : 2007-9-23<br>
 */
public class NatTable extends Canvas implements PaintListener, IClientAreaProvider {
	protected List<IRowSelectionListener> rowSelectionListenerList = Collections
			.synchronizedList(new ArrayList<IRowSelectionListener>());

	protected final INatTableModel model;

	private final SelectionModel selectionModel;

	public static final Logger log = Logger.getLogger(NatTable.class);
	
	private EventBindingSupport eventBindingSupport = new EventBindingSupport(new DefaultEventRegionResolver(this));
	
	private ModeSupport modeSupport;

	private ColumnSortSupport columnSortSupport = new ColumnSortSupport(this);

	private ConflationSupport conflationSupport = new ConflationSupport(this);

	private ColumnResizeSupport columnResizeSupport = new ColumnResizeSupport(this);
	
	private RowResizeSupport rowResizeSupport = new RowResizeSupport(this);	
	
	private final EditorSupport editorSupport;

	private SelectionSupport selectionSupport;

	private ColumnGroupSupport columnGroupSupport;
	
	private ColumnTransformSupport columnTransformSupport;
	
	private final ScrollSupport scrollSupport;
	
	private Map<GridRegionEnum, IRegionPainter> regionPainters = new HashMap<GridRegionEnum, IRegionPainter>();
	
	private List<IOverlayPainter> overlayPainters = new ArrayList<IOverlayPainter>();
	
	private VisibleMetricsSupport visibleMetricsSupport;

	public NatTable(final Composite parent, final int style, final INatTableModel natTableModel) {
		super(parent, style);

		if (natTableModel != null) {
			model = natTableModel;
		} else {
			model = new DefaultNatTableModel();
		}		
		
		columnTransformSupport = new ColumnTransformSupport(model.getBodyConfig());

		selectionModel = new SelectionModel();

		selectionSupport = new SelectionSupport(this,
				getNatTableModel().isFullRowSelection() ? SelectionTypeEnum.ROW : SelectionTypeEnum.CELL,
				getNatTableModel().isMultpleSelection() ? SelectionModeEnum.MULTI : SelectionModeEnum.SINGLE);

		
		
		visibleMetricsSupport = new VisibleMetricsSupport(this, model, columnTransformSupport);
		
		scrollSupport = new ScrollSupport(this);
		
		initRegionPainters();
		
		initInternalListener();
		
		editorSupport = new EditorSupport(this);
	}
	
	protected void initRegionPainters() {
		regionPainters.put(GridRegionEnum.CORNER, new DefaultCornerRegionPainter(this));
		regionPainters.put(GridRegionEnum.COLUMN_HEADER, new DefaultColumnHeaderRegionPainter(this));
		regionPainters.put(GridRegionEnum.ROW_HEADER, new DefaultRowHeaderRegionPainter(this));
		regionPainters.put(GridRegionEnum.BODY, new DefaultBodyRegionPainter(this));
	}
	
	public void setRegionPainter(GridRegionEnum region, IRegionPainter regionPainter) {
		regionPainters.put(region, regionPainter);
	}

	/**
	 * @return the natTableModel
	 */
	public INatTableModel getNatTableModel() {
		return model;
	}

	@Override
	protected void checkSubclass() {
	}

	protected void initInternalListener() {
		modeSupport = new ModeSupport(this);
		
		ConfigurableModeEventHandler configurableModeEventHandler = new ConfigurableModeEventHandler(this);
		configureKeyBindings();
		configureMouseBindings();
		
		modeSupport.registerModeEventHandler(ModeEnum.NORMAL_MODE, configurableModeEventHandler);
		modeSupport.switchMode(ModeEnum.NORMAL_MODE);

		addPaintListener(this);

		addFocusListener(new FocusListener() {

			public void focusLost(final FocusEvent arg0) {
				redraw();
			}

			public void focusGained(final FocusEvent arg0) {
				redraw();
			}

		});

		addListener(SWT.Resize, new Listener() {
			public void handleEvent(final Event e) {
				updateResize();
			}
		});
	}
	
	public EventBindingSupport getEventBindingSupport() {
		return eventBindingSupport;
	}
	
	protected void configureKeyBindings() {
		// Move up
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.ARROW_UP), new MoveUpAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.ARROW_UP), new MoveUpAction(selectionSupport, true, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.ARROW_UP), new MoveUpAction(selectionSupport, false, true));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.ARROW_UP), new MoveUpAction(selectionSupport, true, true));
		
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.CR), new MoveUpAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.CR), new MoveUpAction(selectionSupport, false, true));
		
		// Move down
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.ARROW_DOWN), new MoveDownAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.ARROW_DOWN), new MoveDownAction(selectionSupport, true, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.ARROW_DOWN), new MoveDownAction(selectionSupport, false, true));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.ARROW_DOWN), new MoveDownAction(selectionSupport, true, true));
		
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.CR), new MoveDownAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.CR), new MoveDownAction(selectionSupport, false, true));
		
		// Move left
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.ARROW_LEFT), new MoveLeftAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.ARROW_LEFT), new MoveLeftAction(selectionSupport, true, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.ARROW_LEFT), new MoveLeftAction(selectionSupport, false, true));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.ARROW_LEFT), new MoveLeftAction(selectionSupport, true, true));
		
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.TAB), new MoveLeftAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.TAB), new MoveLeftAction(selectionSupport, false, true));
		
		// Move right
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.ARROW_RIGHT), new MoveRightAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.ARROW_RIGHT), new MoveRightAction(selectionSupport, true, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.ARROW_RIGHT), new MoveRightAction(selectionSupport, false, true));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.ARROW_RIGHT), new MoveRightAction(selectionSupport, true, true));
		
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.TAB), new MoveRightAction(selectionSupport, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.TAB), new MoveRightAction(selectionSupport, false, true));
		
		// Page up
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.PAGE_UP), new PageUpAction(this, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.PAGE_UP), new PageUpAction(this, true, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.PAGE_UP), new PageUpAction(this, false, true));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.PAGE_UP), new PageUpAction(this, true, true));
		
		// Page down
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.PAGE_DOWN), new PageDownAction(this, false, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.PAGE_DOWN), new PageDownAction(this, true, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.PAGE_DOWN), new PageDownAction(this, false, true));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.PAGE_DOWN), new PageDownAction(this, true, true));
		
		// Move to first column
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.HOME), new MoveToFirstColumnAction(this, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.HOME), new MoveToFirstColumnAction(this, true));
		
		// Move to last column
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.END), new MoveToLastColumnAction(this, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT, SWT.END), new MoveToLastColumnAction(this, true));
		
		// Move to first row
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.HOME), new MoveToFirstRowAction(this, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.HOME), new MoveToFirstRowAction(this, true));
		
		// Move to last row
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, SWT.END), new MoveToLastRowAction(this, false));
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.SHIFT | SWT.CONTROL, SWT.END), new MoveToLastRowAction(this, true));
		
		// Select all
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.CONTROL, 'a'), new SelectAllAction(selectionSupport));
		
		// Edit
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.F2), new EditLastSelectedAction(this));
		eventBindingSupport.registerKeyBinding(new LetterOrDigitKeyMatcher(), new EditWithCharAction(this));
		
		// Esc
		eventBindingSupport.registerKeyBinding(new KeyEventMatcher(SWT.NONE, SWT.ESC), new ForceFocusAction(this));
	}
	
	protected void configureMouseBindings() {
		// Mouse move
		eventBindingSupport.registerMouseMoveBinding(new MouseEventMatcher(SWT.NONE, "COLUMN_RESIZE_HANDLE", 0), new ColumnResizeCursorAction(this));
		eventBindingSupport.registerMouseMoveBinding(new MouseEventMatcher(SWT.NONE, "ROW_RESIZE_HANDLE", 0), new RowResizeCursorAction(this));
		eventBindingSupport.registerMouseMoveBinding(new MouseEventMatcher(), new ClearCursorAction(this));
		
		// Single click
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.NONE, "COLUMN_GROUP_HEADER", 1), new ToggleExpandColumnGroupAction(this));
		
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.NONE, GridRegionEnum.COLUMN_HEADER.toString(), 1), new SortColumnAction(this));
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.ALT, GridRegionEnum.COLUMN_HEADER.toString(), 1), new SortColumnAction(this));
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.CONTROL, GridRegionEnum.COLUMN_HEADER.toString(), 1), new SelectColumnAction(this));

		eventBindingSupport.registerSingleClickBinding(new BodyCellEditorMouseEventMatcher(this, CheckBoxCellEditor.class), new EditAction(this));
		eventBindingSupport.registerSingleClickBinding(new BodyCellEditorMouseEventMatcher(this, ComboBoxCellEditor.class), new EditAction(this));
		
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.NONE, GridRegionEnum.BODY.toString(), 1), new SelectCellAction(this, false, false));
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.SHIFT, GridRegionEnum.BODY.toString(), 1), new SelectCellAction(this, true, false));
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.CONTROL, GridRegionEnum.BODY.toString(), 1), new SelectCellAction(this, false, true));
		eventBindingSupport.registerSingleClickBinding(new MouseEventMatcher(SWT.SHIFT | SWT.CONTROL, GridRegionEnum.BODY.toString(), 1), new SelectCellAction(this, true, true));

		// Double click
		eventBindingSupport.registerDoubleClickBinding(new MouseEventMatcher(SWT.NONE, "COLUMN_RESIZE_HANDLE", 1), new AutoResizeAction(this));
		eventBindingSupport.registerDoubleClickBinding(new BodyCellEditorMouseEventMatcher(this, TextCellEditor.class), new EditAction(this));
		
		// Drag
		eventBindingSupport.registerMouseDragMode(new MouseEventMatcher(SWT.NONE, "COLUMN_RESIZE_HANDLE", 1), new ColumnResizeDragMode(this));
		eventBindingSupport.registerMouseDragMode(new MouseEventMatcher(SWT.NONE, "ROW_RESIZE_HANDLE", 1), new RowResizeDragMode(this));
		
		eventBindingSupport.registerMouseDragMode(new MouseEventMatcher(SWT.NONE, GridRegionEnum.COLUMN_HEADER.toString(), 1), new ColumnReorderDragMode(this));
		
		eventBindingSupport.registerMouseDragMode(new MouseEventMatcher(SWT.NONE, GridRegionEnum.BODY.toString(), 1), new SelectionDragMode(this));
	}
	
	@Override
	public boolean forceFocus() {
		editorSupport.close();
		return super.forceFocus();
	}
	
	// Painting ///////////////////////////////////////////////////////////////

	public void addOverlayPainter(IOverlayPainter overlayPainter) {
		overlayPainters.add(overlayPainter);
	}
	
	public void removeOverlayPainter(IOverlayPainter overlayPainter) {
		overlayPainters.remove(overlayPainter);
	}
	
	public void paintControl(final PaintEvent event) {
		try {
			paintNatTable(event);
		} catch(IndexOutOfBoundsException ioe) {
			log.warn("The model size has been modified outside the scope of this drawing thread: "+ ioe.getMessage());
			reset();
			paintNatTable(event);
		}
	}

	private void paintNatTable(final PaintEvent event) {
		final GC gc = event.gc;

		gc.setForeground(GUIHelper.COLOR_LIST_FOREGROUND);
		gc.setBackground(GUIHelper.COLOR_LIST_BACKGROUND);

		final Rectangle client = new Rectangle(event.x, event.y, event.width, event.height);
		final List<Integer> visibleModelBodyColList = getVisibleModelBodyColumns();
		final List<Integer> visibleModelBodyRowList = getVisibleModelBodyRows();
		
		if (log.isDebugEnabled()) {
			log.debug("Visible Model Body Rows = " + visibleModelBodyRowList);
		}

		if (log.isDebugEnabled()) {
			log.debug("Visible Model Body Columns = " + visibleModelBodyColList);
		}

		// Clean Background
		gc.fillRectangle(client.x, client.y, client.width, client.height);

		// Draw grid
		drawGrid(gc, client, visibleModelBodyRowList, visibleModelBodyColList);
		

		if (isFocusControl()) {
			drawSelectionFocus(gc, client, visibleModelBodyRowList, visibleModelBodyColList);
		}

		// draw overlays
		for (IOverlayPainter overlayPainter : overlayPainters) {
			overlayPainter.paintOverlay(gc);
		}
	}

	private void drawGrid(final GC gc, final Rectangle client, final List<Integer> visibleBodyRowList,
			final List<Integer> visibleBodyColList) {
		// TODO Assumption is that all headers are always visible
		final int totalRowHeaderWidth = visibleMetricsSupport.getTotalRowHeaderWidth();
		final int totalColumnHeaderHeight = getTotalColumnHeaderHeight();

		final int columnHeaderRowCount = model.getColumnHeaderRowCount();
		final int rowHeaderColumnCount = model.getRowHeaderColumnCount();
		final int visibleBodyColumnCount = visibleBodyColList.size();
		final int visibleBodyRowCount = visibleBodyRowList.size();

		if (model.isGridLineEnabled()) {
			drawGridLines(gc, visibleBodyRowList, visibleBodyColList, totalRowHeaderWidth, columnHeaderRowCount,
					rowHeaderColumnCount, visibleBodyColumnCount, visibleBodyRowCount);
		}

		// Corner
		regionPainters.get(GridRegionEnum.CORNER).drawRegion(columnHeaderRowCount, rowHeaderColumnCount, 0, 0, null, null, gc, client);

		// Column header
		regionPainters.get(GridRegionEnum.COLUMN_HEADER).drawRegion(columnHeaderRowCount, visibleBodyColumnCount, totalRowHeaderWidth, 0, null,
				visibleBodyColList, gc, client);

		// Row header
		regionPainters.get(GridRegionEnum.ROW_HEADER).drawRegion(visibleBodyRowCount, rowHeaderColumnCount, 0, totalColumnHeaderHeight,
				visibleBodyRowList, null, gc, client);

		// Body
		regionPainters.get(GridRegionEnum.BODY).drawRegion(visibleBodyRowCount, visibleBodyColumnCount, totalRowHeaderWidth,
				totalColumnHeaderHeight, visibleBodyRowList, visibleBodyColList, gc, client);
	}

	private void drawGridLines(final GC gc, final List<Integer> visibleBodyRowList,
			final List<Integer> visibleBodyColList, final int totalRowHeaderWidth, final int columnHeaderRowCount,
			final int rowHeaderColumnCount, final int visibleBodyColumnCount, final int visibleBodyRowCount) {
		final int freezeRow = model.getFreezeRowCount() - 1;
		final int freezeCol = model.getFreezeColumnCount() - 1;

		gc.setForeground(GUIHelper.COLOR_GRAY);

		// Calculate available width
		int availableWidth = totalRowHeaderWidth;
		for (int col = 0; col < visibleBodyColumnCount; col++) {
			availableWidth += model.getBodyColumnWidth(visibleBodyColList.get(col).intValue());
		}

		// Calculate available height, drawing grid lines along the way

		int currentHeight = 0;

		// Draw horizontal lines separating column header rows
		for (int row = 0; row < columnHeaderRowCount; row++) {
			gc.drawLine(0, currentHeight, availableWidth, currentHeight);
			currentHeight += model.getColumnHeaderRowHeight(row);
		}

		final int regionDelimiterHeight = currentHeight;

		// Draw horizontal line separating column headers from body
		gc.drawLine(0, regionDelimiterHeight, availableWidth, regionDelimiterHeight);

		// Draw horizontal lines separating body rows
		for (int row = 0; row < visibleBodyRowCount; row++) {
			final int visibleBodyRow = visibleBodyRowList.get(row).intValue();
			currentHeight += model.getBodyRowHeight(visibleBodyRow);
			if (visibleBodyRow == freezeRow) {
				gc.setForeground(GUIHelper.COLOR_BLACK);
			}
			gc.drawLine(0, currentHeight, availableWidth, currentHeight);
			if (visibleBodyRow == freezeRow) {
				// Reset to default color
				gc.setForeground(GUIHelper.COLOR_GRAY);
			}
		}

		// Current height is now at max y extent
		final int availableHeight = currentHeight;

		int currentWidth = 0;
		// Draw vertical lines separating row header columns
		for (int col = 0; col < rowHeaderColumnCount; col++) {
			gc.drawLine(currentWidth, 0, currentWidth, availableHeight);
			currentWidth += model.getRowHeaderColumnWidth(col);
		}

		final int regionDelimiterWidth = currentWidth;

		// Draw vertical line separating row headers from body
		gc.drawLine(regionDelimiterWidth, 0, regionDelimiterWidth, availableHeight);

		// Draw vertical lines separating body columns
		for (int col = 0; col < visibleBodyColumnCount; col++) {
			final int visibleBodyCol = visibleBodyColList.get(col).intValue();
			currentWidth += model.getBodyColumnWidth(visibleBodyCol);
			if (visibleBodyCol == freezeCol) {
				gc.setForeground(GUIHelper.COLOR_BLACK);
			}
			gc.drawLine(currentWidth, 0, currentWidth, availableHeight);
			if (visibleBodyCol == freezeCol) {
				// Reset to default color
				gc.setForeground(GUIHelper.COLOR_GRAY);
			}
		}
	}

	/**
	 * @param gc
	 * @param clientArea
	 * @param visibleColList
	 * @param rowlist
	 */
	private void drawSelectionFocus(final GC gc, final Rectangle clientArea, final List<Integer> visibleBodyRowList,
			final List<Integer> visibleBodyColList) {

		if (!model.isSingleCellSelection()) {
			drawSelectionFocus(gc, visibleBodyRowList, visibleBodyColList);

		}
	}

	/**
	 * 
	 * @param gc
	 * @param visibleBodyRowList
	 * @param visibleBodyColList
	 * @return true if focus is found and drawn
	 */
	protected boolean drawSelectionFocus(final GC gc, final List<Integer> visibleBodyRowList,
			final List<Integer> visibleBodyColList) {
		final Point lastSelectedCell = selectionSupport.getLastSelectedCell();
		int y = getTotalColumnHeaderHeight();
		int displayColWidth = 0;
		int x = 0;
		
		final int visibleBodyColCount = visibleBodyColList.size();
		
		boolean selectedColumnProcessed = false;
		
		for (int i = 0; i < visibleBodyColCount; i++) {
			int curColumn = visibleBodyColList.get(i).intValue();
			int columnWidth = model.getBodyColumnWidth(curColumn);
			
			if (curColumn == lastSelectedCell.x)
				selectedColumnProcessed = true;
			
			if (!selectedColumnProcessed)
				x += columnWidth;
			
			displayColWidth += columnWidth;
		}

		for (final Integer visibleRow : visibleBodyRowList) {
			final int visibleRowInt = visibleRow.intValue();

			if (visibleRowInt == lastSelectedCell.y) {
				
				if (selectionSupport.getSelectionType() == SelectionTypeEnum.ROW)
					gc.drawFocus(visibleMetricsSupport.getTotalRowHeaderWidth() + 1, y + 1, displayColWidth, model
							.getBodyRowHeight(visibleRowInt) - 1);
				else {
					gc.drawFocus(visibleMetricsSupport.getTotalRowHeaderWidth() + x, y + 1, model.getBodyColumnWidth(lastSelectedCell.x), model
							.getBodyRowHeight(visibleRowInt) - 1);
				}
				return true;
			}

			y += model.getBodyRowHeight(visibleRowInt);
		}
		return false;
	}

	// Hidden columns /////////////////////////////////////
	
	public void hideModelBodyColumn(final int modelBodyColumn) {
		String columnGroupName = null;
		if ((columnGroupName = getColumnGroupName(modelBodyColumn)) != null) {
			columnGroupSupport.hideColumnGroup(columnGroupName);
		} else {
			columnTransformSupport.hideModelBodyColumn(modelBodyColumn);
		}
		
		reset();
		updateResize();
	}

	public void showModelBodyColumn(final int modelBodyColumn) {
		String columnGroupName = null;
		if ((columnGroupName = getColumnGroupName(modelBodyColumn)) != null) {
			columnGroupSupport.showColumnGroup(columnGroupName);
		} else {	
			columnTransformSupport.showModelBodyColumn(modelBodyColumn);
		}
		reset();
		updateResize();		
	}

	private String getColumnGroupName(final int modelBodyColumn) {
		if (isColumnGroupsEnabled() && columnGroupSupport.isColumnInColumnGroup(modelBodyColumn)) {
			return columnGroupSupport.getColumnGroupName(modelBodyColumn);
		}
		return null;
	}
	
	public Set<Integer> getHiddenModelBodyColumns() {		
		return columnTransformSupport.getHiddenModelBodyColumns();
	}

	public boolean isModelBodyColumnViewable(final int modelBodyColumn) {
		return columnTransformSupport.isModelBodyColumnViewable(modelBodyColumn);
	}

	// Viewable ///////////////////////////////////////////////////////////////
	
	public int getViewableBodyColumnCount() {
		return model.getBodyColumnCount() - getHiddenModelBodyColumns().size();
	}
	
	// Visible ////////////////////////////////////////////////////////////////
	
	/**
	 * Get visible body column indexes.
	 * 
	 * @return List of visible body column indexes.
	 */
	public List<Integer> getVisibleModelBodyColumns() {
		return visibleMetricsSupport.getVisibleModelBodyColumns();
	}

	public List<Integer> getVisibleModelBodyRows() {
		return visibleMetricsSupport.getVisibleModelBodyRows();
	}
	
	public int getPreviousAdjacentVisibleModelBodyColumn(int modelBodyColumn) {
		int prevCol = -1;
		List<Integer> visibleModelBodyColumns = getVisibleModelBodyColumns();
		int numVisibleBodyColumns = visibleModelBodyColumns.size();
		for (int i = 0; i < numVisibleBodyColumns; i++) {
			if (visibleModelBodyColumns.get(i).intValue() == modelBodyColumn) {
				prevCol = i - 1;
				break;
			}
		}
		if (prevCol >= 0) {
			return visibleModelBodyColumns.get(prevCol).intValue();
		} else {
			return -1;
		}
	}

	// Calculate aggregate region extents /////////////////////////////////////

	public int getTotalColumnHeaderHeight() {
		return visibleMetricsSupport.getTotalColumnHeaderHeight();
	}

	public int getTotalViewableBodyWidth() {
		return visibleMetricsSupport.getTotalViewableBodyWidth();
	}

	public int getTotalGridHeight() {
		return visibleMetricsSupport.getTotalColumnHeaderHeight() + visibleMetricsSupport.getTotalBodyHeight();
	}

	// Column order ///////////////////////////////////////////////////////////

	public void setModelBodyColumnOrder(final int[] order) {
		columnTransformSupport.setModelBodyColumnOrder(order);
		updateResize();
	}

	/**
	 * Get the body column ordering, which is a list of actual body column
	 * indexes listed in the order in which those column indexes are shown.
	 * 
	 * @return Array of body column indexes.
	 */
	public int[] getModelBodyColumnOrder() {
		return columnTransformSupport.getModelBodyColumnOrder();
	}

	public int modelToReorderedBodyColumn(final int modelBodyColumn) {
		return columnTransformSupport.modelToReorderedBodyColumn(modelBodyColumn);
	}
	
	public int reorderedToModelBodyColumn(final int reorderedBodyColumn) {
		return columnTransformSupport.reorderedToModelBodyColumn(reorderedBodyColumn);
	}
	
	public int modelToViewableBodyColumn(final int targetModelBodyColumn) {
		int viewableIndex = -1;
		int[] modelBodyColumnOrder = getModelBodyColumnOrder();
		for (int i = 0; i < modelBodyColumnOrder.length; i++) {
			int modelBodyColumn = modelBodyColumnOrder[i];
			if (isModelBodyColumnViewable(modelBodyColumn)) {
				viewableIndex++;
				if (modelBodyColumn == targetModelBodyColumn) {
					break;
				}
			}
		}
		
		return viewableIndex;
	}
	
	public int viewableToModelBodyColumn(final int viewableBodyColumn) {
		int modelIndex = -1;
		int[] modelBodyColumnOrder = getModelBodyColumnOrder();

		for (int i = 0, viewableIndex = 0; i < modelBodyColumnOrder.length; i++) {
			int modelBodyColumn = modelBodyColumnOrder[i];
			if (isModelBodyColumnViewable(modelBodyColumn)) {
				
				if (viewableIndex == viewableBodyColumn) {
					modelIndex = modelBodyColumn;
					break;
				}
				
				viewableIndex++;
			}
		}
		
		return modelIndex;
	}
	
	public boolean isSelected(final int modelBodyRow, final int modelBodyColumn) {
		return selectionModel.isSelected(modelBodyRow, modelToReorderedBodyColumn(modelBodyColumn));
	}

	public void updateResize() {
		updateResize(true);
	}

	/**
	 * Update the table screen by re-calculating everything again. It should not
	 * be called too frequently.
	 * 
	 * @param redraw
	 *            true to redraw the table
	 */
	public void updateResize(final boolean redraw) {
		final ScrollBar hBar = getHorizontalBar();
		final ScrollBar vBar = getVerticalBar();
		final Rectangle client = getClientArea();
		
		scrollSupport.recalculate();

		// Reset scrollbar thumb sizes
		hBar.setThumb(Math.min(hBar.getMaximum(), client.width));
		vBar.setThumb(Math.min(vBar.getMaximum(), client.height));
		
		// Update origin
		final int hPage = hBar.getMaximum() - client.width;
		final int vPage = vBar.getMaximum() - client.height;
		int hSelection = hBar.getSelection();
		int vSelection = vBar.getSelection();
		if (hSelection >= hPage) {
			if (hPage <= 0) {
				hSelection = 0;
			}
			visibleMetricsSupport.setOriginX(-hSelection);
		}
		if (vSelection >= vPage) {
			if (vPage <= 0) {
				vSelection = 0;
			}
			visibleMetricsSupport.setOriginY(-vSelection);
		}

		visibleMetricsSupport.refresh();
		if (redraw) {
			redraw();
		}
	}

	public void redrawColumnHeaders() {
		final Rectangle rectangle = new Rectangle(0, 0, 0, 0);

		final int current = getTotalColumnHeaderHeight();

		rectangle.width = getClientArea().width;
		rectangle.height = current;
		redraw(rectangle.x, rectangle.y, rectangle.width, rectangle.height, false);
	}

	/**
	 * Redraw all corresponding rows to make sure new rows can be inserted
	 * properly. This redraw call will check against the from/to row index in
	 * order to know whether it has to either redraw the table or just reset the
	 * scroll bar immediately.
	 * 
	 * @param fromGridRow
	 * @param toGridRow
	 */
	public void redrawInsertedBodyRow(final int fromBodyRow, final int toBodyRow) {

		Rectangle rectangle = getClientArea();

		int total = visibleMetricsSupport.getTotalBodyHeight() + getTotalColumnHeaderHeight();

		if (total >= rectangle.height) {
			final List<Integer> visibleBodyRows = getVisibleModelBodyRows();
			if (visibleBodyRows.size() > 0) {
				final int listStart = visibleBodyRows.get(0).intValue();
				final int listend = visibleBodyRows.get(visibleBodyRows.size() - 1).intValue();

				if ((listStart > fromBodyRow && listStart > toBodyRow) ||
				// Upper Area
						(listend < fromBodyRow && listend < toBodyRow)) {
					// Bottom Area
					updateResize(false);
					return;
				}
			}
		}
		updateResize();
	}

	/**
	 * Redraw all rows which is being displayed and update the scroll bar
	 * immediately
	 * 
	 * @param fromGridRow
	 * @param toGridRow
	 */
	public void redrawDeletedBodyRow(final int fromBodyRow, final int toBodyRow) {
		redrawInsertedBodyRow(fromBodyRow, toBodyRow);
	}

	/**
	 * Redraw the row area among from and to based upon the visible area
	 * 
	 * @param from
	 * @param to
	 */
	public void redrawUpdatedBodyRow(final int fromBodyRow, final int toBodyRow) {

		int realFromRow = -1;
		int realToRow = -1;
		final Rectangle rectangle = new Rectangle(0, 0, 0, 0);

		final List<Integer> visibleBodyRows = getVisibleModelBodyRows();
		if (visibleBodyRows.size() > 0) {
			final int listStart = visibleBodyRows.get(0).intValue();
			final int listend = visibleBodyRows.get(visibleBodyRows.size() - 1).intValue();

			// Crop real start/end to start/end of visible rows
			if (listStart <= fromBodyRow && listend >= fromBodyRow) {
				realFromRow = fromBodyRow;

				if (listStart <= toBodyRow && listend >= toBodyRow) {
					realToRow = toBodyRow;
				} else {
					realToRow = listend;
				}
			} else if (listStart <= toBodyRow && listend >= toBodyRow) {
				realFromRow = listStart;
				realToRow = toBodyRow;
			} else if (fromBodyRow < listStart && toBodyRow > listend) {
				realToRow = listend;
				realFromRow = listStart;
			}

			if (log.isDebugEnabled()) {
				log.info("fromRow " + fromBodyRow + " toRow " + toBodyRow);
				log.info("realFromRow " + realFromRow + " realToRow " + realToRow);
			}

			if (realFromRow >= 0 && realToRow >= 0) {
				int currentHeight = 0;
				final int columnHeaderRowCount = model.getColumnHeaderRowCount();
				for (int row = 0; row < columnHeaderRowCount; row++) {
					currentHeight += model.getColumnHeaderRowHeight(row);
				}

				final int visibleGridRowCount = visibleBodyRows.size();
				for (int row = 0; row < visibleGridRowCount; row++) {
					final int visibleGridRow = visibleBodyRows.get(row).intValue();
					final int height = model.getBodyRowHeight(visibleGridRow);

					if (visibleGridRow == realFromRow) {
						rectangle.y = currentHeight;
						rectangle.height = height;
					} else if (rectangle.height > 0) {
						rectangle.height += height;
					}

					currentHeight += height;

					if (visibleGridRow == realToRow) {
						rectangle.width = getClientArea().width;
						break;
					}
				}
				if (log.isDebugEnabled()) {
					log.debug("redraw rectangle " + rectangle + " redraw index = " + fromBodyRow);
				}

				redraw(rectangle.x, rectangle.y, rectangle.width, rectangle.height, false);
			}

		}

	}

	public void reset() {
		visibleMetricsSupport.reset();
	}

	public void scrollHBarUpdate(final ScrollBar hBar) {
		scrollHBarUpdate(hBar, true);
	}

	public void scrollHBarUpdate(final ScrollBar hBar, final boolean redraw) {
		final int hSelection = hBar.getSelection();
		if (hSelection <= getTotalViewableBodyWidth()) {
			visibleMetricsSupport.reset();
			visibleMetricsSupport.setOriginX(-hSelection);
			if (redraw) {
				redraw();
			}
		}
	}

	public void scrollVBarUpdate(final ScrollBar vBar) {
		scrollVBarUpdate(vBar, true);
	}

	public void scrollVBarUpdate(final ScrollBar vBar, final boolean redraw) {
		visibleMetricsSupport.reset();
		final int vSelection = vBar.getSelection();
		visibleMetricsSupport.setOriginY(-vSelection);
		
		if (redraw) {
			redraw();
		}
	}

	public SelectionModel getSelectionModel() {
		return selectionModel;
	}

	public void clearSelection() {
		selectionModel.clearSelection();
		redraw();
	}

	public void showBodyRow(final Integer bodyRow) {

		final List<Integer> visibleBodyRows = getVisibleModelBodyRows();

		int bodyRowInt = bodyRow.intValue();
		if (visibleBodyRows.size() > 0) {
			int startBodyRow = Math.round(bodyRowInt / RowHeightIndex.BASE);
			startBodyRow = startBodyRow * RowHeightIndex.BASE;
			int currentHeight = visibleMetricsSupport.getHeightByStartIndex(startBodyRow);

			for (int row = startBodyRow; row < bodyRowInt; row++) {
				currentHeight += model.getBodyRowHeight(row);
			}

			final ScrollBar vbar = getVerticalBar();
			vbar.setSelection(currentHeight);
			scrollVBarUpdate(vbar);

		}
	}

	public void showBodyColumn(final int uiBodyColumn, OrderEnum alignment) {

		int bodyColumnIndex = reorderedToModelBodyColumn(uiBodyColumn);
		
		if (!isColumnVisible(bodyColumnIndex)) {
			
			int currentWidth = getBodyVisibleWidth(uiBodyColumn);

			if (alignment == OrderEnum.LAST) {
				int columnWidth = model.getBodyColumnWidth(bodyColumnIndex);
				int viewWidth = visibleMetricsSupport.getBodyScrollableViewWidth();
				int x = columnWidth;
				
				for (int i = uiBodyColumn - 1; i >= 0; i--) {
					int modelBodyColumn = reorderedToModelBodyColumn(i);
					int curColumnWidth = model.getBodyColumnWidth(modelBodyColumn);
					x += curColumnWidth;
					
					if (x < viewWidth) {
						currentWidth -= curColumnWidth;
					} else {
						break;
					}
				}
			}
			
			
			final ScrollBar hbar = getHorizontalBar();
			hbar.setSelection(currentWidth);
			scrollHBarUpdate(hbar);
		}
	}

	private boolean isColumnVisible(int bodyColumnIndex) {
		final List<Integer> visibleModelBodyCols = getVisibleModelBodyColumns();
		
		if (visibleModelBodyCols.size() > 0) {
			
			int viewWidth = visibleMetricsSupport.getBodyScrollableViewWidth();
			
			int width = 0;
			
			int frozenColumns = model.getFreezeColumnCount();
			
			for (int i = frozenColumns; i < visibleModelBodyCols.size(); i++) {
				Integer visibleBodyCol = visibleModelBodyCols.get(i);
				width += model.getBodyColumnWidth(visibleBodyCol.intValue());
				
				if (visibleBodyCol.intValue() == bodyColumnIndex) {
					return width <= viewWidth;
				}
			}
			
		}
		
		return false;
	}
	
	private int getBodyVisibleWidth(int endVisibleUIBodyColumn) {
		int currentWidth = 0;
		
		for (int uiBodyColumn = 0; uiBodyColumn < endVisibleUIBodyColumn; uiBodyColumn++) {
			int columnIndex = reorderedToModelBodyColumn(uiBodyColumn);
			
			if (isModelBodyColumnViewable(columnIndex))
				currentWidth += model.getBodyColumnWidth(columnIndex);
		}

		return currentWidth;
	}
	
	public void activateCell(final int gridRow, final int gridCol) {
		editorSupport.activateCell(gridRow, gridCol);
	}

	public RowHeightIndex getHeightIndex() {
		return visibleMetricsSupport.getHeightIndex();
	}

	// Lock handling //////////////////////////////////////////////////////////

	private ILockHandler lockHandler;

	public ILockHandler getLockHandler() {
		return lockHandler;
	}

	public void setLockHandler(final ILockHandler lockHandler) {
		this.lockHandler = lockHandler;
	}

	public void lockReadOperation() {
		if (lockHandler != null) {
			lockHandler.lockReadOperation();
		}
	}

	public void lockWriteOperation() {
		if (lockHandler != null) {
			lockHandler.lockWriteOperation();
		}
	}

	public void unlockReadOperation() {
		if (lockHandler != null) {
			lockHandler.unlockReadOperation();
		}
	}

	public void unlockWriteOperation() {
		if (lockHandler != null) {
			lockHandler.unlockWriteOperation();
		}
	}

	// Value change ///////////////////////////////////////////////////////////

	private final List<IValueChangeListener> valueChangeListeners = new ArrayList<IValueChangeListener>();

	public void addValueChangeListener(final IValueChangeListener valueChangeListener) {
		valueChangeListeners.add(valueChangeListener);
	}

	public void removeValueChangeListener(final IValueChangeListener valueChangeListener) {
		valueChangeListeners.remove(valueChangeListener);
	}

	public void fireValueChanged(final int row, final int col, final Object oldValue, final Object newValue) {
		for (final IValueChangeListener valueChangeListener : valueChangeListeners) {
			valueChangeListener.valueChanged(row, col, oldValue, newValue);
		}
	}

	// Sort direction change //////////////////////////////////////////////////

	private final List<ISortingDirectionChangeListener> sortingDirectionChangeListeners = new ArrayList<ISortingDirectionChangeListener>();

	public void addSortingDirectionChangeListener(final ISortingDirectionChangeListener sortingDirectionChangeListener) {
		sortingDirectionChangeListeners.add(sortingDirectionChangeListener);
	}

	public void removeSortingDirectionChangeListener(
			final ISortingDirectionChangeListener sortingDirectionChangeListener) {
		sortingDirectionChangeListeners.remove(sortingDirectionChangeListener);
	}

	public void fireSortingDirectionChanged(final SortingDirection[] directions) {
		for (final ISortingDirectionChangeListener sortingDirectionChangeListener : sortingDirectionChangeListeners) {
			sortingDirectionChangeListener.sortingDirectionChanged(directions);
		}
	}

	// NatTable Support ///////////////////////////////////////////////////////

	public ModeSupport getModeSupport() {
		return modeSupport;
	}
	
	public ColumnSortSupport getColumnSortSupport() {
		return columnSortSupport;
	}

	public ConflationSupport getConflationSupport() {
		return conflationSupport;
	}

	public ColumnTransformSupport getReorderSupport() {
		return columnTransformSupport;
	}

	public ColumnResizeSupport getColumnResizeSupport() {
		return columnResizeSupport;
	}
	
	public RowResizeSupport getRowResizeSupport() {
		return rowResizeSupport;
	}

	public SelectionSupport getSelectionSupport() {
		return selectionSupport;
	}
	
	public EditorSupport getEditorSupport() {
		return editorSupport;
	}

	public ColumnGroupSupport getColumnGroupSupport() {
		return columnGroupSupport;
	}

	// Pixel (x, y) to grid (row, col) coordinate conversion //////////////////

	public int getModelBodyRowByY(final int y) {
		return getModelRowByY(y, false);
	}

	public int getModelGridRowByY(final int y) {
		return getModelRowByY(y, true);
	}

	private int getModelRowByY(final int y, final boolean includeHeaderRegion) {
		int currentHeight = 0;
		// TODO Assumption is that all headers are always visible (i.e. uiRow == modelRow)
		final int columnHeaderRowCount = model.getColumnHeaderRowCount();
		for (int row = 0; row < columnHeaderRowCount; row++) {
			currentHeight += model.getColumnHeaderRowHeight(row);
			if (includeHeaderRegion) {
				if (currentHeight > y) {
					return row;
				}
			}
		}

		final int totalColumnHeaderHeight = currentHeight;

		if (y > totalColumnHeaderHeight) {
			final List<Integer> visibleModelBodyRowList = getVisibleModelBodyRows();
			final int visibleBodyRowCount = visibleModelBodyRowList.size();
			for (int row = 0; row < visibleBodyRowCount; row++) {
				final int visibleModelBodyRow = visibleModelBodyRowList.get(row).intValue();
				currentHeight += model.getBodyRowHeight(visibleModelBodyRow);
				if (currentHeight > y) {
					
					if (includeHeaderRegion) {
						return model.getColumnHeaderRowCount() + visibleModelBodyRow;
					} else {
						return visibleModelBodyRow;
					}
				}
			}
		}

		return -1;
	}

	public int getModelBodyColumnByX(final int x) {
		return getModelColumnByX(x, false);
	}

	public int getModelGridColumnByX(final int x) {
		return getModelColumnByX(x, true);
	}

	private int getModelColumnByX(final int x, final boolean includeHeaderRegion) {
		int currentWidth = 0;
		// TODO Assumption is that all headers are always visible
		final int rowHeaderColumnCount = model.getRowHeaderColumnCount();
		for (int col = 0; col < rowHeaderColumnCount; col++) {
			currentWidth += model.getRowHeaderColumnWidth(col);
			if (includeHeaderRegion) {
				if (currentWidth > x) {
					return col;
				}
			}
		}

		final int totalRowHeaderWidth = currentWidth;

		if (x > totalRowHeaderWidth) {
			final List<Integer> visibleModelBodyColList = getVisibleModelBodyColumns();
			final int visibleModelBodyColCount = visibleModelBodyColList.size();
			for (int col = 0; col < visibleModelBodyColCount; col++) {
				final int visibleModelBodyCol = visibleModelBodyColList.get(col).intValue();
				currentWidth += model.getBodyColumnWidth(visibleModelBodyCol);
				if (currentWidth > x) {
					if (includeHeaderRegion) {
						return model.getRowHeaderColumnCount() + visibleModelBodyCol;
					} else {
						return visibleModelBodyCol;
					}
				}
			}
		}

		return -1;
	}

	// Cell bounds ////////////////////////////////////////////////////////////

	/**
	 * 
	 * @param row
	 *            It doesn't include column header rows
	 * @param col
	 * @return
	 */
	public Rectangle getModelBodyCellBound(final int modelBodyRow, final int modelBodyCol) {
		return getModelCellBound(modelBodyRow, modelBodyCol, false);
	}

	public Rectangle getModelGridCellBound(final int modelGridRow, final int modelGridCol) {
		return getModelCellBound(modelGridRow, modelGridCol, true);
	}

	private Rectangle getModelCellBound(int modelRow, int modelCol, final boolean includeHeaderRegion) {
		final Rectangle rectangle = new Rectangle(0, 0, 0, 0);

		// Find Row
		int currentHeight = 0;
		// TODO Assumption is that all headers are always visible
		final int columnHeaderRowCount = model.getColumnHeaderRowCount();
		for (int r = 0; r < columnHeaderRowCount; r++) {
			final int height = model.getColumnHeaderRowHeight(r);
			if (includeHeaderRegion && r == modelRow) {
				rectangle.y = currentHeight;
				rectangle.height = height;
				break;
			} else {
				currentHeight += height;
			}
		}

		if (includeHeaderRegion) {
			modelRow -= model.getColumnHeaderRowCount();
		}

		final List<Integer> visibleBodyRowList = getVisibleModelBodyRows();
		final int visibleBodyRowCount = visibleBodyRowList.size();
		for (int r = 0; r < visibleBodyRowCount; r++) {
			int visBodyRowIndex = visibleBodyRowList.get(r).intValue();
			final int height = model.getBodyRowHeight(visBodyRowIndex);
			if (modelRow == visBodyRowIndex) {
				rectangle.y = currentHeight;
				rectangle.height = height;
				break;
			} else {
				currentHeight += height;
			}
		}

		// Find Column
		int currentWidth = 0;
		final int rowHeaderColumnCount = model.getRowHeaderColumnCount();
		for (int c = 0; c < rowHeaderColumnCount; c++) {
			final int width = model.getRowHeaderColumnWidth(c);
			if (includeHeaderRegion && c == modelCol) {
				rectangle.x = currentWidth;
				rectangle.width = width;
				break;
			} else {
				currentWidth += width;
			}
		}

		if (includeHeaderRegion) {
			modelCol -= model.getRowHeaderColumnCount();
		}

		final List<Integer> visibleModelBodyColList = getVisibleModelBodyColumns();
		final int visibleModelBodyColCount = visibleModelBodyColList.size();
		for (int c = 0; c < visibleModelBodyColCount; c++) {
			int visColumnIndex = visibleModelBodyColList.get(c).intValue();
			final int width = model.getBodyColumnWidth(visColumnIndex);
			if (modelCol == visColumnIndex) {
				rectangle.x = currentWidth;
				rectangle.width = width;
			} else {
				currentWidth += width;
			}
		}

		return rectangle;
	}

	// Column groups	
	public void addColumnGroup(final String groupName, final List<Integer> modelColumnIndices) {
		if (columnGroupSupport == null) {
			columnGroupSupport = new ColumnGroupSupport(columnTransformSupport);
			regionPainters.put(GridRegionEnum.COLUMN_HEADER, new ColumnGroupHeaderRegionPainter(this));
		}
		columnGroupSupport.addColumnGroup(groupName, modelColumnIndices);
	}

	public void addColumnGroup(final String groupName, final List<Integer> modelColumnIndices, final boolean collapse) {
		addColumnGroup(groupName, modelColumnIndices);
		
		columnGroupSupport.setExpanded(collapse, groupName);
	}

	public boolean isColumnGroupsEnabled() {
		return columnGroupSupport != null;
	}

	// Metrics Support
	private RegionMetricsSupport metricsSupport;
	
	public RegionMetricsSupport getRegionMetricsSupport() {
		if (metricsSupport == null) {
			metricsSupport = new RegionMetricsSupport();
		}
		metricsSupport.setNatTableModel(model);
		return metricsSupport;
	}
}
