package net.sourceforge.nattable.painter.region;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.INatTableModel;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.renderer.ICellRenderer;

public class DefaultBodyRegionPainter extends DefaultRegionPainter {

	private NatTable natTable;
	
	private INatTableModel model;
	
	public DefaultBodyRegionPainter(NatTable natTable) {
		super(natTable);

		this.natTable = natTable;
		this.model = natTable.getNatTableModel();
	}

	@Override
	protected ICellRenderer getCellRenderer() {
		return model.getBodyCellRenderer();
	}

	@Override
	protected int getRowHeight(int row) {
		return model.getBodyRowHeight(row);
	}

	@Override
	protected int getColumnWidth(int col) {
		return model.getBodyColumnWidth(col);
	}
	
	@Override
	protected void drawCell(GC gc, ICellRenderer cellRenderer, int visibleRow,
			int visibleCol, Rectangle rectangle, ICellPainter cellPainter) {
		boolean selected = natTable.isSelected(visibleRow, visibleCol);
		cellPainter.drawCell(gc, rectangle, natTable, cellRenderer, visibleRow, visibleCol, selected);
	}

}
