package net.sourceforge.nattable.typeconfig;

import java.util.HashMap;
import java.util.Map;

public class AbstractConfigRegistry {
	
	public AbstractConfigRegistry() {
	}
	
	public AbstractConfigRegistry(IConfigTypeResolver configTypeResolver) {
		this.configTypeResolver = configTypeResolver;
	}
	
	// ConfigTypeResolver /////////////////////////////////////////////////////
	
	private IConfigTypeResolver configTypeResolver;
	
	public IConfigTypeResolver getConfigTypeResolver() {
		return configTypeResolver;
	}
	
	public void setConfigTypeResolver(IConfigTypeResolver configTypeResolver) {
		this.configTypeResolver = configTypeResolver;
	}
	
	public String getConfigType(int modelBodyRow, int modelBodyColumn) {
		if (configTypeResolver != null) {
			return configTypeResolver.getConfigType(modelBodyRow, modelBodyColumn);
		} else {
			return null;
		}
	}

	// Inheritance ////////////////////////////////////////////////////////////

	private Map<String, String> inheritanceMap = new HashMap<String, String>();

	public String getSuperType(String configType) {
		return inheritanceMap.get(configType);
	}

	public void registerSuperType(String configType, String superType) {
		inheritanceMap.put(configType, superType);
	}

	public void unregisterSuperType(String configType) {
		inheritanceMap.remove(configType);
	}
	
	public Map<String, String> getInheritanceMap() {
		return inheritanceMap;
	}
	
}
