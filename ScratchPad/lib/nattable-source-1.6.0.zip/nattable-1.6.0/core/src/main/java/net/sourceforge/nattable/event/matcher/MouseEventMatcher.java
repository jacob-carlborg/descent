package net.sourceforge.nattable.event.matcher;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.eclipse.swt.events.MouseEvent;

public class MouseEventMatcher implements IMouseEventMatcher {
	
	private Integer stateMask;
	
	private String eventRegion;

	private Integer button;

	public MouseEventMatcher() {
		this(null, null, null);
	}
	
	public MouseEventMatcher(String eventRegion) {
		this(null, eventRegion, null);
	}
	
	public MouseEventMatcher(String eventRegion, int button) {
		this(null, eventRegion, Integer.valueOf(button));
	}
	
	public MouseEventMatcher(int stateMask, String eventRegion, int button) {
		this(Integer.valueOf(stateMask), eventRegion, Integer.valueOf(button));
	}
	
	public MouseEventMatcher(Integer stateMask, String eventRegion, Integer button) {
		this.stateMask = stateMask;
		this.eventRegion = eventRegion;
		this.button = button;
	}
	
	public Integer getStateMask() {
		return stateMask;
	}

	public String getEventRegion() {
		return eventRegion;
	}
	
	public Integer getButton() {
		return button;
	}
	
	public boolean matches(MouseEvent event, String eventRegion) {
		boolean stateMaskMatches;
		if (stateMask != null) {
			if (stateMask.intValue() != 0) {
				stateMaskMatches = (stateMask.intValue() & event.stateMask) != 0;
			} else {
				stateMaskMatches = event.stateMask == 0;
			}
		} else {
			stateMaskMatches = true;
		}
		
		boolean eventRegionMatches;
		if (this.eventRegion != null) {
			eventRegionMatches = this.eventRegion.equals(eventRegion);
		} else {
			eventRegionMatches = true;
		}
		
		boolean buttonMatches;
		if (button != null) {
			buttonMatches = button.intValue() == event.button;
		} else {
			buttonMatches = true;
		}
		
		return stateMaskMatches && eventRegionMatches && buttonMatches;
	}
	
	public boolean equals(Object obj) {
		if (obj instanceof MouseEventMatcher == false) {
			return false;
		}
		
		if (this == obj) {
			return true;
		}
		
		MouseEventMatcher rhs = (MouseEventMatcher) obj;
		
		return new EqualsBuilder()
			.appendSuper(super.equals(obj))
			.append(stateMask, rhs.stateMask)
			.append(eventRegion, rhs.eventRegion)
			.append(button, rhs.button)
			.isEquals();
	}
	
	public int hashCode() {
		return new HashCodeBuilder(43, 21)
			.append(stateMask)
			.append(eventRegion)
			.append(button)
			.toHashCode();
	}
	
}
