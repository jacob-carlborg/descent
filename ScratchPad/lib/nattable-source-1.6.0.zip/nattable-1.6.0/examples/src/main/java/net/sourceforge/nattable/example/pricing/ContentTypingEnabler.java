package net.sourceforge.nattable.example.pricing;

import java.text.DecimalFormat;

import net.sourceforge.nattable.data.IDataValidator;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.IDisplayTypeConverter;
import net.sourceforge.nattable.typeconfig.content.IEditableRule;

public class ContentTypingEnabler {
	private String[] contentTypes = new String[]{"prcUp", "yldUp", "frmt"};
	public void enableContentTyping(ContentConfigRegistry contentRegistry, IRowDataProvider<PricingDataBean> rowDataProvider) {
		ContentConfigTypeResolver typeResolver = new ContentConfigTypeResolver(rowDataProvider);
		contentRegistry.setConfigTypeResolver(typeResolver);
		
		enableEditing(contentRegistry);
		enableDisplayConverters(contentRegistry);		
	}

	void enableEditing(ContentConfigRegistry contentRegistry) {

		ManualPriceEditRule priceData = new ManualPriceEditRule();
		contentRegistry.registerEditableRule(contentTypes[0], priceData);
		enableDataValidation(contentRegistry, contentTypes[0], priceData);
		
		ManualYieldEditRule yieldData = new ManualYieldEditRule();
		contentRegistry.registerEditableRule(contentTypes[1], yieldData);
		enableDataValidation(contentRegistry, contentTypes[1], yieldData);
	}

	void enableDisplayConverters(ContentConfigRegistry contentRegistry) {
		DoubleDisplayTypeConverter dblConverter = new DoubleDisplayTypeConverter();
		contentRegistry.registerDisplayTypeConverter(contentTypes[2], dblConverter);
		contentRegistry.registerDisplayTypeConverter(contentTypes[0], dblConverter);
		contentRegistry.registerDisplayTypeConverter(contentTypes[1], dblConverter);
	}
	
	void enableDataValidation(ContentConfigRegistry contentRegistry, String configType, IDataValidator validator) {
		contentRegistry.registerValidator(configType, validator);
	}
	
	public String[] getContentTypes() {
		return contentTypes;
	}
	
	class ManualPriceEditRule implements IEditableRule, IDataValidator {

		public boolean isEditable(int row, int col) {
			if (col == 1 || col == 2 || col == 6 || col == 9) {
				return true;
			}
			return false;
		}
		
		public boolean validate(Object oldValue, Object newValue) {
			if(newValue instanceof String) {
				try {
					newValue = Double.valueOf(Double.parseDouble((String)newValue));
				} catch(Exception e) {
					return false;
				}
			}
			return ((Double)newValue).doubleValue() > 0;
		}
	}

	class ManualYieldEditRule implements IEditableRule, IDataValidator {

		public boolean isEditable(int row, int col) {
			if (col == 4 || col == 5) {
				return true;
			}
			return false;
		}
		
		public boolean validate(Object oldValue, Object newValue) {
			if(newValue instanceof String) {
				try {
					newValue = Double.valueOf(Double.parseDouble((String)newValue));
				} catch(Exception e) {
					return false;
				}
			}
			return ((Double)newValue).doubleValue() > 0;
		}
	}

	class DoubleDisplayTypeConverter implements IDisplayTypeConverter {
		private DecimalFormat displayFormat = new DecimalFormat("###,##0.##");
		private DecimalFormat dataFormat = new DecimalFormat("###,##0.####################");

		public Object dataValueToDisplayValue(Object dataValue) {
			return dataValue != null && (dataValue instanceof Double) ? displayFormat.format(((Double) dataValue).doubleValue()) : dataValue;
		}

		public Object displayValueToDataValue(Object displayValue) {
			return !(displayValue instanceof Double) ? dataFormat.format((new Double((String) displayValue)).doubleValue()) : displayValue;
		}

	}
}