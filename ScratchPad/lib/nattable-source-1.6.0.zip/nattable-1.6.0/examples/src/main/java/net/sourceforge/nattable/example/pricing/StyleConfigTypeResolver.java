package net.sourceforge.nattable.example.pricing;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.typeconfig.DelegatingConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.TypedCellOverrider;
import net.sourceforge.nattable.typeconfig.TypedRowOverrider;

class StyleConfigTypeResolver extends DelegatingConfigTypeResolver {
	public static Map<String, String> priceModelStyles;
	
	private DelegatingConfigTypeResolver delegatingResolver;
	private IRowDataProvider<PricingDataBean> rowDataProvider;
	private TypedCellOverrider<PricingDataBean> cellOverrider;
	private TypedRowOverrider<PricingDataBean> rowOverrider;	
	private String[] styleTypes;

	public StyleConfigTypeResolver(IRowDataProvider<PricingDataBean> dataProvider, TypedCellOverrider<PricingDataBean> cellOverrider, TypedRowOverrider<PricingDataBean> rowOverrider) {
		this.rowDataProvider = dataProvider;
		this.cellOverrider = cellOverrider;
		this.rowOverrider = rowOverrider;
		
		//load types		
		styleTypes = new String[]{"manual_price_based_style",
			"manual_yield_based_style",
			"yss_based_style",
			"att_based_style"};
		
		//map types to cell values
		priceModelStyles = new HashMap<String, String>();
		priceModelStyles.put("MANUAL_PRICE", styleTypes[0]);		
		priceModelStyles.put("MANUAL_YIELD", styleTypes[1]);
		priceModelStyles.put("Y_SS", styleTypes[2]);
		priceModelStyles.put("ATT", styleTypes[3]);
	}

	public String[] getStyleTypes() {
		return styleTypes;
	}
	
	public void decorateTypeResolver(IConfigTypeResolver typeResolver) {
		if(delegatingResolver == null) {
			delegatingResolver = new DelegatingConfigTypeResolver(typeResolver);
		} else {
			delegatingResolver = new DelegatingConfigTypeResolver(delegatingResolver, typeResolver);
		}
	}
	
	public String getConfigType(int modelBodyRow, int modelBodyColumn) {
		if (cellOverrider != null) {
			String configType = null;
			if ((configType = cellOverrider.getConfigType(modelBodyRow, modelBodyColumn)) != null) {
				return configType;
			}
		}
		if (rowOverrider != null) {
			String configType = null;
			if ((configType = rowOverrider.getConfigType(modelBodyRow, modelBodyColumn)) != null) {
				return configType;
			}
		}
		PricingDataBean rowObj = rowDataProvider.getRowObject(modelBodyRow);
		if (rowObj.getErrorSeverity() >= 2) {
			return "error_style";
		}
		if (modelBodyColumn == ColumnHeaders.FOUR.ordinal()) {
			String key = rowDataProvider.getValue(modelBodyRow, modelBodyColumn).toString();
			if (priceModelStyles.containsKey(key)) {
				return priceModelStyles.get(key);
			}
		}
		return delegatingResolver != null ? delegatingResolver.getConfigType(modelBodyRow, modelBodyColumn) : null;
	}

	public TypedCellOverrider<PricingDataBean> getCellOverrider() {
		return cellOverrider;
	}
	
	public void registerCellOverride(Object cellValue, int col, String configType) {
		cellOverrider.registerOverride(cellValue, col, configType);
	}

	public void removeCellOverride(Serializable key) {
		cellOverrider.removeOverride(key);
	}
	
	public TypedRowOverrider<PricingDataBean> getRowOverrider() {
		return rowOverrider;
	}

	public void registerRowOverride(String value, int row) {
		rowOverrider.registerOverride(value, row);
	}

	public void removeRowOverride(Serializable key) {
		rowOverrider.removeOverride(key);
	}
}