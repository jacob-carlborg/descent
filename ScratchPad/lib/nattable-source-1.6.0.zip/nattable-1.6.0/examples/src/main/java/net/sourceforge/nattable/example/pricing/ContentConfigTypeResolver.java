package net.sourceforge.nattable.example.pricing;

import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;

class ContentConfigTypeResolver implements IConfigTypeResolver {
	public static Map<String, String> pricingContentTypes = new HashMap<String,String>();
	private IRowDataProvider<PricingDataBean> rowDataProvider;	

	ContentConfigTypeResolver(IRowDataProvider<PricingDataBean> rowDataProvider) {
		this.rowDataProvider = rowDataProvider;
		pricingContentTypes.put("MANUAL_PRICE", "prcUp");
		pricingContentTypes.put("MANUAL_YIELD", "yldUp");
	}

	public String getConfigType(int modelBodyRow, int modelBodyColumn) {
		PricingDataBean rowObj = rowDataProvider.getRowObject(modelBodyRow);
		if(ColumnHeaders.values()[modelBodyColumn].getType().getSuperclass().equals(Number.class))  {
			if(pricingContentTypes.containsKey(rowObj.getPricingModel())) {
				return pricingContentTypes.get(rowObj.getPricingModel());
			}
			return "frmt";
		}
		
		return null;
	}
}