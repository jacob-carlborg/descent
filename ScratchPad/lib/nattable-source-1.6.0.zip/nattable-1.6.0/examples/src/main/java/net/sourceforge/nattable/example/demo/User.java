package net.sourceforge.nattable.example.demo;

import java.util.Date;

import net.sourceforge.nattable.example.test.TestTableModel;

import org.eclipse.swt.graphics.Image;

/**
 * Author : Andy Tsoi<br>
 */
public class User {
	String name;

	String password;

	long birthday;

	int userID;

	Image image = TestTableModel.image;

	public Image getImage() {
		return image;
	}

	public void setImage(final Image image) {
		this.image = image;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(final int userID) {
		this.userID = userID;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 * 		the name to set
	 */
	public void setName(final String name) {
		this.name = name;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 * 		the password to set
	 */
	public void setPassword(final String password) {
		this.password = password;
	}

	/**
	 * @return the birthday
	 */
	public Date getBirthday() {
		return new Date(birthday);
	}

	/**
	 * @param birthday
	 * 		the birthday to set
	 */
	public void setBirthday(final long birthday) {
		this.birthday = birthday;
	}

}
