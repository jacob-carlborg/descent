package net.sourceforge.nattable.example.snippets;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.model.DefaultNatTableModel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Snippet008ListDataProvider {

	private DateFormat dateFormat = new SimpleDateFormat();
	
	public static void main(String args[]) {
		new Snippet008ListDataProvider();
	}
	
	private Snippet008ListDataProvider() {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display, SWT.SHELL_TRIM);
			shell.setLayout(new FillLayout());
			
			setupNatTable(shell);
			
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void setupNatTable(Composite parent) throws Exception {
		DefaultNatTableModel model = new DefaultNatTableModel();

		// Body
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(15298, "John", "Smith", dateFormat.parse("05/31/1971 00:00 AM, GMT")));
		list.add(new Employee(19875, "Steve", "Miller", dateFormat.parse("06/30/1980 00:00 AM, GMT")));
		list.add(new Employee(59281, "Mary", "Martin", dateFormat.parse("11/22/1949 00:00 AM, GMT")));
		list.add(new Employee(23479, "Jane", "Doe", dateFormat.parse("02/19/1965 00:00 AM, GMT")));
		list.add(new Employee(10983, "Joe", "Porter", dateFormat.parse("10/18/1985 00:00 AM, GMT")));
		
		IColumnAccessor<Employee> columnAccessor = new IColumnAccessor<Employee>() {

			public int getColumnCount() {
				return 4;
			}

			public Object getColumnValue(Employee rowObj, int col) {
				switch (col) {
				case 0:
					return Integer.valueOf(rowObj.employeeId);
				case 1:
					return rowObj.firstName;
				case 2:
					return rowObj.lastName;
				case 3:
					return rowObj.dateOfBirth;
				}
				return null;
			}
			
		};
		
		IDataProvider dataProvider = new ListDataProvider<Employee>(list, columnAccessor);
		model.setBodyConfig(new DefaultBodyConfig(dataProvider));
		
		// NatTable
		new NatTable(
				parent,
				SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL,
				model
		);
	}
	
	private class Employee {
		
		int employeeId;
		
		String firstName;
		
		String lastName;
		
		Date dateOfBirth;
		
		public Employee(int employeeId, String firstName, String lastName, Date dateOfBirth) {
			this.employeeId = employeeId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.dateOfBirth = dateOfBirth;
		}
		
	}
	
}
