package net.sourceforge.nattable.example.demo.excel;

import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.ColumnSelectionBehaviorEnum;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.editor.TextCellEditor;
import net.sourceforge.nattable.listener.IValueChangeListener;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.painter.cell.HeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.painter.cell.TextCellPainter;
import net.sourceforge.nattable.renderer.AbstractCellRenderer;
import net.sourceforge.nattable.renderer.ICellRenderer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��18��<br>
 */
public class ExcelTableModel extends DefaultNatTableModel {
	Map<String, String> values = new HashMap<String, String>();
	
	public ExcelTableModel() {
		final DefaultColumnHeaderConfig columnHeaderConfig = new DefaultColumnHeaderConfig( new IColumnHeaderLabelProvider() {

			public String getColumnHeaderLabel(int col) {
				return String.valueOf(((char) (col + 65)));
			}		
		});
		columnHeaderConfig.setColumnHeaderRowCount(1);
		columnHeaderConfig.setColumnHeaderRowHeightConfig(new SizeConfig(20));
		setColumnHeaderConfig(columnHeaderConfig);
		
		final DefaultRowHeaderConfig rowHeaderConfig = new DefaultRowHeaderConfig();
		rowHeaderConfig.setRowHeaderColumnCount(1);
		rowHeaderConfig.setRowHeaderColumnWidthConfig(new SizeConfig(20));
		rowHeaderConfig.setCellRenderer(rowHeaderCellRenderer);
		setRowHeaderConfig(rowHeaderConfig);
		
		final DefaultBodyConfig bodyConfig = new DefaultBodyConfig(new IDataProvider() {

			public int getColumnCount() {
				return 26;
			}

			public int getRowCount() {
				return 60000;
			}

			public Object getValue(int row, int col) {
				Object obj = values.get(row + "" + col);

				return obj != null ? obj.toString() : "";
			}
			
		});
		bodyConfig.setRowHeightConfig(new SizeConfig(30));
		bodyConfig.setColumnWidthConfig(new SizeConfig(100));
		bodyConfig.setCellRenderer(bodyCellRenderer);
		setBodyConfig(bodyConfig);
	}
	
	// Corner /////////////////////////////////////////////////////////////////

	public ICellRenderer getCornerCellRenderer() {
		return null;
	}

	AbstractCellRenderer rowHeaderCellRenderer = new AbstractCellRenderer() {
		HeaderCellPainter rowHeaderCellPainter = new HeaderCellPainter(SWT.CENTER | SWT.FLAT);

		public String getDisplayText(int row, int col) {
			return (row + 1) + "";
		}

		public Object getValue(int row, int col) {
			return null;
		}

		@Override
		public ICellPainter getCellPainter(int row, int col) {
			return rowHeaderCellPainter;
		}

		@Override
		public ICellEditor getCellEditor(int row, int col) {
			return null;
		}

		@Override
		public boolean isEditable(int row, int col) {
			return false;
		}
	};


	// Body ///////////////////////////////////////////////////////////////////
	
	AbstractCellRenderer bodyCellRenderer = new AbstractCellRenderer() {
		TextCellPainter cellPainter = new TextCellPainter(SWT.LEFT);
		TextCellEditor textCellEditor = new TextCellEditor() {
			@Override
			protected Text createTextControl(Composite control) {
				final Text text = new Text(control, SWT.BORDER | SWT.MULTI);

				return text;
			}
		};

		public String getDisplayText(int row, int col) {
			Object obj = values.get(row + "" + col);

			return obj != null ? obj.toString() : "";
		}

		public Object getValue(int row, int col) {
			Object obj = values.get(row + "" + col);

			return obj != null ? obj.toString() : "";
		}

		@Override
		public ICellPainter getCellPainter(int row, int col) {
			return cellPainter;
		}

		@Override
		public ICellEditor getCellEditor(int row, int col) {
			return textCellEditor;
		}

		@Override
		public boolean isEditable(int row, int col) {
			return true;
		}
	};

	// Grid ///////////////////////////////////////////////////////////////////

	public boolean isMoveColumnEnabled() {
		return false;
	}

	public boolean isFullRowSelection() {
		return true;
	}

	public boolean isMultpleSelection() {
		return true;
	}

	public boolean isSingleCellSelection() {
		return false;
	}

	public void attachListeners(NatTable natTable) {
		natTable.addValueChangeListener(new IValueChangeListener() {

			public void valueChanged(int row, int col, Object oldValue, Object newValue) {
				values.put(row + "" + col, newValue.toString());
			}

		});
	}

	public ColumnSelectionBehaviorEnum getColumnSelectionBehavior() {
		return ColumnSelectionBehaviorEnum.SINGLE_CLICK_SELECTION_DOUBLE_CLICK_SORTING;
	}

}
