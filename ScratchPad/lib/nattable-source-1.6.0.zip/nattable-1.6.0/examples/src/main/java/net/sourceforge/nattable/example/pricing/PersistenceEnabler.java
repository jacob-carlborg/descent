package net.sourceforge.nattable.example.pricing;

import java.io.IOException;

import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.DefaultNatTableModel;

public class PersistenceEnabler implements DisposeListener{

	private NatTable natTable;
	private StyleConfigTypeResolver styleTypeResolver;
	
	PersistenceEnabler(StyleConfigTypeResolver styleTypeResolver, NatTable natTable) {
		this.natTable = natTable;
		this.styleTypeResolver = styleTypeResolver;
	}
	
	public void persistSettings() {
		try {
			PersistableObjectsAccessor.persistNatTable(natTable);
			PersistableObjectsAccessor.persistNatTableModel((DefaultNatTableModel)natTable.getNatTableModel());
			PersistableObjectsAccessor.persistStyleConfigRegistry(natTable.getNatTableModel().getStyleConfigRegistry(), styleTypeResolver.getCellOverrider(), styleTypeResolver.getRowOverrider());
			if(natTable.getColumnGroupSupport() != null) {
				PersistableObjectsAccessor.persistColumnGroups(natTable.getColumnGroupSupport());
			}
			
		} catch (IOException e1) {
			e1.printStackTrace();
		} 
	}

	public void widgetDisposed(DisposeEvent e) {
		persistSettings();
	}
}
