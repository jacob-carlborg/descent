package net.sourceforge.nattable.example.test;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~9��23��<br>
 */
public class Tests extends Shell {

	/**
	 * Launch the application
	 * 
	 * @param args
	 */
	public static void main(String args[]) {
		try {
			Display display = Display.getDefault();
			Tests shell = new Tests(display, SWT.SHELL_TRIM);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the shell
	 * 
	 * @param display
	 * @param style
	 */
	public Tests(Display display, int style) {
		super(display, style);
		createContents();
		setLayout(new FillLayout());
	}

	/**
	 * Create contents of the window
	 */
	protected void createContents() {
		setText("SWT Application");
		setSize(500, 375);

		final Canvas canvas = new Canvas(this, SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED
				| SWT.V_SCROLL | SWT.H_SCROLL);

		canvas.getVerticalBar().setThumb(10000);
		canvas.getVerticalBar().setIncrement(10);
		canvas.getVerticalBar().setMaximum(100);
		canvas.getVerticalBar().setMinimum(0);
		//
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
