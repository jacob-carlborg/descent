package net.sourceforge.nattable.example.snippets;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.model.DefaultNatTableModel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * Demonstrates a custom column header label provider.
 */
public class Snippet002ColumnHeaderLabels {

	public static void main(String args[]) {
		new Snippet002ColumnHeaderLabels();
	}
	
	private Snippet002ColumnHeaderLabels() {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display, SWT.SHELL_TRIM);
			shell.setLayout(new FillLayout());
			
			setupNatTable(shell);
			
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void setupNatTable(Composite parent) {
		DefaultNatTableModel model = new DefaultNatTableModel();
		
		// Column Headers
		IColumnHeaderLabelProvider columnHeaderLabelProvider = new IColumnHeaderLabelProvider() {

			public String getColumnHeaderLabel(int col) {
				char c = (char) ('A' + col);
				return "[ " + c + " ]";
			}
			
		};
		model.setColumnHeaderConfig(new DefaultColumnHeaderConfig(columnHeaderLabelProvider));
		
		// NatTable
		new NatTable(
				parent,
				SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL,
				model
		);
	}
	
}
