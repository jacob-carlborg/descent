package net.sourceforge.nattable.example.snippets;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.DefaultNatTableModel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * Shows the minimal configuration needed to construct a NatTable instance. 
 */
public class Snippet001MinimalNatTable {

	public static void main(String args[]) {
		new Snippet001MinimalNatTable();
	}
	
	private Snippet001MinimalNatTable() {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display, SWT.SHELL_TRIM);
			shell.setLayout(new FillLayout());
			
			setupNatTable(shell);
			
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void setupNatTable(Composite parent) {
		// NatTable
		new NatTable(
				parent,
				SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL,
				new DefaultNatTableModel()
		);
	}
	
}
