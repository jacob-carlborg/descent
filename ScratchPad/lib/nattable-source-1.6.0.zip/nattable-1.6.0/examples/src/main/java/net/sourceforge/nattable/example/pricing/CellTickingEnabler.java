package net.sourceforge.nattable.example.pricing;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.event.KeyBinding;
import net.sourceforge.nattable.event.matcher.LetterOrDigitKeyMatcher;
import net.sourceforge.nattable.extension.action.TickAction;
import net.sourceforge.nattable.extension.event.matcher.TickKeyMatcher;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.support.BulkCellUpdateSupport;
import net.sourceforge.nattable.support.ColumnTransformSupport;
import net.sourceforge.nattable.support.EventBindingSupport;
import net.sourceforge.nattable.support.IClientAreaProvider;

import org.eclipse.swt.widgets.Shell;

public class CellTickingEnabler {
	private TickableUpdateHandler tickHandler;
	
	CellTickingEnabler(SelectionModel selectionModel, ColumnTransformSupport columnReorderSupport, DataUpdateHelper<PricingDataBean> helper, List<PricingDataBean> data, IClientAreaProvider clientAreaProvider) {
		tickHandler = new TickableUpdateHandler(selectionModel, columnReorderSupport, helper, data, clientAreaProvider);
	}
	
	public void enableTicking(EventBindingSupport eventBindingSupport, Shell shell, BulkCellUpdateSupport<PricingDataBean> cellUpdateSupport) {
		List<KeyBinding> bindingsToReset = new ArrayList<KeyBinding>();
		boolean found = false;
		
		for (KeyBinding binding : eventBindingSupport.getKeyBindings()) {
			if (binding.getKeyEventMatcher() instanceof LetterOrDigitKeyMatcher) {
				found = true;
			}
			
			if (found) {
				eventBindingSupport.unregisterKeyBinding(binding);
				bindingsToReset.add(binding);
			}
		}
		
		eventBindingSupport.registerKeyBinding(new TickKeyMatcher(tickHandler), new TickAction(shell, cellUpdateSupport, tickHandler));
		
		for (KeyBinding binding : bindingsToReset) {
			eventBindingSupport.registerKeyBinding(binding.getKeyEventMatcher(), binding.getAction());
		}
		
		bindingsToReset.clear();
	}
}