package net.sourceforge.nattable.example.idol;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ListIterator;
import java.util.Random;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.IColumnHeaderConfig;
import net.sourceforge.nattable.config.IRowHeaderConfig;
import net.sourceforge.nattable.data.ColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnAccessor;
import net.sourceforge.nattable.extension.glazedlists.EventNatTableViewer;
import net.sourceforge.nattable.extension.glazedlists.NatColumnTableFormat;
import net.sourceforge.nattable.extension.glazedlists.NatTableComparatorChooser;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.typeconfig.ClassNameConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.AlternateRowColoringStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.ObservableElementList;
import ca.odell.glazedlists.SortedList;

public class ObservableElementListExample {

    public static class AmericanIdol {
        private String name;
        private int votes;

        private final PropertyChangeSupport support = new PropertyChangeSupport(this);

        public AmericanIdol(String name) {
            this.name = name;
        }

        public void addPropertyChangeListener(PropertyChangeListener l) {
            support.addPropertyChangeListener(l);
        }

        public void removePropertyChangeListener(PropertyChangeListener l) {
            support.removePropertyChangeListener(l);
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            final String oldName = this.name;
            this.name = name;
            support.firePropertyChange("name", oldName, name);
        }

        public int getVotes() {
            return votes;
        }

        public void setVotes(int votes) {
            final int oldVotes = this.votes;
            this.votes = votes;
            support.firePropertyChange("votes", oldVotes, votes);
        }

        public void incrementVotes() {
            setVotes(getVotes() + 1);
        }
    }

    public static void main(String[] args) throws Exception {
    	new ObservableElementListExample();
    }
    
    public ObservableElementListExample() throws Exception {
        // create an EventList of AmericanIdols
        EventList<AmericanIdol> idols = GlazedLists.threadSafeList(new BasicEventList<AmericanIdol>());
        idols.add(new AmericanIdol("Simon Cowell"));
        idols.add(new AmericanIdol("Paula Abdul"));
        idols.add(new AmericanIdol("Randy Jackson"));
        idols.add(new AmericanIdol("Ryan Seacrest"));

        ObservableElementList.Connector<AmericanIdol> idolConnector = GlazedLists.beanConnector(AmericanIdol.class);
        EventList<AmericanIdol> observedIdols = new ObservableElementList<AmericanIdol>(idols, idolConnector);

        // build a NatTable
		final Display display = new Display();
		Shell shell = new Shell(display);
		shell.setSize(1000, 300);
		shell.setLayout(new GridLayout(1, true));

		Composite tableComposite = new Composite(shell, SWT.NONE);
		tableComposite.setLayout(new FillLayout());
		final GridData tableData = new GridData(SWT.FILL, SWT.FILL, true, true);
		tableComposite.setLayoutData(tableData);
		
        String[] propertyNames = {"name", "votes"};
        String[] columnLabels = {"Name", "Votes"};
        
		SortedList<AmericanIdol> sortedRows = new SortedList<AmericanIdol>(observedIdols, null);

		NatTable natTable = setupNatTable(
        		tableComposite,
				sortedRows,
				columnLabels,
				new ReflectiveColumnAccessor<AmericanIdol>(propertyNames)
        );
        
		EventNatTableViewer<AmericanIdol> eventNatTableViewer = new EventNatTableViewer<AmericanIdol>(sortedRows, natTable, false);
        
        new Thread(new MyRunnable(idols)).start();

		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		eventNatTableViewer.dispose();
		display.dispose();
    }
    
	@SuppressWarnings("unchecked")
	private NatTable setupNatTable(Composite parent, SortedList rowData, String[] columnHeaderLabels, IColumnAccessor columnAccessor) {
		IRowDataProvider dataProvider = new ListDataProvider(rowData, columnAccessor);
		
		// column header
		IColumnHeaderConfig colHeaderConfig = new DefaultColumnHeaderConfig(new ColumnHeaderLabelProvider(columnHeaderLabels));
		
		// row header
		IRowHeaderConfig rowHeaderConfig = new DefaultRowHeaderConfig();
		
		// content config registry
		ContentConfigRegistry contentConfigRegistry = new ContentConfigRegistry();
		
		// style config registry
		StyleConfigRegistry styleConfigRegistry = new StyleConfigRegistry(new ClassNameConfigTypeResolver(dataProvider));
		styleConfigRegistry.registerDefaultStyleConfig(DisplayModeEnum.NORMAL.toString(), new AlternateRowColoringStyleConfig());
		
		// body
		DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider, contentConfigRegistry, styleConfigRegistry);
		
		// table
		DefaultNatTableModel natModel = new DefaultNatTableModel(null, colHeaderConfig, rowHeaderConfig, bodyConfig);
		natModel.setSortingEnabled(true);
		natModel.setSingleCellSelection(true);
		natModel.setEnableMoveColumn(true);
		
		NatTable natTable = new NatTable(
				parent,
				SWT.BORDER | SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL,
				natModel);
		
		natTable.addSortingDirectionChangeListener(
				new NatTableComparatorChooser(
						rowData,
						new NatColumnTableFormat(columnHeaderLabels, columnAccessor, contentConfigRegistry)
				)
		);
		
		return natTable;
	}	
    
    private class MyRunnable implements Runnable {

    	private EventList<AmericanIdol> idols;
    	
    	public MyRunnable(EventList<AmericanIdol> idols) {
    		this.idols = idols;
		}
    	
		public void run() {
			try {
		        // vote one idol off each episode
		        while (idols.size() > 1) {
		            // clear the votes
		            for (ListIterator<AmericanIdol> i = idols.listIterator(); i.hasNext();) {
		                AmericanIdol idol = i.next();
		                idol.setVotes(0);
		                Thread.sleep(300);
		            }
	
		            // simulating voting
		            long quittingTime = System.currentTimeMillis() + 5000;
		            Random dice = new Random();
		            while (System.currentTimeMillis() < quittingTime) {
		                int index = dice.nextInt(idols.size());
		                AmericanIdol idol = idols.get(index);
		                idol.incrementVotes();
		                Thread.sleep(100);
		            }
	
		            // find the idol with least votes
		            AmericanIdol votedOff = idols.get(0);
		            for (AmericanIdol idol : idols) {
		                if (idol.getVotes() < votedOff.getVotes())
		                    votedOff = idol;
		            }
	
		            // vote off the idol with the least votes
		            Thread.sleep(1000);
		            idols.remove(votedOff);
		            Thread.sleep(1000);
		        }
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
    	
    }

}