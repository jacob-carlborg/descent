package net.sourceforge.nattable.example.demo.glazedlists;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.IColumnHeaderConfig;
import net.sourceforge.nattable.config.IRowHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.ColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.editor.TextCellEditor;
import net.sourceforge.nattable.example.demo.User;
import net.sourceforge.nattable.extension.glazedlists.NatColumnTableFormat;
import net.sourceforge.nattable.extension.glazedlists.NatTableComparatorChooser;
import net.sourceforge.nattable.listener.IValueChangeListener;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.ReadOnlyDisplayTypeConverter;
import net.sourceforge.nattable.typeconfig.style.AlternateRowColoringStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.widgets.Display;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.matchers.Matcher;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��17��<br>
 */
public class GlazedListsTableModel extends DefaultNatTableModel {

	org.eclipse.swt.graphics.Image image = new org.eclipse.swt.graphics.Image(Display.getDefault(),
			GlazedListsTableModel.class.getClassLoader().getResourceAsStream("icon.gif"));

	BasicEventList<User> basicEventList = new BasicEventList<User>();

	FilterList<User> filterList = new FilterList<User>(basicEventList);

	SortedList<User> sortedList = new SortedList<User>(filterList, null);

	private final DateFormat dateFormat = DateFormat.getInstance();

	private final String[] columnNames;

	private final IColumnAccessor<User> columnAccessor;

	public GlazedListsTableModel() {
		columnNames = new String[GlazedListsColumnEnum.values().length];
		int i = 0;
		for (final GlazedListsColumnEnum glColEnum : GlazedListsColumnEnum.values()) {
			columnNames[i] = glColEnum.toString();
			i++;
		}

		columnAccessor = new IColumnAccessor<User>() {

			public Object getColumnValue(final User user, final int col) {
				switch (GlazedListsColumnEnum.getColumn(col)) {
				case BIRTHDAY:
					return user.getBirthday();
				case NAME:
					return user.getName();
				case PASSWORD:
					return user.getPassword();
				case USER_ID:
					return Integer.valueOf(user.getUserID());
				case IMAGE:
					return user.getImage();
				}
				return null;
			}
			
			public int getColumnCount() {
				return GlazedListsColumnEnum.values().length;
			}

		};

		// Column header

		final IColumnHeaderConfig columnHeaderConfig = new DefaultColumnHeaderConfig(new ColumnHeaderLabelProvider(
				columnNames));
		columnHeaderConfig.getColumnHeaderRowHeightConfig().setDefaultSize(20);

		setColumnHeaderConfig(columnHeaderConfig);

		// Row header

		final IRowHeaderConfig rowHeaderConfig = new DefaultRowHeaderConfig();
		setRowHeaderConfig(rowHeaderConfig);

		// body configuration

		final IDataProvider dataProvider = new ListDataProvider<User>(sortedList, columnAccessor);
		
		ContentConfigRegistry contentConfigRegistry = new ContentConfigRegistry(new IConfigTypeResolver() {

			public String getConfigType(int modelBodyRow, int modelBodyColumn) {
				return GlazedListsColumnEnum.getColumn(modelBodyColumn).toString();
			}
			
		});
		TextCellEditor textCellEditor = new TextCellEditor();
		contentConfigRegistry.registerDefaultCellEditor(textCellEditor);
		contentConfigRegistry.registerDisplayTypeConverter(GlazedListsColumnEnum.BIRTHDAY.toString(), new ReadOnlyDisplayTypeConverter() {

			public Object dataValueToDisplayValue(Object dataValue) {
				return dateFormat.format(dataValue);
			}
			
		});
		contentConfigRegistry.registerDisplayTypeConverter(GlazedListsColumnEnum.IMAGE.toString(), new ReadOnlyDisplayTypeConverter() {

			public Object dataValueToDisplayValue(Object dataValue) {
				return "";
			}
			
		});
		
		StyleConfigRegistry styleConfigRegistry = new StyleConfigRegistry();
		styleConfigRegistry.registerDefaultStyleConfig(DisplayModeEnum.NORMAL.toString(), new AlternateRowColoringStyleConfig());

		final DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider, contentConfigRegistry, styleConfigRegistry);
		setBodyConfig(bodyConfig);
		
		final SizeConfig columnWidthConfig = bodyConfig.getColumnWidthConfig();
		columnWidthConfig.setDefaultSize(100);
		for (final GlazedListsColumnEnum columnEnum : GlazedListsColumnEnum.values()) {
			columnWidthConfig.setSize(columnEnum.ordinal(), columnEnum.width);
		}
		columnWidthConfig.setDefaultResizable(true);
		
		bodyConfig.getRowHeightConfig().setDefaultSize(20);

		// table configuration

		setSortingEnabled(true);
		setEnableMoveColumn(true);
		setFullRowSelection(true);
		setMultipleSelection(true);
	}

	public void attachListeners(final NatTable natTable) {
		natTable.addValueChangeListener(new IValueChangeListener() {

			public void valueChanged(final int row, final int col, final Object oldValue, final Object newValue) {
				final GlazedListsColumnEnum columnEnum = GlazedListsColumnEnum.getColumn(col);
				switch (columnEnum) {
				case NAME:
					sortedList.get(row).setName(newValue.toString());
					break;
				case PASSWORD:
					sortedList.get(row).setPassword(newValue.toString());
					break;
				case USER_ID:
					sortedList.get(row).setUserID(Integer.parseInt(newValue.toString()));
					break;
				}
			}

		});

		natTable.addSortingDirectionChangeListener(new NatTableComparatorChooser<User>(sortedList,
				new NatColumnTableFormat<User>(columnNames, columnAccessor, null)));
	}

	public void setFilter(final NatTable natTable, final Matcher<User> matcher) {
		filterList.setMatcher(matcher);
		natTable.updateResize();
	}

	/**
	 * @return the userList
	 */
	public List<User> getUserList() {
		return new ArrayList<User>(basicEventList);
	}

	/**
	 * @param userList
	 * 		the userList to set
	 */
	public void setUserList(final List<User> userList) {
		basicEventList.addAll(userList);
	}

	public void addUser(final User user) {
		basicEventList.add(user);
	}

}
