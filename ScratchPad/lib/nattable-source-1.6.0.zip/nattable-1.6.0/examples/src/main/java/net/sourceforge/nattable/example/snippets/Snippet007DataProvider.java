package net.sourceforge.nattable.example.snippets;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.model.DefaultNatTableModel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Snippet007DataProvider {

	public static void main(String args[]) {
		new Snippet007DataProvider();
	}
	
	private Snippet007DataProvider() {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display, SWT.SHELL_TRIM);
			shell.setLayout(new FillLayout());
			
			setupNatTable(shell);
			
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void setupNatTable(Composite parent) {
		DefaultNatTableModel model = new DefaultNatTableModel();

		// Body
		IDataProvider dataProvider = new IDataProvider() {

			public int getColumnCount() {
				return 5;
			}

			public int getRowCount() {
				return 10;
			}

			public Object getValue(int row, int col) {
				return row + ":" + col;
			}
			
		};
		model.setBodyConfig(new DefaultBodyConfig(dataProvider));
		
		// NatTable
		new NatTable(
				parent,
				SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL,
				model
		);
	}
	
}
