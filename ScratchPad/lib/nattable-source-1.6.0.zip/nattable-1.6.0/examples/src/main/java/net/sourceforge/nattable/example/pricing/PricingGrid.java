package net.sourceforge.nattable.example.pricing;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.GridRegionEnum;
import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.DefaultBulkUpdateSupport;
import net.sourceforge.nattable.data.IDataValidator;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.data.pricing.PricingDataBeanGenerator;
import net.sourceforge.nattable.event.matcher.MouseEventMatcher;
import net.sourceforge.nattable.extension.copypaste.CopyPasteEventListener;
import net.sourceforge.nattable.extension.copypaste.CopyPasteSupport;
import net.sourceforge.nattable.extension.copypaste.IPasteExecutionSupport;
import net.sourceforge.nattable.extension.dialog.SearchDialog;
import net.sourceforge.nattable.extension.glazedlists.EventNatTableViewer;
import net.sourceforge.nattable.extension.glazedlists.NatColumnTableFormat;
import net.sourceforge.nattable.extension.glazedlists.NatTableComparatorChooser;
import net.sourceforge.nattable.listener.IValueChangeListener;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.support.BulkCellUpdateSupport;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.graphics.DeviceData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

public class PricingGrid {
	private Shell shell;
	private NatTable natTable;
	private PricingDataAccessor dataAccessor;
	private PersistenceEnabler persistence;
	private DataUpdatesEnabler updatesEnabler;
	private BlinkingEnabler blinkingEnabler;
	private CellTickingEnabler cellTicksEnabler;

	public PricingGrid(Shell shell) {
		this.shell = shell;
		dataAccessor = new PricingDataAccessor();
		loadNatTable();
	}

	public BlinkingEnabler getBlinkEnabler() {
		return blinkingEnabler;
	}

	public void addRows(int numRows) {
		// Get original EventList to add data to
		List<PricingDataBean> data = dataAccessor.getBaseEventList();
		data.addAll(PricingDataBeanGenerator.getData(numRows));

		natTable.getDisplay().asyncExec(new Runnable() {
			public void run() {
				natTable.updateResize();
			}
		});
	}

	public void removeAllRows() {
		// Get original EventList to remove data
		dataAccessor.getBaseEventList().clear();
	}

	public boolean isPersistenceEnabled() {
		// Check the persistence flag to see whether it has been enabled or not
		String key = PersistenceEnabler.class.getName();
		Object persistenceFlag = shell.getData(key);
		return persistenceFlag != null ? ((Boolean)persistenceFlag).booleanValue() : false;
	}

	public void attachPersistence() {
		if (!isPersistenceEnabled()) {
			shell.addDisposeListener(persistence);
			// Set the persistence flag to inform that persistence has been enabled
			shell.setData(PersistenceEnabler.class.getName(), Boolean.TRUE);
		}
	}

	public void detachPersistence() {
		if (isPersistenceEnabled()) {
			shell.removeDisposeListener(persistence);
			// Set the persistence flag to inform persistence is disabled
			shell.setData(PersistenceEnabler.class.getName(), Boolean.FALSE);
		}
	}

	/**
	 * Removes all persistence settings by searching for all *.store files and deleting them.
	 */
	public void clearPersistedSettings() {
		detachPersistence();
		File directory = new File(".");
		if (directory.isDirectory()) {
			File[] storeFiles = directory.listFiles(new FileFilter() {
				public boolean accept(File pathname) {
					String ext = pathname.getName();
					ext = ext != null && ext.length() > 0 && ext.indexOf(".") >= 0 ? ext.substring(ext.lastIndexOf(".") + 1, ext.length()) : "";
					return ext.equals("store");
				}
			});
			for (File file : storeFiles) {
				if (file.canRead()) {
					file.delete();
				}
			}
		}
	}
	
	public PricingDataAccessor getDataAccessor() {
		return dataAccessor;
	}
	
	public void setFilter(int modelColumnIndex, Object valueToFilter) {
		dataAccessor.filter(modelColumnIndex, valueToFilter, natTable);
	}
	
	public void removeFilter() {
		dataAccessor.removeFilter(natTable);
	}
	
	private void loadNatTable() {
		// Setup layout
		Composite tableComposite = new Composite(shell, SWT.NONE);
		tableComposite.setLayout(new FillLayout());
		tableComposite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		// Assemble NatTableModel
		ModelAssembler modelAssembler = new ModelAssembler();
		DefaultNatTableModel model = modelAssembler.assembleDefaultNatTableModel(dataAccessor);
		
		natTable = new NatTable(tableComposite, SWT.BORDER | SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, model);
		enableSorting();
		try {
			// Restore user saved settings.
			PersistableObjectsAccessor.restoreNatTable(natTable);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		StyleConfigTypeResolver styleTypeResolver = (StyleConfigTypeResolver)model.getStyleConfigRegistry().getConfigTypeResolver();
		bindConfigurationOverrideMenus(model.getStyleConfigRegistry(), styleTypeResolver);
		enablePersistence(styleTypeResolver);
		enableEventHandling();
	}

	private void bindConfigurationOverrideMenus(StyleConfigRegistry styleRegistry, StyleConfigTypeResolver styleTypeResolver) {

		// bind column header menus
		natTable.getEventBindingSupport().registerMouseDownBinding(new MouseEventMatcher(SWT.NONE, GridRegionEnum.COLUMN_HEADER.toString(), 3), new PopupMenuAction(shell));

		Map<String, Map<String, IStyleConfig>> typesMap = styleRegistry.getStyleConfigMap();
		String[] types = typesMap != null && typesMap.containsKey(DisplayModeEnum.NORMAL.name()) ? typesMap.get(DisplayModeEnum.NORMAL.name()).keySet().toArray(new String[0]) : new String[] { "" };
		// body cell type menus
		RegionConfigOverridesEnabler overridesEnabler = new RegionConfigOverridesEnabler(styleTypeResolver, natTable);
		natTable.getEventBindingSupport().registerMouseDownBinding(new MouseEventMatcher(GridRegionEnum.BODY.toString(), 3), overridesEnabler.enableCellRegionOverrides(types, shell));

		// row header type menus
		natTable.getEventBindingSupport().registerMouseDownBinding(new MouseEventMatcher(GridRegionEnum.ROW_HEADER.toString(), 3), overridesEnabler.enableRowOverrides(types, shell));
	}

	private void enableSorting() {
		natTable.addSortingDirectionChangeListener(new NatTableComparatorChooser<PricingDataBean>(dataAccessor.getSortedRows(), new NatColumnTableFormat<PricingDataBean>(ColumnHeaders.getLabels(),
				dataAccessor.getColumnAccessor(), natTable.getNatTableModel().getContentConfigRegistry())));
	}

	private void enablePersistence(StyleConfigTypeResolver styleTypeResolver) {
		persistence = new PersistenceEnabler(styleTypeResolver, natTable);
		attachPersistence();
	}

	private void enableEventHandling() {
		enableSearchCapabilities();
		
		final EventNatTableViewer<PricingDataBean> eventNatTableViewer = new EventNatTableViewer<PricingDataBean>(dataAccessor.getSortedRows(), natTable);
		updatesEnabler = new DataUpdatesEnabler(natTable.getNatTableModel().getContentConfigRegistry());
		
		enableCopyPaste();
		enableCellBlinking();
		enableCellTicking();
		enableCellEditValidation();

		natTable.addDisposeListener(new DisposeListener() {

			public void widgetDisposed(DisposeEvent e) {
				eventNatTableViewer.dispose();
			}

		});
	}
	
	private void enableSearchCapabilities() {
		SearchDialog.installKeyHandler(natTable);
	}
	
	private void enableCellTicking() {
		cellTicksEnabler = new CellTickingEnabler(natTable.getSelectionModel(), natTable.getReorderSupport(), updatesEnabler.getDataUpdateHelper(), dataAccessor.getBaseEventList(), natTable);
		cellTicksEnabler.enableTicking(natTable.getEventBindingSupport(), natTable.getShell(), new BulkCellUpdateSupport<PricingDataBean>(natTable, dataAccessor.getDataProvider(), dataAccessor.getRowIdAccessor()));
	}

	private void enableCopyPaste() {
		natTable.addKeyListener(new CopyPasteEventListener<PricingDataBean>(natTable.getSelectionModel(), dataAccessor.getDataProvider(), updatesEnabler.getDataUpdateHelper(),
				new CopyPasteSupport<PricingDataBean>(dataAccessor.getRowIdAccessor()), new IPasteExecutionSupport<PricingDataBean>() {

					public void doPaste(DataUpdateHelper<PricingDataBean> helper) {
						DefaultBulkUpdateSupport<PricingDataBean> dataHandler = (DefaultBulkUpdateSupport<PricingDataBean>) helper.getBulkUpdate();
						dataHandler.commitUpdates(dataAccessor.getBaseEventList(), helper);
						if(! dataHandler.foundErrors()) {
							natTable.updateResize();							
						} else {
							MessageBox alertBox = new MessageBox(shell, SWT.ICON_ERROR | SWT.OK);
							alertBox.setMessage("Could not complete paste, found " + dataHandler.getErrors().size() + " errors.");
							alertBox.open();
						}
						// Reset error and update states, making ready for next set of updates
						dataHandler.reset();
					}
				}, natTable.getNatTableModel().getContentConfigRegistry()));
	}

	private void enableCellBlinking() {
		// Pass sorted list so that the PricingBeanValueGenerator can update the model
		blinkingEnabler = new BlinkingEnabler(dataAccessor.getSortedRows(), dataAccessor.getRowIdAccessor(), dataAccessor.getDataProvider(), natTable.getConflationSupport());

		blinkingEnabler.registerCellForBlinking(ColumnHeaders.TWO.ordinal());
		blinkingEnabler.registerCellForBlinking(ColumnHeaders.THREE.ordinal());

		StyleConfigRegistry registry = natTable.getNatTableModel().getStyleConfigRegistry();
		registry.setConfigTypeResolver(blinkingEnabler.linkStyleConfigTypeResolver(registry.getConfigTypeResolver()));
	}

	private void enableCellEditValidation() {
		natTable.addValueChangeListener(new IValueChangeListener() {
			private final ContentConfigRegistry contentRegistry = natTable.getNatTableModel().getContentConfigRegistry();
			public void valueChanged(int modelBodyRow, int modelBodyColumn, Object oldValue, Object newValue) {
				IDataValidator validator = null;
				if((validator = contentRegistry.getDataValidator(modelBodyRow, modelBodyColumn)) != null) {
					if(!validator.validate(oldValue, newValue)) {
						MessageBox alertBox = new MessageBox(shell, SWT.ICON_ERROR | SWT.OK);
						alertBox.setMessage("Validation failed for value: "+ newValue);
						alertBox.open();
					} else {
						DataUpdateHelper<PricingDataBean> helper = updatesEnabler.getDataUpdateHelper();
						List<Object> updateValues = new ArrayList<Object>();
						updateValues.add(newValue);
						List<String> updateProperties = new ArrayList<String>();
						updateProperties.add(ColumnHeaders.values()[modelBodyColumn].getProperty());
						updatesEnabler.getDataUpdateHelper().getBulkUpdate().addUpdates(
								dataAccessor.getRowIdAccessor().getRowId(dataAccessor.getDataProvider().getRowObject(modelBodyRow)),
								updateValues,
								updateProperties,
								helper);
						
						updatesEnabler.getDataUpdateHelper().getBulkUpdate().commitUpdates(dataAccessor.getSortedRows(), helper);
					}
				}
			}
			
		});
	}
	
	public static void main(String[] args) throws SecurityException, NoSuchFieldException {
		DeviceData data = new DeviceData();
		data.tracking = true;
		Display display = new Display(data);
		Shell shell = new Shell(display, SWT.SHELL_TRIM);
		shell.setSize(1038, 300);
		shell.setLayout(new GridLayout());
		shell.setText("Pricing Example");
		PricingGrid pe = new PricingGrid(shell);
		pe.shell = shell;
		pe.shell.open();
		pe.shell.layout();
		while (!pe.shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		display.dispose();
	}
}
