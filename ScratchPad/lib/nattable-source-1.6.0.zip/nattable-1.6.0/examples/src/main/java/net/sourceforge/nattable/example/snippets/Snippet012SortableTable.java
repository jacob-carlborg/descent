package net.sourceforge.nattable.example.snippets;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.extension.glazedlists.NatColumnTableFormat;
import net.sourceforge.nattable.extension.glazedlists.NatTableComparatorChooser;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.IDisplayTypeConverter;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;

public class Snippet012SortableTable {
	public static void main(String args[]) {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display, SWT.SHELL_TRIM);
			shell.setLayout(new FillLayout());

			Snippet012SortableTable grid = new Snippet012SortableTable();
			// Setup table
			grid.setupNatTable(shell);

			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Snippet012SortableTable() {

	}

	public void setupNatTable(Composite parent) throws Exception {
		// GlazedLists sorted list
		SortedList<Event> sortedList = assembleSortedList();
		
		// Load sortable data to grid
		ListDataProvider<Event> dataProvider = assembleListDataProvider(sortedList);
		// Initialize default nattable model
		DefaultNatTableModel defaultNatModel = setupNatModel(sortedList);
		// Load data into model
		loadDataModel(defaultNatModel, dataProvider);
		// NatTable
		NatTable natTable = new NatTable(parent, SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, defaultNatModel);
		// Linkup sorting
		natTable.addSortingDirectionChangeListener(new NatTableComparatorChooser<Event>(sortedList, new NatColumnTableFormat<Event>(getColumnHeaderLabels(),
				dataProvider.getColumnAccessor(), defaultNatModel.getContentConfigRegistry())));
	}

	public DefaultNatTableModel setupNatModel(SortedList<Event> sortedList) throws Exception {
		DefaultNatTableModel defaultNatModel = new DefaultNatTableModel();
		// Set column header rendering
		assembleColumnHeaderConfig(defaultNatModel);

		// Set row headers
		assembleRowHeaderConfig(defaultNatModel);

		return defaultNatModel;
	}

	private String[] getColumnHeaderLabels() {
		String[] columnNames = new String[ColumnDefinitions.values().length];
		
		ColumnDefinitions[] colDefinitions = ColumnDefinitions.values();
		for(int colIndex = 0; colIndex < colDefinitions.length; colIndex++) {
			columnNames[colIndex] = colDefinitions[colIndex].getColumnHeaderLabel();
		}
		
		return columnNames;
	}
	
	private SortedList<Event> assembleSortedList() throws Exception {
		EventList<Event> baseList = GlazedLists.threadSafeList(GlazedLists.eventList(getEvents()));
		return new SortedList<Event>(baseList, null);
	}
	
	private void assembleColumnHeaderConfig(DefaultNatTableModel defaultNatModel) {
		DefaultColumnHeaderConfig defaultColHeaderConfig = new DefaultColumnHeaderConfig(new IColumnHeaderLabelProvider() {

			public String getColumnHeaderLabel(int col) {
				return ColumnDefinitions.values()[col].getColumnHeaderLabel();
			}

		});
		SizeConfig columnHeaderSize = new SizeConfig(24);
		columnHeaderSize.setDefaultResizable(true);
		defaultColHeaderConfig.setColumnHeaderRowHeightConfig(columnHeaderSize);
		defaultNatModel.setColumnHeaderConfig(defaultColHeaderConfig);
	}

	private void assembleRowHeaderConfig(DefaultNatTableModel defaultNatModel) {
		DefaultRowHeaderConfig rowHeaderConfig = new DefaultRowHeaderConfig();
		rowHeaderConfig.setRowHeaderColumnCount(1);
		rowHeaderConfig.setRowHeaderColumnWidthConfig(new SizeConfig(24));
		defaultNatModel.setRowHeaderConfig(rowHeaderConfig);
	}

	private ListDataProvider<Event> assembleListDataProvider(SortedList<Event> sortedList) throws Exception {
		ListDataProvider<Event> dataList = new ListDataProvider<Event>(sortedList, new IColumnAccessor<Event>() {

			public int getColumnCount() {
				return ColumnDefinitions.values().length;
			}

			public Object getColumnValue(Event rowObj, int col) {
				return ColumnDefinitions.values()[col].extractValue(rowObj);
			}

		});
		
		return dataList;
		
	}

	private void loadDataModel(DefaultNatTableModel defaultNatModel, ListDataProvider<Event> dataList) {
		defaultNatModel.setSortingEnabled(true);
		DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataList, assembleContentConfigRegistry(), assembleStyleConfigRegistry());
		
		defaultNatModel.setBodyConfig(bodyConfig);
		
		// Enable column resize
		defaultNatModel.getBodyConfig().getColumnWidthConfig().setDefaultResizable(true);
	}
	
	private ContentConfigRegistry assembleContentConfigRegistry() {
		ContentConfigRegistry contentRegistry = new ContentConfigRegistry();

		// Return 'date' type
		contentRegistry.setConfigTypeResolver(new IConfigTypeResolver() {

			public String getConfigType(int modelBodyRow, int modelBodyColumn) {
				if (modelBodyColumn == ColumnDefinitions.STARTDATE.ordinal() || modelBodyColumn == ColumnDefinitions.ENDDATE.ordinal()) {
					return "date";
				}
				return null;
			}

		});

		// Set register display converter to format the start and end dates.
		contentRegistry.registerDisplayTypeConverter("date", new IDisplayTypeConverter() {
			private final SimpleDateFormat dateFormatter = new SimpleDateFormat("EEEE MMMM dd yyyy 'at' hh:00 a");

			public Object dataValueToDisplayValue(Object dataValue) {
				return dateFormatter.format(new Date(((Long) dataValue).longValue()));
			}

			public Object displayValueToDataValue(Object displayValue) {
				try {
					return Long.valueOf(dateFormatter.parse((String) displayValue).getTime());
				} catch (ParseException e) {
					throw new RuntimeException("Unable to parse display date : " + displayValue + "\n" + e.getMessage(), e);
				}
			}

		});
		return contentRegistry;
	}

	private StyleConfigRegistry assembleStyleConfigRegistry() {
		StyleConfigRegistry styleRegistry = new StyleConfigRegistry();

		return styleRegistry;
	}

	// The code below is application specific

	private List<Event> getEvents() throws Exception {
		List<Event> events = new ArrayList<Event>();

		// Generate event start and end dates
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date(System.currentTimeMillis()));
		long[] startDates = new long[10];
		long[] endDates = new long[10];
		// Generate incremental schedules
		for (int eventIndex = 0; eventIndex < 10; eventIndex++) {
			calendar.add(Calendar.MONTH, eventIndex);
			calendar.roll(Calendar.HOUR, eventIndex / 2);
			startDates[eventIndex] = calendar.getTime().getTime();
			calendar.add(Calendar.HOUR, 2);
			endDates[eventIndex] = calendar.getTime().getTime();
		}

		events.add(new Event(startDates[0], endDates[0], "Web Development I", "Basic HTML teachings.", "Marriot, New York, New York"));
		events.add(new Event(startDates[1], endDates[1], "Web Development II", "Intermediate HTML tagging.", "Hilton, New York, New York"));
		events.add(new Event(startDates[2], endDates[2], "Web Development III", "Advanced HTML tagging.", "Marriot, New York, New York"));
		events.add(new Event(startDates[3], endDates[3], "Multi Media on the Web I", "Basic Streaming Technologies.", "Marriot, New York, New York"));
		events.add(new Event(startDates[4], endDates[4], "Multi Media on the Web II", "Adobe Flash Movies.", "Sheraton, New York, New York"));
		events.add(new Event(startDates[5], endDates[5], "Multi Media on the Web III", "Decoding and Encoding.", "NYU, New York, New York"));
		events.add(new Event(startDates[6], endDates[6], "Ajax I", "Basic HTTP Request support (Prototype).", "Embassy Suites, Montreal, Quebec, CA"));
		events.add(new Event(startDates[7], endDates[7], "Ajax II", "Server side object mappings.", "Hilton, Montreal, Quebec, CA"));
		events.add(new Event(startDates[8], endDates[8], "Ajax III", "Call backs and error handling.", "Marriot, Montreal, Quebec, CA"));
		events.add(new Event(startDates[9], endDates[9], "Putting it all together", "Maximizing user experience", "Marriot, New York, New York"));

		return events;
	}

	class Event {
		private long startDate;
		private long endDate;
		private String name;
		private String description;
		private String location;

		Event(long startDate, long endDate, String name, String description, String location) {
			this.startDate = startDate;
			this.endDate = endDate;
			this.name = name;
			this.description = description;
			this.location = location;
		}

		public long getStartDate() {
			return startDate;
		}

		public long getEndDate() {
			return endDate;
		}

		public String getName() {
			return name;
		}

		public String getDescription() {
			return description;
		}

		public String getLocation() {
			return location;
		}
	}

	enum ColumnDefinitions {

		STARTDATE("Start Time", "startDate", long.class) {

			public Long extractValue(Event rowObject) {
				return Long.valueOf(rowObject.getStartDate());
			}
		},
		ENDDATE("End Time", "endDate", long.class) {

			public Long extractValue(Event rowObject) {
				return Long.valueOf(rowObject.getEndDate());
			}
		},
		EVENTNAME("Event", "name", String.class) {

			public String extractValue(Event rowObject) {
				return rowObject.getName();
			}
		},
		EVENTDESC("Description", "description", String.class) {

			public String extractValue(Event rowObject) {
				return rowObject.getDescription();
			}
		},
		EVENTLOC("Location", "location", String.class) {

			public String extractValue(Event rowObject) {
				return rowObject.getLocation();
			}
		};

		private String columnHeaderLabel;
		private String beanPropertyName;
		private Class<?> beanPropertyClass;

		ColumnDefinitions(String columnHeaderLabel, String beanPropertyName, Class<?> beanPropertyClass) {
			this.columnHeaderLabel = columnHeaderLabel;
			this.beanPropertyName = beanPropertyName;
			this.beanPropertyClass = beanPropertyClass;
		}

		public abstract Object extractValue(Event rowObject);

		public String getColumnHeaderLabel() {
			return columnHeaderLabel;
		}

		public String getBeanPropertyName() {
			return beanPropertyName;
		}

		public Class<?> getBeanPropertyClass() {
			return beanPropertyClass;
		}
	}
}
