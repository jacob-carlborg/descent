package net.sourceforge.nattable.example.test;

import java.util.Random;
import java.util.concurrent.Executors;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~9��23��<br>
 */
public class NatTableShell extends Shell {

	private Text row_txt;
	private Text col_txt;
	private Combo combo;
	private Text text;
	private NatTable natTable;

	/**
	 * Launch the application
	 * 
	 * @param args
	 */
	public static void main(String args[]) {
		try {
			Display display = Display.getDefault();
			NatTableShell shell = new NatTableShell(display, SWT.SHELL_TRIM);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the shell
	 * 
	 * @param display
	 * @param style
	 */
	public NatTableShell(Display display, int style) {
		super(display, style);
		createContents();
		setLayout(new GridLayout());
	}

	public NatTable getNatTable() {
		return natTable;
	}
	
	/**
	 * Create contents of the window
	 */
	protected void createContents() {
		setText("SWT Application");
		setSize(800, 600);

		final Composite composite = new Composite(this, SWT.NONE);
		composite.setLayout(new FillLayout());
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		final TestTableModel model = new TestTableModel();
		natTable = new NatTable(composite, SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE
				| SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, model);
		model.attachListeners(natTable);
		natTable.setFocus();

		final Composite composite_1 = new Composite(this, SWT.NONE);
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		final GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 8;
		composite_1.setLayout(gridLayout);

		final Button addDataButton = new Button(composite_1, SWT.NONE);
		addDataButton.setText("Add Data");
		addDataButton.addSelectionListener(new SelectionListener() {

			public void widgetSelected(SelectionEvent arg0) {
				model.setRow(model.getBodyRowCount() + 100000);
				natTable.updateResize();
			}

			public void widgetDefaultSelected(SelectionEvent arg0) {
			}

		});

		final Button updateRowButton = new Button(composite_1, SWT.NONE);
		updateRowButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Thread thread = new Thread(new Runnable() {

					public void run() {
						final Random random = new Random(System.currentTimeMillis());

						while (true) {
							try {
								Thread.sleep(50);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}

							Display.getDefault().asyncExec(new Runnable() {

								public void run() {
									int row = random.nextInt(30);
									model.getUpdateList().put(Integer.valueOf(row), "new updated value[" + row + "]");
									natTable.redrawUpdatedBodyRow(row, row);

								}

							});

						}

					}

				});
				thread.start();
			}
		});
		updateRowButton.setText("Update Row");

		final Button showSelectionButton = new Button(composite_1, SWT.NONE);
		showSelectionButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				String index = text.getText();

				natTable.showBodyRow(Integer.valueOf(index));
			}
		});
		showSelectionButton.setText("Show Selection");

		text = new Text(composite_1, SWT.BORDER);
		text.setText("0");
		text.setLayoutData(new GridData(56, SWT.DEFAULT));

		final Button showVerticalBarButton = new Button(composite_1, SWT.NONE);
		showVerticalBarButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println(natTable.getVerticalBar().getSelection());
			}
		});
		showVerticalBarButton.setText("Show Vertical Bar Selection");

		final Button showGridButton = new Button(composite_1, SWT.CHECK);
		showGridButton.setSelection(true);
		showGridButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				model.setGridLineEnabled(!model.isGridLineEnabled());
				natTable.updateResize();

			}
		});
		showGridButton.setText("Show Grid");

		final Label lnfStyleLabel = new Label(composite_1, SWT.NONE);
		lnfStyleLabel.setText("LnF Style: ");

		combo = new Combo(composite_1, SWT.NONE);
		combo.select(0);
		combo.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				if (combo.getSelectionIndex() == 0) {
					model.getColumnHeaderCellPainter().setStyle(SWT.LEFT | SWT.BORDER);
					natTable.updateResize();
				} else {
					model.getColumnHeaderCellPainter().setStyle(SWT.LEFT);
					natTable.updateResize();
				}

			}
		});
		combo.setItems(new String[] { "Border Column", "Gradient Column" });
		final GridData gd_combo = new GridData(70, SWT.DEFAULT);
		combo.setLayoutData(gd_combo);

		final Composite composite_2 = new Composite(composite_1, SWT.BORDER);
		final GridLayout gridLayout_1 = new GridLayout();
		gridLayout_1.numColumns = 5;
		composite_2.setLayout(gridLayout_1);
		final GridData gd_composite_2 = new GridData(SWT.FILL, SWT.FILL, false, false, 3, 1);
		gd_composite_2.widthHint = 224;
		composite_2.setLayoutData(gd_composite_2);

		final Label freezeColLabel = new Label(composite_2, SWT.NONE);
		freezeColLabel.setText("Freeze Col :");

		col_txt = new Text(composite_2, SWT.BORDER);
		final GridData gd_col_txt = new GridData(20, SWT.DEFAULT);
		col_txt.setLayoutData(gd_col_txt);

		final Label rowLabel = new Label(composite_2, SWT.NONE);
		rowLabel.setText("Row :");

		row_txt = new Text(composite_2, SWT.BORDER);
		final GridData gd_row_txt = new GridData(20, SWT.DEFAULT);
		row_txt.setLayoutData(gd_row_txt);

		final Button setButton = new Button(composite_2, SWT.NONE);
		setButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				String col = col_txt.getText();
				String row = row_txt.getText();

				try {
					model.setFreezeColumnCount(Integer.parseInt(col));
					model.setFreezeRowCount(Integer.parseInt(row));
					
					natTable.redraw();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		setButton.setText("Set");

		final Composite composite_3 = new Composite(composite_1, SWT.BORDER);
		final GridLayout gridLayout_2 = new GridLayout();
		gridLayout_2.numColumns = 3;
		composite_3.setLayout(gridLayout_2);
		composite_3.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 2, 1));

		final Label rateLabel = new Label(composite_3, SWT.NONE);
		rateLabel.setText("Rate : ");

		final Text text_1 = new Text(composite_3, SWT.BORDER);
		text_1.setText("1000");
		final GridData gd_text_1 = new GridData(SWT.FILL, SWT.CENTER, false, false);
		gd_text_1.widthHint = 21;
		text_1.setLayoutData(gd_text_1);

		final Button updateButton = new Button(composite_3, SWT.NONE);
		updateButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				try {
					final int rate = Integer.parseInt(text_1.getText());

					Executors.newCachedThreadPool().execute(new Runnable() {

						public void run() {
							System.out.println("Start refresh rate at " + rate);
							try {
								Random random = new Random(System.currentTimeMillis());
								for (int i = 0; i < rate; i++) {
									int row = random.nextInt(natTable.getNatTableModel().getBodyRowCount());
									natTable.getConflationSupport().redrawUpdatedRow(row, row);
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							System.out.println("End");

						}

					});

				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		updateButton.setText("Update");
		new Label(composite_1, SWT.NONE);
		new Label(composite_1, SWT.NONE);
		new Label(composite_1, SWT.NONE);
		//
	}

	long start = 0;

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
