package net.sourceforge.nattable.example.pricing;

import java.io.IOException;

import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultCornerConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.IBodyConfig;
import net.sourceforge.nattable.config.IColumnHeaderConfig;
import net.sourceforge.nattable.config.ICornerConfig;
import net.sourceforge.nattable.config.IRowHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.ColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.typeconfig.TypedCellOverrider;
import net.sourceforge.nattable.typeconfig.TypedRowOverrider;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

class ModelAssembler {

	public DefaultNatTableModel assembleDefaultNatTableModel(PricingDataAccessor dataAccessor) {

		ContentConfigRegistry contentRegistry = new ContentConfigRegistry();
		StyleConfigRegistry styleRegistry = new StyleConfigRegistry();
		assembleConfigurationRegistries(dataAccessor, contentRegistry, styleRegistry);

		IBodyConfig bodyConfig = assembleBodyConfig(dataAccessor, contentRegistry, styleRegistry);
		ICornerConfig cornerConfig = assembleCornerConfig();
		IColumnHeaderConfig colHeaderConfig = assembleColumnHeaderConfig();
		IRowHeaderConfig rowHeaderConfig = assembleRowHeaderConfig();

		// Initialize the model
		DefaultNatTableModel model = new DefaultNatTableModel();
		model.setStyleConfigRegistry(styleRegistry);
		model.setContentConfigRegistry(contentRegistry);
		model.setColumnHeaderConfig(colHeaderConfig);
		model.setCornerConfig(cornerConfig);
		model.setRowHeaderConfig(rowHeaderConfig);
		model.setBodyConfig(bodyConfig);
		// Try to load any persisted settings
		try {
			if (!PersistableObjectsAccessor.restoreNatTableModel(model)) {
				// Set grid settings
				model.setSingleCellSelection(true);
				model.setFullRowSelection(false);
				model.setMultipleSelection(true);
				model.setSortingEnabled(true);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		return model;
	}

	private void assembleConfigurationRegistries(PricingDataAccessor dataAccessor, ContentConfigRegistry contentRegistry, StyleConfigRegistry styleRegistry) {
		assembleContentConfigRegistry(dataAccessor, contentRegistry);
		assembleStyleConfigRegistry(dataAccessor, styleRegistry);
		// Keep reference to original (non-decorated) resolver will need it later.
		((StyleConfigTypeResolver)styleRegistry.getConfigTypeResolver()).decorateTypeResolver(contentRegistry.getConfigTypeResolver());
	}

	private void assembleStyleConfigRegistry(PricingDataAccessor dataAccessor, StyleConfigRegistry styleRegistry) {
		IRowDataProvider<PricingDataBean> dataProvider = dataAccessor.getDataProvider();

		TypedCellOverrider<PricingDataBean> cellOverrider = new TypedCellOverrider<PricingDataBean>(dataProvider);
		TypedRowOverrider<PricingDataBean> rowOverrider = new TypedRowOverrider<PricingDataBean>(dataProvider, dataAccessor.getRowIdAccessor());
		try {
			StyleEnabler styleEnabler = new StyleEnabler();
			if (!PersistableObjectsAccessor.restoreStyleRegistry(styleRegistry, cellOverrider, rowOverrider)) {
				// Enable custom styling if these settings have not been persisted
				styleEnabler.enableCustomStyles(styleRegistry, dataProvider, cellOverrider, rowOverrider);
			} else {
				styleEnabler.enableAlternateRowColoring(styleRegistry);
				styleRegistry.setConfigTypeResolver(styleEnabler.initStyleTypeResolver(dataProvider, cellOverrider, rowOverrider));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void assembleContentConfigRegistry(PricingDataAccessor dataAccessor, ContentConfigRegistry contentRegistry) {
		ContentTypingEnabler contentTypesEnabler = new ContentTypingEnabler();
		contentTypesEnabler.enableContentTyping(contentRegistry, dataAccessor.getDataProvider());
	}

	private ICornerConfig assembleCornerConfig() {
		return new DefaultCornerConfig();
	}

	private IRowHeaderConfig assembleRowHeaderConfig() {
		DefaultRowHeaderConfig rowConfig = new DefaultRowHeaderConfig();
		rowConfig.setRowHeaderColumnCount(1);
		rowConfig.setRowHeaderColumnWidthConfig(new SizeConfig(25));

		return rowConfig;
	}

	private IBodyConfig assembleBodyConfig(PricingDataAccessor dataAccessor, ContentConfigRegistry contentRegistry, StyleConfigRegistry styleRegistry) {
		DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataAccessor.getDataProvider(), contentRegistry, styleRegistry);
		SizeConfig colSizeConfig = new SizeConfig();
		colSizeConfig.setDefaultResizable(true);
		colSizeConfig.setDefaultSize(190);
		bodyConfig.setColumnWidthConfig(colSizeConfig);
		bodyConfig.getRowHeightConfig().setDefaultSize(20);
		return bodyConfig;
	}

	private IColumnHeaderConfig assembleColumnHeaderConfig() {
		DefaultColumnHeaderConfig colHeaderConfig = new DefaultColumnHeaderConfig(assembleColumnLabelProvider());
		colHeaderConfig.setColumnHeaderRowCount(1);
		colHeaderConfig.setColumnHeaderRowHeightConfig(new SizeConfig(25));
		return colHeaderConfig;
	}

	private IColumnHeaderLabelProvider assembleColumnLabelProvider() {
		return new ColumnHeaderLabelProvider(ColumnHeaders.getLabels());
	}
}