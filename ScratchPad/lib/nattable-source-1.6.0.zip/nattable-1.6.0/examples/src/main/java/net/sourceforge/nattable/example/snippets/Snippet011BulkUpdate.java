package net.sourceforge.nattable.example.snippets;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.IColumnHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.DefaultBulkUpdateSupport;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IColumnPropertyProvider;
import net.sourceforge.nattable.data.IDataValidator;
import net.sourceforge.nattable.data.IRowIDPropertyResolver;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.data.IRowObjectCreator;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveNumericPropertyInstanceCreator;
import net.sourceforge.nattable.event.KeyBinding;
import net.sourceforge.nattable.event.matcher.LetterOrDigitKeyMatcher;
import net.sourceforge.nattable.extension.action.TickAction;
import net.sourceforge.nattable.extension.event.matcher.TickKeyMatcher;
import net.sourceforge.nattable.extension.handler.ITickableHandler;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.support.BulkCellUpdateSupport;
import net.sourceforge.nattable.support.BulkUpdateResponse;
import net.sourceforge.nattable.support.BulkUpdateTypeEnum;
import net.sourceforge.nattable.support.ColumnTransformSupport;
import net.sourceforge.nattable.support.EventBindingSupport;
import net.sourceforge.nattable.support.IClientAreaProvider;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.IEditableRule;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;

import ca.odell.glazedlists.BasicEventList;

/**
 * Shows the minimal configuration needed to construct a NatTable instance.
 */
public class Snippet011BulkUpdate {

	private static final String BULK_UPDATE = "Bulk update...";
	private DataUpdateHelper<InventoryItem> helper;
	private IClientAreaProvider clientAreaProvider;

	public static void main(String args[]) {
		new Snippet011BulkUpdate();
	}

	private BasicEventList<InventoryItem> list;

	private Snippet011BulkUpdate() {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display, SWT.SHELL_TRIM);
			shell.setLayout(new FillLayout());

			setupNatTable(shell);

			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param parent
	 */
	private void setupNatTable(Composite parent) {

		DefaultNatTableModel model = new DefaultNatTableModel();

		list = new BasicEventList<InventoryItem>();

		list.add(new InventoryItem("Apple", "fruit-001"));
		list.add(new InventoryItem("Orange", "fruit-002"));
		list.add(new InventoryItem("Pear", "fruit-003"));

		ListDataProvider<InventoryItem> dataProvider = createDataProvider(list);

		ContentConfigRegistry contentRegistry = new ContentConfigRegistry();
		// Set the content type resolver returning content types which will map
		// to our editable rules
		assembleContentTypeResolver(contentRegistry);
		// Registers the editable rules for each of the editable columns
		assembleEditableRules(contentRegistry);
		assembleDataValidators(contentRegistry);

		model.setContentConfigRegistry(contentRegistry);

		// Create and link body config
		DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider, contentRegistry, new StyleConfigRegistry());

		model.setBodyConfig(bodyConfig);
		model.setColumnHeaderConfig(createColumnHeaderConfig());
		model.setMultipleSelection(true);

		// Create row header config
		DefaultRowHeaderConfig rowHeaderConfig = new DefaultRowHeaderConfig();
		rowHeaderConfig.setRowHeaderColumnCount(1);
		rowHeaderConfig.setRowHeaderColumnWidthConfig(new SizeConfig(24));
		model.setRowHeaderConfig(rowHeaderConfig);

		// Enable grid settings
		model.setSingleCellSelection(true);

		// NatTable
		NatTable natTable = new NatTable(parent, SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, model);
		clientAreaProvider = natTable;
		// Hook up ticking to the table
		helper = assembleUpdateHelperObject(contentRegistry);
		enableCellTickUpdates(natTable, dataProvider);
	}

	private void enableCellTickUpdates(NatTable natTable, ListDataProvider<InventoryItem> dataProvider) {
		final BulkCellUpdateSupport<InventoryItem> bulkCellUpdateSupport = createBulkCellUpdateSupport(natTable, dataProvider);

		// Bind ticking behavior to natTable events
		EventBindingSupport eventBindingSupport = natTable.getEventBindingSupport();
		List<KeyBinding> bindingsToReset = new ArrayList<KeyBinding>();
		boolean found = false;
		for (KeyBinding binding : eventBindingSupport.getKeyBindings()) {
			if (binding.getKeyEventMatcher() instanceof LetterOrDigitKeyMatcher) {
				found = true;
			}

			if (found) {
				eventBindingSupport.unregisterKeyBinding(binding);
				bindingsToReset.add(binding);
			}
		}
		BulkUpdateResponseHandler tickHandler = new BulkUpdateResponseHandler(natTable.getSelectionModel(), natTable.getReorderSupport());
		eventBindingSupport.registerKeyBinding(new TickKeyMatcher(tickHandler), new TickAction(natTable.getShell(), bulkCellUpdateSupport, tickHandler));

		for (KeyBinding binding : bindingsToReset) {
			eventBindingSupport.registerKeyBinding(binding.getKeyEventMatcher(), binding.getAction());
		}

		bindingsToReset.clear();
	}

	private void assembleContentTypeResolver(ContentConfigRegistry contentRegistry) {
		contentRegistry.setConfigTypeResolver(new IConfigTypeResolver() {

			public String getConfigType(int modelBodyRow, int modelBodyColumn) {
				return modelBodyColumn == 2 ? "costPricePerUnit" : modelBodyColumn == 3 ? "count" : null;
			}

		});
	}

	private void assembleEditableRules(ContentConfigRegistry contentRegistry) {
		contentRegistry.registerEditableRule("costPricePerUnit", new IEditableRule() {

			public boolean isEditable(int row, int col) {
				return col == 2;
			}

		});

		contentRegistry.registerEditableRule("count", new IEditableRule() {

			public boolean isEditable(int row, int col) {
				return col == 3;
			}

		});
	}

	private void assembleDataValidators(ContentConfigRegistry contentRegistry) {
		contentRegistry.registerValidator("count", new IDataValidator() {
			public boolean validate(Object oldValue, Object newValue) {
				return false;
			}
		});

		contentRegistry.registerValidator("costPricePerUnit", new IDataValidator() {
			public boolean validate(Object oldValue, Object newValue) {
				return false;
			}
		});
	}

	private BulkCellUpdateSupport<InventoryItem> createBulkCellUpdateSupport(NatTable natTable, ListDataProvider<InventoryItem> dataProvider) {
		IRowIdAccessor<InventoryItem> rowIdAccessor = new IRowIdAccessor<InventoryItem>() {

			public Serializable getRowId(InventoryItem rowObject) {
				return rowObject.getId();
			}

		};

		return new BulkCellUpdateSupport<InventoryItem>(natTable, dataProvider, rowIdAccessor);
	}

	private ListDataProvider<InventoryItem> createDataProvider(BasicEventList<InventoryItem> list) {
		IColumnAccessor<InventoryItem> columnAccessor = new IColumnAccessor<InventoryItem>() {

			public int getColumnCount() {
				return 4;
			}

			public Object getColumnValue(InventoryItem rowObj, int col) {
				switch (col) {
				case 0:
					return rowObj.getId();
				case 1:
					return rowObj.getItemName();
				case 2:
					return rowObj.getCostPricePerUnit();
				case 3:
					return rowObj.getCount();
				}
				return null;
			}

		};

		return new ListDataProvider<InventoryItem>(list, columnAccessor);
	}

	private IColumnHeaderConfig createColumnHeaderConfig() {
		// Column Headers
		IColumnHeaderLabelProvider columnHeaderLabelProvider = new IColumnHeaderLabelProvider() {

			public String getColumnHeaderLabel(int col) {
				switch (col) {
				case 0:
					return "Id";
				case 1:
					return "Name";
				case 2:
					return "Cost price per unit";
				case 3:
					return "Count";
				}
				return null;
			}

		};

		return new DefaultColumnHeaderConfig(columnHeaderLabelProvider);
	}

	private DataUpdateHelper<InventoryItem> assembleUpdateHelperObject(ContentConfigRegistry contentRegistry) {
		helper = new DataUpdateHelper<InventoryItem>();

		helper.setBulkUpdate(new DefaultBulkUpdateSupport<InventoryItem>(contentRegistry));
		helper.setPropertyResolver(new IColumnPropertyProvider() {
			public String getPropertyName(int col) {
				return col == 2 ? "costPricePerUnit" : "count";
			}

			public Class<?> getPropertyType(String propertyName) {
				return propertyName.equals("count") ? Integer.class : Double.class;
			}
		});

		helper.setPropertyInstanceCreator(new ReflectiveNumericPropertyInstanceCreator());

		helper.setRowIdResolver(new IRowIDPropertyResolver() {
			public Serializable resolveRowIdProperty(Map<String, Object> propertyToValue) {
				return propertyToValue.containsKey("id") ? (Serializable) propertyToValue.get("id") : new Double(Math.random());
			}
		});

		helper.setRowComparator(new Comparator<InventoryItem>() {
			public int compare(InventoryItem o1, InventoryItem o2) {
				return o1.getId().compareTo(o2.getId());
			}
		});

		helper.setRowObjectCreator(new IRowObjectCreator<InventoryItem>() {
			public InventoryItem createRowObject(Serializable rowObjectId) {
				InventoryItem bean = new InventoryItem(rowObjectId.toString());

				return bean;
			}

			public Class<InventoryItem> getRowClass() {
				return InventoryItem.class;
			}
		});
		return helper;
	}

	class GridRegionMenuAction implements IMouseEventAction {
		private Menu options;
		private BulkCellUpdateSupport<InventoryItem> bulkCellUpdateSupport;

		public GridRegionMenuAction(Shell shell, BulkCellUpdateSupport<InventoryItem> bulkCellUpdateSupport) {
			options = new Menu(shell, SWT.POP_UP);
			this.bulkCellUpdateSupport = bulkCellUpdateSupport;
		}

		public void run(MouseEvent e) {
			options.setVisible(true);

			for (MenuItem item : options.getItems()) {
				if (item.getText().equals(BULK_UPDATE)) {
					item.setEnabled(bulkCellUpdateSupport.isSelectionValid());
				}
			}
		}

	}

	class BulkUpdateResponseHandler implements ITickableHandler {
		private SelectionModel selectionModel;
		private ColumnTransformSupport columnReorderSupport;
		
		BulkUpdateResponseHandler(SelectionModel selectionModel, ColumnTransformSupport columnReorderSupport) {
			this.selectionModel = selectionModel;
			this.columnReorderSupport = columnReorderSupport;
		}
		public boolean isQuickEditEvent(KeyEvent event) {
			if (isSelectionTickable()) {
				return Character.isDigit(event.character) || event.character == '.';
			}

			return false;
		}

		private boolean isSelectionTickable() {
			int[] selectedColumns = selectionModel.getSelectedColumns();

			if (selectedColumns.length == 1) {
				int viewColumnIndex = selectedColumns[0];
				int modelColumnIndex = columnReorderSupport.reorderedToModelBodyColumn(viewColumnIndex);

				Class<?> type = modelColumnIndex == 2 ? Double.class : Integer.class;

				return Number.class.isAssignableFrom(type);
			}

			return false;
		}
		
		public boolean isTickDownEvent(KeyEvent event) {
			if (isSelectionTickable()) {
				return event.character == '-';
			}

			return false;
		}

		public boolean isTickUpEvent(KeyEvent event) {
			if (isSelectionTickable()) {
				return event.character == '+';
			}

			return false;
		}

		public boolean applyBulkUpdate(BulkUpdateResponse response, Serializable[] rowIds, int fieldIndex) {
			Map<Serializable, Number> oldValues = null;

			String property = fieldIndex == 2 ? "costPricePerUnit" : "count";
			if (response.getType() != BulkUpdateTypeEnum.SET) {
				oldValues = new HashMap<Serializable, Number>();

				HashSet<Serializable> ids = new HashSet<Serializable>();

				for (Serializable rowId : rowIds) {
					ids.add(rowId);
				}
				Field field;
				try {
					field = InventoryItem.class.getDeclaredField(property);
					field.setAccessible(true);
					for (InventoryItem item : list) {
						if (ids.remove(item.getId())) {
							oldValues.put(item.getId(), (Number) field.get(item));
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

			for (Serializable rowId : rowIds) {
				Object newValue = response.getNewValue();
				Class<?> type = fieldIndex == 2 ? Double.class : Integer.class;
				List<Object> values = new ArrayList<Object>(1);
				if (type == String.class) {
					newValue = newValue.toString();
					values.add(newValue);
				} else if (type == Double.class) {
					Double d = Double.valueOf(newValue.toString());
					newValue = d;

					if (response.getType() != BulkUpdateTypeEnum.SET) {
						Number oldNumber = oldValues.get(rowId);

						if (oldNumber == null)
							oldNumber = Double.valueOf(0);

						if (response.getType() == BulkUpdateTypeEnum.INCREASE) {
							newValue = Double.valueOf(d.doubleValue() + oldNumber.doubleValue());
						} else if (response.getType() == BulkUpdateTypeEnum.DECREASE) {
							newValue = Double.valueOf(oldNumber.doubleValue() - d.doubleValue());
						}
					}
					values.add(newValue);
				} else if (type == Integer.class) {
					
					Integer i = newValue instanceof Number ? Integer.valueOf(((Number)newValue).intValue()) : 
						Integer.valueOf(newValue.toString());
					Number oldNumber = oldValues.get(rowId);
					if (oldNumber == null)
						oldNumber = Integer.valueOf(0);

					if (response.getType() == BulkUpdateTypeEnum.INCREASE) {
						i = Integer.valueOf(i.intValue() + oldNumber.intValue());
					} else if (response.getType() == BulkUpdateTypeEnum.DECREASE) {
						i = Integer.valueOf(oldNumber.intValue() - i.intValue());
					}
					values.add(i);
				}
				List<String> colProperties = new ArrayList<String>(1);
				colProperties.add(property);
				helper.getBulkUpdate().addUpdates(rowId, values, colProperties, helper);
			}
			helper.getBulkUpdate().commitUpdates(list, helper);
			clientAreaProvider.updateResize();
			return true;
		}
	}

	static class InventoryItem {

		private String itemName;
		private String id;
		private Integer count;
		private Double costPricePerUnit;

		public InventoryItem(String id) {
			this.id = id;
			setCount(Integer.valueOf(0));
			setCostPricePerUnit(Double.valueOf(0));
		}
		
		public InventoryItem(String itemName, String id) {
			this.itemName = itemName;
			this.id = id;
			setCount(Integer.valueOf(0));
			setCostPricePerUnit(Double.valueOf(0));
		}

		public String getItemName() {
			return itemName;
		}

		public String getId() {
			return id;
		}

		public Integer getCount() {
			return count;
		}

		public void setCount(Integer count) {
			this.count = count;
		}

		public Double getCostPricePerUnit() {
			return costPricePerUnit;
		}

		public void setCostPricePerUnit(Double costPricePerUnit) {
			this.costPricePerUnit = costPricePerUnit;
		}

	}
}