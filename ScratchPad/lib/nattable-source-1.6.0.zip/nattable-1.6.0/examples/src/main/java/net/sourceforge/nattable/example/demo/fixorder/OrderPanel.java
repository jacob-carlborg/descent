/**
 * 
 */
package net.sourceforge.nattable.example.demo.fixorder;

import java.util.Random;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2008�~5��25��<br>
 */
public class OrderPanel extends Composite {

	Random random = new Random(System.currentTimeMillis());
	OrderTableModel orderTableModel = new OrderTableModel();

	/**
	 * Create the composite
	 * 
	 * @param parent
	 * @param style
	 */
	public OrderPanel(Composite parent, int style) {
		super(parent, style);
		setLayout(new GridLayout());

		final Composite composite = new Composite(this, SWT.NONE);
		composite.setLayout(new FillLayout());
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		final NatTable natTable = new NatTable(composite, SWT.BORDER | SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED
				| SWT.V_SCROLL | SWT.H_SCROLL, orderTableModel);

		final Composite composite_1 = new Composite(this, SWT.NONE);
		final GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		composite_1.setLayout(gridLayout);
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		final Button addOrderButton = new Button(composite_1, SWT.NONE);
		addOrderButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				Order order = new Order();
				order.setClOrdID(String.valueOf(Math.abs(random.nextLong())));
				order.setHandlInst(String.valueOf(Order.HandlInstEnum.ORDER_PUBLIC.getNum()));
				order.setOrdType('1');
				order.setSide(Order.SideEnum.BUY.getNum());
				order.setSymbol("0005.HK");
				order.setOrderQty(400);
				
				orderTableModel.getOrderList().add(order);
				natTable.updateResize();
			}
		});
		addOrderButton.setText("Add Order");

		final Button startButton = new Button(composite_1, SWT.NONE);
		startButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				//Create and update order with special row effect
				
			}
		});
		startButton.setText("Start Simulator");
		//
	}

	@Override
	public void dispose() {
		super.dispose();
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
