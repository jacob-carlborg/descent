package net.sourceforge.nattable.example.demo.simple;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.ColumnSelectionBehaviorEnum;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.editor.TextCellEditor;
import net.sourceforge.nattable.example.demo.User;
import net.sourceforge.nattable.listener.IValueChangeListener;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.renderer.AbstractColumnHeaderRenderer;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.content.DefaultEditableRule;
import net.sourceforge.nattable.typeconfig.style.DefaultStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.widgets.Display;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��17��<br>
 */
public class SimpleTableModel extends DefaultNatTableModel {
	org.eclipse.swt.graphics.Image image = new org.eclipse.swt.graphics.Image(Display.getDefault(), SimpleTableModel.class.getClassLoader().getResourceAsStream("icon.gif"));
	List<User> userList = new ArrayList<User>();
	final ListDataProvider<User> dataProvider = new ListDataProvider<User>(userList, new IColumnAccessor<User>() {

		public int getColumnCount() {
			return SimpleColumnEnum.values().length + random;
		}

		public Object getColumnValue(User rowObj, int col) {
			final DateFormat dateFormat = DateFormat.getInstance();
			SimpleColumnEnum columnEnum = SimpleColumnEnum.getColumn(col);
			if (columnEnum != null)
				switch (columnEnum) {
				case NAME:
					return rowObj.getName();
				case BIRTHDAY:
					return dateFormat.format(rowObj.getBirthday());
				case PASSWORD:
					return rowObj.getPassword();
				case USER_ID:
					return String.valueOf(rowObj.getUserID());
				}
			return "[ col " + col + " ]";
		}

	});
	int random = 0;

	public SimpleTableModel() {
		//column configuration
		final DefaultColumnHeaderConfig columnHeaderConfig = new DefaultColumnHeaderConfig(new IColumnHeaderLabelProvider() {

			public String getColumnHeaderLabel(int col) {
				return null;
			}
		});
		columnHeaderConfig.setCellRenderer(columnHeaderRenderer);
		columnHeaderConfig.setColumnHeaderRowCount(1);
		columnHeaderConfig.setColumnHeaderRowHeightConfig(new SizeConfig(20));
		setColumnHeaderConfig(columnHeaderConfig);
		
		// body configuration
		IConfigTypeResolver configTypeResolver = new IConfigTypeResolver() {

			public String getConfigType(int modelBodyRow, int modelBodyColumn) {
				SimpleColumnEnum columnEnum = SimpleColumnEnum.getColumn(modelBodyColumn);
				if (columnEnum != null) {
					switch (columnEnum) {
					case USER_ID:
					case NAME:
					case PASSWORD:
						return "SPECIAL";
					}
				}
				return "NORMAL";
			}
			
		};
		
		ContentConfigRegistry contentConfigRegistry = new ContentConfigRegistry(configTypeResolver);
		TextCellEditor textCellEditor = new TextCellEditor();
		contentConfigRegistry.registerDefaultCellEditor(textCellEditor);
		contentConfigRegistry.registerEditableRule("SPECIAL", new DefaultEditableRule(true));
		
		StyleConfigRegistry styleConfigRegistry = new StyleConfigRegistry(configTypeResolver);
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.toString(), "SPECIAL", new DefaultStyleConfig(GUIHelper.COLOR_YELLOW, null, null, null));
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.toString(), "NORMAL", new DefaultStyleConfig(GUIHelper.COLOR_WHITE, null, null, null));
		
		final DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider, contentConfigRegistry, styleConfigRegistry);
		bodyConfig.setRowHeightConfig(new SizeConfig(20));
		bodyConfig.setColumnWidthConfig(new SizeConfig(100));
		
		setBodyConfig(bodyConfig);
		
		final SizeConfig columnWidthConfig = bodyConfig.getColumnWidthConfig();
		columnWidthConfig.setDefaultSize(100);
		for (final SimpleColumnEnum columnEnum : SimpleColumnEnum.values()) {
			columnWidthConfig.setSize(columnEnum.ordinal(), columnEnum.width);
		}
		columnWidthConfig.setDefaultResizable(true);
		
		bodyConfig.setRowHeightConfig(new SizeConfig(20));
		
		setMultipleSelection(true);
		setEnableMoveColumn(true);
		setFullRowSelection(true);
		setSingleCellSelection(false);
		setSortingEnabled(false);
		setColumnSelectionBehavior(ColumnSelectionBehaviorEnum.SINGLE_CLICK_SELECTION_NO_SORTING);
	}

	public int getRandom() {
		return random;
	}

	public void setRandom(int random) {
		this.random = random;
	}

	/**
	 * @return the userList
	 */
	public List<User> getUserList() {
		return userList;
	}

	/**
	 * @param userList
	 *            the userList to set
	 */
	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	// Column header //////////////////////////////////////////////////////////

	AbstractColumnHeaderRenderer columnHeaderRenderer = new AbstractColumnHeaderRenderer() {

		public String getDisplayText(int row, int col) {
			SimpleColumnEnum columnEnum = SimpleColumnEnum.getColumn(col);
			if (columnEnum != null)
				switch (columnEnum) {
				case NAME:
					return SimpleColumnEnum.NAME.toString();
				case BIRTHDAY:
					return SimpleColumnEnum.BIRTHDAY.toString();
				case PASSWORD:
					return SimpleColumnEnum.PASSWORD.toString();
				case USER_ID:
					return SimpleColumnEnum.USER_ID.toString();
				}
			return "Column " + col;
		}

	};

	// Body ///////////////////////////////////////////////////////////////////

	@Override
	public boolean isAllBodyRowsSameHeight() {
		return true;
	}

	@Override
	public int getInitialBodyColumnWidth(int col) {
		if (SimpleColumnEnum.values().length > col) {
			return SimpleColumnEnum.getColumn(col).width;
		}
		
		return 100;
	}

	@Override
	public boolean isBodyColumnResizable(int col) {
		return true;
	}

	// Grid ///////////////////////////////////////////////////////////////////

	public void attachListeners(NatTable natTable) {
		natTable.addValueChangeListener(new IValueChangeListener() {

			public void valueChanged(int row, int col, Object oldValue, Object newValue) {
				SimpleColumnEnum columnEnum = SimpleColumnEnum.getColumn(col);
				switch (columnEnum) {
				case NAME:
					userList.get(row).setName(newValue.toString());
					break;
				case PASSWORD:
					userList.get(row).setPassword(newValue.toString());
					break;
				case USER_ID:
					userList.get(row).setUserID(Integer.parseInt(newValue.toString()));
					break;
				}
			}

		});
	}
}
