package net.sourceforge.nattable.example.pricing;

import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.typeconfig.TypedCellOverrider;
import net.sourceforge.nattable.typeconfig.TypedRowOverrider;
import net.sourceforge.nattable.typeconfig.style.AlternateRowColoringStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.StaticStyleAssembler;
import net.sourceforge.nattable.typeconfig.style.StaticStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

import org.eclipse.swt.widgets.Display;

public class StyleEnabler {
	public void enableCustomStyles(StyleConfigRegistry styleRegistry, IRowDataProvider<PricingDataBean> rowDataProvider, TypedCellOverrider<PricingDataBean> cellOverrider,
			TypedRowOverrider<PricingDataBean> rowOverrider) {
		
		StyleConfigTypeResolver resolver = initStyleTypeResolver(rowDataProvider, cellOverrider, rowOverrider);
		
		enableAlternateRowColoring(styleRegistry);
		String[] styleTypes = resolver.getStyleTypes();
		registerCustomStyles(styleRegistry, styleTypes);
		registerDisplayModeBasedStyles(styleRegistry);
		
		//register config type resolver
		styleRegistry.setConfigTypeResolver(resolver);
		
		//register inheritance
		setInheritance(styleRegistry, styleTypes);
	}
	
	public StyleConfigTypeResolver initStyleTypeResolver(IRowDataProvider<PricingDataBean> rowDataProvider, TypedCellOverrider<PricingDataBean> cellOverrider,
			TypedRowOverrider<PricingDataBean> rowOverrider) {
		return new StyleConfigTypeResolver(rowDataProvider, cellOverrider, rowOverrider);
	}
	
	public void enableAlternateRowColoring(StyleConfigRegistry styleRegistry) {
		styleRegistry.registerDefaultStyleConfig(DisplayModeEnum.NORMAL.name(), new AlternateRowColoringStyleConfig());
	}

	private void registerCustomStyles(StyleConfigRegistry styleRegistry, String[] styleTypes) {
		Display display = Display.getDefault();
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), styleTypes[0], 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "155,231,223"), 
						StaticStyleAssembler.assembleColor(display, "0,0,0"), 
						null, 
						null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), styleTypes[1], 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "155,231,123"), 
						StaticStyleAssembler.assembleColor(display, "0,0,0"), 
						null, 
						null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), styleTypes[2], 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "160,227,255"), 
						StaticStyleAssembler.assembleColor(display, "0,0,0"), 
						null, 
						null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), styleTypes[3], 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "130,230,150"), 
						StaticStyleAssembler.assembleColor(display, "0,0,0"), 
						null, 
						null));
	}

	private void setInheritance(StyleConfigRegistry styleRegistry, String[] styleTypes) {
		styleRegistry.registerSuperType(styleTypes[0], "default_font");
		styleRegistry.registerSuperType(styleTypes[1], "default_font");
		styleRegistry.registerSuperType(styleTypes[2], "default_italic_font");
		styleRegistry.registerSuperType(styleTypes[3], "default_bold_font");
		styleRegistry.registerSuperType("blink_up", "blink_base");
		styleRegistry.registerSuperType("blink_down", "blink_base");
	}
	
	private void registerDisplayModeBasedStyles(StyleConfigRegistry styleRegistry) {
		Display display = Display.getDefault();

		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "error_style", 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "255,231,123"), 
						StaticStyleAssembler.assembleColor(display, "0,0,0"), 
						StaticStyleAssembler.assembleFont(display, "arial", "BOLD", "10"), 
						null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.SELECT.name(), "error_style", 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "215,191,83"), 
						StaticStyleAssembler.assembleColor(display, "60,80,160"), 
						StaticStyleAssembler.assembleFont(display, "arial", "ITALIC|BOLD", "10"), 
						null));
		
		styleRegistry.registerDefaultStyleConfig(DisplayModeEnum.SELECT.name(), 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "230,230,230"),
				StaticStyleAssembler.assembleColor(display, "60,80,160"),
				null,
				null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "blink_up", 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "120,120,250"), 
						null, 
						null, 
						null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "blink_down", 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "250,120,120"), 
						null, 
						null, 
						null));	
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "default_font", 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "230,230,230"),
				StaticStyleAssembler.assembleColor(display, "60,80,160"),
				StaticStyleAssembler.assembleFont(display, "verdana", "NORMAL", "10"),
				null));	
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "default_italic_font", 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "230,230,230"),
				StaticStyleAssembler.assembleColor(display, "60,80,160"),
				StaticStyleAssembler.assembleFont(display, "verdana", "ITALIC", "10"),
				null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "default_bold_font", 
				new StaticStyleConfig(StaticStyleAssembler.assembleColor(display, "230,230,230"),
				StaticStyleAssembler.assembleColor(display, "60,80,160"),
				StaticStyleAssembler.assembleFont(display, "verdana", "BOLD", "10"),
				null));
		
		styleRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.name(), "blink_base", 
				new StaticStyleConfig(null,
				StaticStyleAssembler.assembleColor(display, "250,250,250"),
				StaticStyleAssembler.assembleFont(display, "courier", "BOLD", "10"),
				null));
	}
}