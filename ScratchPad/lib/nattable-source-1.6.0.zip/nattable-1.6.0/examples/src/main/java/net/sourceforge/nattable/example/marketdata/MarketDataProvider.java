package net.sourceforge.nattable.example.marketdata;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import net.sourceforge.nattable.NatTable;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

public class MarketDataProvider implements net.sourceforge.nattable.data.IDataProvider {
	private Map<String, List<InstrumentHistoricalData>> map = new LinkedHashMap<String, List<InstrumentHistoricalData>>();
	private SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyyy hh:mm");
	private SimpleDateFormat dateF = new SimpleDateFormat("MM/dd/yyyyy");
	private SimpleDateFormat timeF = new SimpleDateFormat("hh:mm");
	private int instrumentcount = 0;
	private ReentrantReadWriteLock updatelock = new ReentrantReadWriteLock();
	private AtomicLong eventCount = new AtomicLong(0);

	public MarketDataProvider() {
		initData();

	}

	private void initData() {
		try {
			URL url = MarketDataProvider.class.getClassLoader().getResource("mdhk");

			File file = new File(url.toURI());

			File[] files = file.listFiles();

			int len = files.length;
			for (int i = 0; i < len; i++) {
				instrumentcount++;
				FileReader fileReader = new FileReader(files[i]);
				BufferedReader bufferedReader = new BufferedReader(fileReader);
				// title
				bufferedReader.readLine();

				String data = null;
				ArrayList<InstrumentHistoricalData> arrayList = new ArrayList<InstrumentHistoricalData>();
				while ((data = bufferedReader.readLine()) != null) {

					InstrumentHistoricalData historicalData = new InstrumentHistoricalData();
					historicalData.setStock(files[i].getName() + "." + instrumentcount);
					String[] str = data.split(",");

					Date date = dateFormat.parse(str[1] + " " + str[2]);

					historicalData.setDate(date);
					historicalData.setPrice(Double.valueOf(str[3]));
					historicalData.setQty(Double.valueOf(str[4]));
					historicalData.setValue(Double.valueOf(str[5]));
					historicalData.setTradeType(str[6]);

					arrayList.add(0, historicalData);
				}
				fileReader.close();
				map.put(files[i].getName() + "." + instrumentcount, arrayList);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getColumnCount() {

		return 7;
	}

	public int getRowCount() {

		return map.size();
	}

	public InstrumentHistoricalData getInstrumentHistoricalData(int row) {

		InstrumentHistoricalData historicalData = null;
		try {
			if (map.size() > row) {
				String key = map.keySet().toArray()[row].toString();
				List<InstrumentHistoricalData> list = map.get(key);

				historicalData = list.get(0);
			}
		} catch (RuntimeException e) {
			e.printStackTrace();
		}

		return historicalData;
	}

	public Object getValue(int row, int col) {
		if (map.size() > row) {
			String key = map.keySet().toArray()[row].toString();
			List<InstrumentHistoricalData> list = map.get(key);

			InstrumentHistoricalData historicalData = list.get(0);

			switch (col) {
			case 0:
				return historicalData.getStock();
			case 1:
				return dateF.format(historicalData.getDate());
			case 2:
				return timeF.format(historicalData.getDate());
			case 3:
				return historicalData.getPrice();
			case 4:
				return historicalData.getQty();
			case 5:
				return historicalData.getValue();
			case 6:
				return historicalData.getTradeType();

			}
		}
		return null;
	}

	public void run(final NatTable natTable, final Label label) {

		final Calendar calendar = Calendar.getInstance();
		calendar.set(2008, 0, 30, 10, 0);

		Timer ratetimer = new Timer(true);
		ratetimer.scheduleAtFixedRate(new TimerTask() {

			public void run() {
				final long count = eventCount.get();
				eventCount.set(0);

				Display.getDefault().asyncExec(new Runnable() {

					public void run() {
						label.setText("Refresh Rate : " + count);
					}

				});

			}

		}, 1000, 1000);

		Timer deletetimer = new Timer(true);
		deletetimer.scheduleAtFixedRate(new TimerTask() {
			Random random = new Random(System.currentTimeMillis());

			public void run() {
				updatelock.writeLock().lock();
				int index = random.nextInt(map.size());
				String key = map.keySet().toArray()[index].toString();
				InstrumentHistoricalData data = map.get(key).get(0);

				data.setDelete(true);
				updatelock.writeLock().unlock();
				eventCount.addAndGet(1);
				natTable.getConflationSupport().redrawUpdatedRow(index, index);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				updatelock.writeLock().lock();
				map.remove(key);
				updatelock.writeLock().unlock();
				eventCount.addAndGet(1);
				natTable.getConflationSupport().redrawDeletedRow(index, index);

			}

		}, 1000, 1000);

		Timer timer = new Timer(true);
		timer.scheduleAtFixedRate(new TimerTask() {

			public void run() {
				updatelock.writeLock().lock();
				initData();
				updatelock.writeLock().unlock();
				eventCount.addAndGet(1);
				natTable.getConflationSupport().redrawInsertedRow(map.size(), map.size() + 8);

			}

		}, 1000, 5000);
		timer.scheduleAtFixedRate(new TimerTask() {

			public void run() {
				updatelock.writeLock().lock();
				Collection<List<InstrumentHistoricalData>> collection = map.values();

				Iterator<List<InstrumentHistoricalData>> iterator = collection.iterator();

				int count = 0;
				while (iterator.hasNext()) {
					List<InstrumentHistoricalData> list = iterator.next();

					InstrumentHistoricalData data = list.get(0);

					if (calendar.get(Calendar.HOUR) >= data.getDate().getHours()
							&& calendar.get(Calendar.MINUTE) > data.getDate().getMinutes()) {
						if (list.size() > 1) {
							list.remove(0);
							list.get(0).setUpdate(true);
						}
						eventCount.addAndGet(1);
						natTable.getConflationSupport().redrawUpdatedRow(count, count);
					} else {
						if (list.get(0).isUpdate()) {
							list.get(0).setUpdate(false);
							eventCount.addAndGet(1);
							natTable.getConflationSupport().redrawUpdatedRow(count, count);
						}
					}

					count++;
				}
				calendar.add(Calendar.SECOND, 10);
				updatelock.writeLock().unlock();
			}

		}, 100, 100);

	}
}
