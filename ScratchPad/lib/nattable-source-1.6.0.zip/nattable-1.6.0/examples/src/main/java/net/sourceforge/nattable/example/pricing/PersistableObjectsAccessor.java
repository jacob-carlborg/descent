package net.sourceforge.nattable.example.pricing;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.sorting.ISortingDirectionChangeListener;
import net.sourceforge.nattable.support.ColumnGroupSupport;
import net.sourceforge.nattable.support.ColumnSortSupport;
import net.sourceforge.nattable.typeconfig.TypedCellOverrider;
import net.sourceforge.nattable.typeconfig.TypedRowOverrider;
import net.sourceforge.nattable.typeconfig.persistence.AbstractPersistor;
import net.sourceforge.nattable.typeconfig.persistence.ColumnGroupPersistor;
import net.sourceforge.nattable.typeconfig.persistence.DefaultNatModelPersistor;
import net.sourceforge.nattable.typeconfig.persistence.NatTablePersistor;
import net.sourceforge.nattable.typeconfig.persistence.StyleConfigRegistryPersistor;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;

public class PersistableObjectsAccessor {
	private static final String TABLE_STORE_FILE_NAME = "tableSettings.store";
	private static final String MODEL_STORE_FILE_NAME = "modelSettings.store";
	private static final String STYLE_STORE_FILE_NAME = "styleSettings.store";
	private static final String COLUMN_GROUP_STORE_FILE_NAME = "columnGroups.store";

	// Persiste settings
	public static void persistNatTable(NatTable natTable) throws IOException {
		persistObject(new NatTablePersistor(natTable), TABLE_STORE_FILE_NAME);
	}

	public static void persistNatTableModel(DefaultNatTableModel natTableModel) throws IOException {
		persistObject(new DefaultNatModelPersistor(natTableModel), MODEL_STORE_FILE_NAME);
	}

	public static<T> void persistStyleConfigRegistry(StyleConfigRegistry styleRegistry, TypedCellOverrider<T> cellOverrider, TypedRowOverrider<T> rowOverrider) throws IOException {
		persistObject(new StyleConfigRegistryPersistor<T>(styleRegistry, cellOverrider, rowOverrider), STYLE_STORE_FILE_NAME);
	}
	
	public static void persistColumnGroups(ColumnGroupSupport colGroups) throws IOException {
		persistObject(new ColumnGroupPersistor(colGroups), COLUMN_GROUP_STORE_FILE_NAME);
	}
	
	private static void persistObject(AbstractPersistor persistor, String fileName) throws IOException {
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(fileName);
			persistor.save(out);
		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

	
	//Restore settings
	public static boolean restoreNatTable(NatTable natTable) throws IOException {
		boolean restored = restoreObject(new NatTablePersistor(natTable), TABLE_STORE_FILE_NAME);
		if (restored) {
			restoreSortingDirection(natTable);
		}
		return restored;
	}

	public static boolean restoreNatTableModel(DefaultNatTableModel model) throws IOException {
		return restoreObject(new DefaultNatModelPersistor(model), MODEL_STORE_FILE_NAME);
	}

	public static<T> boolean restoreStyleRegistry(StyleConfigRegistry styleRegistry, TypedCellOverrider<T> cellOverrider, TypedRowOverrider<T> rowOverrider) throws IOException {
		return restoreObject(new StyleConfigRegistryPersistor<T>(styleRegistry, cellOverrider, rowOverrider), STYLE_STORE_FILE_NAME);
	}

	public static boolean restoreColumnGroups(ColumnGroupSupport colGroups) throws IOException {
		return restoreObject(new ColumnGroupPersistor(colGroups), COLUMN_GROUP_STORE_FILE_NAME);
	}

	private static boolean restoreObject(AbstractPersistor persistor, String fileName) throws IOException {
		File source = new File(fileName);
		FileInputStream in = null;
		if (source.exists()) {
			try {
				in = new FileInputStream(source);
				persistor.load(in);
			} finally {
				if (in != null) {
					in.close();
				}
			}
			return true;
		}
		return false;
	}

	private static void restoreSortingDirection(NatTable natTable) {
		// restore sort table in case sort direction were persisted
		final ColumnSortSupport sorter = natTable.getColumnSortSupport();
		if (sorter != null) {
			ISortingDirectionChangeListener sortingColumnHeaderRenderer = (ISortingDirectionChangeListener) natTable.getNatTableModel().getColumnHeaderCellRenderer();
			sortingColumnHeaderRenderer.sortingDirectionChanged(sorter.getSortingDirections());
			natTable.fireSortingDirectionChanged(sorter.getSortingDirections());
		}
	}
}
