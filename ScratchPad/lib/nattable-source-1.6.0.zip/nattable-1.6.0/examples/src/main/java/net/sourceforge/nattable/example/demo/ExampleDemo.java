package net.sourceforge.nattable.example.demo;

import java.text.DateFormat;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.example.demo.excel.ExcelTableModel;
import net.sourceforge.nattable.example.demo.fixorder.OrderPanel;
import net.sourceforge.nattable.example.demo.glazedlists.GlazedListsTableModel;
import net.sourceforge.nattable.example.demo.simple.SimpleTableModel;
import net.sourceforge.nattable.util.RowHeightIndex;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;

import ca.odell.glazedlists.matchers.Matcher;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��17��<br>
 */
public class ExampleDemo extends Shell {

	private NatTable glazedListTable;

	/**
	 * Launch the application
	 * 
	 * @param args
	 */
	public static void main(final String args[]) {
		try {
			final Display display = Display.getDefault();
			final ExampleDemo shell = new ExampleDemo(display, SWT.SHELL_TRIM);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the shell
	 * 
	 * @param display
	 * @param style
	 */
	public ExampleDemo(final Display display, final int style) {
		super(display, style);
		createContents();
		setLayout(new GridLayout());
	}

	/**
	 * Create contents of the window
	 */
	protected void createContents() {

		RowHeightIndex.BASE = 1000;

		setText("NatTable Demo");
		setSize(800, 600);

		final Composite composite = new Composite(this, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		composite.setLayout(new GridLayout());

		final TabFolder tabFolder = new TabFolder(composite, SWT.NONE);
		tabFolder.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		glazedListTable = createGlazedListsExampleTab(tabFolder);

		createSimpleExampleTab(tabFolder);

		createExcelExampleTab(tabFolder);
	}

	// GlazedLists Example ////////////////////////////////////////////////////

	private NatTable createGlazedListsExampleTab(final TabFolder tabFolder) {
		final GlazedListsTableModel glazedListsTableModel = new GlazedListsTableModel();

		final TabItem glazedListDemoTabItem = new TabItem(tabFolder, SWT.NONE);
		glazedListDemoTabItem.setText("GlazedLists Demo");

		final Composite composite_5 = new Composite(tabFolder, SWT.NONE);
		composite_5.setLayout(new GridLayout());
		glazedListDemoTabItem.setControl(composite_5);

		final Composite composite_6 = new Composite(composite_5, SWT.NONE);
		final GridLayout gridLayout_1 = new GridLayout();
		gridLayout_1.numColumns = 4;
		composite_6.setLayout(gridLayout_1);
		composite_6.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));

		final Composite glazedListTableComposite = new Composite(composite_5, SWT.NONE);
		glazedListTableComposite.setLayout(new FillLayout());
		final GridData gd_glazedListTableComposite = new GridData(SWT.FILL, SWT.FILL, true, true);
		glazedListTableComposite.setLayoutData(gd_glazedListTableComposite);

		final NatTable natTable = new NatTable(glazedListTableComposite, SWT.BORDER | SWT.NO_BACKGROUND
				| SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, glazedListsTableModel);
		glazedListsTableModel.attachListeners(natTable);

		final Label filterByNameLabel = new Label(composite_6, SWT.NONE);
		filterByNameLabel.setText("Filter By Name : ");

		final Text filterNameText = new Text(composite_6, SWT.BORDER);
		initNameFilter(natTable, glazedListsTableModel, filterNameText);

		final GridData gd_filterNameText = new GridData(SWT.FILL, SWT.CENTER, false, false);
		gd_filterNameText.widthHint = 111;
		filterNameText.setLayoutData(gd_filterNameText);

		final Label ituneFilterLabel = new Label(composite_6, SWT.NONE);
		ituneFilterLabel.setText("iTune Filter : ");

		final Text iTuneFilterText = new Text(composite_6, SWT.BORDER);
		initITuneFilter(natTable, glazedListsTableModel, iTuneFilterText);

		final GridData gd_iTuneFilterTxt = new GridData(SWT.FILL, SWT.CENTER, false, false);
		gd_iTuneFilterTxt.widthHint = 161;
		iTuneFilterText.setLayoutData(gd_iTuneFilterTxt);

		initGlazedListTableModel(glazedListsTableModel);
		return natTable;
	}

	private final DateFormat dateFormat = DateFormat.getInstance();

	private void initITuneFilter(final NatTable natTable, final GlazedListsTableModel glazedListsTableModel,
			final Text iTuneFilterText) {
		iTuneFilterText.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(final KeyEvent e) {
				final String text = iTuneFilterText.getText();
				glazedListsTableModel.setFilter(natTable, new Matcher<User>() {

					public boolean matches(final User arg0) {
						if (text.length() <= 0) {
							return true;
						}
						if (arg0.getName().indexOf(text) >= 0) {
							return true;
						}
						if (arg0.getPassword().indexOf(text) >= 0) {
							return true;
						}
						if (String.valueOf(arg0.getUserID()).indexOf(text) >= 0) {
							return true;
						}
						if (dateFormat.format(arg0.getBirthday()).indexOf(text) >= 0) {
							return true;
						}

						return false;
					}

				});
			}

		});
		iTuneFilterText.addFocusListener(new FocusListener() {

			public void focusLost(final FocusEvent arg0) {
				final String text = iTuneFilterText.getText();
				glazedListsTableModel.setFilter(natTable, new Matcher<User>() {

					public boolean matches(final User arg0) {
						if (text.length() <= 0) {
							return true;
						}
						if (arg0.getName().indexOf(text) >= 0) {
							return true;
						}
						if (arg0.getPassword().indexOf(text) >= 0) {
							return true;
						}
						if (String.valueOf(arg0.getUserID()).indexOf(text) >= 0) {
							return true;
						}
						if (dateFormat.format(arg0.getBirthday()).indexOf(text) >= 0) {
							return true;
						}
						return false;
					}

				});

			}

			public void focusGained(final FocusEvent arg0) {

			}

		});
	}

	private void initNameFilter(final NatTable natTable, final GlazedListsTableModel glazedListsTableModel,
			final Text filterNameText) {
		filterNameText.addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(final KeyEvent e) {
				final String text = filterNameText.getText();
				glazedListsTableModel.setFilter(natTable, new Matcher<User>() {

					public boolean matches(final User arg0) {
						if (arg0.getName().startsWith(text)) {
							return true;
						}
						return false;
					}

				});
			}

		});
		filterNameText.addFocusListener(new FocusListener() {

			public void focusLost(final FocusEvent arg0) {
				final String text = filterNameText.getText();
				glazedListsTableModel.setFilter(natTable, new Matcher<User>() {

					public boolean matches(final User arg0) {
						if (arg0.getName().startsWith(text)) {
							return true;
						}
						return false;
					}

				});

			}

			public void focusGained(final FocusEvent arg0) {

			}

		});
	}

	private void initGlazedListTableModel(final GlazedListsTableModel glazedListsTableModel) {
		int count = 1;
		String[] userNames = new String[]{"Chan Kong","Chan Kwok Shun Anson","Chan Tin Yan, Rufina",
				"Chan Tsz Wang","Chan Yuen Hung","Cheng Sau Kuen","Meau Yin Tai","Pang Chi Kong",
				"Siu Lai Ngor","Siu Shing Wai","So Ka Man","Sze Ching Yan","Wong Kwan Hing"};
		int userCounter = 0;
		for (int i = 0; i < 100; i++) {			
			User user = createUser(i);
			user.setName(userNames[userCounter]);
			user.setUserID(count++);
			glazedListsTableModel.addUser(user);
			
			if(++userCounter >= userNames.length) {
				userCounter = 0;
			}
		}
	}

	// Simple Example /////////////////////////////////////////////////////////

	private NatTable createSimpleExampleTab(final TabFolder tabFolder) {
		final SimpleTableModel model = new SimpleTableModel();

		final TabItem fixOrderSimulatorTabItem = new TabItem(tabFolder, SWT.NONE);
		fixOrderSimulatorTabItem.setText("Fix Order Simulator");

		final OrderPanel orderPanel = new OrderPanel(tabFolder, SWT.NONE);
		fixOrderSimulatorTabItem.setControl(orderPanel);

		final TabItem simpleTabItem = new TabItem(tabFolder, SWT.NONE);
		simpleTabItem.setText("Simple Style");

		final Composite composite_1 = new Composite(tabFolder, SWT.NONE);
		composite_1.setLayout(new GridLayout());
		simpleTabItem.setControl(composite_1);

		final Composite composite_2 = new Composite(composite_1, SWT.NONE);
		composite_2.setLayout(new FillLayout());
		composite_2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		final NatTable natTable = new NatTable(composite_2,  SWT.BORDER | SWT.NO_BACKGROUND
				| SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, model);

		model.attachListeners(natTable);

		// data generating controls
		final Composite composite_3 = new Composite(composite_1, SWT.NONE);
		composite_3.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		final GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 7;
		composite_3.setLayout(gridLayout);

		final Button addRowButton = new Button(composite_3, SWT.NONE);
		addRowButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent e) {

				model.getUserList().add(createUser(model.getUserList().size()));
				natTable.redrawInsertedBodyRow(model.getUserList().size(), model.getUserList().size());
			}
		});
		addRowButton.setText("Add Row");

		final Button deleteRowButton = new Button(composite_3, SWT.NONE);
		deleteRowButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent e) {
				final int[] selectedRows = natTable.getSelectionModel().getSelectedRows();

				if (selectedRows.length == 1) {
					model.getUserList().remove(model.getUserList().get(selectedRows[0]));
				}
				natTable.clearSelection();
				natTable.updateResize();
			}
		});
		deleteRowButton.setText("Delete Row");

		final Button removeAllButton = new Button(composite_3, SWT.NONE);
		removeAllButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent e) {
				model.getUserList().clear();
				natTable.clearSelection();
				natTable.updateResize();
			}
		});
		removeAllButton.setText("Remove All");

		final Button add1000RowsButton = new Button(composite_3, SWT.NONE);
		add1000RowsButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent e) {
				for (int i = 0; i < 10000; i++) {
					model.getUserList().add(createUser(i));
				}
				natTable.updateResize();
			}
		});
		add1000RowsButton.setText("Add 10,000 Rows");

		final Button add100000RowsButton = new Button(composite_3, SWT.NONE);
		add100000RowsButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent e) {
				int size = model.getUserList().size();
				for (int i = 0; i < 100000; i++) {
					model.getUserList().add(createUser(size + i));
				}
				natTable.updateResize();
			}
		});
		add100000RowsButton.setText("Add 100,000 Rows");

		final Button button = new Button(composite_3, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent e) {
				int size = model.getUserList().size();
				for (int i = 0; i < 1000000; i++) {
					model.getUserList().add(createUser(size + i));
				}
				natTable.updateResize();
			}
		});
		button.setText("Add 1,000,000 Rows");

		final Button add100ColumnsButton = new Button(composite_3, SWT.NONE);
		add100ColumnsButton.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(final SelectionEvent e) {

				model.setRandom(100);
				final int[] colOrders = new int[model.getBodyColumnCount()];
				for (int i = 0; i < colOrders.length; i++) {
					colOrders[i] = i;
				}
				natTable.setModelBodyColumnOrder(colOrders);
				natTable.updateResize();
			}
		});
		add100ColumnsButton.setText("Add 100 Columns");
		return natTable;
	}

	// Excel Example //////////////////////////////////////////////////////////

	private void createExcelExampleTab(final TabFolder tabFolder) {
		final TabItem excelStyleTabItem = new TabItem(tabFolder, SWT.NONE);
		excelStyleTabItem.setText("Excel Style");

		final Composite composite_4 = new Composite(tabFolder, SWT.NONE);
		composite_4.setLayout(new FillLayout());
		excelStyleTabItem.setControl(composite_4);

		final ExcelTableModel excelTableModel = new ExcelTableModel();

		final NatTable natTable = new NatTable(composite_4, SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE
				| SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, excelTableModel);

		excelTableModel.attachListeners(natTable);
	}

	// /////////////////////////////////////////////////////////////////////////

	private User createUser(int userCount) {
		final User user = new User();
		user.setName("Andy " + userCount++);
		user.setPassword("password");
		user.setUserID((int)(Math.random() * 100000));
		user.setBirthday(System.currentTimeMillis());
		return user;
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	public NatTable getGlazedListTable() {
		return glazedListTable;
	}

}
