/**
 * 
 */
package net.sourceforge.nattable.example.demo.fixorder;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2008�~5��25��<br>
 */
public enum FixOrderEnum {
	ClOrdID(11, "ClOrdID"), HandlInst(21, "HandlInst"), Symbol(55, "Symbol"), Side(54, "Side"), OrderQty(38, "OrderQty"), OrdType(
			40, "OrdType");
	int num;
	String name;

	FixOrderEnum(int num, String name) {
		this.num = num;
		this.name = name;
	}

	public int getNum() {
		return num;
	}

	public String getName() {
		return name;
	}

	public static FixOrderEnum getColumn(int col) {
		switch (col) {
		case 0:
			return ClOrdID;
		case 1:
			return HandlInst;
		case 2:
			return Symbol;
		case 3:
			return Side;
		case 4:
			return OrderQty;
		case 5:
			return OrdType;
		}
		return null;
	}
}
