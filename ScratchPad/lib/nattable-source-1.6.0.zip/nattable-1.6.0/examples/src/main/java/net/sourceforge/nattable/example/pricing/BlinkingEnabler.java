package net.sourceforge.nattable.example.pricing;

import ca.odell.glazedlists.EventList;
import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.extension.blink.BlinkingFieldChangeHandler;
import net.sourceforge.nattable.support.ConflationSupport;
import net.sourceforge.nattable.typeconfig.DelegatingConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;

public class BlinkingEnabler{
	private PricingValueChangeHandler valueChanger;
	private PriceUpdaterRunnable<PricingDataBean> updateRunnable;
	private BlinkingFieldChangeHandler<PricingDataBean> fieldChangeHandler;
	
	BlinkingEnabler(EventList<PricingDataBean>sortedRows, IRowIdAccessor<PricingDataBean> rowIdProvider, IRowDataProvider<PricingDataBean> rowDataProvider, ConflationSupport conflationSupport) {
		valueChanger = new PricingValueChangeHandler();
		fieldChangeHandler = new BlinkingFieldChangeHandler<PricingDataBean>(sortedRows, 667, rowIdProvider, rowDataProvider);
		fieldChangeHandler.setConflationSupport(conflationSupport);
		updateRunnable = new PriceUpdaterRunnable<PricingDataBean>(sortedRows, valueChanger);
	}
	
	void startBlinking() {
		updateRunnable.reset();
		Thread updateThread = new Thread(updateRunnable);
		updateThread.setDaemon(true);
		updateThread.start();
	}
	
	void stopBlinking() {
		updateRunnable.stop();
	}
	
	public void disableBlinking(int modelColumnIndex) {
		valueChanger.disableBlinking(modelColumnIndex);
		fieldChangeHandler.removeBlinkingField(modelColumnIndex);
		
		if (!fieldChangeHandler.hasBlinkingFields()) {
			stopBlinking();
		}
	}
	
	public void registerCellForBlinking(int modelColumnIndex) {
		valueChanger.registerCellForBlinking(modelColumnIndex);
	}
	
	public DelegatingConfigTypeResolver linkStyleConfigTypeResolver(IConfigTypeResolver styleConfigTypeResolver) {
		return new DelegatingConfigTypeResolver(fieldChangeHandler, styleConfigTypeResolver);
	}
	
	public void enableBlinking(int modelColumnIndex) {
		// Checks to see if fields are blinking to determine whether blinking needs to start
		boolean blinkingStarted = fieldChangeHandler.hasBlinkingFields();
		
		// Map column index to ColumnHeaders enum
		ColumnHeaders columnHeader = ColumnHeaders.values()[modelColumnIndex];	
		String fieldName = columnHeader.getProperty();
		
		valueChanger.enableBlinking(modelColumnIndex, columnHeader);
		
		// Hook up the field to enable the display style changes for this field
		fieldChangeHandler.setBlinkingField(fieldName, modelColumnIndex);
		if(!blinkingStarted) {
			startBlinking();
		}
	}
	
	public ColumnHeaders[] getBlinkingColumnHeaders() {
		return valueChanger.getBlinkingColumnHeaders();
	}
}

