package net.sourceforge.nattable.example.marketdata;

import java.util.Date;
import java.util.concurrent.atomic.AtomicBoolean;

public class InstrumentHistoricalData {

	private String stock;
	private Number price;
	private Number qty;
	private Number value;
	private String tradeType;
	private Date date;
	private AtomicBoolean update = new AtomicBoolean(false);
	private AtomicBoolean delete = new AtomicBoolean(false);

	public boolean getDelete() {
		return delete.get();
	}

	public void setDelete(boolean delete) {
		this.delete.set(delete);
	}

	public boolean isUpdate() {
		return update.get();
	}

	public void setUpdate(boolean update) {
		this.update.set(update);
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public Number getPrice() {
		return price;
	}

	public void setPrice(Number price) {
		this.price = price;
	}

	public Number getQty() {
		return qty;
	}

	public void setQty(Number qty) {
		this.qty = qty;
	}

	public Number getValue() {
		return value;
	}

	public void setValue(Number value) {
		this.value = value;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

}
