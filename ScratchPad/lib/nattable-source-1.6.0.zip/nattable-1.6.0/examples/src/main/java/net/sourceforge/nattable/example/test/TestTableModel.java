package net.sourceforge.nattable.example.test;

import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.ColumnSelectionBehaviorEnum;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.editor.CheckBoxCellEditor;
import net.sourceforge.nattable.editor.ComboBoxCellEditor;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.listener.IValueChangeListener;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.painter.cell.CheckBoxCellPainter;
import net.sourceforge.nattable.painter.cell.ComboBoxCellPainter;
import net.sourceforge.nattable.painter.cell.HeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.renderer.AbstractCellRenderer;
import net.sourceforge.nattable.renderer.DataBindingCellRenderer;
import net.sourceforge.nattable.renderer.ICellRenderer;
import net.sourceforge.nattable.typeconfig.style.DefaultStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007<br>
 */
public class TestTableModel extends DefaultNatTableModel {

	private int row = 10;

	public static Image image = new Image(Display.getDefault(), TestTableModel.class.getClassLoader().getResourceAsStream("icon.gif"));

	public TestTableModel() {
		DefaultColumnHeaderConfig columnHeaderConfig = new DefaultColumnHeaderConfig(new IColumnHeaderLabelProvider() {

			public String getColumnHeaderLabel(int col) {
				return "Column " + col;
			}

		});

		setEnableMoveColumn(true);
		setSingleCellSelection(false);
		setMultipleSelection(true);
		setFullRowSelection(false);

		columnHeaderConfig.setColumnHeaderRowCount(1);
		columnHeaderConfig.setColumnHeaderRowHeightConfig(new SizeConfig(25));
		setColumnHeaderConfig(columnHeaderConfig);

		DefaultRowHeaderConfig rowHeaderConfig = new DefaultRowHeaderConfig();
		rowHeaderConfig.setRowHeaderColumnCount(1);
		rowHeaderConfig.setRowHeaderColumnWidthConfig(new SizeConfig(50));
		rowHeaderConfig.setCellRenderer(rowHeaderCellRenderer);
		setRowHeaderConfig(rowHeaderConfig);

		// body configuration
		final IDataProvider dataProvider = new IDataProvider() {

			public int getColumnCount() {
				return 800;
			}

			public int getRowCount() {
				return row;
			}

			public Object getValue(int row, int col) {
				Integer rowInt = Integer.valueOf(row);
				if (col == 0) {
					return checkboxMap.containsKey(rowInt) ? checkboxMap.get(rowInt) : Boolean.valueOf(false);
				}
				if (col == 3) {
					final String text = comboMapValue.get(rowInt);
					if (text != null) {
						return text;
					}
				}
				if (col == 1 && updateList.containsKey(Integer.valueOf(row))) {
					return updateList.get(Integer.valueOf(row));
				}
				return "Demo " + row + " " + col;
			}

		};

		final DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider);
		bodyConfig.setRowHeightConfig(new SizeConfig(20));
		bodyConfig.setColumnWidthConfig(new SizeConfig(100));
		bodyConfig.setCellRenderer(new DataBindingCellRenderer(dataProvider) {

			@Override
			public boolean isEditable(int row, int col) {
				if (col == 0) {
					return true;
				}
				if (col == 1) {
					return true;
				}
				if (col == 3) {
					return true;
				}
				return false;
			}

			public Object getValue(int row, int col) {
				return dataProvider.getValue(row, col);
			}

			public String getDisplayText(int row, int col) {
				if (col == 0) {
					return null;
				}

				if (col == 3) {
					final String text = comboMapValue.get(Integer.valueOf(row));
					if (text != null) {
						return text;
					}
				}
				return "[" + row + "," + col + "]";
			}

			CheckBoxCellPainter boxCellPainter = new CheckBoxCellPainter(SWT.CENTER);

			ComboBoxCellPainter comboBoxCellPainter = new ComboBoxCellPainter(SWT.LEFT);

			public ICellPainter getCellPainter(final int row, final int col) {
				if (col == 0) {
					return boxCellPainter;
				}
				if (col == 3) {
					return comboBoxCellPainter;
				}
				return super.getCellPainter(row, col);
			}

			CheckBoxCellEditor boxCellEditor = new CheckBoxCellEditor();

			ComboBoxCellEditor comboBoxCellEditor = new ComboBoxCellEditor() {
				@Override
				protected String[] getItems(final Object oldValue) {
					return new String[] { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Item 6", "Item 7", "Item 8", "Item 9" };
				}
			};

			public ICellEditor getCellEditor(final int row, final int col) {
				if (col == 0) {
					return boxCellEditor;
				}
				if (col == 1) {
					return super.getCellEditor(row, col);
				}
				if (col == 3) {
					return comboBoxCellEditor;
				}
				return null;
			}
			
			@Override
			public IStyleConfig getStyleConfig(String displayMode, int row,
					int col) {
				switch (DisplayModeEnum.valueOf(displayMode)) {
				case NORMAL:
					return new DefaultStyleConfig() {

						private static final long serialVersionUID = 1L;

						public Color getBackgroundColor(final int row, final int col) {
							if (updateList.containsKey(Integer.valueOf(row))) {
								return GUIHelper.COLOR_RED;
							}
	
							if (row % 2 == 0) {
								return GUIHelper.COLOR_WIDGET_BACKGROUND;
							}
	
							return null;
						}
	
						public Image getImage(final int row, final int col) {
							if (col == 2) {
								return image;
							}
							return null;
						}
						
					};
				case SELECT:
					return new DefaultStyleConfig(GUIHelper.COLOR_BLUE, null, null, null);
				default:
					return super.getStyleConfig(displayMode, row, col);
				}
			}

		});
		setBodyConfig(bodyConfig);

	}

	private final Map<Integer, Object> updateList = new HashMap<Integer, Object>();

	private final Map<Integer, String> comboMapValue = new HashMap<Integer, String>();

	// Corner /////////////////////////////////////////////////////////////////

	public ICellRenderer getCornerCellRenderer() {
		return null;
	}

	private final HeaderCellPainter rowHeaderCellPainter = new HeaderCellPainter(SWT.CENTER | SWT.FLAT);

	/**
	 * @return the columnCellPainter
	 */
	public HeaderCellPainter getColumnHeaderCellPainter() {
		return rowHeaderCellPainter;
	}

	AbstractCellRenderer rowHeaderCellRenderer = new AbstractCellRenderer() {

		public Object getValue(final int row, final int col) {
			return null;
		}

		public ICellPainter getCellPainter(final int row, final int col) {
			return rowHeaderCellPainter;
		}

		public ICellEditor getCellEditor(final int row, final int col) {
			return null;
		}

		public String getDisplayText(final int row, final int col) {
			return "Row " + row;
		}
	};

	public void setRow(int row) {
		this.row = row;
	}

	public int getInitialBodyRowHeight(final int row) {
		if (row % 10 == 0) {
			return 40;
		}
		// if (row % 35 == 0)
		// return 50;
		return 20;
	}

	HashMap<Integer, Boolean> checkboxMap = new HashMap<Integer, Boolean>();

	public void attachListeners(final NatTable natTable) {

		natTable.addValueChangeListener(new IValueChangeListener() {

			public void valueChanged(final int row, final int col, final Object oldValue, final Object newValue) {
				if (col == 0) {
					checkboxMap.put(new Integer(row), (Boolean) newValue);
				} else if (col == 3) {
					comboMapValue.put(Integer.valueOf(row), newValue != null ? newValue.toString() : "");
				} else if (col == 1) {
					updateList.put(Integer.valueOf(row), newValue);
				}
			}

		});
	}

	/**
	 * @return the updateList
	 */
	public Map<Integer, Object> getUpdateList() {
		return updateList;
	}

	public ColumnSelectionBehaviorEnum getColumnSelectionBehavior() {
		return ColumnSelectionBehaviorEnum.SINGLE_CLICK_SELECTION_DOUBLE_CLICK_SORTING;
	}

}
