package net.sourceforge.nattable.example.marketdata;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.ColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.IDataProvider;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.typeconfig.IConfigTypeResolver;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.DefaultStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class HKMarketDataShell extends Shell {

	/**
	 * Launch the application
	 * 
	 * @param args
	 */
	public static void main(String args[]) {
		try {
			Display display = Display.getDefault();
			HKMarketDataShell shell = new HKMarketDataShell(display, SWT.SHELL_TRIM);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the shell
	 * 
	 * @param display
	 * @param style
	 */
	public HKMarketDataShell(Display display, int style) {
		super(display, style);
		createContents();
		final GridLayout gridLayout = new GridLayout();
		setLayout(gridLayout);
	}

	/**
	 * Create contents of the window
	 */
	protected void createContents() {
		setText("HK Market Data");
		setSize(500, 375);
		//
		DefaultColumnHeaderConfig columnHeaderConfig = new DefaultColumnHeaderConfig(new ColumnHeaderLabelProvider(
				new String[] { "Stock", "Date", "Time", "Price", "Qty", "Value", "TradeType" }));
		columnHeaderConfig.setColumnHeaderRowHeightConfig(new SizeConfig(25));
		final MarketDataProvider mddataProvider = new MarketDataProvider();

		final IDataProvider dataProvider = mddataProvider;

		IConfigTypeResolver styleConfigTypeResolver = new IConfigTypeResolver() {

			public String getConfigType(int modelBodyRow, int modelBodyColumn) {
				InstrumentHistoricalData data = mddataProvider.getInstrumentHistoricalData(modelBodyRow);
				if (data != null) {
					if (data.getDelete()) {
						return "DELETE";
					}
					if (data.isUpdate()) {
						if (modelBodyColumn == 3) {
							return "UPDATE_3";
						}
						if (modelBodyColumn == 4) {
							return "UPDATE_4";
						}
					} else {
						if (modelBodyColumn == 3) {
							return "NO_UPDATE_3";
						}
						if (modelBodyColumn == 4) {
							return "NO_UPDATE_4";
						}
					}
				}
				return "NORMAL";
			}
			
		};
		
		ContentConfigRegistry contentConfigRegistry = new ContentConfigRegistry();
		
		StyleConfigRegistry styleConfigRegistry = new StyleConfigRegistry(styleConfigTypeResolver);
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.toString(), "DELETE", new DefaultStyleConfig(GUIHelper.COLOR_RED, GUIHelper.COLOR_WHITE, null, null));
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.toString(), "UPDATE_3", new DefaultStyleConfig(GUIHelper.COLOR_DARK_GRAY, GUIHelper.COLOR_WHITE, null, null));
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.toString(), "UPDATE_4", new DefaultStyleConfig(GUIHelper.COLOR_DARK_GRAY, GUIHelper.COLOR_YELLOW, null, null));
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.toString(), "NO_UPDATE_3", new DefaultStyleConfig(null, GUIHelper.COLOR_BLUE, null, null));
		styleConfigRegistry.registerStyleConfig(DisplayModeEnum.NORMAL.toString(), "NO_UPDATE_4", new DefaultStyleConfig(null, GUIHelper.COLOR_YELLOW, null, null));
		
		DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider, contentConfigRegistry, styleConfigRegistry);
		bodyConfig.setRowHeightConfig(new SizeConfig(20));
		SizeConfig columnWidthConfig = bodyConfig.getColumnWidthConfig();
		columnWidthConfig.setDefaultSize(100);
		columnWidthConfig.setDefaultResizable(true);

		DefaultNatTableModel defaultNatTableModel = new DefaultNatTableModel(columnHeaderConfig, bodyConfig);
		defaultNatTableModel.setFullRowSelection(true);

		final Composite composite = new Composite(this, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		composite.setLayout(new FillLayout());

		NatTable natTable = new NatTable(composite, SWT.BORDER | SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE
				| SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL, defaultNatTableModel);

		final Label label = new Label(this, SWT.NONE);
		label.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		mddataProvider.run(natTable, label);
	}

	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
