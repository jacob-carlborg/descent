package net.sourceforge.nattable.example.pricing;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;

import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.DefaultBulkUpdateSupport;
import net.sourceforge.nattable.data.IBeanConfigTypeResolver;
import net.sourceforge.nattable.data.IColumnPropertyProvider;
import net.sourceforge.nattable.data.IRowIDPropertyResolver;
import net.sourceforge.nattable.data.IRowObjectCreator;
import net.sourceforge.nattable.data.ReflectiveNumericPropertyInstanceCreator;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.util.MethodNameGenerator;

public class DataUpdatesEnabler {
	private DataUpdateHelper<PricingDataBean> helper;

	DataUpdatesEnabler(ContentConfigRegistry contentRegistry) {
		initializeDataHelper(contentRegistry);
	}

	public DataUpdateHelper<PricingDataBean> getDataUpdateHelper() {
		return helper;
	}

	/**
	 * This method initializes all the objects needed to perform updates to the
	 * model. - DefaultBulkUpdateSupport - this object will cache all updates
	 * and allow the user to commit the changes to the model when ready. -
	 * Comparator - used to determine if an the change is an update or insert. -
	 * IRowObjectCreator - knows how to create a model object which will be used
	 * in the comparison to determine the type of change, either update or
	 * insert. - IBeanConfigTypeResolver - used to map any updates done to a
	 * bean to with the ContentConfigRegistry -
	 * ReflectiveNumericPropertyInstanceCreator - used to instantiate parameters
	 * to use with the call to the updated attribute's set method. -
	 * IRowIDPropertyResolver - used to find row Id's in the update context.
	 * 
	 * @param contentConfigRegistry
	 */
	private void initializeDataHelper(ContentConfigRegistry contentConfigRegistry) {
		helper = new DataUpdateHelper<PricingDataBean>();

		helper.setBulkUpdate(new DefaultBulkUpdateSupport<PricingDataBean>(contentConfigRegistry));

		helper.setPropertyResolver(new IColumnPropertyProvider() {
			public String getPropertyName(int col) {
				return ColumnHeaders.values()[col].getProperty();
			}

			public Class<?> getPropertyType(String propertyName) {
				return ColumnHeaders.values()[ColumnHeaders.getPropertyMap().get(propertyName).intValue()].getType();
			}

		});

		helper.setRowComparator(new Comparator<PricingDataBean>() {

			public int compare(PricingDataBean o1, PricingDataBean o2) {
				return ((PricingDataBean) o1).getIsin().compareTo(((PricingDataBean) o2).getIsin());
			}

		});

		helper.setRowObjectCreator(new IRowObjectCreator<PricingDataBean>() {

			public PricingDataBean createRowObject(Serializable rowObjectId) {
				PricingDataBean bean = new PricingDataBean();
				bean.setIsin((String) rowObjectId);
				return bean;
			}

			public Class<PricingDataBean> getRowClass() {
				return PricingDataBean.class;
			}

		});

		helper.setRowIdResolver(new IRowIDPropertyResolver() {

			public Serializable resolveRowIdProperty(Map<String, Object> propertyToValue) {
				return propertyToValue.containsKey("isin") ? (Serializable) propertyToValue.get("isin") : new Double(Math.random());
			}

		});

		helper.setPropertyInstanceCreator(new ReflectiveNumericPropertyInstanceCreator());

		helper.setBeanConfigResolver(generatorTypeResolver());
	}

	private IBeanConfigTypeResolver<PricingDataBean> generatorTypeResolver() {
		return new IBeanConfigTypeResolver<PricingDataBean>() {
			public String getConfigType(PricingDataBean rowObject, String fieldName) {
				ColumnHeaders colHeader = ColumnHeaders.values()[3];
				try {
					String pricingModel = (String) rowObject.getClass().getMethod(MethodNameGenerator.buildGetMethodName(colHeader.getProperty()), new Class[] {}).invoke(rowObject);
					if (ContentConfigTypeResolver.pricingContentTypes.containsKey(pricingModel)) {
						return ContentConfigTypeResolver.pricingContentTypes.get(pricingModel);
					}
				} catch (Exception e) {
					throw new RuntimeException(e.getMessage(), e);
				}
				return null;
			}

		};
	}
}
