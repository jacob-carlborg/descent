package net.sourceforge.nattable.example.pricing;

public interface PricingBeanValueGenerator<T> {
	public Object generateRandomValue(Object source);
	
	public Class<T> getClassToGenerate();
}
