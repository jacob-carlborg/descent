package net.sourceforge.nattable.example.demo.glazedlists;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��17��<br>
 */
public enum GlazedListsColumnEnum {
	USER_ID(100), NAME(200), PASSWORD(100), BIRTHDAY(150), IMAGE(100);

	int width;

	GlazedListsColumnEnum(final int width) {
		this.width = width;
	}

	public static GlazedListsColumnEnum getColumn(final int col) {
		switch (col) {
		case 0:
			return USER_ID;
		case 1:
			return NAME;
		case 2:
			return PASSWORD;
		case 3:
			return BIRTHDAY;
		case 4:
			return IMAGE;
		}
		return null;
	}
}
