package net.sourceforge.nattable.example.pricing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.Filterator;
import ca.odell.glazedlists.GlazedLists;

public class NewPricingExampleShell {
	private Shell shell;
	private static final String FILTER_REMOVER = "No Filter";

	NewPricingExampleShell() {
		Display display = new Display();
		shell = new Shell(display);
		shell.setLayout(new GridLayout());
		shell.setText("New Pricing Example Shell");

		final PricingGrid pricingGrid = new PricingGrid(shell);
		
		// load shell components
		Composite bottomComposite = new Composite(shell, SWT.NONE);
		bottomComposite.setLayout(new GridLayout(4,false));
		GridData gd = new GridData(SWT.FILL, SWT.CENTER, true, false);
		bottomComposite.setLayoutData(gd);
		
		// constructs control groups displayed at the bottom of the pricing shell gui
		buildBlinkingCellGroup(bottomComposite, pricingGrid);
		buildRowControlsGroup(bottomComposite, pricingGrid);
		buildPersistenceControls(bottomComposite, pricingGrid);
		buildFilteringControl(bottomComposite, pricingGrid);
	}

	private void buildBlinkingCellGroup(Composite parent, PricingGrid pricingGrid) {
		//construct group
		Group group = new Group(parent, SWT.SHADOW_ETCHED_OUT);
		group.setText("Blinking Cells Control");
		group.setLayout(new GridLayout(2, false));
		
		// Creating and wiring up controls to enable or disable blinking for specific columns.
		final BlinkingEnabler blinkEnabler = pricingGrid.getBlinkEnabler();
		ColumnHeaders[] enabledCols = blinkEnabler.getBlinkingColumnHeaders();
		
		for (ColumnHeaders col : enabledCols) {
			Button check = new Button(group, SWT.CHECK);
			check.setText(col.getLabel());
			check.setData("column", col);
			check.addSelectionListener(new SelectionAdapter() {

				@Override
				public void widgetSelected(SelectionEvent e) {
					ColumnHeaders column = (ColumnHeaders) e.widget.getData("column");
					if (!((Button) e.widget).getSelection()) {
						blinkEnabler.disableBlinking(column.ordinal());
					} else {
						blinkEnabler.enableBlinking(column.ordinal());
					}
				}

			});
			check.setSelection(false);
		}
	}

	private void buildRowControlsGroup(Composite parent, final PricingGrid pricingGrid) {
		Group gp = new Group(parent, SWT.SHADOW_ETCHED_OUT);
		gp.setText("Row Control");
		gp.setLayout(new GridLayout(3, false));
		GridData gpd = new GridData(SWT.LEFT, SWT.FILL, false, true);
		gp.setLayoutData(gpd);

		Label label = new Label(gp, SWT.NONE);
		label.setText("Add rows: ");
		final Text numRowsToAddText = new Text(gp, SWT.SINGLE | SWT.BORDER);
		final Button addRowsBtn = new Button(gp, SWT.PUSH);
		addRowsBtn.setText("ADD");
		addRowsBtn.setEnabled(false);

		numRowsToAddText.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent e) {
				e.doit = "0123456789".indexOf(e.character) != -1 || e.character == SWT.DEL || e.character == SWT.BS;
				addRowsBtn.setEnabled(e.doit);
			}
		});

		SelectionListener selectionListener = new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				handleEvent(e);
			}

			public void widgetSelected(SelectionEvent e) {
				handleEvent(e);
			}

			private void handleEvent(SelectionEvent e) {
				try {//
					pricingGrid.addRows(Integer.parseInt(numRowsToAddText.getText()));

				} catch (NumberFormatException nfe) {
					nfe.printStackTrace();
				}
			}
		};
		numRowsToAddText.addSelectionListener(selectionListener);
		addRowsBtn.addSelectionListener(selectionListener);

		Button clearAllRows = new Button(gp, SWT.PUSH);
		GridData gd = new GridData();
		gd.horizontalSpan = 3;
		gd.horizontalAlignment = SWT.RIGHT;
		clearAllRows.setLayoutData(gd);
		clearAllRows.setText("Remove All Rows");
		clearAllRows.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				pricingGrid.removeAllRows();
			}
		});
	}

	private void buildPersistenceControls(Composite parent, final PricingGrid pricingGrid) {
		Group gp = new Group(parent, SWT.SHADOW_ETCHED_OUT);
		gp.setText("Persistence Control");
		gp.setLayout(new GridLayout());

		final Button enableSave = new Button(gp, SWT.CHECK);
		enableSave.setText("Save Enabled");
		enableSave.setSelection(pricingGrid.isPersistenceEnabled());
		enableSave.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				if (!((Button) e.widget).getSelection()) {
					pricingGrid.detachPersistence();
				} else {
					pricingGrid.attachPersistence();
				}
			}

		});

		final Button reset = new Button(gp, SWT.PUSH);
		reset.setText("Reset");
		reset.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				// delete store files
				try {
					pricingGrid.clearPersistedSettings();
					MessageBox msg = new MessageBox(shell, SWT.ICON_INFORMATION | SWT.OK);
					msg.setMessage("Next time you restart this example, the grid will display using its default settings.");
					msg.open();
					enableSave.setEnabled(false);
					reset.setEnabled(false);

				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}

		});
	}

	/**
	 * This class generates random values for the pricing model field.
	 * @author cmartine
	 *
	 */
	class PricingModelGenerator implements PricingBeanValueGenerator<String> {
		public String[] sources;
		private Random rand = new Random();
		PricingModelGenerator(PricingGrid pricingGrid) {
			// get unique pricing source values to populate combo
			List<String> pricingSources = new ArrayList<String>();
			Filterator<String, PricingDataBean> pSourceFilter = GlazedLists.filterator(new String[] { ColumnHeaders.getProperties()[3] });
			for (PricingDataBean bean : pricingGrid.getDataAccessor().getBaseEventList()) {
				pSourceFilter.getFilterValues(pricingSources, bean);
			}
			sources = pricingSources.toArray(new String[0]);
			Arrays.sort(sources);
		}

		public void getSource() {

		}

		public Object generateRandomValue(Object source) {
			return sources[rand.nextInt(sources.length)];
		}

		public Class<String> getClassToGenerate() {
			return String.class;
		}
	};

	private void buildFilteringControl(Composite parent, final PricingGrid pricingGrid) {

		Group gp = new Group(parent, SWT.SHADOW_ETCHED_IN);
		gp.setText("Pricing Model Filter");
		gp.setLayout(new GridLayout());
		Composite pGroup = new Composite(gp, SWT.NONE);
		FormLayout layout = new FormLayout();
		layout.marginLeft = layout.marginRight = 5;
		layout.marginBottom = layout.marginTop = 2;
		pGroup.setLayout(layout);

		// Build pricing model options drop down
		CCombo combo = new CCombo(pGroup, SWT.FLAT | SWT.BORDER);
		combo.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false));
		combo.setToolTipText("Select filter criteria");
		
		combo.add(FILTER_REMOVER);
		
		// Pricing model field value generator
		final PricingModelGenerator pricingModelGenerator = new PricingModelGenerator(pricingGrid);
		
		String val = "";
		for (String source : pricingModelGenerator.sources) {
			if (!val.equals(source)) {
				combo.add(source);
				val = source;
			}
		}
		FormData formComponents = new FormData(100, SWT.DEFAULT);
		combo.setLayoutData(formComponents);
		combo.addSelectionListener(new SelectionAdapter() {

			public void widgetSelected(SelectionEvent e) {
				CCombo combo = (CCombo) e.widget;
				String selectedText = combo.getText();
				if (selectedText != null && selectedText.length() > 0) {
					if (!selectedText.equals(FILTER_REMOVER)) {
						pricingGrid.setFilter(ColumnHeaders.values()[3].ordinal(), selectedText);
					} else {
						pricingGrid.removeFilter();
					}
				}
			}

		});

		Label psLabel = new Label(pGroup, SWT.NONE);
		psLabel.setText("Model: ");
		formComponents.left = new FormAttachment(psLabel, 5);

		final Button blink = new Button(gp, SWT.PUSH);
		blink.setText("Start Updates");
		blink.addSelectionListener(new SelectionAdapter() {
			boolean isUpdating = false;
			@SuppressWarnings("unchecked")
			private PriceUpdaterRunnable updateThread;

			public void widgetSelected(SelectionEvent e) {

				if (isUpdating) {
					updateThread.stop();
					updateThread = null;
					blink.setText("Start Update");
					isUpdating = false;
				} else {
						if (updateThread == null) {
							// Generate and set PricingModel changes when updates are started
							updateThread = new PriceUpdaterRunnable<PricingDataBean>((EventList<PricingDataBean>) pricingGrid.getDataAccessor().getBaseEventList(), 
									new RowObjectUpdater<PricingDataBean>() {

										public void updateRow(PricingDataBean item) {
											item.setPricingModel((String)pricingModelGenerator.generateRandomValue(item));
										}
								
							});
							Thread runner = new Thread(updateThread);
							runner.setDaemon(true);
							runner.start();
						}
						blink.setText("Stop Update");
						isUpdating = true;
					}
				}
			
		});
		blink.setVisible(true);
	}

	Shell getShell() {
		return shell;
	}

	void open() {
		shell.open();
	}

	public static void main(String[] args) {
		NewPricingExampleShell ps = new NewPricingExampleShell();
		ps.getShell().open();
		while (ps.getShell() != null && !ps.getShell().isDisposed()) {
			if (!ps.getShell().getDisplay().readAndDispatch())
				ps.getShell().getDisplay().sleep();
		}
	}
}
