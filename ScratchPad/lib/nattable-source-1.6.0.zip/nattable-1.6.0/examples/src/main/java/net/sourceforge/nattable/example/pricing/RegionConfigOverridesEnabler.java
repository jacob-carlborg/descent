package net.sourceforge.nattable.example.pricing;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.listener.NatEventData;
import net.sourceforge.nattable.support.IClientAreaProvider;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;

public class RegionConfigOverridesEnabler {
	
	private StyleConfigTypeResolver styleConfigResolver;
	private IClientAreaProvider clientArea;
	
	RegionConfigOverridesEnabler(StyleConfigTypeResolver styleConfigResolver, IClientAreaProvider clientArea) {
		this.styleConfigResolver = styleConfigResolver;
		this.clientArea = clientArea;
	}

	GridRegionMenuAction enableCellRegionOverrides(String[] items, Shell shell) {
		final GridRegionMenuAction regionHandler = new GridRegionMenuAction(shell);
		for (String item : items) {
			MenuItem cellItem = new MenuItem(regionHandler.options, SWT.RADIO);
			cellItem.setText(item);
			cellItem.addSelectionListener(new SelectionListener() {

				public void widgetDefaultSelected(SelectionEvent e) {
				}

				public void widgetSelected(SelectionEvent e) {
					MenuItem item = (MenuItem) e.widget;
					if (item.getSelection()) {
						NatTable table = regionHandler.currentEvent.getNatTable();
						int row = regionHandler.currentEvent.getRowIndex();
						int col = regionHandler.currentEvent.getColumnIndex();
						Object cellValue = table.getNatTableModel().getBodyCellRenderer().getValue(row, col);
						styleConfigResolver.registerCellOverride(cellValue, regionHandler.currentEvent.getColumnIndex(), item.getText());
					} else {
						styleConfigResolver.removeCellOverride(new Integer(regionHandler.currentEvent.getColumnIndex()));
					}
					clientArea.updateResize();
				}

			});
		}
		
		return regionHandler;
	}

	GridRegionMenuAction enableRowOverrides(String[] items, Shell shell) {
		final GridRegionMenuAction regionHandler = new GridRegionMenuAction(shell);
		for (String item : items) {
			MenuItem rowItem = new MenuItem(regionHandler.options, SWT.RADIO);
			rowItem.setText(item);
			rowItem.addSelectionListener(new SelectionListener() {
				public void widgetDefaultSelected(SelectionEvent e) {
				}

				public void widgetSelected(SelectionEvent e) {
					MenuItem item = (MenuItem) e.widget;
					if (item.getSelection()) {
						styleConfigResolver.registerRowOverride(item.getText(), regionHandler.currentEvent.getRowIndex());
					} else {
						styleConfigResolver.removeRowOverride(new Integer(regionHandler.currentEvent.getRowIndex()));
					}
					clientArea.updateResize();
				}
			});
		}
		return regionHandler;
	}

	class GridRegionMenuAction implements IMouseEventAction {
		private Menu options;
		private NatEventData currentEvent;

		public GridRegionMenuAction(Shell shell) {
			options = new Menu(shell, SWT.POP_UP);
		}

		public void run(MouseEvent e) {
			options.setVisible(true);
			currentEvent = (NatEventData) e.data;

			String type = styleConfigResolver.getConfigType(currentEvent.getRowIndex(), currentEvent.getColumnIndex());
			for (MenuItem item : options.getItems()) {
				if (type != null && item.getText().equalsIgnoreCase(type)) {
					item.setSelection(true);
				} else {
					item.setSelection(false);
				}
			}
		}
	}
}
