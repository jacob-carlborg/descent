package net.sourceforge.nattable.example.pricing;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.support.IClientAreaProvider;
import net.sourceforge.nattable.util.MethodNameGenerator;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.FilterList;
import ca.odell.glazedlists.matchers.AbstractMatcherEditor;
import ca.odell.glazedlists.matchers.Matcher;
import ca.odell.glazedlists.matchers.MatcherEditor;

public class DataFilteringHandler {
	private FilterList<PricingDataBean> filteredList;
	private Map<Integer, MatcherEditor<PricingDataBean>> beanDataMatchers = new HashMap<Integer, MatcherEditor<PricingDataBean>>();
	
	DataFilteringHandler(EventList<PricingDataBean> baseList) {
		filteredList = new FilterList<PricingDataBean>(baseList);
	}
	
	/** 
	 * Uses GlazedLists MatcherEditor to filter a column by the passed valueToMatch object.
	 * @param modelColumnIndex
	 * @param valueToMatch
	 * @param client
	 */
	public void filter(int modelColumnIndex, Object valueToMatch, IClientAreaProvider client) {
		BeanCriteriaMatcher matcher = null;
		String fieldToMatch = ColumnHeaders.values()[modelColumnIndex].getProperty();
		if(beanDataMatchers.containsKey(Integer.valueOf(modelColumnIndex))) {
			matcher = (BeanCriteriaMatcher)beanDataMatchers.get(Integer.valueOf(modelColumnIndex));
			if (!matcher.valueToMatch.equals(valueToMatch)) {
				matcher.setMatchCriteria(fieldToMatch, valueToMatch);
			}
		} else {
			matcher = new BeanCriteriaMatcher(fieldToMatch, valueToMatch);
			beanDataMatchers.put(Integer.valueOf(modelColumnIndex), matcher);
		}
		filteredList.getReadWriteLock().writeLock().lock();
		try {
			filteredList.setMatcherEditor(matcher);
			client.updateResize();
		} finally {
			filteredList.getReadWriteLock().writeLock().unlock();
		}		
	}
	
	public void removeFilter(IClientAreaProvider client) {
		filteredList.getReadWriteLock().writeLock().lock();
		try {
			filteredList.setMatcherEditor(null);
			client.updateResize();
		} finally {
			filteredList.getReadWriteLock().writeLock().unlock();
		}
	}
	
	public FilterList<PricingDataBean> getFilteredList() {
		return filteredList;
	}
	
	class BeanCriteriaMatcher extends AbstractMatcherEditor<PricingDataBean> {
		private String fieldToMatch;
		private Object valueToMatch;

		public BeanCriteriaMatcher(String fieldToMatch, Object valueToMatch) {
			setMatchCriteria(fieldToMatch, valueToMatch);
		}
		
		public void setMatchCriteria(String fieldToMatch, Object valueToMatch) {
			this.fieldToMatch = fieldToMatch;
			this.valueToMatch = valueToMatch;
		}

		public Matcher<PricingDataBean> getMatcher() {
			return new Matcher<PricingDataBean>() {
				public boolean matches(PricingDataBean item) {
					if (fieldToMatch != null && valueToMatch != null) {
						try {
							Method method = item.getClass().getDeclaredMethod(MethodNameGenerator.buildGetMethodName(fieldToMatch));
							method.setAccessible(true);
							Object val = method.invoke(item);
							if (Number.class.isAssignableFrom(val.getClass())) {
								return ((Number) val).equals(valueToMatch);
							} else if (String.class.isAssignableFrom(val.getClass())) {
								return ((String) val).equals(valueToMatch);
							}
						} catch (SecurityException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						} catch (Exception e) {
							throw new RuntimeException(e.getMessage());
						}
					}
					return false;
				}

			};
		}
	}
}
