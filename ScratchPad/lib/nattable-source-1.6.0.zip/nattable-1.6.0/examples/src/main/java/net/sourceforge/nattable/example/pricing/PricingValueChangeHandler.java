package net.sourceforge.nattable.example.pricing;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.example.pricing.generators.DoubleValueGenerator;
import net.sourceforge.nattable.example.pricing.generators.IValueGenerator;
import net.sourceforge.nattable.example.pricing.generators.IntegerValueGenerator;
import net.sourceforge.nattable.example.pricing.generators.SentenceValueGenerator;
import net.sourceforge.nattable.util.MethodNameGenerator;
import net.sourceforge.nattable.util.PrimitiveClassResolver;

public class PricingValueChangeHandler implements RowObjectUpdater<PricingDataBean> {
	// This map manages the value generators which go with a specific column
	private Map<Integer, UpdateDataGeneratorHelper> valueGenerators = new HashMap<Integer, UpdateDataGeneratorHelper>();
	private Map<Integer, ColumnHeaders> blinkingColumnHeaders = new HashMap<Integer, ColumnHeaders>();
	private Random random = new Random();
	private DoubleValueGenerator dblGenerator = new DoubleValueGenerator(1, 2);
	private IntegerValueGenerator intGenerator = new IntegerValueGenerator(1,2);

	public void enableBlinking(int modelColumnIndex, ColumnHeaders columnHeader) {
		// Determine class type to generate.
		Class<?> type = columnHeader.getType();
		IValueGenerator generator;
		if (type.equals(Double.class)) {
			generator = dblGenerator;
		} else if (type.equals(Integer.class)) {
			generator = intGenerator;
		} else {
			generator = new SentenceValueGenerator();
		}
		
		valueGenerators.put(Integer.valueOf(modelColumnIndex), new UpdateDataGeneratorHelper(columnHeader.getProperty(), generator, type));
	}
	
	public void registerCellForBlinking(int modelColumnIndex) {
		blinkingColumnHeaders.put(Integer.valueOf(modelColumnIndex), ColumnHeaders.values()[modelColumnIndex]);		
	}
	
	public void unregisterCellForBlinking(int modelColumnIndex) {
		blinkingColumnHeaders.remove(Integer.valueOf(modelColumnIndex));
	}

	public void disableBlinking(int modelColumnIndex) {		
		valueGenerators.remove(Integer.valueOf(modelColumnIndex));		
	}
	
	public ColumnHeaders[] getBlinkingColumnHeaders() {
		return blinkingColumnHeaders.values().toArray(new ColumnHeaders[0]);
	}

	public void updateRow(PricingDataBean item) {
		for (Integer key : valueGenerators.keySet()) {
			UpdateDataGeneratorHelper updateValueGenerator = valueGenerators.get(key);
			try {
				Object itemVal = updateValueGenerator.getMethod.invoke(item);
				if (updateValueGenerator.dataGenerator instanceof DoubleValueGenerator) {
					double orgVal = ((Double) itemVal).doubleValue();
					double delta = orgVal * 0.1 * ((Double) updateValueGenerator.dataGenerator.newValue(random)).doubleValue();
					double sign = random.nextBoolean() ? +1.0d : -1.0d;					
					double val = sign > 0 ? orgVal + (delta * sign) : (delta * sign) - orgVal;
					updateValueGenerator.setMethod.invoke(item, new Double(val));
				} else if (updateValueGenerator.dataGenerator instanceof IntegerValueGenerator) {
					int orgVal = ((Integer) itemVal).intValue();
					int delta = orgVal * ((Integer) updateValueGenerator.dataGenerator.newValue(random)).intValue();
					int sign = random.nextBoolean() ? +1 : -1;
					int val = sign > 0 ? orgVal + (delta * sign) : orgVal - (delta * sign);
					updateValueGenerator.setMethod.invoke(item, new Integer(val));
				} else {
					 String orgVal = (String)updateValueGenerator.dataGenerator.newValue(random);
					 updateValueGenerator.setMethod.invoke(item, orgVal);
				}
				
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage(), e);
			}
		}
	}
	
	class UpdateDataGeneratorHelper {
		Method getMethod;
		Method setMethod;
		IValueGenerator dataGenerator;
		Class<?> paramClass;
		String fieldName;

		UpdateDataGeneratorHelper(String fieldName, IValueGenerator valueGenerator, Class<?> paramClass) {

			this.dataGenerator = valueGenerator;
			try {
				paramClass = PrimitiveClassResolver.checkClassForPrimitives(paramClass);
				this.fieldName = fieldName;
				this.paramClass = paramClass;
				setMethod = PricingDataBean.class.getMethod(MethodNameGenerator.buildSetMethodName(fieldName), paramClass);
				getMethod = PricingDataBean.class.getMethod(MethodNameGenerator.buildGetMethodName(fieldName));
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage(), e);
			}
		}
	}
}

interface RowObjectUpdater<R> {

	void updateRow(R item);
}
