package net.sourceforge.nattable.example.pricing;

import net.sourceforge.nattable.data.IRowDataProvider;
import net.sourceforge.nattable.typeconfig.content.IEditableRule;

public class PricingModeRule<R> implements IEditableRule {

	private IRowDataProvider<R> dataProvider;
	PricingModeRule(IRowDataProvider<R> dataProvider) {
		this.dataProvider = dataProvider;
	}
	
	public boolean isEditable(int row, int col) {
		Object value = dataProvider.getValue(row, 3);
		return value != null && ((String)value).equalsIgnoreCase("ATT") ? false : true;
	}

}
