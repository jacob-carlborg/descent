package net.sourceforge.nattable.example.snippets;

import net.sourceforge.nattable.GridRegionEnum;
import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.event.matcher.MouseEventMatcher;
import net.sourceforge.nattable.extension.dialog.ColumnChooser;
import net.sourceforge.nattable.listener.NatEventData;
import net.sourceforge.nattable.model.DefaultNatTableModel;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;

/**
 * Demonstrates how to invoke the column chooser and the hide column actions.
 */
public class Snippet009ColumnChooser {

	public static void main(String args[]) {
		new Snippet009ColumnChooser();
	}
	
	private Snippet009ColumnChooser() {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display, SWT.SHELL_TRIM);
			shell.setLayout(new FillLayout());
			
			setupNatTable(shell);
			
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void setupNatTable(Composite parent) {
		// NatTable
		NatTable natTable = new NatTable(
				parent,
				SWT.NO_BACKGROUND | SWT.NO_REDRAW_RESIZE | SWT.DOUBLE_BUFFERED | SWT.V_SCROLL | SWT.H_SCROLL,
				new DefaultNatTableModel()
		);
		
		// we are only interested in events triggered on the column header
		natTable.getEventBindingSupport().registerMouseDownBinding(new MouseEventMatcher(SWT.NONE, GridRegionEnum.COLUMN_HEADER.toString(), 3), new MyPopupMenuAction(natTable));
		
	}
	
	static class MyPopupMenuAction implements IMouseEventAction {
		
		private final NatTable natTable;
		private final Menu menu;
		private int columnIndex;

		public MyPopupMenuAction(NatTable natTable) {
			this.natTable = natTable;
			menu = new Menu(natTable.getShell(), SWT.POP_UP);
			initMenu();
		}
		
		private void initMenu() {
			MenuItem hideColumnItem = new MenuItem(menu, SWT.PUSH);
			hideColumnItem.setText("Hide column");
			hideColumnItem.setEnabled(true);
			hideColumnItem.addSelectionListener(new SelectionAdapter() {

				@Override
				public void widgetSelected(SelectionEvent e) {
					natTable.hideModelBodyColumn(columnIndex);
				}
				
			});
			
			MenuItem columnChooserItem = new MenuItem(menu, SWT.PUSH);
			columnChooserItem.setText("Column chooser...");
			columnChooserItem.setEnabled(true);
			columnChooserItem.addSelectionListener(new SelectionAdapter() {
				
				@Override
				public void widgetSelected(SelectionEvent e) {
					// open the column chooser without frozen column support
					ColumnChooser.open(natTable, false);
				}
				
			});
		}
		
		public void run(MouseEvent e) {
			menu.setVisible(true);
			
			NatEventData natEventData = (NatEventData) e.data;
			this.columnIndex = natEventData.getColumnIndex();
		}
		
	}
	
}
