/**
 * 
 */
package net.sourceforge.nattable.example.demo.fixorder;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2008�~5��25��<br>
 */
public class Order {

	private long OrderQty;
	/*
	 * Unique identifier for Order as assigned by institution. Uniqueness must
	 * be guaranteed within a single trading day. Firms which electronically
	 * submit multi-day orders should consider embedding a date within the
	 * ClOrdID <11> field to assure uniqueness across days.
	 */
	private String ClOrdID;

	public static enum HandlInstEnum {
		ORDER_PRIVATE(1), ORDER_PUBLIC(2), ORDER_MANUAL(3);
		private int num;

		HandlInstEnum(int num) {
			this.num = num;
		}

		public int getNum() {
			return num;
		}

	}

	/*
	 * Instructions for order handling on Broker trading floor
	 * 
	 * Valid values:
	 * 
	 * 1 = Automated execution order, private, no Broker intervention
	 * 
	 * 2 = Automated execution order, public, Broker intervention OK
	 * 
	 * 3 = Manual order, best execution
	 */
	private String HandlInst;

	/* Ticker symbol */
	private String Symbol;

	public static enum SideEnum {
		BUY('1'), SELL('2'), BUY_MINUS('3'), SELL_PLUS('4'), SELL_SHORT('5'), SELL_SHORT_EXEMPT('6'), UNDISCLOSED('7');
		private char num;

		SideEnum(char num) {
			this.num = num;
		}

		public char getNum() {
			return num;
		}

		public static SideEnum getName(char side) {
			if (BUY.num == side) {
				return BUY;
			}
			if (SELL.num == side) {
				return SELL;
			}
			if (BUY_MINUS.num == side) {
				return BUY_MINUS;
			}
			if (SELL_PLUS.num == side) {
				return SELL_PLUS;
			}
			if (SELL_SHORT.num == side) {
				return SELL_SHORT;
			}
			if (SELL_SHORT_EXEMPT.num == side) {
				return SELL_SHORT_EXEMPT;
			}
			if (UNDISCLOSED.num == side) {
				return UNDISCLOSED;
			}
			return SideEnum.BUY;
		}
	}

	/*
	 * Valid values:
	 * 
	 * 1 = Buy
	 * 
	 * 2 = Sell
	 * 
	 * 3 = Buy minus
	 * 
	 * 4 = Sell plus
	 * 
	 * 5 = Sell short
	 * 
	 * 6 = Sell short exempt
	 * 
	 * 7 = Undisclosed (valid for IOI message only)
	 * 
	 * 8 = Cross (orders where counterparty is an exchange, valid for all
	 * messages except IOIs)
	 */
	private char Side;

	public static enum OrderTypeEnum {
		Market('1', "Market"), Limit('2', "Limit"), Stop('3', "Stop"), Stop_limit('4', "Stop limit"), Market_on_close(
				'5', "Market on close");

		char type;
		String name;

		OrderTypeEnum(char type, String name) {
			this.type = type;
			this.name = name;
		}

		public char getType() {
			return type;
		}

		public String getName() {
			return name;
		}

		public static OrderTypeEnum getName(char type) {
			if (Market.type == type) {
				return Market;
			}
			if (Limit.type == type) {
				return Limit;
			}
			if (Stop.type == type) {
				return Stop;
			}
			if (Stop_limit.type == type) {
				return Stop_limit;
			}
			if (Market_on_close.type == type) {
				return Market_on_close;
			}

			return OrderTypeEnum.Market;
		}
	};

	/*
	 * Valid values:
	 * 
	 * 1 = Market
	 * 
	 * 2 = Limit
	 * 
	 * 3 = Stop
	 * 
	 * 4 = Stop limit
	 * 
	 * 5 = Market on close
	 * 
	 * 6 = With or without
	 * 
	 * 7 = Limit or better
	 * 
	 * 8 = Limit with or without
	 * 
	 * 9 = On basis
	 * 
	 * A = On close
	 * 
	 * B = Limit on close
	 * 
	 * C =Forex - Market
	 * 
	 * D = Previously quoted
	 * 
	 * E = Previously indicated
	 * 
	 * F = Forex - Limit
	 * 
	 * G = Forex - Swap
	 * 
	 * H = Forex - Previously Quoted
	 * 
	 * P = Pegged (requires ExecInst <18> = L, R, M, P or O)
	 */
	private char OrdType;

	public String getClOrdID() {
		return ClOrdID;
	}

	public void setClOrdID(String clOrdID) {
		ClOrdID = clOrdID;
	}

	public String getHandlInst() {
		return HandlInst;
	}

	public void setHandlInst(String handlInst) {
		HandlInst = handlInst;
	}

	public String getSymbol() {
		return Symbol;
	}

	public void setSymbol(String symbol) {
		Symbol = symbol;
	}

	public char getSide() {
		return Side;
	}

	public void setSide(char side) {
		Side = side;
	}

	public char getOrdType() {
		return OrdType;
	}

	public void setOrdType(char ordType) {
		OrdType = ordType;
	}

	public long getOrderQty() {
		return OrderQty;
	}

	public void setOrderQty(long orderQty) {
		OrderQty = orderQty;
	}

}
