package net.sourceforge.nattable.example.pricing;

import net.sourceforge.nattable.NatTable;
import net.sourceforge.nattable.action.IMouseEventAction;
import net.sourceforge.nattable.extension.dialog.ColumnChooser;
import net.sourceforge.nattable.listener.NatEventData;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Decorations;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

public class PopupMenuAction implements IMouseEventAction {

	public final static String HIDE_MENU_NAME = "Hide Column";
	
	public final static String COL_CHOOSER_NAME = "Column Chooser...";
	
	private Menu displayOptions;
	
	private NatTable natTable;
	
	private int columnIndex;

	public PopupMenuAction(Decorations deco) {
		loadDisplayOptions(deco);
	}

	public void run(MouseEvent e) {
		displayOptions.setVisible(true);
		
		NatEventData natEventData = (NatEventData) e.data;
		this.natTable = natEventData.getNatTable();
		this.columnIndex = natEventData.getColumnIndex();
	}

	private void loadDisplayOptions(Decorations parent) {
		displayOptions = new Menu(parent, SWT.POP_UP);
		initMenu();
	}

	private void initMenu() {
		MenuItem hideColumnItem = new MenuItem(displayOptions, SWT.PUSH);
		hideColumnItem.setText(HIDE_MENU_NAME);
		hideColumnItem.setEnabled(true);
		hideColumnItem.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				natTable.hideModelBodyColumn(columnIndex);
			}
			
		});
		
		MenuItem columnChooserItem = new MenuItem(displayOptions, SWT.PUSH);
		columnChooserItem.setText(COL_CHOOSER_NAME);
		columnChooserItem.setEnabled(true);
		columnChooserItem.addSelectionListener(new SelectionAdapter() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				ColumnChooser.open(natTable);
			}
			
		});
	}
}
