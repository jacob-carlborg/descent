package net.sourceforge.nattable.example.pricing;

import java.io.Serializable;

import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IRowIdAccessor;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.data.ReflectiveColumnAccessor;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.data.pricing.PricingDataBeanGenerator;
import net.sourceforge.nattable.support.IClientAreaProvider;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;

public class PricingDataAccessor {
	private ListDataProvider<PricingDataBean> dataProvider;	
	private SortedList<PricingDataBean> sortedRows;
	private IColumnAccessor<PricingDataBean> columnAccessor;
	private EventList<PricingDataBean> dataList;
	private IRowIdAccessor<PricingDataBean> rowIdAccessor;
	private DataFilteringHandler filter;

	PricingDataAccessor() {
		enableDataManagement();
	}
	private void enableDataManagement() {
		if (dataProvider == null) {
			dataList = GlazedLists.threadSafeList((GlazedLists.eventList(PricingDataBeanGenerator.getData(100))));
			filter = new DataFilteringHandler(dataList);

			sortedRows = new SortedList<PricingDataBean>((filter.getFilteredList()), null);
			try {
				columnAccessor = new ReflectiveColumnAccessor<PricingDataBean>(ColumnHeaders.getProperties());
				dataProvider = new ListDataProvider<PricingDataBean>(sortedRows, columnAccessor);
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage(), e);
			}

			rowIdAccessor = new IRowIdAccessor<PricingDataBean>() {

				public Serializable getRowId(PricingDataBean rowObject) {
					return rowObject.getIsin();
				}
			};

		}
	}

	public EventList<PricingDataBean> getBaseEventList() {
		return dataList;
	}

	public IColumnAccessor<PricingDataBean> getColumnAccessor() {
		return columnAccessor;
	}

	public SortedList<PricingDataBean> getSortedRows() {
		return sortedRows;
	}

	public ListDataProvider<PricingDataBean> getDataProvider() {
		return dataProvider;
	}
	
	public IRowIdAccessor<PricingDataBean> getRowIdAccessor() {
		return rowIdAccessor;
	}
	
	public void filter(int modelColumnIndex, Object valueToMatch, IClientAreaProvider client) {
		filter.filter(modelColumnIndex, valueToMatch, client);	
	}
	
	public void removeFilter(IClientAreaProvider client) {
		filter.removeFilter(client);
	}
}