package net.sourceforge.nattable.example.pricing;

import java.util.Random;

import ca.odell.glazedlists.EventList;

public class PriceUpdaterRunnable<R> implements Runnable {
		private static final int MIN_BURST_SLEEP_DURATION = 500;
		private final EventList<R> eventList;
		private Random dice = new Random();
		private final RowObjectUpdater<R> updater;
		private boolean stop = false;
		private long burstCounter;
		public final Object lock = new Object();

		PriceUpdaterRunnable(EventList<R> eventList, RowObjectUpdater<R> updater) {
			this.eventList = eventList;
			this.updater = updater;
		}

		public void stop() {
			stop = true;
		}
		
		public void reset() {
			stop = false;
		}

		public void run() {
			while (!stop) {
				waitIfNoRowsPresent();
				int rowCount = 0;
				rowCount = eventList.size();
				int index = dice.nextInt(rowCount);
				final R item = eventList.get(index);
				updater.updateRow(item);
				eventList.set(index, item);
				try {
					int maxSleep = Math.max(0, (int) ((1.0d / rowCount) * 20000d));
					if (maxSleep > 0) {
						Thread.sleep(dice.nextInt(maxSleep));
					}
					if (++burstCounter % 37 == 0) { // Add 'burstiness' to the
						// simulation, more like a
						// real market
						final int sleepDuration = MIN_BURST_SLEEP_DURATION + dice.nextInt(1000);
						Thread.sleep(sleepDuration);
						burstCounter = 0;
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		private void waitIfNoRowsPresent() {
			boolean isEmpty = false;
			eventList.getReadWriteLock().readLock().lock();
			try {
				isEmpty = eventList.isEmpty();
			} finally {
				eventList.getReadWriteLock().readLock().unlock();
			}
			if (isEmpty) {
				synchronized (lock) {
					try {
						System.out.println("PriceUpdaterRunnable.run() Waiting until data present again...");
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}