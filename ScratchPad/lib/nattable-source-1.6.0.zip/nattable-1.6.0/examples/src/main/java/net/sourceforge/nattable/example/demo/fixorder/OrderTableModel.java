package net.sourceforge.nattable.example.demo.fixorder;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.config.DefaultBodyConfig;
import net.sourceforge.nattable.config.DefaultColumnHeaderConfig;
import net.sourceforge.nattable.config.DefaultRowHeaderConfig;
import net.sourceforge.nattable.config.SizeConfig;
import net.sourceforge.nattable.data.IColumnAccessor;
import net.sourceforge.nattable.data.IColumnHeaderLabelProvider;
import net.sourceforge.nattable.data.ListDataProvider;
import net.sourceforge.nattable.editor.ICellEditor;
import net.sourceforge.nattable.editor.TextCellEditor;
import net.sourceforge.nattable.model.DefaultNatTableModel;
import net.sourceforge.nattable.painter.cell.HeaderCellPainter;
import net.sourceforge.nattable.painter.cell.ICellPainter;
import net.sourceforge.nattable.renderer.AbstractCellRenderer;
import net.sourceforge.nattable.renderer.AbstractColumnHeaderRenderer;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;
import net.sourceforge.nattable.typeconfig.style.AlternateRowColoringStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DefaultStyleConfig;
import net.sourceforge.nattable.typeconfig.style.DisplayModeEnum;
import net.sourceforge.nattable.typeconfig.style.IStyleConfig;
import net.sourceforge.nattable.typeconfig.style.OverrideStyleConfig;
import net.sourceforge.nattable.typeconfig.style.StyleConfigRegistry;
import net.sourceforge.nattable.util.GUIHelper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;

/**
 * Author : Andy Tsoi<br>
 * Created Date : 2007�~10��17��<br>
 */
public class OrderTableModel extends DefaultNatTableModel {
	org.eclipse.swt.graphics.Image image = new org.eclipse.swt.graphics.Image(Display.getDefault(), OrderTableModel.class.getClassLoader().getResourceAsStream("icon.gif"));
	List<Order> orderList = new ArrayList<Order>();
	final ListDataProvider<Order> dataProvider = new ListDataProvider<Order>(orderList, new IColumnAccessor<Order>() {

		public int getColumnCount() {
			return FixOrderEnum.values().length + random;
		}

		public Object getColumnValue(Order rowObj, int col) {
			FixOrderEnum columnEnum = FixOrderEnum.getColumn(col);
			if (columnEnum != null)
				switch (columnEnum) {
				case ClOrdID:
					return rowObj.getClOrdID();
				case HandlInst:
					return rowObj.getHandlInst();
				case Symbol:
					return rowObj.getSymbol();
				case Side:
					return Character.valueOf(rowObj.getSide());
				case OrdType:
					return Character.valueOf(rowObj.getOrdType());
				case OrderQty:
					return Long.valueOf(rowObj.getOrderQty());
				}

			return null;
		}
	});
	int random = 0;

	public OrderTableModel() {
		// column configuration
		final DefaultColumnHeaderConfig columnHeaderConfig = new DefaultColumnHeaderConfig(new IColumnHeaderLabelProvider() {

			public String getColumnHeaderLabel(int col) {
				return null;
			}
		});
		columnHeaderConfig.setCellRenderer(columnHeaderRenderer);
		columnHeaderConfig.setColumnHeaderRowCount(1);
		columnHeaderConfig.setColumnHeaderRowHeightConfig(new SizeConfig(25));
		setColumnHeaderConfig(columnHeaderConfig);

		final DefaultRowHeaderConfig rowHeaderConfig = new DefaultRowHeaderConfig();
		rowHeaderConfig.setRowHeaderColumnCount(1);
		rowHeaderConfig.setRowHeaderColumnWidthConfig(new SizeConfig(20));
		rowHeaderConfig.setCellRenderer(new AbstractCellRenderer() {
			HeaderCellPainter rowHeaderCellPainter = new HeaderCellPainter(SWT.CENTER | SWT.FLAT);

			public String getDisplayText(int row, int col) {
				return (row + 1) + "";
			}

			public Object getValue(int row, int col) {
				return null;
			}

			@Override
			public ICellPainter getCellPainter(int row, int col) {
				return rowHeaderCellPainter;
			}

			@Override
			public ICellEditor getCellEditor(int row, int col) {
				return null;
			}

			@Override
			public boolean isEditable(int row, int col) {
				return false;
			}
		});
		setRowHeaderConfig(rowHeaderConfig);

		// body configuration
		ContentConfigRegistry contentConfigRegistry = new ContentConfigRegistry();
		TextCellEditor textCellEditor = new TextCellEditor();
		contentConfigRegistry.registerDefaultCellEditor(textCellEditor);
		
		StyleConfigRegistry styleConfigRegistry = new StyleConfigRegistry();
		Color alternativeColor = new Color(Display.getDefault(), 218, 227, 215);
		styleConfigRegistry.registerDefaultStyleConfig(DisplayModeEnum.NORMAL.toString(), new AlternateRowColoringStyleConfig(alternativeColor, GUIHelper.COLOR_WHITE));
		Color selectColor = new Color(Display.getDefault(), 149, 188, 236);
		styleConfigRegistry.registerDefaultStyleConfig(DisplayModeEnum.SELECT.toString(), new DefaultStyleConfig(selectColor, null, null, null));
		
		final DefaultBodyConfig bodyConfig = new DefaultBodyConfig(dataProvider, contentConfigRegistry, styleConfigRegistry);
		bodyConfig.setRowHeightConfig(new SizeConfig(20));
		bodyConfig.setColumnWidthConfig(new SizeConfig(100));
		
		setBodyConfig(bodyConfig);
	}

	public List<Order> getOrderList() {
		return orderList;
	}

	public int getRandom() {
		return random;
	}

	public void setRandom(int random) {
		this.random = random;
	}

	// Column header //////////////////////////////////////////////////////////

	AbstractColumnHeaderRenderer columnHeaderRenderer = new AbstractColumnHeaderRenderer() {
		HeaderCellPainter cellPainter = new HeaderCellPainter(SWT.CENTER) {
			Color color2 = new Color(Display.getDefault(), 132, 132, 255);

			@Override
			protected Color getGradientForeground() {
				return GUIHelper.COLOR_BLUE;
			}

			@Override
			protected Color getGradientBackground() {
				return color2;
			}
		};

		@Override
		public IStyleConfig getStyleConfig(String displayMode, int row, int col) {
			switch (DisplayModeEnum.valueOf(displayMode)) {
			case NORMAL:
				return new OverrideStyleConfig(super.getStyleConfig(displayMode, row, col)) {

					@Override
					public Color getForegroundColor(int row, int col) {
						return GUIHelper.COLOR_WHITE;
					}
					
				};
			}
			return super.getStyleConfig(displayMode, row, col);
		}

		public String getDisplayText(int row, int col) {
			FixOrderEnum columnEnum = FixOrderEnum.getColumn(col);

			return columnEnum.getName();
		}

		@Override
		public ICellPainter getCellPainter(int row, int col) {
			return cellPainter;
		}

	};

	/*
	 * @Override public boolean isAllBodyRowsSameHeight() { return true; }
	 */

	public int getBodyColumnCount() {
		return FixOrderEnum.values().length + random;
	}

	public int getInitialBodyColumnWidth(int col) {
		FixOrderEnum columnEnum = FixOrderEnum.getColumn(col);
		if (columnEnum != null)
			switch (columnEnum) {
			case ClOrdID:
				return 180;
			case HandlInst:
				return 100;
			case Symbol:
				return 100;
			case Side:
				return 50;
			case OrdType:
				return 80;
			case OrderQty:
				return 100;
			}
		return 100;

	}
}
