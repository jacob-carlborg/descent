package net.sourceforge.nattable.example.pricing;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.IRowObjectCreator;
import net.sourceforge.nattable.data.pricing.ColumnHeaders;
import net.sourceforge.nattable.data.pricing.PricingDataBean;
import net.sourceforge.nattable.extension.handler.ITickableHandler;
import net.sourceforge.nattable.model.SelectionModel;
import net.sourceforge.nattable.support.BulkUpdateResponse;
import net.sourceforge.nattable.support.BulkUpdateTypeEnum;
import net.sourceforge.nattable.support.ColumnTransformSupport;
import net.sourceforge.nattable.support.IClientAreaProvider;

import org.eclipse.swt.events.KeyEvent;

public class TickableUpdateHandler implements ITickableHandler {

	private final Comparator<PricingDataBean> comparator;
	private final RowObjectCreator updateHandler;
	private SelectionModel selectionModel;
	private ColumnTransformSupport columnReorderSupport;
	private DataUpdateHelper<PricingDataBean> updateHelper;
	private List<PricingDataBean> data;
	private IClientAreaProvider clientAreaProvider;

	public TickableUpdateHandler(SelectionModel selectionModel, ColumnTransformSupport columnReorderSupport, DataUpdateHelper<PricingDataBean> helper, List<PricingDataBean> data, IClientAreaProvider clientAreaProvider) {
		updateHandler = new RowObjectCreator();
		comparator = new ComparatorImpl();
		this.selectionModel = selectionModel;
		this.columnReorderSupport = columnReorderSupport;
		this.updateHelper = helper;
		this.data = data;
		this.clientAreaProvider = clientAreaProvider;
	}

	private boolean isSelectionTickable() {
		int[] selectedColumns = selectionModel.getSelectedColumns();

		if (selectedColumns.length == 1) {
			int viewColumnIndex = selectedColumns[0];
			int modelColumnIndex = columnReorderSupport.reorderedToModelBodyColumn(viewColumnIndex);

			Class<?> type = ColumnHeaders.values()[modelColumnIndex].getType();

			return Number.class.isAssignableFrom(type);
		}

		return false;
	}

	public boolean isQuickEditEvent(KeyEvent event) {
		if (isSelectionTickable()) {
			return Character.isDigit(event.character) || event.character == '.';
		}

		return false;
	}

	public boolean isTickDownEvent(KeyEvent event) {
		if (isSelectionTickable()) {
			return event.character == '-';
		}

		return false;
	}

	public boolean isTickUpEvent(KeyEvent event) {
		if (isSelectionTickable()) {
			return event.character == '+';
		}

		return false;
	}

	public boolean applyBulkUpdate(BulkUpdateResponse response, Serializable[] rowIds, int fieldIndex) {
		ColumnHeaders columnHeader = ColumnHeaders.values()[fieldIndex];

		Map<Serializable, Number> oldValues = null;

		if (response.getType() != BulkUpdateTypeEnum.SET) {
			oldValues = new HashMap<Serializable, Number>();

			HashSet<Serializable> ids = new HashSet<Serializable>();

			for (Serializable rowId : rowIds) {
				ids.add(rowId);
			}

			Field field;
			try {
				field = PricingDataBean.class.getDeclaredField(columnHeader.getProperty());
				field.setAccessible(true);
				for (PricingDataBean pxBean : data) {
					if (ids.remove(pxBean.getIsin())) {
						oldValues.put(pxBean.getIsin(), (Number) field.get(pxBean));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		for (Serializable rowId : rowIds) {
			Object newValue = response.getNewValue();
			Class<?> type = columnHeader.getType();

			if (type == String.class) {
				newValue = newValue.toString();
			} else if (type == Double.class) {
				Double d = Double.valueOf(newValue.toString());
				newValue = d;

				if (response.getType() != BulkUpdateTypeEnum.SET) {
					Number oldNumber = oldValues.get(rowId);

					if (oldNumber == null)
						oldNumber = Double.valueOf(0);

					if (response.getType() == BulkUpdateTypeEnum.INCREASE) {
						newValue = Double.valueOf(d.doubleValue() + oldNumber.doubleValue());
					} else if (response.getType() == BulkUpdateTypeEnum.DECREASE) {
						newValue = Double.valueOf(oldNumber.doubleValue() - d.doubleValue());
					}
				}
			}

			List<Object> values = new ArrayList<Object>(1);
			values.add(newValue);
			List<String> colProperties = new ArrayList<String>(1);
			colProperties.add(columnHeader.getProperty());
			updateHelper.getBulkUpdate().addUpdates(rowId, values, colProperties, updateHelper);
		}

		updateHelper.getBulkUpdate().commitUpdates((List<PricingDataBean>)data, new DataUpdateHelper<PricingDataBean>(null, null, comparator, updateHandler, null, null, null));

		clientAreaProvider.updateResize();

		return true;
	}

	static class ComparatorImpl implements Comparator<PricingDataBean> {
		public int compare(PricingDataBean o1, PricingDataBean o2) {
			return o1.getIsin().compareTo(o2.getIsin());
		}
	}

	static class RowObjectCreator implements IRowObjectCreator<PricingDataBean> {

		public PricingDataBean createRowObject(Serializable rowObjectId) {
			PricingDataBean bean = new PricingDataBean();
			bean.setIsin(rowObjectId.toString());

			return bean;
		}

		public Class<PricingDataBean> getRowClass() {
			return PricingDataBean.class;
		}
	}
}
