package net.sourceforge.nattable.data.generator;

import java.util.Random;

/**
 * Concrete implementations must have a default constructor (i.e. with zero parameters)
 */
public interface IValueGenerator {
	
	Object newValue(Random random);
}
