package net.sourceforge.nattable.data.pricing.valuegenerator;

import net.sourceforge.nattable.data.valuegenerator.AbstractListValueGenerator;

public class BidAskTypeValueGenerator extends AbstractListValueGenerator<String> {

	public BidAskTypeValueGenerator() {
		super(new String[] {
				"Bid-BA",
				null
		});
	}

}
