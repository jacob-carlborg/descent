package net.sourceforge.nattable.data.valuegenerator;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import net.sourceforge.nattable.data.generator.IValueGenerator;

public class ListValueGenerator<T> implements IValueGenerator
{
	private final List<T> values;
	private final int nullLoadFactor;

	public ListValueGenerator(int nullLoadFactor, T... values) {
		
		this.nullLoadFactor = nullLoadFactor;
		this.values = Arrays.asList(values);
	}
	
	public Object newValue(Random random) {
		
		final int choice = random.nextInt(values.size() + nullLoadFactor);
		return choice >= values.size() ? null : values.get(choice);
	}

}
