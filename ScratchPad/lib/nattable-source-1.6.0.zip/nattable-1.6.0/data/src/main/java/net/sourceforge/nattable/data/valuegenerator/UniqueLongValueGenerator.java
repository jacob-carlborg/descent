package net.sourceforge.nattable.data.valuegenerator;

import java.util.Random;

import net.sourceforge.nattable.data.generator.IValueGenerator;

public class UniqueLongValueGenerator implements IValueGenerator {

	private static long value = 0;
	
	public Object newValue(Random random) {
		return Long.valueOf(value++);
	}

}
