package net.sourceforge.nattable.data.valuegenerator;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import net.sourceforge.nattable.data.generator.IValueGenerator;

public abstract class AbstractListValueGenerator<T> implements IValueGenerator
{
	private final List<T> listOfValues;

	public AbstractListValueGenerator(List<T> listOfValues) {
		
		this.listOfValues = Collections.unmodifiableList(listOfValues);
	}

	public AbstractListValueGenerator(T... values) {
		
		this(Arrays.asList(values));
	}
	
	public Object newValue(Random random) {
		
		return listOfValues.get(random.nextInt(listOfValues.size()));
	}

	protected static <V> String[] toStringArray(V... values) {
		
		String[] retStrings = new String[values.length];
		for (int i=0; i < values.length; i++) {
			retStrings[i] = String.valueOf(values[i]);
		}
		return retStrings;
	}
}
