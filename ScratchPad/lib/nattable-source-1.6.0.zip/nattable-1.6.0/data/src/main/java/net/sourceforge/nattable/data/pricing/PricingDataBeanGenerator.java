package net.sourceforge.nattable.data.pricing;

import java.util.ArrayList;
import java.util.List;

import net.sourceforge.nattable.data.generator.DataGenerator;
import net.sourceforge.nattable.data.generator.GeneratorException;

public class PricingDataBeanGenerator {

	private static DataGenerator<PricingDataBean> beanGenerator = new DataGenerator<PricingDataBean>();
	
	public static List<PricingDataBean> getData(int num) {
		List<PricingDataBean> beans = new ArrayList<PricingDataBean>();
		
		try {
			for (int i = 0; i < num; i++) {
				beans.add(beanGenerator.generate(PricingDataBean.class));
				if ((i + 1) % 1000 == 0) {
					System.out.println("Generated " + (i + 1) + " rows");
				}
			}
		} catch (GeneratorException e) {
			throw new RuntimeException(e);
		}
		
		return beans;
	}
	
}
