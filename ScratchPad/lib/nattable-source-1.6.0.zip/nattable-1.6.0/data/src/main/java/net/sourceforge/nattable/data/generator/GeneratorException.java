package net.sourceforge.nattable.data.generator;

import java.lang.reflect.InvocationTargetException;

public class GeneratorException extends InvocationTargetException {
	
	private static final long serialVersionUID = 1L;

	public GeneratorException(Exception sourceException) {
		super(sourceException);
	}
}
