package net.sourceforge.nattable.data.pricing;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;

import net.sourceforge.nattable.data.DataUpdateHelper;
import net.sourceforge.nattable.data.DefaultBulkUpdateSupport;
import net.sourceforge.nattable.data.IBeanConfigTypeResolver;
import net.sourceforge.nattable.data.IColumnPropertyProvider;
import net.sourceforge.nattable.data.IRowIDPropertyResolver;
import net.sourceforge.nattable.data.IRowObjectCreator;
import net.sourceforge.nattable.data.ReflectiveNumericPropertyInstanceCreator;
import net.sourceforge.nattable.typeconfig.content.ContentConfigRegistry;

public class DataUpdateHelperCreator {
	public static DataUpdateHelper<PricingDataBean> getUpdateHelper(ContentConfigRegistry registry) {
		return new DataUpdateHelper<PricingDataBean>(new DefaultBulkUpdateSupport<PricingDataBean>(registry), new IColumnPropertyProvider() {
			public String getPropertyName(int col) {
				return ColumnHeaders.getProperties()[col];
			}

			public Class<?> getPropertyType(String propertyName) {
				return ColumnHeaders.values()[ColumnHeaders.getPropertyMap().get(propertyName).intValue()].getType();
			}

		}, new Comparator<PricingDataBean>() {
			public int compare(PricingDataBean o1, PricingDataBean o2) {
				return o1.getIsin().compareTo(o2.getIsin());
			}
		}, new IRowObjectCreator<PricingDataBean>() {

			public PricingDataBean createRowObject(Serializable rowObjectId) {
				PricingDataBean bean = new PricingDataBean();
				bean.setIsin((String) rowObjectId);
				return bean;
			}

			public Class<PricingDataBean> getRowClass() {
				return PricingDataBean.class;
			}

		}, new IBeanConfigTypeResolver<PricingDataBean>() {

			public String getConfigType(PricingDataBean rowObject, String fieldName) {
				return null;
			}

		}, new ReflectiveNumericPropertyInstanceCreator()
		, new IRowIDPropertyResolver() {

			public Serializable resolveRowIdProperty(Map<String, Object> propertyToValue) {
				return propertyToValue.containsKey("isin") ? (Serializable)propertyToValue.get("isin") : new Double(Math.random());
			}
			
		});
	}
}
