package net.sourceforge.nattable.data.pricing.valuegenerator;

import net.sourceforge.nattable.data.valuegenerator.AbstractListValueGenerator;

public class ErrorSeverityValueGenerator extends AbstractListValueGenerator<Integer> {
	
	public ErrorSeverityValueGenerator() {
		super(new Integer[] {
				Integer.valueOf(0),
				Integer.valueOf(0),
				Integer.valueOf(0),
				Integer.valueOf(0),
				Integer.valueOf(0),
				Integer.valueOf(0),
				Integer.valueOf(0),
				Integer.valueOf(1),
				Integer.valueOf(2),
				}
		);
	}

}
